==============================================================================
README for HOMEWORK #4
==============================================================================
AUTHORS:
- Alexander Lokhanov
- Patrik De Quevedo

COURSE:
COP3402 - Systems Security, Spring 2024
Instructor: Montagne
Due Date: April 7, 2024

To use this code and compile it, use "gcc hw4compiler.c"
Once it is compiled, use "./a.out " followed by a file name (must be .txt!)
Output will be displayed on screen as well as in outParse.txt in the same directory.

Objective:
In this assignment, you must extend the functionality of Assignment 3 (HW3) to include the
additional grammatical constructs highlighted in yellow in the grammar on Appendix B.

==============================================================================