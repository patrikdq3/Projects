#!/usr/bin/env bash
set -euo pipefail

deployment_environment="${1:-}"

case "$deployment_environment" in
  dev)
    workflow=.github/workflows/p2bp-cf-worker-deploy-dev.yml
    job=deploy-dev
    event=workflow_run
    ;;
  staging)
    workflow=.github/workflows/p2bp-cf-worker-deploy-staging.yml
    job=deploy-staging
    event=workflow_run
    ;;
  production)
    workflow=.github/workflows/p2bp-cf-worker-deploy-production.yml
    job=deploy-production
    event=workflow_dispatch
    ;;
  *)
    echo "Usage: $0 <dev|staging|production>" >&2
    exit 2
    ;;
esac

secret_arguments=(
  -s CLOUDFLARE_WORKER_DEPLOYMENT_TOKEN
)

while IFS= read -r secret_name; do
  secret_arguments+=(-s "$secret_name")
done < <(
  cd apps/p2bp-cf-worker
  bun -e '
    import config from "./wrangler.jsonc";
    const environment = process.argv[1];
    const selected = environment === "production" ? config : config.env[environment];
    for (const name of selected.secrets.required) console.log(name);
  ' "$deployment_environment"
)

act_arguments=(
  "$event"
  -W "$workflow"
  -j "$job"
  "${secret_arguments[@]}"
)

if [[ "$event" == workflow_run ]]; then
  act_arguments+=(
    -e tools/act/workflow-run-success.json
  )
fi

act "${act_arguments[@]}"
