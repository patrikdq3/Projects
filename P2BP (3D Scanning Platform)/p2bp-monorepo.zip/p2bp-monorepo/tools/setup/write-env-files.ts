/**
 * Creates the local `.env` files each app needs, if they do not exist yet.
 *
 * Run through `bash tools/setup/setup.sh --with-env` (generation is opt-in, since
 * an env manager may already supply these values), or directly with
 * `bun tools/setup/write-env-files.ts`. Existing files are never touched, so this
 * is safe to re-run.
 *
 * The Worker's key list is read straight out of `wrangler.jsonc` so it cannot
 * drift from the secrets the Worker actually declares as required.
 */

import { randomBytes } from 'node:crypto';
import { existsSync } from 'node:fs';
import { writeFile } from 'node:fs/promises';
import { dirname, join, relative } from 'node:path';
import { fileURLToPath } from 'node:url';

import wranglerConfig from '../../apps/p2bp-cf-worker/wrangler.jsonc';

type WranglerEnvironment = { secrets?: { required?: string[] } };
type WranglerConfig = WranglerEnvironment & {
  env?: Record<string, WranglerEnvironment>;
};

const repoRoot = join(dirname(fileURLToPath(import.meta.url)), '..', '..');

/** Values that are the same on every machine, so setup can fill them in. */
const workerDefaults: Record<string, string> = {
  BASE_URL: 'http://localhost:8787',
  BETTER_AUTH_SECRET: randomBytes(32).toString('base64url'),
};

/** Required by `require_env()` in apps/p2bp-postprocessing/src. */
const postprocessingKeys = [
  'CLOUDFLARE_ACCOUNT_ID',
  'CLOUDFLARE_QUEUE_ID',
  'CLOUDFLARE_POSTPROCESSING_API_TOKEN',
  'AWS_REGION',
  'R2_ACCESS_KEY_ID',
  'R2_SECRET_ACCESS_KEY',
  'R2_BUCKET',
];

function workerKeys(): string[] {
  const config = wranglerConfig as WranglerConfig;
  const required =
    config.env?.dev?.secrets?.required ?? config.secrets?.required;

  if (!required?.length) {
    throw new Error(
      'No required secrets found in apps/p2bp-cf-worker/wrangler.jsonc',
    );
  }

  return required;
}

/** "A", "A and B", "A, B and C" - so the note reads naturally at any length. */
function formatList(items: string[]): string {
  if (items.length < 2) {
    return items[0] ?? '';
  }

  return `${items.slice(0, -1).join(', ')} and ${items[items.length - 1]}`;
}

/**
 * Describes which keys setup pre-filled, derived from `defaults` so adding or
 * removing one needs no edit here. Falls back to the bare sentence when a file
 * has no defaults at all.
 */
function prefilledNote(
  keys: string[],
  defaults: Record<string, string>,
): string {
  const sentence = 'Keys mirror the required secrets in wrangler.jsonc';
  const prefilled = keys.filter((key) => key in defaults);

  if (prefilled.length === 0) {
    return `${sentence}.`;
  }

  return `${sentence}; ${formatList(prefilled)} ${
    prefilled.length === 1 ? 'was' : 'were'
  } filled in for you.`;
}

function render(
  header: string[],
  keys: string[],
  defaults: Record<string, string> = {},
): string {
  const lines = [
    ...header.map((line) => `# ${line}`),
    '',
    ...keys.map((key) => `${key}=${defaults[key] ?? ''}`),
    '',
  ];

  return lines.join('\n');
}

async function writeIfMissing(path: string, contents: string): Promise<void> {
  const label = relative(repoRoot, path);

  if (existsSync(path)) {
    console.log(`    kept    ${label} (already exists)`);
    return;
  }

  await writeFile(path, contents, { mode: 0o600 });
  console.log(`    created ${label}`);
}

await writeIfMissing(
  join(repoRoot, 'apps/p2bp-cf-worker/.env'),
  render(
    [
      'Local development values for the Cloudflare Worker.',
      prefilledNote(workerKeys(), workerDefaults),
      'Git-ignored - never commit this file.',
    ],
    workerKeys(),
    workerDefaults,
  ),
);

await writeIfMissing(
  join(repoRoot, 'apps/p2bp-postprocessing/.env'),
  render(
    [
      'Local values for the EC2 queue worker.',
      "CLOUDFLARE_QUEUE_ID is the queue's 32-character id, not its name.",
      'Optional tuning knobs are documented in apps/p2bp-postprocessing/README.md.',
      'Git-ignored - never commit this file.',
    ],
    postprocessingKeys,
  ),
);
