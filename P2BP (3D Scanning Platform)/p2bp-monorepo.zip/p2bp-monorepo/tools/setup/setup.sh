#!/usr/bin/env bash
#
# One-command setup for the p2bp monorepo.
#
#   bash tools/setup/setup.sh              # set up everything this machine supports
#   bash tools/setup/setup.sh --with-env   # also write starter .env files
#   bash tools/setup/setup.sh --check      # report tool status, change nothing
#
# The script is idempotent: re-run it after pulling, and it will only do the
# work that is still missing. It never overwrites an existing .env file.

set -euo pipefail

repo_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "$repo_root"

do_python=1
do_ios=1
do_hooks=1
do_env=0
check_only=0

notes=()

usage() {
	cat <<'EOF'
Usage: bash tools/setup/setup.sh [options]

Options:
  --with-env      Write starter .env files for any app that has none.
                  Off by default: an env manager such as Doppler supplies the
                  same values, and a local .env silently fills any gap it leaves.
  --check         Report toolchain status and exit without changing anything
  --skip-python   Skip the Python queue worker (apps/p2bp-postprocessing)
  --skip-ios      Skip the iOS app tooling (apps/scanner-consolidator)
  --skip-hooks    Skip installing the pre-commit git hooks
  -h, --help      Show this message
EOF
}

while [[ $# -gt 0 ]]; do
	case "$1" in
	--with-env) do_env=1 ;;
	--check) check_only=1 ;;
	--skip-python) do_python=0 ;;
	--skip-ios) do_ios=0 ;;
	--skip-hooks) do_hooks=0 ;;
	-h | --help)
		usage
		exit 0
		;;
	*)
		echo "error: unknown option '$1'" >&2
		usage >&2
		exit 2
		;;
	esac
	shift
done

step() { printf '\n==> %s\n' "$1"; }
info() { printf '    %s\n' "$1"; }
note() { notes+=("$1"); }

have() { command -v "$1" >/dev/null 2>&1; }

is_macos() { [[ "$(uname -s)" == "Darwin" ]]; }

# report_path <path> <message when present> <message when absent>
report_path() {
	if [[ -e "$1" ]]; then
		info "$2"
	else
		info "$3"
	fi
}

# Version pinned in mise.toml, e.g. pinned_version node -> 24.14.0
pinned_version() {
	awk -F'"' -v tool="$1" '$0 ~ "^"tool" *= *\"" { print $2; exit }' mise.toml
}

# Always run Bun through mise when mise is available so the pinned version wins
# over whatever else happens to be on PATH.
bun_run() {
	if have mise; then
		mise exec -- bun "$@"
	else
		bun "$@"
	fi
}

report_tool() {
	local name="$1" purpose="$2" version=""

	if ! have "$name"; then
		printf '    %-12s %-10s %s\n' "$name" "MISSING" "$purpose"
		return
	fi

	# xcodebuild wants -version; everything else here takes --version.
	version="$({ "$name" --version 2>/dev/null || "$name" -version 2>/dev/null; } |
		grep -oE '[0-9]+\.[0-9]+(\.[0-9]+)?' | head -n 1)"
	printf '    %-12s %-10s %s\n' "$name" "${version:-ok}" "$purpose"
}

run_check() {
	step "Toolchain status"
	report_tool mise "node + bun + SwiftLint/SwiftFormat (required)"
	report_tool bun "workspace + Cloudflare Worker"
	report_tool uv "Python queue worker"
	report_tool pre-commit "git hooks"
	report_tool xcodebuild "iOS app builds"

	step "Workspace status"
	report_path node_modules \
		"node_modules present" \
		"node_modules MISSING - run: bash tools/setup/setup.sh"
	report_path apps/p2bp-postprocessing/.venv \
		"apps/p2bp-postprocessing/.venv present" \
		"apps/p2bp-postprocessing/.venv MISSING"
	# Absent .env files are normal - an env manager may be supplying the values -
	# so these are reported without alarm.
	report_path apps/p2bp-cf-worker/.env \
		"apps/p2bp-cf-worker/.env present" \
		"apps/p2bp-cf-worker/.env absent (optional - see --with-env)"
	report_path apps/p2bp-postprocessing/.env \
		"apps/p2bp-postprocessing/.env present" \
		"apps/p2bp-postprocessing/.env absent (optional - see --with-env)"

	if have mise; then
		return 0
	fi
	printf '\n'
	info "mise is required. Install it with 'brew install mise' or"
	info "'curl https://mise.run | sh', then re-run this script."
	return 1
}

setup_toolchain() {
	step "Toolchain (node ${node_version:-?}, bun ${bun_version:-?})"

	if ! have mise; then
		info "mise not found - falling back to whatever node/bun are on PATH"
		note "Install mise so the pinned toolchain is used: brew install mise (or curl https://mise.run | sh)"
		if ! have bun; then
			echo "error: neither mise nor bun is installed; cannot continue." >&2
			echo "       Install mise (brew install mise) and re-run this script." >&2
			exit 1
		fi
		return
	fi

	mise trust --quiet "$repo_root/mise.toml" >/dev/null 2>&1 || true
	mise install
	info "installed: $(mise exec -- node --version) / bun $(mise exec -- bun --version)"

	if ! have bun || [[ "$(bun --version 2>/dev/null)" != "$bun_version" ]]; then
		note "Activate mise in your shell so 'bun' resolves to the pinned version: echo 'eval \"\$(mise activate zsh)\"' >> ~/.zshrc"
	fi
}

setup_workspace_dependencies() {
	step "Workspace dependencies (bun install)"
	bun_run install --frozen-lockfile
}

setup_python() {
	step "Python queue worker (apps/p2bp-postprocessing)"

	if ! have uv; then
		info "uv not found - skipping"
		note "Install uv to work on the Python queue worker: brew install uv (or curl -LsSf https://astral.sh/uv/install.sh | sh)"
		return
	fi

	bun_run x nx run p2bp-postprocessing:sync
}

setup_ios() {
	step "iOS app tooling (apps/scanner-consolidator)"

	if ! is_macos; then
		info "not macOS - skipping"
		return
	fi

	if ! have xcodebuild; then
		info "Xcode not found - skipping"
		note "Install Xcode from the App Store to build the iOS app, then re-run this script."
		return
	fi

	if ! have mise; then
		info "mise not found - skipping"
		note "Install mise for the pinned SwiftLint/SwiftFormat: brew install mise"
		return
	fi

	(cd apps/scanner-consolidator && mise install && bash ./scripts/check-tooling.sh)
	info "SwiftLint and SwiftFormat match apps/scanner-consolidator/mise.toml"
}

setup_hooks() {
	step "Git hooks (pre-commit)"

	if ! have pre-commit; then
		if have uv; then
			info "pre-commit not found - installing it with uv"
			uv tool install pre-commit || true
			hash -r
		fi
	fi

	if ! have pre-commit; then
		info "pre-commit not found - skipping"
		note "Install pre-commit to get the commit/push checks: brew install pre-commit (or uv tool install pre-commit)"
		return
	fi

	# pre-commit refuses to install while core.hooksPath is set. Whatever set it
	# may well depend on it, so this is left for the reader to sort out.
	local hooks_path
	hooks_path="$(git config --get core.hooksPath || true)"
	if [[ -n "$hooks_path" ]]; then
		info "core.hooksPath is set to '$hooks_path' - pre-commit will not install next to it"
		note "Git hooks are not installed. See the troubleshooting section in README.md, then: pre-commit install"
		return
	fi

	# .pre-commit-config.yaml sets default_install_hook_types, so this installs
	# both the pre-commit and pre-push hooks.
	if ! pre-commit install; then
		info "pre-commit install failed"
		note "Install the git hooks manually: pre-commit install"
	fi
}

setup_env_files() {
	step "Local env files"

	if [[ $do_env -eq 0 ]]; then
		info "not generated - pass --with-env if you are not using an env manager"
		return
	fi

	bun_run tools/setup/write-env-files.ts
}

print_summary() {
	step "Done"

	# ${notes[*]:-} rather than ${#notes[@]}: bash 3.2 (macOS /bin/bash) treats an
	# empty array as unset under `set -u`.
	if [[ -n "${notes[*]:-}" ]]; then
		info "Optional pieces you can still add:"
		for entry in "${notes[@]}"; do
			printf '      - %s\n' "$entry"
		done
		printf '\n'
	fi

	info "Next steps:"
	info "  1. Supply the Worker's secrets - your env manager, or"
	info "     'bash tools/setup/setup.sh --with-env' to write .env files to fill in"
	info "  2. bunx wrangler login"
	info "  3. bunx nx run p2bp-cf-worker:serve   # http://localhost:8787/api"
	printf '\n'
	info "Everything else: see README.md"
}

node_version="$(pinned_version node)"
bun_version="$(pinned_version bun)"

if [[ $check_only -eq 1 ]]; then
	if run_check; then
		exit 0
	fi
	exit 1
fi

setup_toolchain
setup_workspace_dependencies

if [[ $do_python -eq 1 ]]; then
	setup_python
fi

if [[ $do_ios -eq 1 ]]; then
	setup_ios
fi

if [[ $do_hooks -eq 1 ]]; then
	setup_hooks
fi

setup_env_files
print_summary
