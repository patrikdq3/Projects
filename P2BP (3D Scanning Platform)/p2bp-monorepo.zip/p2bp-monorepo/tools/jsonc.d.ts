/**
 * Bun imports .jsonc files directly, comments and all. TypeScript's
 * resolveJsonModule only covers .json, so it needs to be told these modules
 * exist. The value is deliberately `unknown` — importers state the shape they
 * expect, as tools/setup/write-env-files.ts does with WranglerConfig.
 */
declare module '*.jsonc' {
  const value: unknown;
  export default value;
}
