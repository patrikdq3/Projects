## Local development workflow

1. Install [`mise`](https://mise.jdx.dev) and `pre-commit`.
2. Run `mise install` to install the pinned [`SwiftLint`](mise.toml:11) and [`SwiftFormat`](mise.toml:12) versions declared in [`mise.toml`](mise.toml). mise fetches both as prebuilt release binaries, so no local Swift toolchain is needed.
3. Run `pre-commit install`. Because [`.pre-commit-config.yaml`](.pre-commit-config.yaml) sets `default_install_hook_types: [pre-commit, pre-push]`, this installs both Git hook types.
4. Keep the committed shared schemes under [`ScannerConsolidator.xcodeproj/xcshareddata/xcschemes/`](ScannerConsolidator.xcodeproj/xcshareddata/xcschemes/) tracked so clean machines can resolve the app, CI, and UI-test schemes without user-specific Xcode data.

Useful wrapper commands under [`scripts/`](scripts/):

- `bash ./scripts/check-tooling.sh` verifies that `mise` is available, that [`mise.toml`](mise.toml) declares both tools, and that [`SwiftLint`](mise.toml:11) and [`SwiftFormat`](mise.toml:12) actually run at the pinned versions.
- `bash ./scripts/run-swiftformat.sh .` runs [`SwiftFormat`](scripts/run-swiftformat.sh) through `mise exec`. In environments that set `CI=true` or `GITHUB_ACTIONS=true`, the same wrapper automatically switches to lint-only mode and, unless you pass another reporter, enables the GitHub Actions log reporter so CI can reuse the local hook definition.
- `bash ./scripts/run-swiftlint.sh --strict` runs [`SwiftLint`](scripts/run-swiftlint.sh) through `mise exec`. In GitHub Actions, it automatically enables the GitHub Actions reporter unless you explicitly pass another reporter.
- `bash ./scripts/run-swiftlint-analyze.sh --strict` runs a clean `build-for-testing`, captures the compiler log, and then runs [`SwiftLint analyze`](scripts/run-swiftlint-analyze.sh) so [`analyzer_rules`](.swiftlint.yml:61) are actually enforced.
- `bash ./scripts/run-xcodebuild.sh build`, `bash ./scripts/run-xcodebuild.sh test`, `bash ./scripts/run-xcodebuild.sh build-for-testing`, and `bash ./scripts/run-xcodebuild.sh test-without-building` run [`xcodebuild`](scripts/run-xcodebuild.sh) against the `ScannerConsolidator Dev` scheme by default. Set `SCHEME_NAME=ScannerConsolidatorCI` to exclude UI tests or `SCHEME_NAME=ScannerConsolidatorUILaunchTests` to run only the UI launch test scheme. The wrapper auto-selects a concrete available iOS Simulator destination from `xcodebuild -showdestinations -sdk iphonesimulator -destination 'generic/platform=iOS Simulator'`, and if Xcode exposes only the generic placeholder they fall back to `xcrun simctl list devices available` filtered to the simulator SDK version reported by Xcode. The wrapper disables code signing and writes logs plus `.xcresult` bundles under `build/`.
- `bash ./scripts/run-xcodebuild.sh test-without-building` expects an existing `build-for-testing` output in `build/DerivedData`, which the analyzer wrapper already produces for the `pre-push` stage.
- If you need to override simulator selection, set `IOS_SIMULATOR_ID` directly or provide `IOS_SIMULATOR_NAME` plus optional `IOS_SIMULATOR_OS` before invoking [`scripts/run-xcodebuild.sh`](scripts/run-xcodebuild.sh).

## Build settings and xcconfig layering

The app target builds in six configurations (`Debug`/`Release` × `Dev`/`Staging`/`Prod`), and its build settings are layered so a setting is declared exactly once:

- [`Config/Shared.xcconfig`](Config/Shared.xcconfig) holds every app-target setting that is identical across all environments and configurations (bridging header, Swift version, Info.plist keys, entitlements, …). **Add new shared settings here**, not in Xcode's Build Settings editor — a setting added there lands in one `project.pbxproj` configuration block and silently misses the other five (this is exactly how the LAZ decoder bridging header went missing from the Dev/Staging configurations during a rebase).
- [`Config/Dev.xcconfig`](Config/Dev.xcconfig), [`Config/Staging.xcconfig`](Config/Staging.xcconfig), and [`Config/Prod.xcconfig`](Config/Prod.xcconfig) each `#include "Shared.xcconfig"` and add only the per-environment values: `PRODUCT_BUNDLE_IDENTIFIER` and `CODE_SIGN_STYLE`. `Dev.xcconfig` additionally does an optional include of the git-ignored `Config/Signing.local.xcconfig` so developers on individual Apple accounts can override signing locally.
- The app target's `project.pbxproj` configuration blocks contain only what genuinely differs between `Debug` and `Release` within an environment (currently just `SWIFT_ACTIVE_COMPILATION_CONDITIONS` with the `ENV_DEV`/`ENV_STAGING`/`ENV_PROD` flags).

Because a value in a `project.pbxproj` configuration block overrides the xcconfig files, keep the app-target blocks minimal: if Xcode writes a setting back into the project file (editing anything under Signing & Capabilities or Build Settings tends to do this), move it into the appropriate xcconfig or delete it. [`scripts/check-code-signing.sh`](scripts/check-code-signing.sh) guards against the signing-related cases in CI. Test targets are intentionally not covered by the xcconfig files and keep plain automatic signing in the project file.

## `pre-commit` hooks

[`.pre-commit-config.yaml`](.pre-commit-config.yaml) installs both `pre-commit` and `pre-push` hooks. Unspecified hooks default to the `pre-commit` stage; analyzer and Xcode test hooks opt into `pre-push` explicitly.

- Standard hooks check trailing whitespace, final newlines, YAML validity, merge conflicts, and added files larger than 1000 KB.
- [`actionlint`](.pre-commit-config.yaml:16) validates tracked GitHub Actions workflow files.
- [`shellcheck`](.pre-commit-config.yaml:20) validates tracked shell wrappers under [`scripts/`](scripts/).
- `check-tooling` is marked `always_run: true`.
- [`SwiftFormat`](.pre-commit-config.yaml:37) runs `bash ./scripts/run-swiftformat.sh .` for Swift changes and [`.swiftformat`](.swiftformat) changes, and can rewrite files locally.
- [`SwiftLint`](.pre-commit-config.yaml:44) runs `bash ./scripts/run-swiftlint.sh --strict` for Swift changes and [`.swiftlint.yml`](.swiftlint.yml) changes.
- `SwiftLint Analyzer` runs `bash ./scripts/run-swiftlint-analyze.sh --strict` during the `pre-push` stage.
- [`xcodebuild-test`](.pre-commit-config.yaml:58) runs `bash ./scripts/run-xcodebuild.sh test-without-building` during `pre-push`, so it reuses the analyzer's preceding `build-for-testing` output instead of compiling the project again.

## CI automation

[`scanner-consolidator-ci.yml`](../../.github/workflows/scanner-consolidator-ci.yml) runs on pushes to `main`, every pull request, and manual dispatch. [`scanner-consolidator-ui-launch-tests.yml`](../../.github/workflows/scanner-consolidator-ui-launch-tests.yml) runs the UI launch test scheme on a weekly schedule and on manual dispatch. Restricting the main `push` trigger to `main` avoids duplicate CI runs when a same-repository branch also has an open pull request.

CI now splits cheap repository validation from expensive Apple-specific work so workflow and docs changes do not always pay for a full macOS build:

1. A cheap `ubuntu-latest` scope job classifies the diff and decides whether the PR needs repository checks only, Swift tooling checks, compile-only Apple validation, or full Xcode test execution.
2. A `repo-checks` job on `ubuntu-latest` installs `pre-commit`, restores a Linux `PRE_COMMIT_HOME` cache, and runs the `pre-commit` stage with `SKIP=check-tooling,swiftformat,swiftlint`. That keeps `actionlint`, `shellcheck`, YAML validation, whitespace checks, and project hygiene checks off the macOS runner.
3. Pull requests and ordinary pushes run repository checks against the changed diff with `--from-ref/--to-ref`; manual runs still fall back to `--all-files`.
4. The `apple-ci` job runs on `macos-26` only when Swift/Xcode-relevant files changed, selects pinned Xcode `26.3`, installs the pinned Swift tools with `jdx/mise-action` (which caches them), and uses the shared `ScannerConsolidatorCI` scheme so default UI launch tests are excluded from normal CI.
5. Swift tooling checks (`check-tooling`, [`SwiftFormat`](.pre-commit-config.yaml:37), and [`SwiftLint`](.pre-commit-config.yaml:44)) run only when Swift sources or Swift tooling configuration changed.
6. Pull requests default to `SCHEME_NAME=ScannerConsolidatorCI bash ./scripts/run-xcodebuild.sh build` for a cheaper compile-only check when app or project files change. Pushes to `main`, manual runs, and PRs that touch unit tests, the CI scheme, the project file, or the `xcodebuild` wrapper still use `build-for-testing` followed by `test-without-building` against that CI-only scheme.
7. The default UI launch tests now run only in [`scanner-consolidator-ui-launch-tests.yml`](../../.github/workflows/scanner-consolidator-ui-launch-tests.yml), which uses the shared `ScannerConsolidatorUILaunchTests` scheme on a weekly schedule and manual dispatch.
8. `main` remains the shared cache producer for `pre-commit` environments; pull requests restore from those caches but do not save their own branch-scoped copies.
9. CI uploads `build/ci-artifacts` and `build/result-bundles` only on failures, which cuts artifact time and storage without losing debugging data when a run breaks.

Unlike the local formatting hook, GitHub Actions sets `CI=true` and `GITHUB_ACTIONS=true`, so the shared [`SwiftFormat`](scripts/run-swiftformat.sh) wrapper automatically reports formatting issues instead of rewriting files in-place.

Because [`scripts/run-swiftlint-analyze.sh`](scripts/run-swiftlint-analyze.sh) already performs a clean `build-for-testing`, the local `pre-push` stage still avoids a separate redundant build and executes tests with [`test-without-building`](scripts/run-xcodebuild.sh) against the same derived data.
