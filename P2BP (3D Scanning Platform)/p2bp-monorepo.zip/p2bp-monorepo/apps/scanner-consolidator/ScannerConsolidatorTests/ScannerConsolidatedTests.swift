@MainActor
struct ScannerConsolidatedTests {}
