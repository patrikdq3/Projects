@testable import ScannerConsolidator
import Testing

struct MergedArtifactIdentityTests {
    @Test
    func parsesVersionedJobObjectKey() {
        let identity = MergedArtifactIdentity(
            objectKey: "organizations/org-123/projects/project-123/mesh-jobs/job-123/merged-point-cloud.laz"
        )

        #expect(identity == .job(
            organizationID: "org-123",
            projectID: "project-123",
            jobID: "job-123"
        ))
        #expect(identity?.jobID == "job-123")
    }

    @Test
    func parsesLegacyObjectKey() {
        let identity = MergedArtifactIdentity(
            objectKey: "organizations/org-123/projects/project-123/merged-point-cloud.laz"
        )

        #expect(identity == .legacy(
            organizationID: "org-123",
            projectID: "project-123"
        ))
        #expect(identity?.jobID == nil)
    }

    @Test
    func rejectsUnexpectedObjectKeyLayouts() {
        #expect(MergedArtifactIdentity(objectKey: "merged-point-cloud.laz") == nil)
        #expect(MergedArtifactIdentity(
            objectKey: "organizations/org-123/projects/project-123/other/job-123/merged-point-cloud.laz"
        ) == nil)
    }
}
