// swiftlint:disable:next unused_import
import CoreLocation
import SwiftUI

// MARK: - GeoCoordinate

nonisolated struct GeoCoordinate: Codable, Equatable, Hashable {
    // MARK: Lifecycle

    init(latitude: Double, longitude: Double) {
        self.latitude = latitude
        self.longitude = longitude
    }

    init(_ coordinate: CLLocationCoordinate2D) {
        self.latitude = coordinate.latitude
        self.longitude = coordinate.longitude
    }

    // MARK: Internal

    var latitude: Double
    var longitude: Double

    var clCoordinate: CLLocationCoordinate2D {
        CLLocationCoordinate2D(latitude: self.latitude, longitude: self.longitude)
    }
}

// MARK: - LocalPoint

/// A 2D point expressed in meters relative to the project boundary's
/// north-west bounding-box corner. `x` grows east, `y` grows south.
nonisolated struct LocalPoint: Codable, Equatable, Hashable {
    var xMeters: Double
    var yMeters: Double
}

// MARK: - ProjectBoundary

nonisolated struct ProjectBoundary: Codable, Equatable, Hashable {
    // MARK: Lifecycle

    init(vertices: [GeoCoordinate]) {
        self.vertices = vertices
    }

    /// Convenience initializer that builds a north-aligned rectangle of 4 vertices.
    /// Used by legacy call sites and tests that still think in width/height terms.
    init(center: GeoCoordinate, widthMeters: Double, heightMeters: Double) {
        let halfWidth = widthMeters / 2.0
        let halfHeight = heightMeters / 2.0
        self.vertices = [
            BoundaryGeometry.coordinate(from: center, movingEast: -halfWidth, movingNorth: halfHeight),
            BoundaryGeometry.coordinate(from: center, movingEast: halfWidth, movingNorth: halfHeight),
            BoundaryGeometry.coordinate(from: center, movingEast: halfWidth, movingNorth: -halfHeight),
            BoundaryGeometry.coordinate(from: center, movingEast: -halfWidth, movingNorth: -halfHeight),
        ]
    }

    // MARK: Internal

    var vertices: [GeoCoordinate]

    var center: GeoCoordinate {
        BoundaryGeometry.boundingBox(of: self.vertices).center
    }

    var widthMeters: Double {
        BoundaryGeometry.boundingBox(of: self.vertices).widthMeters
    }

    var heightMeters: Double {
        BoundaryGeometry.boundingBox(of: self.vertices).heightMeters
    }

    var areaSquareMeters: Double {
        BoundaryGeometry.polygonArea(of: self.vertices)
    }
}

// MARK: - ZoneFootprint

nonisolated struct ZoneFootprint: Codable, Equatable, Hashable {
    var points: [LocalPoint]

    var originXMeters: Double {
        self.points.map(\.xMeters).min() ?? 0
    }

    var originYMeters: Double {
        self.points.map(\.yMeters).min() ?? 0
    }

    var widthMeters: Double {
        let xs = self.points.map(\.xMeters)
        return (xs.max() ?? 0) - (xs.min() ?? 0)
    }

    var heightMeters: Double {
        let ys = self.points.map(\.yMeters)
        return (ys.max() ?? 0) - (ys.min() ?? 0)
    }

    var areaSquareMeters: Double {
        BoundaryGeometry.polygonArea(of: self.points)
    }
}

// MARK: - ZoneStatus

enum ZoneStatus: String, Codable, CaseIterable, Hashable, Identifiable {
    case notStarted
    case inProgress
    case complete

    // MARK: Internal

    var id: String {
        rawValue
    }

    var displayName: String {
        switch self {
        case .notStarted:
            "Not Started"
        case .inProgress:
            "In Progress"
        case .complete:
            "Complete"
        }
    }

    /// The color the specific zone cell should conform to depending on the zone status
    var color: Color {
        switch self {
        case .notStarted:
            Color("Warning")
        case .inProgress:
            Color("Primary")
        case .complete:
            Color("Success")
        }
    }
}

// MARK: - Zone

nonisolated struct Zone: Codable, Equatable, Hashable, Identifiable {
    var id: UUID
    var remoteID: String?
    var name: String
    var rowIndex: Int
    var columnIndex: Int
    var footprint: ZoneFootprint
    var scanProjectID: UUID?
    var scanState: ZoneStatus
    var scanStartedAt: Date?
    var scanCompletedAt: Date?

    var status: ZoneStatus {
        self.scanState
    }

    var hasLinkedScan: Bool {
        self.scanProjectID != nil
    }
}

// MARK: - Project

nonisolated struct Project: Codable, Equatable, Hashable, Identifiable {
    var id: UUID
    var name: String
    var createdAt: Date
    var boundary: ProjectBoundary
    var zones: [Zone]
    var remoteID: String?
    var remoteOrganizationID: String?
    var pendingRemoteOrganizationID: String?

    var owningRemoteOrganizationID: String? {
        self.remoteOrganizationID ?? self.pendingRemoteOrganizationID
    }

    var sortedZones: [Zone] {
        self.zones.sorted {
            if $0.rowIndex != $1.rowIndex {
                return $0.rowIndex < $1.rowIndex
            }
            return $0.columnIndex < $1.columnIndex
        }
    }

    var zoneCountSummary: [ZoneStatus: Int] {
        ZoneStatus.allCases.reduce(into: [:]) { partialResult, status in
            partialResult[status] = self.zones.count(where: { $0.status == status })
        }
    }
}

// MARK: - MapSelectionResult

nonisolated struct MapSelectionResult: Codable, Equatable, Hashable {
    var boundary: ProjectBoundary
}

// MARK: - ProjectLocationChoice

nonisolated enum ProjectLocationChoice: String, Identifiable {
    case currentLocation
    case address

    // MARK: Internal

    var id: String {
        rawValue
    }
}
