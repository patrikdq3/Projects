import Foundation
import SwiftUI

// MARK: - ProjectsAPIProject

nonisolated struct ProjectsAPIProject: Codable, Equatable, Hashable, Identifiable {
    // MARK: Internal

    let id: String
    let organizationID: String
    let name: String
    let description: String?
    let initialLat: Double
    let initialLong: Double
    let zoneSize: Int
    let createdAt: String
    let boundary: [ProjectsAPICoordinate]?

    // MARK: Private

    private enum CodingKeys: String, CodingKey {
        case id
        case organizationID = "organizationId"
        case name
        case description
        case initialLat
        case initialLong
        case zoneSize
        case createdAt
        case boundary
    }
}

// MARK: - ProjectsAPICoordinate

nonisolated struct ProjectsAPICoordinate: Codable, Equatable, Hashable {
    // MARK: Lifecycle

    init(latitude: Double, longitude: Double) {
        self.latitude = latitude
        self.longitude = longitude
    }

    init(coordinate: GeoCoordinate) {
        self.latitude = coordinate.latitude
        self.longitude = coordinate.longitude
    }

    // MARK: Internal

    let latitude: Double
    let longitude: Double

    var geoCoordinate: GeoCoordinate {
        GeoCoordinate(latitude: self.latitude, longitude: self.longitude)
    }
}

// MARK: - CreateProjectsAPIProjectRequest

nonisolated struct CreateProjectsAPIProjectRequest: Codable, Equatable, Hashable {
    let name: String
    let description: String?
    let initialLat: Double
    let initialLong: Double
    let zoneSize: Int
    let boundary: [ProjectsAPICoordinate]
}

// MARK: - UpdateProjectsAPIProjectRequest

/// Partial edit of a remote project: only non-nil fields are changed.
nonisolated struct UpdateProjectsAPIProjectRequest: Codable, Equatable, Hashable {
    var name: String?
    var description: String?
    var initialLat: Double?
    var initialLong: Double?
    var zoneSize: Int?
}

// MARK: - DefaultSuccessResponse

nonisolated struct DefaultSuccessResponse: Codable, Equatable, Hashable {
    let success: Bool
}

// MARK: - ProjectsAPIOrganization

nonisolated struct ProjectsAPIOrganization: Codable, Equatable, Hashable, Identifiable {
    let id: String
    let name: String
    let slug: String
    let logo: String?
    let createdAt: String
    let metadata: String?
}

// MARK: - ProjectsAPIOrganizationMember

nonisolated struct ProjectsAPIOrganizationMember: Codable, Equatable, Hashable, Identifiable {
    // MARK: Internal

    let id: String
    let userID: String
    let organizationID: String
    let role: String

    // MARK: Private

    private enum CodingKeys: String, CodingKey {
        case id
        case userID = "userId"
        case organizationID = "organizationId"
        case role
    }
}

// MARK: - SetActiveProjectsAPIOrganizationRequest

nonisolated struct SetActiveProjectsAPIOrganizationRequest: Codable, Equatable, Hashable {
    // MARK: Internal

    let organizationID: String?
    let organizationSlug: String?

    // MARK: Private

    private enum CodingKeys: String, CodingKey {
        case organizationID = "organizationId"
        case organizationSlug
    }
}

// MARK: - MeshJobType

nonisolated enum MeshJobType: String, Codable, Equatable, Hashable {
    case generate = "mesh.generate"
    case refine = "mesh.refine"
    case unknown

    // MARK: Lifecycle

    init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        self = try Self(rawValue: container.decode(String.self)) ?? .unknown
    }
}

// MARK: - MeshJobStatus

nonisolated enum MeshJobStatus: String, Codable, Equatable, Hashable {
    case queued
    case running
    case completed
    case failed
    case unknown

    // MARK: Lifecycle

    init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        self = try Self(rawValue: container.decode(String.self)) ?? .unknown
    }

    // MARK: Internal

    var isInFlight: Bool {
        self == .queued || self == .running
    }
}

// MARK: - MeshJob

nonisolated struct MeshJob: Codable, Equatable, Hashable, Identifiable {
    let id: String
    let type: MeshJobType
    let status: MeshJobStatus
    /// Opaque identity supplied by the API. Compare for equality only.
    let inputFingerprint: String
    let zoneScanObjectKeys: [String]
    let error: String?
    let createdAt: String
    let startedAt: String?
    let completedAt: String?
}

// MARK: - MeshJobsResponse

nonisolated struct MeshJobsResponse: Codable, Equatable, Hashable {
    let jobs: [MeshJob]
}

// MARK: - MeshJobResponse

nonisolated struct MeshJobResponse: Codable, Equatable, Hashable {
    let job: MeshJob
}

// MARK: - LaunchMeshJobResponse

nonisolated struct LaunchMeshJobResponse: Codable, Equatable, Hashable {
    let success: Bool
    let reused: Bool
    let job: MeshJob
}

// MARK: - MeshArtifactKind

nonisolated enum MeshArtifactKind: Equatable, Hashable {
    case fullLAZ
    case fullE57
    case previewLAZ
    case previewE57
    case viewerMetadata

    // MARK: Internal

    var pathComponents: [String] {
        switch self {
        case .fullLAZ:
            ["merged-point-cloud", "download-url"]
        case .fullE57:
            ["merged-point-cloud", "e57", "download-url"]
        case .previewLAZ:
            ["merged-point-cloud", "preview", "download-url"]
        case .previewE57:
            ["merged-point-cloud", "preview", "e57", "download-url"]
        case .viewerMetadata:
            ["merged-point-cloud", "viewer-metadata", "download-url"]
        }
    }

    /// Name the artifact is cached and exported under. Mirrors the merge job's R2 output
    /// filenames, so a file shared out of the app arrives with the extension CAD tools
    /// expect (Rhino imports `.e57` natively).
    var filename: String {
        switch self {
        case .fullLAZ:
            "merged-point-cloud.laz"
        case .fullE57:
            "merged-point-cloud.e57"
        case .previewLAZ:
            "merged-point-cloud.preview.laz"
        case .previewE57:
            "merged-point-cloud.preview.e57"
        case .viewerMetadata:
            "merged-point-cloud.viewer.json"
        }
    }
}

// MARK: - GetMeshJobResponse

nonisolated struct GetMeshJobResponse: Codable, Equatable, Hashable {
    // MARK: Internal

    let objectKey: String
    let downloadURL: String
    let expiresAt: String

    // MARK: Private

    private enum CodingKeys: String, CodingKey {
        case objectKey
        case downloadURL = "downloadUrl"
        case expiresAt
    }
}

typealias GetMeshPreviewResponse = GetMeshJobResponse

// MARK: - MergedArtifactIdentity

nonisolated enum MergedArtifactIdentity: Equatable, Hashable {
    case job(organizationID: String, projectID: String, jobID: String)
    case legacy(organizationID: String, projectID: String)

    // MARK: Lifecycle

    init?(objectKey: String) {
        let components = objectKey.split(separator: "/", omittingEmptySubsequences: false)
        guard components.count >= 5,
              components[0] == "organizations",
              components[2] == "projects"
        else {
            return nil
        }

        let organizationID = String(components[1])
        let projectID = String(components[3])
        switch components.count {
        case 5:
            self = .legacy(organizationID: organizationID, projectID: projectID)
        case 7 where components[4] == "mesh-jobs":
            self = .job(
                organizationID: organizationID,
                projectID: projectID,
                jobID: String(components[5])
            )
        default:
            return nil
        }
    }

    // MARK: Internal

    var jobID: String? {
        switch self {
        case let .job(_, _, jobID):
            jobID
        case .legacy:
            nil
        }
    }
}

// MARK: - DownloadedMeshArtifact

nonisolated struct DownloadedMeshArtifact: Equatable {
    let objectKey: String
    let fileURL: URL

    var identity: MergedArtifactIdentity? {
        MergedArtifactIdentity(objectKey: self.objectKey)
    }
}

// MARK: - MeshFile

nonisolated struct MeshFile: Equatable {
    let objectKey: String
    let data: Data
}

// MARK: - ProjectRowModel

struct ProjectRowModel: Identifiable {
    // MARK: Lifecycle

    /// Builds a row for a remote API project. When a local copy has already been materialized
    /// (`localProject`), its live zone counts drive the progress bar so scan progress shows
    /// immediately.
    init(apiProject project: ProjectsAPIProject, localProject: Project? = nil) {
        let boundary = project.boundary.map { coordinates in
            ProjectBoundary(vertices: coordinates.map(\.geoCoordinate))
        }

        self.id = project.id
        self.localID = localProject?.id
        self.remoteID = project.id
        self.remoteOrganizationID = project.organizationID
        self.remoteBoundary = boundary
        self.name = project.name
        self.detailText = "Created \(Self.createdAtText(project.createdAt))"
        self.metricText = boundary?.areaSquareMeters.areaText ?? "\(project.zoneSize)m zones"

        if let localProject {
            self.notStarted = localProject.zoneCountSummary[.notStarted] ?? 0
            self.inProgress = localProject.zoneCountSummary[.inProgress] ?? 0
            self.complete = localProject.zoneCountSummary[.complete] ?? 0
        } else {
            self.notStarted = 0
            self.inProgress = 0
            self.complete = 0
        }
    }

    /// Builds a row for a local project when the remote list is unavailable or the project has
    /// not been created remotely yet.
    init(localProject project: Project) {
        self.id = project.remoteID ?? project.id.uuidString
        self.localID = project.id
        self.remoteID = project.remoteID
        self.remoteOrganizationID = project.owningRemoteOrganizationID
        self.remoteBoundary = project.boundary
        self.name = project.name
        self.detailText = "Created \(Self.createdAtText(project.createdAt))"
        self.metricText = project.boundary.areaSquareMeters.areaText
        self.notStarted = project.zoneCountSummary[.notStarted] ?? 0
        self.inProgress = project.zoneCountSummary[.inProgress] ?? 0
        self.complete = project.zoneCountSummary[.complete] ?? 0
    }

    // MARK: Internal

    let id: String
    let localID: UUID?
    /// Set for rows backed by a remote API project.
    let remoteID: String?
    /// Organization that owns the remote API project, when known.
    let remoteOrganizationID: String?
    /// Remote boundary, when present. A remote row can only open its detail once it has a
    /// boundary and zones have been fetched from the API.
    let remoteBoundary: ProjectBoundary?
    let name: String
    let detailText: String
    let metricText: String
    let notStarted: Int
    let inProgress: Int
    let complete: Int

    /// Whether tapping this row can reach a detail view or attempt remote materialization.
    var canOpen: Bool {
        self.localID != nil || (self.remoteID != nil && self.remoteBoundary != nil)
    }

    var percentComplete: Int {
        let total = self.notStarted + self.inProgress + self.complete
        guard total > 0 else { return 0 }
        return Int((Double(self.complete) / Double(total) * 100).rounded())
    }

    // MARK: Private

    private static let fractionalSecondsFormatter: ISO8601DateFormatter = {
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        return formatter
    }()

    private static let internetDateTimeFormatter: ISO8601DateFormatter = {
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime]
        return formatter
    }()

    private static func createdAtText(_ value: String) -> String {
        if let date = fractionalSecondsFormatter.date(from: value) {
            return date.formatted(.relative(presentation: .numeric))
        }
        if let date = Self.internetDateTimeFormatter.date(from: value) {
            return date.formatted(.relative(presentation: .numeric))
        }
        return value
    }

    private static func createdAtText(_ date: Date) -> String {
        date.formatted(.relative(presentation: .numeric))
    }
}

// MARK: - Organization

/// Lightweight organization model backing the workspace switcher.
struct Organization: Identifiable {
    let id: String
    /// Full name, shown in the dropdown rows (e.g. "Stanford Civil Eng").
    let name: String

    /// Per-org accent used across the pill mark and switcher rows.
    let tint: Color
    /// The signed-in user's role in this org (e.g. "Owner", "Member").
    let role: String
    /// Number of projects the user can see in this org.
    let projectCount: Int

    /// Short display name for the collapsed organization pill.
    var shortName: String {
        let words = self.name.split(separator: " ")
        guard words.count > 2 else { return self.name }
        return words.prefix(2).joined(separator: " ")
    }

    /// One or two letters for the colored mark badge.
    var mark: String {
        let words = self.name.split(separator: " ")

        let initials = words.map { word in
            String(word.prefix(1))
        }

        return String(initials.joined().uppercased().prefix(2))
    }
}
