import Foundation

// MARK: - ZonesAPICoordinate

nonisolated struct ZonesAPICoordinate: Codable, Equatable, Hashable {
    let latitude: Double
    let longitude: Double
}

// MARK: - ZonesAPIUploadStatus

nonisolated enum ZonesAPIUploadStatus: String, Codable, Equatable, Hashable {
    case pending
    case uploaded
    case expired
    case unknown

    // MARK: Lifecycle

    init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        let rawValue = try container.decode(String.self)
        self = Self(rawValue: rawValue) ?? .unknown
    }

    // MARK: Internal

    var displayName: String {
        switch self {
        case .pending:
            "Pending"
        case .uploaded:
            "Uploaded"
        case .expired:
            "Expired"
        case .unknown:
            "Unknown"
        }
    }
}

// MARK: - ZonesAPIJSONValue

nonisolated enum ZonesAPIJSONValue: Codable, Equatable, Hashable {
    case string(String)
    case number(Double)
    case bool(Bool)
    case object([String: ZonesAPIJSONValue])
    case array([ZonesAPIJSONValue])
    case null

    // MARK: Lifecycle

    init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()

        if container.decodeNil() {
            self = .null
        } else if let value = try? container.decode(Bool.self) {
            self = .bool(value)
        } else if let value = try? container.decode(Double.self) {
            self = .number(value)
        } else if let value = try? container.decode(String.self) {
            self = .string(value)
        } else if let value = try? container.decode([ZonesAPIJSONValue].self) {
            self = .array(value)
        } else {
            self = try .object(container.decode([String: ZonesAPIJSONValue].self))
        }
    }

    // MARK: Internal

    func encode(to encoder: Encoder) throws {
        var container = encoder.singleValueContainer()

        switch self {
        case let .string(value):
            try container.encode(value)
        case let .number(value):
            try container.encode(value)
        case let .bool(value):
            try container.encode(value)
        case let .object(value):
            try container.encode(value)
        case let .array(value):
            try container.encode(value)
        case .null:
            try container.encodeNil()
        }
    }
}

// MARK: - ZonesAPIZone

nonisolated struct ZonesAPIZone: Codable, Equatable, Hashable, Identifiable {
    // MARK: Internal

    let id: String
    let projectID: String
    let x: Int
    let y: Int
    let corners: [ZonesAPICoordinate]
    let scannedAt: String
    let duration: Double?
    let pointCount: Int?
    let scanObjectKey: String?
    let scanUploadStatus: ZonesAPIUploadStatus?
    let scanUploadExpiresAt: String?
    let scanUploadedAt: String?
    let metadata: ZonesAPIJSONValue?
    let createdAt: String

    // MARK: Private

    /// Avoids SwiftLint warnings when mapping projectID -> projectID.
    private enum CodingKeys: String, CodingKey {
        case id
        case projectID = "projectId"
        case x
        case y
        case corners
        case scannedAt
        case duration
        case pointCount
        case scanObjectKey
        case scanUploadStatus
        case scanUploadExpiresAt
        case scanUploadedAt
        case metadata
        case createdAt
    }
}

// MARK: - UpdateZonesAPIZoneRequest

nonisolated struct UpdateZonesAPIZoneRequest: Codable, Equatable, Hashable {
    var scannedAt: String?
    var duration: Double?
    var pointCount: Int?
    var metadata: ZonesAPIJSONValue?
}

// MARK: - ZonesAPIRequiredHeaders

nonisolated struct ZonesAPIRequiredHeaders: Codable, Equatable, Hashable {
    // MARK: Internal

    let contentType: String

    // MARK: Private

    private enum CodingKeys: String, CodingKey {
        case contentType = "Content-Type"
    }
}

// MARK: - ZonesAPIScanArchive

nonisolated struct ZonesAPIScanArchive: Codable, Equatable, Hashable, Identifiable {
    // MARK: Internal

    let id: String
    let zoneID: String
    let objectKey: String
    let uploadStatus: ZonesAPIUploadStatus
    let uploadExpiresAt: String
    let uploadedAt: String?
    let previewObjectKey: String?
    let previewUploadStatus: ZonesAPIUploadStatus?
    let previewUploadExpiresAt: String?
    let previewUploadedAt: String?
    let createdAt: String

    // MARK: Private

    private enum CodingKeys: String, CodingKey {
        case id
        case zoneID = "zoneId"
        case objectKey
        case uploadStatus
        case uploadExpiresAt
        case uploadedAt
        case previewObjectKey
        case previewUploadStatus
        case previewUploadExpiresAt
        case previewUploadedAt
        case createdAt
    }
}

// MARK: - ZonesAPIScanArchiveUploadURLResponse

nonisolated struct ZonesAPIScanArchiveUploadURLResponse: Codable, Equatable, Hashable {
    // MARK: Internal

    let objectKey: String
    let requiredHeaders: ZonesAPIRequiredHeaders
    let uploadURL: String
    let expiresAt: String
    let previewObjectKey: String?
    let previewRequiredHeaders: ZonesAPIRequiredHeaders?
    let previewUploadURL: String?
    let previewExpiresAt: String?
    let zone: ZonesAPIZone

    // MARK: Private

    private enum CodingKeys: String, CodingKey {
        case objectKey
        case requiredHeaders
        case uploadURL = "uploadUrl"
        case expiresAt
        case previewObjectKey
        case previewRequiredHeaders
        case previewUploadURL = "previewUploadUrl"
        case previewExpiresAt
        case zone
    }
}

// MARK: - ZonesAPIScanDownloadURLResponse

nonisolated struct ZonesAPIScanDownloadURLResponse: Codable, Equatable, Hashable {
    // MARK: Internal

    let objectKey: String
    let downloadURL: String?
    let uploadStatus: ZonesAPIUploadStatus
    let expiresAt: String

    // MARK: Private

    private enum CodingKeys: String, CodingKey {
        case objectKey
        case downloadURL = "downloadUrl"
        case uploadStatus
        case expiresAt
    }
}

// MARK: - ZonesAPIPreviewDownloadURLResponse

nonisolated struct ZonesAPIPreviewDownloadURLResponse: Codable, Equatable, Hashable {
    // MARK: Internal

    let previewObjectKey: String?
    let downloadURL: String?
    let previewUploadStatus: ZonesAPIUploadStatus?
    let expiresAt: String

    // MARK: Private

    private enum CodingKeys: String, CodingKey {
        case previewObjectKey
        case downloadURL = "downloadUrl"
        case previewUploadStatus
        case expiresAt
    }
}

// MARK: - ZonesAPIPreviewFile

nonisolated struct ZonesAPIPreviewFile: Equatable {
    let archiveID: String
    let previewObjectKey: String?
    let data: Data
}

// MARK: - RemoteZoneResolutionContext

nonisolated struct RemoteZoneResolutionContext {
    let localProjectID: UUID
    let organizationID: String
    let remoteProjectID: String
    let zoneID: UUID
    let preferredRemoteZoneID: String?
    let service: ZonesService
}

// MARK: - ZoneScanUploadStatus

nonisolated struct ZoneScanUploadStatus: Equatable, Hashable {
    let scanProjectID: UUID?
    let state: ZoneScanUploadState
    let detail: String
    let updatedAt: Date
}

// MARK: - ZoneScanUploadState

nonisolated enum ZoneScanUploadState: Equatable, Hashable {
    case queued
    case uploading
    case uploaded
    case failed
    case unavailable
}

// MARK: - ZoneScanUploadUnavailableReason

nonisolated enum ZoneScanUploadUnavailableReason {
    case localProject
    case missingOrganization
    case notSignedIn

    // MARK: Internal

    var detail: String {
        switch self {
        case .localProject:
            "Project is not connected to remote upload"
        case .missingOrganization:
            "No active organization selected"
        case .notSignedIn:
            "Sign in to upload this scan"
        }
    }
}

// MARK: - ZoneScanArchiveCacheError

nonisolated enum ZoneScanArchiveCacheError: LocalizedError {
    case invalidLocalZoneID
    case remoteZoneUnavailable
    case scanArchiveNotUploaded
    case scanArchiveUnavailable

    // MARK: Internal

    var errorDescription: String? {
        switch self {
        case .invalidLocalZoneID:
            "The queued scan references an invalid local zone."
        case .remoteZoneUnavailable:
            "The local zone could not be matched to a server zone."
        case .scanArchiveNotUploaded:
            "Only uploaded scan versions can be made active for merge jobs."
        case .scanArchiveUnavailable:
            "The displayed scan version is not available on the server."
        }
    }
}

// MARK: - ZoneScanArchiveOption

nonisolated struct ZoneScanArchiveOption: Equatable, Identifiable {
    let id: String
    let previewID: UUID?
    let uploadStatus: ZonesAPIUploadStatus
    let previewUploadStatus: ZonesAPIUploadStatus?
    let createdAt: Date?

    var isSelectable: Bool {
        self.uploadStatus == .uploaded
            && self.previewID != nil
            && (self.previewUploadStatus == nil || self.previewUploadStatus == .uploaded)
    }
}

// MARK: - ZoneScanArchivePage

/// One page of scan history. The active archive is pinned to the top of the first
/// page and excluded from every later page, even when it is chronologically old.
/// `pageIndex` is the served page, clamped when the requested page is out of range.
nonisolated struct ZoneScanArchivePage: Equatable {
    let pageIndex: Int
    let options: [ZoneScanArchiveOption]
    let hasNextPage: Bool
    let activeScanProjectID: UUID?
}

// MARK: - PendingZoneScanUpload

nonisolated struct PendingZoneScanUpload: Codable, Equatable, Hashable {
    /// Account that queued the scan; entries are only flushed under this user's session.
    /// Nil on entries persisted before user scoping was added.
    let userID: String
    let localProjectID: UUID
    let organizationID: String
    let remoteProjectID: String
    let zoneID: String
    let remoteZoneID: String?
    let scanProjectID: UUID
}

// MARK: - ZonesServiceError

nonisolated enum ZonesServiceError: LocalizedError {
    case missingRequiredIdentifier(String)
    case invalidLimit(Int)
    case invalidReconcileLimit(Int)
    case invalidURL(field: String, value: String)
    case scanProjectUnavailable(URL)
    case archiveCreationFailed(Error)
    case uploadFailed(statusCode: Int?, underlying: Error?)
    case downloadUnavailable
    case downloadFailed(statusCode: Int?, underlying: Error?)

    // MARK: Internal

    var errorDescription: String? {
        switch self {
        case let .missingRequiredIdentifier(name):
            "Missing required zone service identifier: \(name)."
        case let .invalidLimit(limit):
            "Invalid scan archive limit \(limit). Expected a value from 1 through 100."
        case let .invalidReconcileLimit(reconcileLimit):
            "Invalid scan archive reconcile limit \(reconcileLimit). Expected a value from 0 through 10."
        case let .invalidURL(field, value):
            "Zone service response contained an invalid URL for \(field): \(value)."
        case let .scanProjectUnavailable(url):
            "No scan project directory was found at \(url.path)."
        case let .archiveCreationFailed(error):
            "Failed to archive the scan project: \(error.localizedDescription)."
        case let .uploadFailed(statusCode, underlying):
            if let statusCode {
                "Scan archive upload failed with status code \(statusCode)."
            } else if let underlying {
                "Scan archive upload failed: \(underlying.localizedDescription)."
            } else {
                "Scan archive upload failed with an unexpected response."
            }
        case .downloadUnavailable:
            "No preview download URL is available for this scan archive."
        case let .downloadFailed(statusCode, underlying):
            if let statusCode {
                "Scan archive preview download failed with status code \(statusCode)."
            } else if let underlying {
                "Scan archive preview download failed: \(underlying.localizedDescription)."
            } else {
                "Scan archive preview download failed with an unexpected response."
            }
        }
    }
}
