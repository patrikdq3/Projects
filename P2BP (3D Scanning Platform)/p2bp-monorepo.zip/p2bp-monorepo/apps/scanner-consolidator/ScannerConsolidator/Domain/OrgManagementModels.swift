import SwiftUI

// MARK: - OrgRole

enum OrgRole: String, CaseIterable, Identifiable, Hashable {
    case owner
    case admin
    case scanner
    case member

    // MARK: Lifecycle

    init(apiValue: String) {
        let values = apiValue.lowercased()
            .split { character in
                character == "," || character == " "
            }
            .map(String.init)

        if values.contains(Self.owner.rawValue) {
            self = .owner
        } else if values.contains(Self.admin.rawValue) {
            self = .admin
        } else if values.contains(Self.scanner.rawValue) {
            self = .scanner
        } else {
            self = .member
        }
    }

    // MARK: Internal

    var id: String {
        self.rawValue
    }

    /// Human-facing label shown on role badges and pickers.
    var label: String {
        switch self {
        case .owner: "Owner"
        case .admin: "Admin"
        case .scanner: "Scanner"
        case .member: "Member"
        }
    }

    /// One-line description surfaced beneath the role picker.
    var blurb: String {
        switch self {
        case .owner: "Full control including the ability to delete org."
        case .admin: "Can manage members, send invites, and edit settings."
        case .scanner: "Can view and scan zones for projects in this organization"
        case .member: "Can view projects in this organization."
        }
    }

    /// Badge text color.
    var badgeForeground: Color {
        switch self {
        case .owner: Color("Primary")
        case .admin: Color(red: 59 / 255, green: 111 / 255, blue: 176 / 255)
        case .scanner: Color(red: 0 / 255, green: 128 / 255, blue: 112 / 255)
        case .member: Color(red: 60 / 255, green: 60 / 255, blue: 67 / 255).opacity(0.7)
        }
    }

    /// Badge fill color.
    var badgeBackground: Color {
        switch self {
        case .owner: Color("Primary").opacity(0.12)
        case .admin: Color(red: 59 / 255, green: 111 / 255, blue: 176 / 255).opacity(0.12)
        case .scanner: Color(red: 0 / 255, green: 128 / 255, blue: 112 / 255).opacity(0.12)
        case .member: Color(red: 60 / 255, green: 60 / 255, blue: 67 / 255).opacity(0.08)
        }
    }

    /// The article that reads correctly before the role label ("the Owner", "an Admin",
    /// "a Member") in the detail header.
    var article: String {
        switch self {
        case .owner: "the"
        case .admin: "an"
        case .scanner: "a"
        case .member: "a"
        }
    }
}

// MARK: - OrgMember

/// A person belonging to an organization. Mirrors a better-auth `Member` record joined with
/// its `User`.
struct OrgMember: Identifiable, Hashable {
    // MARK: Lifecycle

    init(
        id: String,
        name: String,
        email: String,
        role: OrgRole,
        tint: Color,
        isYou: Bool = false
    ) {
        self.id = id
        self.name = name
        self.email = email
        self.role = role
        self.tint = tint
        self.isYou = isYou
    }

    init(apiMember: OrganizationsAPIMember, currentUserID: String?, tint: Color) {
        let fallbackName = apiMember.user?.email ?? "Member"

        self.id = apiMember.id
        self.name = apiMember.user?.name?.isEmpty == false ? apiMember.user?.name ?? fallbackName : fallbackName
        self.email = apiMember.user?.email ?? ""
        self.role = OrgRole(apiValue: apiMember.role)
        self.tint = tint
        self.isYou = apiMember.userID == currentUserID
    }

    // MARK: Internal

    let id: String
    let name: String
    let email: String
    var role: OrgRole
    /// Per-member avatar tint.
    let tint: Color
    /// True when this row represents the signed-in user.
    var isYou = false
}

// MARK: - InvitationStatus

/// Lifecycle of an outstanding invite.
enum InvitationStatus: Hashable {
    case pending
    case expired
}

// MARK: - OrgInvitation

/// A pending or expired invitation. Mirrors a better-auth `Invitation` record.
struct OrgInvitation: Identifiable, Hashable {
    // MARK: Lifecycle

    init(id: String, email: String, role: OrgRole, status: InvitationStatus, expiresText: String) {
        self.id = id
        self.email = email
        self.role = role
        self.status = status
        self.expiresText = expiresText
    }

    init(apiInvitation: OrganizationsAPIInvitation) {
        let expiry = apiInvitation.expiresDate

        self.id = apiInvitation.id
        self.email = apiInvitation.email
        self.role = OrgRole(apiValue: apiInvitation.role)
        self.status = apiInvitation.isExpired ? .expired : .pending
        self.expiresText = expiry.map {
            let formatter = RelativeDateTimeFormatter()
            formatter.unitsStyle = .full
            return formatter.localizedString(for: $0, relativeTo: Date())
        } ?? ""
    }

    // MARK: Internal

    let id: String
    let email: String
    var role: OrgRole
    var status: InvitationStatus
    /// Relative expiry copy, e.g. "in 2 days" or "3 days ago".
    var expiresText: String
}

// MARK: - ManageableOrganization

/// An organization the user belongs to, as shown in the management list and detail header.
/// Richer than `Organization` (the switcher model) because it carries the slug, member count,
/// and the viewer's own role for permission gating.
struct ManageableOrganization: Identifiable, Hashable {
    // MARK: Lifecycle

    init(
        id: String,
        name: String,
        slug: String,
        tint: Color,
        viewerRole: OrgRole,
        memberCount: Int
    ) {
        self.id = id
        self.name = name
        self.slug = slug
        self.tint = tint
        self.viewerRole = viewerRole
        self.memberCount = memberCount
    }

    init(apiDetail: OrganizationsAPIFullOrganization, currentUserID: String?, tint: Color) {
        let viewerRole = apiDetail.members.first { member in
            member.userID == currentUserID
        }.map { member in
            OrgRole(apiValue: member.role)
        } ?? .member

        self.id = apiDetail.organization.id
        self.name = apiDetail.organization.name
        self.slug = apiDetail.organization.slug
        self.tint = tint
        self.viewerRole = viewerRole
        self.memberCount = apiDetail.members.count
    }

    // MARK: Internal

    let id: String
    let name: String
    /// URL slug used in links and invites (rendered as `p2bp.app/<slug>`).
    let slug: String
    /// Org accent used by the colored mark.
    let tint: Color
    /// The signed-in user's role in this org — gates Edit / Invite / Delete.
    var viewerRole: OrgRole
    var memberCount: Int

    /// One or two letters for the colored mark badge.
    var mark: String {
        let initials = self.name.split(separator: " ").map { String($0.prefix(1)) }
        return String(initials.joined().uppercased().prefix(2))
    }

    static func tint(for index: Int) -> Color {
        let tints = [
            Color(red: 46 / 255, green: 125 / 255, blue: 107 / 255),
            Color(red: 59 / 255, green: 111 / 255, blue: 176 / 255),
            Color(red: 176 / 255, green: 122 / 255, blue: 46 / 255),
            Color(red: 31 / 255, green: 138 / 255, blue: 138 / 255),
            Color(red: 138 / 255, green: 75 / 255, blue: 46 / 255),
            Color(red: 91 / 255, green: 91 / 255, blue: 176 / 255),
        ]
        return tints[index % tints.count]
    }
}

// MARK: - OrganizationsAPIFullOrganization

/// Includes organization definition plus members in the organization
nonisolated struct OrganizationsAPIFullOrganization: Codable, Hashable, Identifiable {
    // MARK: Lifecycle

    init(organization: ProjectsAPIOrganization, members: [OrganizationsAPIMember]) {
        self.organization = organization
        self.members = members
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)

        if let organization = try? container.decode(ProjectsAPIOrganization.self, forKey: .organization) {
            self.organization = organization
        } else {
            self.organization = try ProjectsAPIOrganization(from: decoder)
        }

        self.members = (try? container.decode([OrganizationsAPIMember].self, forKey: .members)) ?? []
    }

    // MARK: Internal

    let organization: ProjectsAPIOrganization
    let members: [OrganizationsAPIMember]

    var id: String {
        self.organization.id
    }

    // MARK: Private

    private enum CodingKeys: String, CodingKey {
        case organization
        case members
    }
}

// MARK: - OrganizationsAPIMember

nonisolated struct OrganizationsAPIMember: Codable, Hashable, Identifiable {
    // MARK: Lifecycle

    init(
        id: String,
        userID: String,
        organizationID: String,
        role: String,
        createdAt: String? = nil,
        user: OrganizationsAPIUser? = nil
    ) {
        self.id = id
        self.userID = userID
        self.organizationID = organizationID
        self.role = role
        self.createdAt = createdAt
        self.user = user
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)

        self.id = try container.decode(String.self, forKey: .id)
        self.userID = try container.decode(String.self, forKey: .userID)
        self.organizationID = try container.decode(String.self, forKey: .organizationID)
        self.role = try Self.decodeRole(from: container)
        self.createdAt = try container.decodeIfPresent(String.self, forKey: .createdAt)
        self.user = try container.decodeIfPresent(OrganizationsAPIUser.self, forKey: .user)
    }

    // MARK: Internal

    let id: String
    let userID: String
    let organizationID: String
    let role: String
    let createdAt: String?
    let user: OrganizationsAPIUser?

    // MARK: Private

    private enum CodingKeys: String, CodingKey {
        case id
        case userID = "userId"
        case organizationID = "organizationId"
        case role
        case createdAt
        case user
    }

    private static func decodeRole(from container: KeyedDecodingContainer<CodingKeys>) throws -> String {
        if let role = try? container.decode(String.self, forKey: .role) {
            return role
        }

        let roles = try container.decode([String].self, forKey: .role)
        return roles.joined(separator: ",")
    }
}

// MARK: - OrganizationsAPIUser

nonisolated struct OrganizationsAPIUser: Codable, Hashable {
    let id: String
    let name: String?
    let email: String?
    let image: String?
}

// MARK: - CheckOrganizationSlugRequest

nonisolated struct CheckOrganizationSlugRequest: Encodable {
    let slug: String
}

// MARK: - CreateOrganizationRequest

nonisolated struct CreateOrganizationRequest: Encodable {
    let name: String
    let slug: String
    let logo: String?
    let keepCurrentActiveOrganization: Bool
}

// MARK: - UpdateOrganizationMemberRoleRequest

nonisolated struct UpdateOrganizationMemberRoleRequest: Encodable {
    // MARK: Internal

    let role: String
    let memberID: String
    let organizationID: String

    // MARK: Private

    private enum CodingKeys: String, CodingKey {
        case role
        case memberID = "memberId"
        case organizationID = "organizationId"
    }
}

// MARK: - RemoveOrganizationMemberRequest

nonisolated struct RemoveOrganizationMemberRequest: Encodable {
    // MARK: Internal

    let memberIDOrEmail: String
    let organizationID: String

    // MARK: Private

    private enum CodingKeys: String, CodingKey {
        case memberIDOrEmail = "memberIdOrEmail"
        case organizationID = "organizationId"
    }
}

// MARK: - OrganizationIDRequest

nonisolated struct OrganizationIDRequest: Encodable {
    // MARK: Internal

    let organizationID: String

    // MARK: Private

    private enum CodingKeys: String, CodingKey {
        case organizationID = "organizationId"
    }
}

// MARK: - CheckOrganizationSlugResponse

nonisolated struct CheckOrganizationSlugResponse: Decodable {
    let available: Bool?
    let status: Bool?
    let taken: Bool?
}

// MARK: - OrganizationResponse

nonisolated struct OrganizationResponse: Decodable {
    let organization: ProjectsAPIOrganization
}

// MARK: - OrganizationsAPIMembersResponse

nonisolated struct OrganizationsAPIMembersResponse: Decodable {
    let members: [OrganizationsAPIMember]
}

// MARK: - InviteOrganizationMemberRequest

nonisolated struct InviteOrganizationMemberRequest: Encodable {
    // MARK: Internal

    let email: String
    let role: String
    let organizationID: String
    let resend: Bool?

    // MARK: Private

    private enum CodingKeys: String, CodingKey {
        case email
        case role
        case organizationID = "organizationId"
        case resend
    }
}

// MARK: - InvitationIDRequest

nonisolated struct InvitationIDRequest: Encodable {
    // MARK: Internal

    let invitationID: String

    // MARK: Private

    private enum CodingKeys: String, CodingKey {
        case invitationID = "invitationId"
    }
}

// MARK: - OrganizationsAPIInvitation

/// An invitation the signed-in user has received to join an organization. Mirrors a better-auth
/// `Invitation` record, optionally enriched with the organization name when the API provides it.
nonisolated struct OrganizationsAPIInvitation: Decodable, Hashable, Identifiable {
    // MARK: Lifecycle

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)

        self.id = try container.decode(String.self, forKey: .id)
        self.email = try container.decodeIfPresent(String.self, forKey: .email) ?? ""
        self.role = (try? container.decode(String.self, forKey: .role)) ?? OrgRole.member.rawValue
        self.status = try container.decodeIfPresent(String.self, forKey: .status) ?? "pending"
        self.organizationID = try container.decode(String.self, forKey: .organizationID)
        self.expiresAt = try container.decodeIfPresent(String.self, forKey: .expiresAt)
        self.inviterEmail = try container.decodeIfPresent(String.self, forKey: .inviterEmail)

        // The name can arrive flat or nested under an `organization` object, depending on whether
        // the endpoint enriches the record.
        let nestedOrganization = try? container.nestedContainer(keyedBy: NameKey.self, forKey: .organization)
        self.organizationName = (try? container.decode(String.self, forKey: .organizationName))
            ?? nestedOrganization.flatMap { try? $0.decode(String.self, forKey: .name) }
    }

    // MARK: Internal

    let id: String
    let email: String
    let role: String
    let status: String
    let organizationID: String
    let organizationName: String?
    let inviterEmail: String?
    let expiresAt: String?

    var isPending: Bool {
        self.status.lowercased() == "pending"
    }

    var isExpired: Bool {
        self.expiresDate.map { $0 <= Date() } ?? false
    }

    var isActivePending: Bool {
        self.isPending && !self.isExpired
    }

    /// Parsed expiry, tolerating ISO-8601 with or without fractional seconds.
    var expiresDate: Date? {
        guard let expiresAt else { return nil }
        let withFraction = ISO8601DateFormatter()
        withFraction.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        return withFraction.date(from: expiresAt) ?? ISO8601DateFormatter().date(from: expiresAt)
    }

    /// Organization name shown in the invitations list, with a graceful fallback.
    var displayName: String {
        let name = self.organizationName ?? ""
        return name.isEmpty ? "an organization" : name
    }

    /// One or two letters for the colored mark badge.
    var mark: String {
        let initials = self.displayName.split(separator: " ").map { String($0.prefix(1)) }
        return String(initials.joined().uppercased().prefix(2))
    }

    // MARK: Private

    private enum CodingKeys: String, CodingKey {
        case id
        case email
        case role
        case status
        case organizationID = "organizationId"
        case organization
        case organizationName
        case inviterEmail
        case expiresAt
    }

    private enum NameKey: String, CodingKey {
        case name
    }
}

// MARK: - OrganizationsAPIInvitationsResponse

nonisolated struct OrganizationsAPIInvitationsResponse: Decodable {
    let invitations: [OrganizationsAPIInvitation]
}
