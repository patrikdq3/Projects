// swiftlint:disable:next unused_import
import Foundation

// MARK: - VerifyEmailOtpRequest

nonisolated struct VerifyEmailOtpRequest: Codable {
    let email: String
    let otp: String
}

// MARK: - ResendEmailOtpRequest

nonisolated struct ResendEmailOtpRequest: Codable {
    let email: String
    let type: EmailOtpType
}

// MARK: - EmailOtpType

nonisolated enum EmailOtpType: String, Codable {
    case emailVerification = "email-verification"
    case signIn = "sign-in"
    case forgetPassword = "forget-password"
}

// MARK: - EmailLoginRequest

nonisolated struct EmailLoginRequest: Codable {
    let email: String
    let password: String
}

// MARK: - EmailSignUpRequest

nonisolated struct EmailSignUpRequest: Codable {
    let email: String
    let name: String
    let password: String
}

// MARK: - AppleSignInCredential

nonisolated struct AppleSignInCredential {
    let identityToken: String
    let nonce: String?
    let email: String?
    let firstName: String?
    let lastName: String?
}

// MARK: - AppleSocialSignInRequest

nonisolated struct AppleSocialSignInRequest: Codable {
    // MARK: Lifecycle

    init(credential: AppleSignInCredential) {
        let name = AppleSocialSignInName(
            firstName: credential.firstName,
            lastName: credential.lastName
        )
        let hasName = credential.firstName != nil || credential.lastName != nil
        let user = AppleSocialSignInUser(
            name: hasName ? name : nil,
            email: credential.email
        )
        let hasUser = hasName || credential.email != nil

        self.idToken = AppleSocialSignInIDToken(
            token: credential.identityToken,
            nonce: credential.nonce,
            user: hasUser ? user : nil
        )
    }

    // MARK: Internal

    var provider = "apple"
    let idToken: AppleSocialSignInIDToken
}

// MARK: - AppleSocialSignInIDToken

nonisolated struct AppleSocialSignInIDToken: Codable {
    let token: String
    let nonce: String?
    let user: AppleSocialSignInUser?
}

// MARK: - AppleSocialSignInUser

nonisolated struct AppleSocialSignInUser: Codable {
    let name: AppleSocialSignInName?
    let email: String?
}

// MARK: - AppleSocialSignInName

nonisolated struct AppleSocialSignInName: Codable {
    let firstName: String?
    let lastName: String?
}

// MARK: - AuthAPIErrorResponse

nonisolated struct AuthAPIErrorResponse: Codable {
    let message: String?
    let code: String?
}

// MARK: - VerifyEmailOtpResponse

nonisolated struct VerifyEmailOtpResponse: Codable {
    let status: Bool
    let token: String?
    let user: User
}

// MARK: - ResendEmailOtpResponse

nonisolated struct ResendEmailOtpResponse: Codable {
    let success: Bool
}

// MARK: - LoginResponse

nonisolated struct LoginResponse: Codable {
    let user: User
    let token: String
}

// MARK: - EmailSignUpResponse

nonisolated struct EmailSignUpResponse: Codable {
    let user: User
    let token: String?
}

// MARK: - GetSessionResponse

nonisolated struct GetSessionResponse: Codable {
    let session: Session
    let user: User
}

// MARK: - User

nonisolated struct User: Codable {
    let id: String
    let email: String
    let name: String
    let emailVerified: Bool
    let createdAt: String
    let image: String?
    let twoFactorEnabled: Bool?
    let username: String?
}

// MARK: - Session

nonisolated struct Session: Codable {
    let id: String
    let expiresAt: String
    let token: String
    let createdAt: String
    let updatedAt: String
    let ipAddress: String
    let userAgent: String
    // swiftformat:disable:next acronyms
    let userId: String
}

// MARK: - AuthError

nonisolated enum AuthError: Error {
    case invalidURL
    case invalidResponse
    case unauthorized
    case emailNotVerified
    case passwordTooShort
    case loginFailed(String)
    case signUpFailed(String)
    case incorrectOtp(String)
    case tooManyOtpAttempts(String)
    case otpVerificationFailed(String)
    case resendOtpFailed(String)
    case appleSignInFailed(String)
    case missingAuthToken
    case storeAuthTokenError
    case keychainSaveFailed
}

// MARK: - TokenStoreError

nonisolated enum TokenStoreError: Error {
    case invalidStoredData
    case tokenNotFound
    case unhandledError(OSStatus)
}
