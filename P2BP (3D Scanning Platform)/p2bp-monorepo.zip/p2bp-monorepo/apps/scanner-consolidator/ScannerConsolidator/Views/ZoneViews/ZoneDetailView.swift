import SwiftUI

// MARK: - ZoneDetailView

struct ZoneDetailView: View {
    // MARK: Internal

    let projectID: UUID
    let zoneID: UUID
    let onReturnToProjectMap: () -> Void

    var body: some View {
        if let project = projectStore.project(withID: projectID) {
            if let zone = project.zones.first(where: { $0.id == zoneID }) {
                self.content(project: project, zone: zone)
            } else {
                ContentUnavailableView("Zone Missing", systemImage: "square.dashed")
            }
        } else {
            ContentUnavailableView("Zone Missing", systemImage: "square.dashed")
        }
    }

    // MARK: Private

    @EnvironmentObject private var projectStore: ProjectStore
    @EnvironmentObject private var zoneScanArchiveCacheService: ZoneScanArchiveCacheService
    @EnvironmentObject private var remoteProjectsDataCoordinator: RemoteProjectsDataCoordinator

    @State private var scannerPresentation: ZoneScannerPresentation?
    @State private var didManuallySelectScanArchive = false
    @State private var completedPreviewRefreshIDs: Set<UUID> = []
    @State private var verifiedActiveScanZoneIDs: Set<UUID> = []

    @ViewBuilder
    private func content(project: Project, zone: Zone) -> some View {
        let uploadStatus = self.zoneScanArchiveCacheService.uploadStatus(for: zone)

        ZStack {
            if zone.scanState == .complete, let scanProjectID = zone.scanProjectID {
                if self.showsScanLoadingPane(scanProjectID: scanProjectID, project: project, zone: zone) {
                    VStack(spacing: 12) {
                        ProgressView()
                            .controlSize(.regular)
                        Text("Loading scan preview")
                            .font(.subheadline.weight(.medium))
                            .foregroundStyle(.secondary)
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .background(Color("Background"))
                } else {
                    CompletedZoneRenderView(
                        scanProjectID: scanProjectID,
                        project: project,
                        zone: zone,
                        uploadStatus: uploadStatus,
                        onScanAgain: { self.startScanAgain() },
                        onScanSelectionStarted: {
                            self.didManuallySelectScanArchive = true
                        }
                    )
                    .id(scanProjectID)
                }
            } else {
                PendingZoneRenderView(
                    project: project,
                    zone: zone,
                    uploadStatus: uploadStatus,
                    onStart: { self.scannerPresentation = .start },
                    onResume: { self.scannerPresentation = .resume },
                    onScanAgain: { self.startScanAgain() }
                )
            }
        }
        .background(Color.black)
        .navigationTitle(zone.name)
        .navigationBarTitleDisplayMode(.inline)
        .task(id: zone.scanProjectID) {
            guard !self.didManuallySelectScanArchive else { return }
            await self.refreshPreviewIfNeeded(project: project, zone: zone)
        }
        .toolbarBackground(.visible, for: .navigationBar)
        .navigationDestination(item: self.$scannerPresentation) { presentation in
            ZoneScannerContainerView(
                projectID: project.id,
                projectName: project.name,
                zoneID: zone.id,
                zoneName: zone.name,
                scanProjectID: presentation == .start ? nil : zone.scanProjectID,
                presentation: presentation,
                onReturnToProjectMap: self.onReturnToProjectMap
            )
        }
    }

    private func startScanAgain() {
        self.scannerPresentation = .start
    }

    private func showsScanLoadingPane(scanProjectID: UUID, project: Project, zone: Zone) -> Bool {
        self.shouldLoadRemotePreview(scanProjectID: scanProjectID, project: project)
            || self.shouldResolveActiveScan(project: project, zone: zone)
    }

    /// Whether the cached scan should stay hidden behind the loading pane until the server's
    /// active scan has been resolved, so an outdated version is never flashed first.
    private func shouldResolveActiveScan(project: Project, zone: Zone) -> Bool {
        project.remoteID != nil
            && !self.didManuallySelectScanArchive
            && !self.verifiedActiveScanZoneIDs.contains(zone.id)
    }

    private func refreshPreviewIfNeeded(project: Project, zone: Zone) async {
        guard zone.scanState == .complete, let scanProjectID = zone.scanProjectID else { return }

        defer {
            self.completedPreviewRefreshIDs.insert(scanProjectID)
            self.verifiedActiveScanZoneIDs.insert(zone.id)
        }

        guard let remoteProjectID = project.remoteID else { return }
        guard let organizationID = self.remoteOrganizationID(for: project) else { return }

        do {
            let didRefresh = try await self.zoneScanArchiveCacheService.refreshPreviewIfNeeded(
                localProjectID: project.id,
                organizationID: organizationID,
                remoteProjectID: remoteProjectID,
                zoneID: zone.id,
                currentScanProjectID: zone.scanProjectID
            )
            if didRefresh != nil {
                try self.projectStore.reload()
            }
        } catch {
            // Keep showing the cached preview; refresh is best-effort.
        }
    }

    private func shouldLoadRemotePreview(scanProjectID: UUID, project: Project) -> Bool {
        guard project.remoteID != nil else { return false }
        guard !self.completedPreviewRefreshIDs.contains(scanProjectID) else { return false }

        let previewURL = ScanProjectStore()
            .projectDirectory(for: scanProjectID)
            .appendingPathComponent("preview.bin")
        return !FileManager.default.fileExists(atPath: previewURL.path)
    }

    private func remoteOrganizationID(for project: Project) -> String? {
        project.owningRemoteOrganizationID
            ?? self.remoteProjectsDataCoordinator.selectedOrganizationID
    }
}
