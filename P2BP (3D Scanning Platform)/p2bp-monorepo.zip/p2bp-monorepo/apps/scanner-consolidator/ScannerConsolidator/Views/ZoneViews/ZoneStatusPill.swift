import SwiftUI

// MARK: - ZoneStatusPill

struct ZoneStatusPill: View {
    let status: ZoneStatus

    var body: some View {
        Text(self.status.displayName)
            .font(.system(size: 11, weight: .semibold))
            .foregroundStyle(self.status.color)
            .padding(.horizontal, 8)
            .padding(.vertical, 3)
            .background(
                self.status.color.opacity(0.14),
                in: RoundedRectangle(cornerRadius: 6, style: .continuous)
            )
    }
}
