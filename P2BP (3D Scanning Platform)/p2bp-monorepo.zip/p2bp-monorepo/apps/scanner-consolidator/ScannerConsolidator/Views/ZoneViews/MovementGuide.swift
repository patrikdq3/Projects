import SwiftUI

// MARK: - PointCloudMovementGuideButton

struct PointCloudMovementGuideButton: View {
    // MARK: Internal

    @Binding var isPresented: Bool

    let accessibilityIdentifier: String

    var body: some View {
        Button {
            withAnimation(.spring(response: 0.32, dampingFraction: 0.86)) {
                self.isPresented = true
            }
            self.didTap.toggle()
        } label: {
            Image(systemName: "hand.draw.fill")
                .font(.system(size: PointCloudViewerControlStyle.iconSize, weight: .semibold))
                .foregroundStyle(Color("TextPrimary"))
                .frame(width: PointCloudViewerControlStyle.size, height: PointCloudViewerControlStyle.size)
                .background(.regularMaterial, in: Circle())
                .glassEffect(.regular, in: .circle)
                .overlay(
                    Circle()
                        .stroke(Color.white.opacity(0.28), lineWidth: 0.75)
                )
                .shadow(color: .black.opacity(0.22), radius: 14, x: 0, y: 6)
        }
        .buttonStyle(.plain)
        .accessibilityLabel("Movement guide")
        .accessibilityIdentifier(self.accessibilityIdentifier)
        .sensoryFeedback(.selection, trigger: self.didTap)
    }

    // MARK: Private

    @State private var didTap = false
}

// MARK: - PointCloudMovementGuideModifier

private struct PointCloudMovementGuideModifier: ViewModifier {
    // MARK: Internal

    @Binding var isPresented: Bool

    func body(content: Content) -> some View {
        content
            .overlay {
                if self.isPresented {
                    PointCloudMovementGuideOverlay {
                        withAnimation(.spring(response: 0.32, dampingFraction: 0.86)) {
                            self.isPresented = false
                        }
                        self.didAccept.toggle()
                    }
                    .transition(.opacity.combined(with: .scale(scale: 0.98)))
                }
            }
            .sensoryFeedback(.success, trigger: self.didAccept)
    }

    // MARK: Private

    @State private var didAccept = false
}

extension View {
    func pointCloudMovementGuide(isPresented: Binding<Bool>) -> some View {
        self.modifier(PointCloudMovementGuideModifier(isPresented: isPresented))
    }
}

// MARK: - PointCloudMovementGuideOverlay

private struct PointCloudMovementGuideOverlay: View {
    let onAccept: () -> Void

    var body: some View {
        ZStack(alignment: .bottom) {
            Color.black.opacity(0.34)
                .ignoresSafeArea()

            VStack(spacing: 18) {
                HStack(spacing: 12) {
                    Image(systemName: "hand.draw.fill")
                        .font(.system(size: 22, weight: .semibold))
                        .foregroundStyle(Color("Primary"))
                        .frame(width: 46, height: 46)
                        .background(Color("Primary").opacity(0.14), in: Circle())

                    VStack(alignment: .leading, spacing: 3) {
                        Text("Move Through the Scan")
                            .font(.system(size: 20, weight: .bold))
                            .foregroundStyle(Color("TextPrimary"))
                    }
                }
                .frame(maxWidth: .infinity, alignment: .leading)

                VStack(spacing: 12) {
                    PointCloudMovementGuideRow(
                        icon: "hand.point.up.left.fill",
                        title: "One finger",
                        detail: "Move the camera around the scan."
                    )
                    PointCloudMovementGuideRow(
                        icon: "hand.raised.fingers.spread.fill",
                        title: "Two fingers up or down",
                        detail: "Slide the scan through the viewing area."
                    )
                    PointCloudMovementGuideRow(
                        icon: "hand.pinch.fill",
                        title: "Pinch",
                        detail: "Zoom in and zoom out."
                    )
                    PointCloudMovementGuideRow(
                        icon: "dot.scope",
                        title: "Double tap",
                        detail: "Re-center the scan."
                    )
                }

                Spacer(minLength: 0)

                Button {
                    self.onAccept()
                } label: {
                    Label("Got It", systemImage: "checkmark")
                        .font(.system(size: 16, weight: .bold))
                        .foregroundStyle(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 15)
                        .background(
                            Color("Primary"),
                            in: RoundedRectangle(cornerRadius: 18, style: .continuous)
                        )
                        .overlay(
                            RoundedRectangle(cornerRadius: 18, style: .continuous)
                                .stroke(Color.white.opacity(0.32), lineWidth: 1)
                        )
                }
                .buttonStyle(.plain)
                .accessibilityIdentifier("acceptZoneScanMovementGuideButton")
            }
            .padding(20)
            .frame(maxWidth: 420)
            .frame(maxHeight: 470)
            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 28, style: .continuous))
            .glassEffect(.regular, in: .rect(cornerRadius: 28))
            .overlay(
                RoundedRectangle(cornerRadius: 28, style: .continuous)
                    .stroke(Color.white.opacity(0.28), lineWidth: 1)
            )
            .shadow(color: .black.opacity(0.26), radius: 28, x: 0, y: 18)
            .padding(.horizontal, 22)
            .padding(.bottom, 26)
        }
    }
}

// MARK: - PointCloudMovementGuideRow

private struct PointCloudMovementGuideRow: View {
    let icon: String
    let title: String
    let detail: String

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: self.icon)
                .font(.system(size: 17, weight: .semibold))
                .foregroundStyle(Color("Primary"))
                .frame(width: 34, height: 34)
                .background(.thinMaterial, in: Circle())

            VStack(alignment: .leading, spacing: 2) {
                Text(self.title)
                    .font(.system(size: 14.5, weight: .bold))
                    .foregroundStyle(Color("TextPrimary"))
                Text(self.detail)
                    .font(.system(size: 13, weight: .medium))
                    .foregroundStyle(Color("TextSecondary"))
                    .fixedSize(horizontal: false, vertical: true)
            }

            Spacer(minLength: 0)
        }
        .padding(12)
        .background(Color("Surface").opacity(0.42), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
    }
}

// MARK: - PointCloudViewerControlStyle

enum PointCloudViewerControlStyle {
    static let size: CGFloat = 44
    static let iconSize: CGFloat = 22
}
