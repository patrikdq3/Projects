import SwiftUI

// MARK: - CompletedZoneRenderView

struct CompletedZoneRenderView: View {
    // MARK: Lifecycle

    init(
        scanProjectID: UUID,
        project: Project? = nil,
        zone: Zone? = nil,
        uploadStatus: ZoneScanUploadStatus? = nil,
        onScanAgain: (() -> Void)?,
        pointCloudPreviewOrientation: PointCloudPreviewOrientation = .yUp,
        showsScanSelector: Bool = true,
        versionSelector: PointCloudVersionSelectorConfiguration? = nil,
        onScanSelectionStarted: @escaping () -> Void = {}
    ) {
        self.scanProjectID = scanProjectID
        self.project = project
        self.zone = zone
        self.uploadStatus = uploadStatus
        self.onScanAgain = onScanAgain
        self.pointCloudPreviewOrientation = pointCloudPreviewOrientation
        self.showsScanSelector = showsScanSelector
        self.versionSelector = versionSelector
        self.onScanSelectionStarted = onScanSelectionStarted
        _controller = StateObject(
            wrappedValue: ScanSessionController(entryMode: .reviewZone(scanProjectID))
        )
    }

    // MARK: Internal

    let scanProjectID: UUID
    let project: Project?
    let zone: Zone?
    let uploadStatus: ZoneScanUploadStatus?
    let onScanAgain: (() -> Void)?
    let pointCloudPreviewOrientation: PointCloudPreviewOrientation
    let showsScanSelector: Bool
    let versionSelector: PointCloudVersionSelectorConfiguration?
    let onScanSelectionStarted: () -> Void

    var body: some View {
        Group {
            if self.controller.previewPoints.isEmpty {
                ContentUnavailableView(
                    "No Preview Points",
                    systemImage: "cube.transparent",
                    description: Text(self.controller.statusMessage)
                )
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .background(Color("Background"))
            } else {
                PointCloudPreviewView(
                    points: self.controller.previewPoints,
                    orientation: self.pointCloudPreviewOrientation
                )
                .accessibilityIdentifier("zoneRenderPointCloud")
                .ignoresSafeArea(edges: .bottom)
            }
        }
        .overlay(alignment: .topTrailing) {
            self.renderControls
                .padding(.top, 12)
                .padding(.trailing, 16)
        }
        .pointCloudMovementGuide(isPresented: self.$isShowingMovementGuide)
        .overlay(alignment: .topLeading) {
            if let uploadStatus {
                ZoneUploadStatusBadge(status: uploadStatus)
                    .padding(.top, 12)
                    .padding(.leading, 16)
            }
        }
        .toolbar {
            if self.hasRenderActions {
                ToolbarItem(placement: .topBarTrailing) {
                    self.renderMenu
                }
            }
        }
        .task(id: self.scanProjectID) {
            self.controller.prepareIfNeeded()
        }
        .task(id: self.activeScanTaskID) {
            await self.loadActiveScan()
        }
        .onDisappear {
            self.versionSelector?.onPresentationChanged(false)
        }
        .sensoryFeedback(.success, trigger: self.didMakeScanActive)
        .sensoryFeedback(.error, trigger: self.didFailToMakeScanActive)
        .confirmationPrompt(self.$activeScanConfirmation)
        .alert(
            "Scanner Error",
            isPresented: Binding(
                get: { self.controller.errorMessage != nil },
                set: {
                    if !$0 {
                        self.controller.dismissError()
                    }
                }
            ),
            actions: {
                Button("OK", role: .cancel) {
                    self.controller.dismissError()
                }
            },
            message: {
                Text(self.controller.errorMessage ?? "")
            }
        )
        .alert(
            self.activeScanAlert?.title ?? "",
            isPresented: self.activeScanAlertBinding,
            presenting: self.activeScanAlert
        ) { _ in
            Button("OK", role: .cancel) {}
        } message: { alert in
            Text(alert.message)
        }
    }

    // MARK: Private

    @StateObject private var controller: ScanSessionController
    @EnvironmentObject private var zoneScanArchiveCacheService: ZoneScanArchiveCacheService
    @EnvironmentObject private var remoteProjectsDataCoordinator: RemoteProjectsDataCoordinator
    @State private var isShowingScanSelector = false
    @State private var isLoadingScanArchives = false
    @State private var scanArchives: [ZoneScanArchiveOption] = []
    @State private var scanArchivePageIndex = 0
    @State private var hasNextScanArchivePage = false
    @State private var scanArchiveErrorMessage: String?
    @State private var selectingScanArchiveID: String?
    @State private var isShowingMovementGuide = false
    @State private var activeScanProjectID: UUID?
    @State private var isMakingScanActive = false
    @State private var activeScanConfirmation: ConfirmationPrompt?
    @State private var activeScanAlert: ZoneActiveScanAlert?
    @State private var didMakeScanActive = false
    @State private var didFailToMakeScanActive = false

    private var canShowScanSelector: Bool {
        self.versionSelector != nil
            || (self.showsScanSelector
                && self.project?.remoteID != nil
                && self.zone != nil
                && self.remoteOrganizationID != nil)
    }

    private var remoteOrganizationID: String? {
        self.project?.owningRemoteOrganizationID
            ?? self.remoteProjectsDataCoordinator.selectedOrganizationID
    }

    private var hasRenderActions: Bool {
        self.onScanAgain != nil || self.previewFileURL != nil || self.canManageActiveScan
    }

    private var canManageActiveScan: Bool {
        guard self.project?.remoteID != nil,
              self.zone != nil,
              let organizationID = self.remoteOrganizationID,
              let organization = self.remoteProjectsDataCoordinator.organizations.first(where: {
                  $0.id == organizationID
              })
        else {
            return false
        }
        let role = OrgRole(apiValue: organization.role)
        return role == .owner || role == .admin
    }

    private var activeScanTaskID: String {
        [
            self.project?.id.uuidString ?? "none",
            self.project?.remoteID ?? "local",
            self.zone?.id.uuidString ?? "none",
            self.scanProjectID.uuidString,
        ].joined(separator: "|")
    }

    private var activeScanAlertBinding: Binding<Bool> {
        Binding(
            get: { self.activeScanAlert != nil },
            set: { isPresented in
                if !isPresented {
                    self.activeScanAlert = nil
                }
            }
        )
    }

    /// On-disk location of the raw preview point-cloud file backing this render, when present.
    private var previewFileURL: URL? {
        let url = ScanProjectStore()
            .projectDirectory(for: self.scanProjectID)
            .appendingPathComponent("preview.bin")
        return FileManager.default.fileExists(atPath: url.path) ? url : nil
    }

    private var renderMenu: some View {
        Menu {
            if let onScanAgain {
                Button {
                    onScanAgain()
                } label: {
                    Label("Scan Again", systemImage: "viewfinder")
                }
            }
            if let previewFileURL {
                ShareLink(item: previewFileURL) {
                    Label("Export raw preview", systemImage: "square.and.arrow.up")
                }
            }
            if self.canManageActiveScan {
                Divider()
                if self.activeScanProjectID == self.scanProjectID {
                    Button {} label: {
                        Label("Active for Merge", systemImage: "checkmark.circle.fill")
                    }
                    .disabled(true)
                } else {
                    Button {
                        self.confirmMakeDisplayedScanActive()
                    } label: {
                        Label("Make Active", systemImage: "checkmark.circle")
                    }
                    .disabled(self.isMakingScanActive)
                }
            }
        } label: {
            Image(systemName: "ellipsis.circle")
                .font(.system(size: PointCloudViewerControlStyle.iconSize, weight: .semibold))
                .frame(width: PointCloudViewerControlStyle.size, height: PointCloudViewerControlStyle.size)
        }
        .accessibilityLabel("Zone actions")
    }

    private var renderControls: some View {
        VStack(alignment: .trailing, spacing: 8) {
            if self.canShowScanSelector {
                self.scanSelectorButton
            }

            PointCloudMovementGuideButton(
                isPresented: self.$isShowingMovementGuide,
                accessibilityIdentifier: "zoneScanMovementGuideButton"
            )

            if self.canShowScanSelector, self.isShowingScanSelector {
                self.versionOverlay
                    .transition(.scale(scale: 0.94, anchor: .topTrailing).combined(with: .opacity))
            }
        }
    }

    @ViewBuilder
    private var versionOverlay: some View {
        if let versionSelector {
            PointCloudVersionOverlay(
                title: versionSelector.title,
                options: versionSelector.options,
                isLoading: versionSelector.isLoading,
                selectingID: versionSelector.selectingID,
                errorMessage: versionSelector.errorMessage,
                pagination: nil,
                onRefresh: versionSelector.onRefresh,
                onSelect: { optionID in
                    withAnimation(.spring(response: 0.28, dampingFraction: 0.85)) {
                        self.isShowingScanSelector = false
                    }
                    versionSelector.onPresentationChanged(false)
                    versionSelector.onSelect(optionID)
                }
            )
        } else {
            ZoneScanArchiveOverlay(
                archives: self.scanArchives,
                currentScanProjectID: self.scanProjectID,
                activeScanProjectID: self.activeScanProjectID,
                isLoading: self.isLoadingScanArchives,
                selectingArchiveID: self.selectingScanArchiveID,
                errorMessage: self.scanArchiveErrorMessage,
                pagination: PointCloudVersionPagination(
                    pageIndex: self.scanArchivePageIndex,
                    hasNextPage: self.hasNextScanArchivePage,
                    onPreviousPage: {
                        Task {
                            await self.loadScanArchives(page: self.scanArchivePageIndex - 1, force: true)
                        }
                    },
                    onNextPage: {
                        Task {
                            await self.loadScanArchives(page: self.scanArchivePageIndex + 1, force: true)
                        }
                    }
                ),
                onRefresh: {
                    Task {
                        await self.loadScanArchives(force: true)
                    }
                },
                onSelect: { archive in
                    Task {
                        await self.selectScanArchive(archive)
                    }
                }
            )
        }
    }

    private var scanSelectorButton: some View {
        Button {
            withAnimation(.spring(response: 0.28, dampingFraction: 0.85)) {
                self.isShowingScanSelector.toggle()
            }
            self.versionSelector?.onPresentationChanged(self.isShowingScanSelector)
            if self.versionSelector == nil, self.isShowingScanSelector, self.scanArchives.isEmpty {
                Task {
                    await self.loadScanArchives()
                }
            }
        } label: {
            Image(systemName: "clock.arrow.circlepath")
                .font(.system(size: PointCloudViewerControlStyle.iconSize, weight: .semibold))
                .foregroundStyle(Color("TextPrimary"))
                .frame(width: PointCloudViewerControlStyle.size, height: PointCloudViewerControlStyle.size)
                .background(.regularMaterial, in: Circle())
                .overlay(
                    Circle()
                        .stroke(Color.white.opacity(0.28), lineWidth: 0.75)
                )
                .shadow(color: .black.opacity(0.18), radius: 12, x: 0, y: 5)
        }
        .buttonStyle(.plain)
        .accessibilityLabel(self.versionSelector?.accessibilityLabel ?? "Zone scans")
        .accessibilityValue(self.isShowingScanSelector ? "Shown" : "Hidden")
        .accessibilityIdentifier("zoneScanArchiveToggle")
    }

    /// Loads one page of scan history. Refreshing (page 0) also re-adopts the server's
    /// active-scan pointer, which the page fetch returns alongside the rows.
    private func loadScanArchives(page: Int = 0, force: Bool = false) async {
        guard !self.isLoadingScanArchives else { return }
        guard force || self.scanArchives.isEmpty else { return }
        guard let project, let zone, let remoteProjectID = project.remoteID,
              let organizationID = self.remoteOrganizationID
        else {
            return
        }

        self.isLoadingScanArchives = true
        self.scanArchiveErrorMessage = nil

        do {
            let archivePage = try await self.zoneScanArchiveCacheService.listScanArchivePage(
                localProjectID: project.id,
                organizationID: organizationID,
                remoteProjectID: remoteProjectID,
                zoneID: zone.id,
                page: page
            )
            self.scanArchives = archivePage.options
            self.scanArchivePageIndex = archivePage.pageIndex
            self.hasNextScanArchivePage = archivePage.hasNextPage
            self.activeScanProjectID = archivePage.activeScanProjectID
        } catch {
            self.scanArchiveErrorMessage = "Couldn’t load scans."
        }

        self.isLoadingScanArchives = false
    }

    private func selectScanArchive(_ archive: ZoneScanArchiveOption) async {
        guard archive.isSelectable else { return }
        guard archive.previewID != self.scanProjectID else {
            withAnimation(.spring(response: 0.28, dampingFraction: 0.85)) {
                self.isShowingScanSelector = false
            }
            return
        }
        guard let project, let zone, let remoteProjectID = project.remoteID,
              let organizationID = self.remoteOrganizationID
        else {
            return
        }

        self.onScanSelectionStarted()
        self.selectingScanArchiveID = archive.id
        self.scanArchiveErrorMessage = nil

        do {
            try await self.zoneScanArchiveCacheService.selectScanArchivePreview(
                localProjectID: project.id,
                organizationID: organizationID,
                remoteProjectID: remoteProjectID,
                zoneID: zone.id,
                archive: archive
            )
            withAnimation(.spring(response: 0.28, dampingFraction: 0.85)) {
                self.isShowingScanSelector = false
            }
        } catch {
            self.scanArchiveErrorMessage = "Couldn’t load that scan."
        }

        self.selectingScanArchiveID = nil
    }

    private func loadActiveScan() async {
        guard let project, let zone, let remoteProjectID = project.remoteID,
              let organizationID = self.remoteOrganizationID
        else {
            return
        }

        do {
            self.activeScanProjectID = try await self.zoneScanArchiveCacheService.fetchActiveScanProjectID(
                localProjectID: project.id,
                organizationID: organizationID,
                remoteProjectID: remoteProjectID,
                zoneID: zone.id
            )
        } catch {
            // Active state is supplemental; browsing and exporting remain available if it fails.
        }
    }

    private func confirmMakeDisplayedScanActive() {
        self.activeScanConfirmation = ConfirmationPrompt(
            icon: "checkmark.circle",
            tint: Color("Primary"),
            title: "Make this scan active?",
            message: "Future merge jobs will use this scan version for this zone. This does not start a merge job.",
            confirmTitle: "Make active",
            confirmIcon: "checkmark.circle"
        ) {
            Task {
                await self.makeDisplayedScanActive()
            }
        }
    }

    private func makeDisplayedScanActive() async {
        guard let project, let zone, let remoteProjectID = project.remoteID,
              let organizationID = self.remoteOrganizationID
        else {
            self.presentActiveScanFailure("This scan is not connected to the server.")
            return
        }

        self.isMakingScanActive = true
        defer { self.isMakingScanActive = false }

        do {
            self.activeScanProjectID = try await self.zoneScanArchiveCacheService.selectScanArchiveForMerge(
                localProjectID: project.id,
                organizationID: organizationID,
                remoteProjectID: remoteProjectID,
                zoneID: zone.id,
                scanProjectID: self.scanProjectID
            )
            self.activeScanAlert = ZoneActiveScanAlert(
                title: "Active scan updated",
                message: "Future merge jobs will use this scan version for \(zone.name)."
            )
            self.didMakeScanActive.toggle()
        } catch {
            self.presentActiveScanFailure(self.activeScanErrorMessage(for: error))
        }
    }

    private func presentActiveScanFailure(_ message: String) {
        self.activeScanAlert = ZoneActiveScanAlert(title: "Couldn’t make scan active", message: message)
        self.didFailToMakeScanActive.toggle()
    }

    private func activeScanErrorMessage(for error: Error) -> String {
        switch error {
        case RequestServiceError.missingAuthToken, RequestServiceError.unauthorized:
            "Sign in again to change the active scan."
        case RequestServiceError.forbidden:
            "Only organization owners and admins can change the active scan."
        case let RequestServiceError.conflict(message):
            message ?? "Only uploaded scan versions can be made active."
        case RequestServiceError.network:
            "Couldn’t reach the server. Check your connection and try again."
        default:
            error.localizedDescription
        }
    }
}

// MARK: - ZoneActiveScanAlert

private struct ZoneActiveScanAlert: Identifiable {
    let id = UUID()
    let title: String
    let message: String
}
