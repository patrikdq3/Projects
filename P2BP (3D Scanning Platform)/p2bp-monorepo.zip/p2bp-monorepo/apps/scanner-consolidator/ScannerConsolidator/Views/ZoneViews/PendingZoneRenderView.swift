import SwiftUI

// MARK: - PendingZoneRenderView

struct PendingZoneRenderView: View {
    // MARK: Internal

    let project: Project
    let zone: Zone
    let uploadStatus: ZoneScanUploadStatus?
    let onStart: () -> Void
    let onResume: () -> Void
    let onScanAgain: () -> Void

    var body: some View {
        ZStack(alignment: .bottomLeading) {
            ProjectZoneMapView(
                project: self.project,
                focusedZoneID: self.zone.id,
                isInteractive: false
            )
            .ignoresSafeArea(edges: .bottom)

            VStack(alignment: .leading, spacing: 8) {
                ZoneStatusPill(status: self.zone.status)
                if let uploadStatus {
                    ZoneUploadStatusBadge(status: uploadStatus)
                }
                Text(self.emptyStateText)
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundStyle(Color("TextPrimary"))
            }
            .padding(16)
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottomLeading)
            .background {
                LinearGradient(
                    colors: [.clear, Color.black.opacity(0.42)],
                    startPoint: .center,
                    endPoint: .bottom
                )
                .ignoresSafeArea()
            }
        }
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                self.pendingMenu
            }
        }
    }

    // MARK: Private

    private var emptyStateText: String {
        switch self.zone.scanState {
        case .notStarted:
            "No render yet. Start a LiDAR pass from this zone."
        case .inProgress:
            "Scan in progress. Resume capture to finish the render."
        case .complete:
            "No render preview is available for this completed scan."
        }
    }

    private var pendingMenu: some View {
        Menu {
            switch self.zone.scanState {
            case .notStarted:
                Button {
                    self.onStart()
                } label: {
                    Label("Start Scan", systemImage: "viewfinder")
                }
            case .inProgress:
                Button {
                    self.onResume()
                } label: {
                    Label("Resume Scan", systemImage: "play.fill")
                }

                Button {
                    self.onScanAgain()
                } label: {
                    Label("Start New Scan", systemImage: "viewfinder")
                }
            case .complete:
                Button {
                    self.onScanAgain()
                } label: {
                    Label("Scan Again", systemImage: "viewfinder")
                }
            }
        } label: {
            Image(systemName: "ellipsis.circle")
        }
        .accessibilityLabel("Zone actions")
    }
}
