import SwiftUI

// MARK: - ZoneScannerPresentation

enum ZoneScannerPresentation: String, Identifiable {
    case start
    case resume

    // MARK: Internal

    var id: String {
        rawValue
    }
}

// MARK: - ZoneScannerContainerView

struct ZoneScannerContainerView: View {
    // MARK: Internal

    let projectID: UUID
    let projectName: String
    let zoneID: UUID
    let zoneName: String
    let scanProjectID: UUID?
    let presentation: ZoneScannerPresentation
    let onReturnToProjectMap: () -> Void

    var body: some View {
        Group {
            if let completedScanProjectID {
                CompletedZoneRenderView(
                    scanProjectID: completedScanProjectID,
                    onScanAgain: nil,
                    showsScanSelector: false
                )
                .safeAreaInset(edge: .bottom) {
                    if !self.didConfirmCompletedScan {
                        self.confirmationBar
                    }
                }
            } else {
                ScannerFeatureView(
                    title: self.zoneName,
                    subtitle: self.projectName,
                    entryMode: self.entryMode,
                    zoneFootprint: self.zone?.footprint,
                    projectBoundary: self.project?.boundary,
                    onStateChange: { phase, manifest in
                        self.latestPhase = phase
                        self.latestManifest = manifest
                    }
                )
            }
        }
        .navigationTitle(self.zoneName)
        .navigationBarTitleDisplayMode(.inline)
        .sensoryFeedback(.success, trigger: self.didConfirmCompletedScan)
        .sensoryFeedback(.warning, trigger: self.didDiscardCompletedScan)
        .onDisappear {
            self.handleDisappear()
        }
        .alert("Couldn’t Update Zone", isPresented: Binding(
            get: { self.errorMessage != nil },
            set: { isPresented in
                if !isPresented {
                    self.errorMessage = nil
                }
            }
        )) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(self.errorMessage ?? "")
        }
    }

    // MARK: Private

    @EnvironmentObject private var projectStore: ProjectStore
    @EnvironmentObject private var zoneScanArchiveCacheService: ZoneScanArchiveCacheService
    @EnvironmentObject private var remoteProjectsDataCoordinator: RemoteProjectsDataCoordinator
    @State private var latestPhase: ScanSessionController.ScanPhase = .idle
    @State private var latestManifest: ScanProjectManifest?
    @State private var didConfirmCompletedScan = false
    @State private var didDiscardCompletedScan = false
    @State private var isConfirmingScan = false
    @State private var errorMessage: String?

    private var project: Project? {
        self.projectStore.project(withID: self.projectID)
    }

    private var zone: Zone? {
        self.project?.zones.first { $0.id == self.zoneID }
    }

    private var remoteOrganizationID: String? {
        self.project?.owningRemoteOrganizationID
            ?? self.remoteProjectsDataCoordinator.selectedOrganizationID
    }

    private var entryMode: ScanSessionController.EntryMode {
        switch self.presentation {
        case .start:
            .newZone
        case .resume:
            if let scanProjectID {
                .resumeZone(scanProjectID)
            } else {
                .newZone
            }
        }
    }

    private var completedScanProjectID: UUID? {
        guard self.latestPhase == .preview,
              self.latestManifest?.state == .completed
        else {
            return nil
        }

        return self.latestManifest?.id
    }

    private var confirmationBar: some View {
        HStack(spacing: 12) {
            Button(role: .destructive) {
                self.discardCompletedScanAndDismiss()
            } label: {
                Label("Discard", systemImage: "xmark")
                    .font(.system(size: 15, weight: .bold))
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 15)
                    .background(
                        .thinMaterial,
                        in: RoundedRectangle(cornerRadius: 18, style: .continuous)
                    )
                    .overlay(
                        RoundedRectangle(cornerRadius: 18, style: .continuous)
                            .stroke(Color("Warning").opacity(0.34), lineWidth: 1)
                    )
            }
            .buttonStyle(.plain)
            .foregroundStyle(Color("Warning"))
            .disabled(self.isConfirmingScan)
            .accessibilityIdentifier("discardZoneScanButton")

            Button {
                self.confirmCompletedScan()
            } label: {
                HStack(spacing: 8) {
                    if self.isConfirmingScan {
                        ProgressView()
                            .controlSize(.small)
                    }
                    Text("Confirm Scan")
                        .font(.system(size: 16, weight: .bold))
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 15)
                .background(
                    LinearGradient(
                        colors: [
                            Color("Primary"),
                            Color("Primary").opacity(0.82),
                        ],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    ),
                    in: RoundedRectangle(cornerRadius: 18, style: .continuous)
                )
                .overlay(
                    RoundedRectangle(cornerRadius: 18, style: .continuous)
                        .stroke(Color.white.opacity(0.34), lineWidth: 1)
                )
                .shadow(color: Color("Primary").opacity(0.32), radius: 14, x: 0, y: 8)
            }
            .buttonStyle(.plain)
            .foregroundStyle(.white)
            .disabled(self.isConfirmingScan)
            .accessibilityIdentifier("confirmZoneScanButton")
        }
        .padding(.horizontal, 16)
        .padding(.top, 12)
        .padding(.bottom, 10)
        .background(.ultraThinMaterial)
    }

    private func handleDisappear() {
        guard let latestManifest else {
            return
        }

        if latestManifest.state == .completed || self.latestPhase == .preview {
            self.discardPendingCompletedScanIfNeeded()
        } else if self.shouldPreserveExistingZoneScan(insteadOf: latestManifest) {
            self.discardUnconfirmedScan(manifest: latestManifest)
        } else {
            self.persistZoneState()
        }
    }

    private func persistZoneState() {
        guard let latestManifest else {
            return
        }

        let scanState: ZoneStatus = switch latestManifest.state {
        case .completed:
            .complete
        case .capturing, .failed:
            .inProgress
        }

        do {
            try self.projectStore.updateZoneScan(
                projectID: self.projectID,
                zoneID: self.zoneID,
                scanProjectID: latestManifest.id,
                scanState: self.latestPhase == .preview ? .complete : scanState
            )
        } catch {
            assertionFailure("Failed to sync zone scan state: \(error.localizedDescription)")
        }
    }

    private func confirmCompletedScan() {
        guard let latestManifest else { return }

        self.isConfirmingScan = true

        do {
            try self.projectStore.updateZoneScan(
                projectID: self.projectID,
                zoneID: self.zoneID,
                scanProjectID: latestManifest.id,
                scanState: .complete
            )
            self.didConfirmCompletedScan = true
            self.enqueueUploadIfNeeded(manifest: latestManifest, scanState: .complete)
            self.onReturnToProjectMap()
        } catch {
            self.errorMessage = error.localizedDescription
        }

        self.isConfirmingScan = false
    }

    private func discardCompletedScanAndDismiss() {
        if self.discardPendingCompletedScanIfNeeded() {
            self.onReturnToProjectMap()
        }
    }

    @discardableResult
    private func discardPendingCompletedScanIfNeeded() -> Bool {
        guard let latestManifest,
              latestManifest.state == .completed || self.latestPhase == .preview,
              !self.didConfirmCompletedScan,
              !self.didDiscardCompletedScan
        else {
            return true
        }

        do {
            try ScanProjectStore().deleteProject(id: latestManifest.id)
            if !self.shouldPreserveExistingZoneScan(insteadOf: latestManifest) {
                try self.projectStore.updateZoneScan(
                    projectID: self.projectID,
                    zoneID: self.zoneID,
                    scanProjectID: nil,
                    scanState: .notStarted
                )
            }
            self.didDiscardCompletedScan = true
            return true
        } catch {
            self.errorMessage = error.localizedDescription
            return false
        }
    }

    private func shouldPreserveExistingZoneScan(insteadOf manifest: ScanProjectManifest) -> Bool {
        guard let zone else { return false }
        guard zone.scanProjectID != nil || zone.scanState != .notStarted else { return false }
        return zone.scanProjectID != manifest.id
    }

    private func discardUnconfirmedScan(manifest: ScanProjectManifest) {
        guard !self.didConfirmCompletedScan, !self.didDiscardCompletedScan else {
            return
        }

        do {
            try ScanProjectStore().deleteProject(id: manifest.id)
            self.didDiscardCompletedScan = true
        } catch {
            self.errorMessage = error.localizedDescription
        }
    }

    private func enqueueUploadIfNeeded(manifest: ScanProjectManifest, scanState: ZoneStatus) {
        guard scanState == .complete || self.latestPhase == .preview else { return }
        guard let remoteProjectID = self.project?.remoteID else {
            self.zoneScanArchiveCacheService.markUploadUnavailable(
                zoneID: self.zoneID,
                scanProjectID: manifest.id,
                reason: .localProject
            )
            return
        }
        guard let organizationID = self.remoteOrganizationID else {
            self.zoneScanArchiveCacheService.markUploadUnavailable(
                zoneID: self.zoneID,
                scanProjectID: manifest.id,
                reason: .missingOrganization
            )
            return
        }
        guard let zone = self.zone else { return }

        self.zoneScanArchiveCacheService.enqueueCompletedScan(
            localProjectID: self.projectID,
            organizationID: organizationID,
            remoteProjectID: remoteProjectID,
            zone: zone,
            scanProjectID: manifest.id
        )
    }
}
