import SwiftUI

// MARK: - ZoneUploadStatusBadge

struct ZoneUploadStatusBadge: View {
    // MARK: Internal

    let status: ZoneScanUploadStatus

    var body: some View {
        HStack(spacing: 7) {
            if self.status.state == .uploading {
                ProgressView()
                    .controlSize(.small)
            } else {
                Image(systemName: self.iconName)
                    .font(.system(size: 12, weight: .bold))
                    .foregroundStyle(self.tint)
            }

            VStack(alignment: .leading, spacing: 1) {
                Text(self.title)
                    .font(.system(size: 11.5, weight: .bold))
                    .foregroundStyle(Color("TextPrimary"))
                    .lineLimit(1)

                Text(self.status.detail)
                    .font(.system(size: 10.5, weight: .medium))
                    .foregroundStyle(Color("TextSecondary"))
                    .lineLimit(2)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 7)
        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 8, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 8, style: .continuous)
                .stroke(self.tint.opacity(0.45), lineWidth: 0.75)
        )
        .accessibilityElement(children: .combine)
        .accessibilityLabel("Zone upload status")
        .accessibilityValue("\(self.title), \(self.status.detail)")
    }

    // MARK: Private

    private var title: String {
        switch self.status.state {
        case .queued:
            "Upload Queued"
        case .uploading:
            "Uploading"
        case .uploaded:
            "Uploaded"
        case .failed:
            "Upload Failed"
        case .unavailable:
            "Not Uploading"
        }
    }

    private var iconName: String {
        switch self.status.state {
        case .queued:
            "clock"
        case .uploading:
            "arrow.up.circle"
        case .uploaded:
            "checkmark.circle.fill"
        case .failed:
            "exclamationmark.triangle.fill"
        case .unavailable:
            "icloud.slash"
        }
    }

    private var tint: Color {
        switch self.status.state {
        case .queued, .uploading:
            Color("Primary")
        case .uploaded:
            Color("Success")
        case .failed, .unavailable:
            Color("Warning")
        }
    }
}
