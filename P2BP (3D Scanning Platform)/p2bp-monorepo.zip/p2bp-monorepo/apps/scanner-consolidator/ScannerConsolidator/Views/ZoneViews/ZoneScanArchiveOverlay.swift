import SwiftUI

// MARK: - PointCloudVersionOption

struct PointCloudVersionOption: Identifiable {
    let id: String
    let title: String
    let subtitle: String
    /// Leading symbol for the row; omit for plain rows.
    let icon: String?
    let tint: Color
    let isCurrent: Bool
    let isSelectable: Bool
    /// Short marker rendered as a capsule next to the subtitle (e.g. "Active").
    var badge: String?
}

// MARK: - PointCloudVersionPagination

/// Arrow-based page controls shown at the bottom of the version list. `pageIndex` is
/// zero-based; the left arrow steps to newer pages and the right arrow to older ones.
struct PointCloudVersionPagination {
    let pageIndex: Int
    let hasNextPage: Bool
    let onPreviousPage: () -> Void
    let onNextPage: () -> Void
}

// MARK: - PointCloudVersionSelectorConfiguration

struct PointCloudVersionSelectorConfiguration {
    let title: String
    let options: [PointCloudVersionOption]
    let isLoading: Bool
    let selectingID: String?
    let errorMessage: String?
    let accessibilityLabel: String
    let onRefresh: () -> Void
    let onSelect: (String) -> Void
    let onPresentationChanged: (Bool) -> Void
}

// MARK: - PointCloudVersionOverlay

/// Shared version picker chrome used by zone scans and project mesh jobs.
struct PointCloudVersionOverlay: View {
    // MARK: Internal

    let title: String
    let options: [PointCloudVersionOption]
    let isLoading: Bool
    let selectingID: String?
    let errorMessage: String?
    let pagination: PointCloudVersionPagination?
    let onRefresh: () -> Void
    let onSelect: (String) -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 8) {
                Text(self.title)
                    .font(.system(size: 15, weight: .bold))
                    .foregroundStyle(Color("TextPrimary"))

                Spacer(minLength: 8)

                Button(action: self.onRefresh) {
                    Image(systemName: "arrow.clockwise")
                        .font(.system(size: 12, weight: .bold))
                        .foregroundStyle(Color("TextSecondary"))
                        .frame(width: 26, height: 26)
                        .background(Color("SurfaceSecondary"), in: Circle())
                }
                .buttonStyle(.plain)
                .disabled(self.isLoading)
                .accessibilityLabel("Refresh \(self.title.lowercased())")
            }

            if self.isLoading, self.options.isEmpty {
                HStack(spacing: 10) {
                    ProgressView()
                        .controlSize(.small)
                    Text("Loading \(self.title.lowercased())")
                        .font(.system(size: 13, weight: .medium))
                        .foregroundStyle(Color("TextSecondary"))
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.vertical, 8)
            } else if self.options.isEmpty {
                Text("No versions found.")
                    .font(.system(size: 13, weight: .medium))
                    .foregroundStyle(Color("TextSecondary"))
                    .padding(.vertical, 8)
            } else {
                ScrollView {
                    LazyVStack(spacing: 6) {
                        ForEach(self.options) { option in
                            self.versionRow(option)
                        }

                        if let pagination, pagination.pageIndex > 0 || pagination.hasNextPage {
                            self.paginationRow(pagination)
                        }
                    }
                }
                .frame(maxHeight: 300)
            }

            if let errorMessage {
                Text(errorMessage)
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundStyle(Color("Warning"))
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
        }
        .padding(12)
        .frame(width: 286)
        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .stroke(Color.white.opacity(0.22), lineWidth: 0.75)
        )
        .shadow(color: .black.opacity(0.22), radius: 22, x: 0, y: 10)
    }

    // MARK: Private

    private func badgeView(_ badge: String) -> some View {
        HStack(spacing: 3) {
            Image(systemName: "arrow.triangle.merge")
                .font(.system(size: 8, weight: .bold))
            Text(badge)
                .font(.system(size: 9, weight: .heavy))
        }
        .foregroundStyle(Color("Success"))
        .padding(.horizontal, 6)
        .padding(.vertical, 2.5)
        .background(Color("Success").opacity(0.14), in: Capsule())
        .accessibilityLabel("\(badge) version")
    }

    private func paginationRow(_ pagination: PointCloudVersionPagination) -> some View {
        HStack(spacing: 10) {
            self.pageArrowButton(
                systemImage: "chevron.left",
                accessibilityLabel: "Newer \(self.title.lowercased())",
                accessibilityIdentifier: "pointCloudVersionPreviousPage",
                isEnabled: pagination.pageIndex > 0,
                action: pagination.onPreviousPage
            )

            Spacer(minLength: 6)

            Text("Page \(pagination.pageIndex + 1)")
                .font(.system(size: 11.5, weight: .semibold))
                .foregroundStyle(Color("TextSecondary"))

            Spacer(minLength: 6)

            self.pageArrowButton(
                systemImage: "chevron.right",
                accessibilityLabel: "Older \(self.title.lowercased())",
                accessibilityIdentifier: "pointCloudVersionNextPage",
                isEnabled: pagination.hasNextPage,
                action: pagination.onNextPage
            )
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 4)
    }

    private func pageArrowButton(
        systemImage: String,
        accessibilityLabel: String,
        accessibilityIdentifier: String,
        isEnabled: Bool,
        action: @escaping () -> Void
    ) -> some View {
        Button(action: action) {
            Image(systemName: systemImage)
                .font(.system(size: 12, weight: .bold))
                .foregroundStyle(Color("TextSecondary"))
                .frame(width: 26, height: 26)
                .background(Color("SurfaceSecondary"), in: Circle())
        }
        .buttonStyle(.plain)
        .disabled(!isEnabled || self.isLoading || self.selectingID != nil)
        .accessibilityLabel(accessibilityLabel)
        .accessibilityIdentifier(accessibilityIdentifier)
    }

    private func versionRow(_ option: PointCloudVersionOption) -> some View {
        let isSelecting = self.selectingID == option.id

        return Button {
            self.onSelect(option.id)
        } label: {
            HStack(spacing: 10) {
                if let icon = option.icon {
                    Image(systemName: icon)
                        .font(.system(size: 17, weight: .semibold))
                        .foregroundStyle(option.tint)
                        .frame(width: 22)
                }

                VStack(alignment: .leading, spacing: 3) {
                    Text(option.title)
                        .font(.system(size: 13.5, weight: .semibold))
                        .foregroundStyle(Color("TextPrimary"))
                        .lineLimit(1)

                    HStack(spacing: 5) {
                        Text(option.subtitle)
                            .font(.system(size: 11.5, weight: .medium))
                            .foregroundStyle(Color("TextSecondary"))
                            .lineLimit(2)

                        if let badge = option.badge {
                            self.badgeView(badge)
                        }
                    }
                }

                Spacer(minLength: 6)

                if isSelecting {
                    ProgressView()
                        .controlSize(.small)
                } else if option.isSelectable, !option.isCurrent {
                    Image(systemName: "chevron.right")
                        .font(.system(size: 11, weight: .bold))
                        .foregroundStyle(Color("TextTertiary"))
                }
            }
            .padding(.horizontal, 10)
            .padding(.vertical, 9)
            .background(
                option.isCurrent ? Color("Primary").opacity(0.12) : Color("Surface").opacity(0.88),
                in: RoundedRectangle(cornerRadius: 12, style: .continuous)
            )
        }
        .buttonStyle(.plain)
        .disabled(!option.isSelectable || option.isCurrent || self.selectingID != nil)
        .accessibilityIdentifier("pointCloudVersionRow_\(option.id)")
    }
}

// MARK: - ZoneScanArchiveOverlay

struct ZoneScanArchiveOverlay: View {
    // MARK: Internal

    let archives: [ZoneScanArchiveOption]
    let currentScanProjectID: UUID
    /// The archive the server will use for merge jobs; its row is marked with an "Active" badge.
    let activeScanProjectID: UUID?
    let isLoading: Bool
    let selectingArchiveID: String?
    let errorMessage: String?
    let pagination: PointCloudVersionPagination?
    let onRefresh: () -> Void
    let onSelect: (ZoneScanArchiveOption) -> Void

    var body: some View {
        PointCloudVersionOverlay(
            title: "Scans",
            options: self.archives.map(self.versionOption),
            isLoading: self.isLoading,
            selectingID: self.selectingArchiveID,
            errorMessage: self.errorMessage,
            pagination: self.pagination,
            onRefresh: self.onRefresh,
            onSelect: { archiveID in
                guard let archive = self.archives.first(where: { $0.id == archiveID }) else { return }
                self.onSelect(archive)
            }
        )
    }

    // MARK: Private

    private func versionOption(_ archive: ZoneScanArchiveOption) -> PointCloudVersionOption {
        let isCurrent = archive.previewID == self.currentScanProjectID
        let isActive = archive.previewID != nil && archive.previewID == self.activeScanProjectID
        return PointCloudVersionOption(
            id: archive.id,
            title: self.archiveTitle(archive),
            subtitle: self.archiveStatusText(archive),
            icon: nil,
            tint: Color("TextSecondary"),
            isCurrent: isCurrent,
            isSelectable: archive.isSelectable,
            badge: isActive ? "Active" : nil
        )
    }

    private func archiveTitle(_ archive: ZoneScanArchiveOption) -> String {
        if let createdAt = archive.createdAt {
            return createdAt.formatted(date: .abbreviated, time: .shortened)
        }
        return "Scan \(archive.id.prefix(8))"
    }

    private func archiveStatusText(_ archive: ZoneScanArchiveOption) -> String {
        if archive.previewID == self.currentScanProjectID {
            return "Currently shown"
        }
        guard archive.isSelectable else {
            return archive.uploadStatus.displayName
        }
        if let previewUploadStatus = archive.previewUploadStatus, previewUploadStatus != .uploaded {
            return "Preview \(previewUploadStatus.displayName.lowercased())"
        }
        return "Ready to view"
    }
}
