import SwiftUI

// MARK: - ProfileView

/// Account / device profile sheet, opened from the avatar in the Projects toolbar.
struct ProfileView: View {
    // MARK: Internal

    let user: User?
    /// Invoked after `AuthService.logout()` completes so the host can route back to sign-in.
    let onSignOut: () -> Void

    var body: some View {
        VStack(spacing: 20) {
            self.identityHeader
            self.signOutButton
        }
        .padding(.top, 24)
        .padding(.bottom, 28)
        .background(Color("Surface").ignoresSafeArea())
        .presentationDetents([.height(220)])
        .presentationDragIndicator(.hidden)
        .alert("Sign out failed", isPresented: self.$logoutFailed) {
            Button("OK", role: .cancel) {}
        } message: {
            Text("We couldn't sign you out. Check your connection and try again.")
        }
    }

    // MARK: Private

    @State private var isSigningOut = false
    @State private var logoutFailed = false

    // MARK: Derived values

    private var displayName: String {
        let name = self.user?.name.trimmingCharacters(in: .whitespaces) ?? ""
        if !name.isEmpty {
            return name
        }
        if let local = self.user?.email.split(separator: "@").first {
            return String(local)
        }
        return "Your account"
    }

    private var displayEmail: String {
        self.user?.email ?? "Not signed in"
    }

    private var joinedText: String {
        guard let createdAt = self.user?.createdAt, let date = Self.createdAtDate(from: createdAt) else {
            return "Joined in —"
        }
        let formatter = DateFormatter()
        formatter.dateFormat = "MMMM yyyy"
        return "Joined in \(formatter.string(from: date))"
    }

    private var identityHeader: some View {
        HStack(spacing: 14) {
            ProfileAvatar(user: self.user, size: 56)

            VStack(alignment: .leading, spacing: 2) {
                Text(self.displayName)
                    .font(.system(size: 20, weight: .semibold))
                    .foregroundStyle(Color("TextPrimary"))
                Text(self.displayEmail)
                    .font(.system(size: 14))
                    .foregroundStyle(Color("TextSecondary"))
                Text(self.joinedText)
                    .font(.system(size: 12))
                    .foregroundStyle(Color("TextSecondary").opacity(0.7))
                    .padding(.top, 2)
            }

            Spacer(minLength: 0)
        }
        .padding(.horizontal, 20)
    }

    private var signOutButton: some View {
        Button(action: self.signOut) {
            HStack(spacing: 8) {
                if self.isSigningOut {
                    ProgressView().tint(Color("Error"))
                } else {
                    Image(systemName: "rectangle.portrait.and.arrow.right")
                        .font(.system(size: 14, weight: .semibold))
                    Text("Sign out")
                        .font(.system(size: 15, weight: .medium))
                }
            }
            .foregroundStyle(Color("Error"))
            .frame(maxWidth: .infinity, minHeight: 50)
            .background(Color("Error").opacity(0.08))
            .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
        }
        .buttonStyle(.plain)
        .disabled(self.isSigningOut)
        .padding(.horizontal, 20)
        .padding(.top, 4)
        .accessibilityIdentifier("signOutButton")
    }

    private static func createdAtDate(from value: String) -> Date? {
        let isoFormatter = ISO8601DateFormatter()
        isoFormatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        if let date = isoFormatter.date(from: value) {
            return date
        }

        isoFormatter.formatOptions = [.withInternetDateTime]
        return isoFormatter.date(from: value)
    }

    private func signOut() {
        guard !self.isSigningOut else { return }
        self.isSigningOut = true
        Task {
            let signedOut = await AuthService.shared.logout()
            await MainActor.run {
                self.isSigningOut = false
                if signedOut {
                    self.onSignOut()
                } else {
                    // Logout failed — keep the user signed in and surface the error.
                    self.logoutFailed = true
                }
            }
        }
    }
}

// MARK: - ProfileAvatar

/// Circular avatar with the user's initials over the brand gradient.
struct ProfileAvatar: View {
    // MARK: Lifecycle

    init(initials: String, size: CGFloat = 32) {
        self.initials = initials
        self.size = size
    }

    init(user: User?, size: CGFloat = 32) {
        self.init(initials: Self.initials(for: user), size: size)
    }

    // MARK: Internal

    let initials: String
    var size: CGFloat = 32

    var body: some View {
        Text(self.initials)
            .font(.system(size: self.size * 0.42, weight: .semibold))
            .foregroundStyle(.white)
            .frame(width: self.size, height: self.size)
            .background(
                LinearGradient(
                    colors: [
                        Color(red: 58 / 255, green: 141 / 255, blue: 119 / 255),
                        Color(red: 46 / 255, green: 125 / 255, blue: 107 / 255),
                    ],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
            )
            .clipShape(Circle())
    }

    static func initials(for user: User?) -> String {
        if let name = user?.name.trimmingCharacters(in: .whitespaces), !name.isEmpty {
            let letters = name.split(separator: " ").prefix(2).compactMap { $0.first }
            if !letters.isEmpty {
                return letters.map { String($0).uppercased() }.joined()
            }
        }
        if let first = user?.email.trimmingCharacters(in: .whitespaces).first {
            return String(first).uppercased()
        }
        return "SC"
    }
}
