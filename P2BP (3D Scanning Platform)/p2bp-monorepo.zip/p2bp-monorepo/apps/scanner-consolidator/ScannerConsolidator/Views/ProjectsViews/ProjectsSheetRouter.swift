import SwiftUI

// MARK: - ProjectsSheetRouter

/// Maps a `ProjectsSheet` case to its destination view. Holds no state of its own — every
/// completion is delegated back to `ProjectsView` through closures so navigation, sheet
/// dismissal, and refresh work stay with the owning view.
struct ProjectsSheetRouter: View {
    let sheet: ProjectsSheet
    let currentUser: User?
    let selectedOrganizationID: Organization.ID?
    let pendingInvitations: [OrganizationsAPIInvitation]
    let onSignOut: () -> Void
    let onProjectCreated: (Project) -> Void
    let onOrganizationCreated: (ProjectsAPIOrganization) -> Void
    let onInvitationsChanged: () -> Void

    var body: some View {
        switch self.sheet {
        case .profile:
            ProfileView(user: self.currentUser, onSignOut: self.onSignOut)

        case .createProject:
            NavigationStack {
                CreateProjectView(organizationID: self.selectedOrganizationID) { project in
                    self.onProjectCreated(project)
                }
            }

        case .createOrganization:
            NavigationStack {
                CreateOrganizationView(
                    ownerName: self.currentUser?.name ?? "You",
                    ownerEmail: self.currentUser?.email ?? ""
                ) { organization in
                    self.onOrganizationCreated(organization)
                }
            }

        case .manageOrganizations:
            ManageOrganizationsView(
                currentUser: self.currentUser,
                showsDoneButton: true
            )

        case .invitations:
            InvitationsView(invitations: self.pendingInvitations) {
                self.onInvitationsChanged()
            }
        }
    }
}
