import SwiftUI

// MARK: - ProjectDetailView

/// The project hub container: a segmented toggle between the management overview, the spatial
/// map, and the scrollable zone list, plus the navigation into each zone's render or scanner.
/// The overview and zone-list surfaces live in `ProjectOverviewView` and `ProjectZonesView`.
struct ProjectDetailView: View {
    // MARK: Internal

    let projectID: UUID

    var body: some View {
        if let project = projectStore.project(withID: projectID) {
            self.content(project)
        } else {
            ContentUnavailableView("Project Missing", systemImage: "exclamationmark.triangle")
        }
    }

    // MARK: Private

    @EnvironmentObject private var projectStore: ProjectStore
    @EnvironmentObject private var zoneScanArchiveCacheService: ZoneScanArchiveCacheService
    @EnvironmentObject private var remoteProjectsDataCoordinator: RemoteProjectsDataCoordinator

    @State private var zoneDestination: ZoneDestination?
    @State private var usesSatelliteMap = true
    @State private var viewMode: ProjectViewMode = .map

    private var mapStyleToggle: some View {
        Button {
            withAnimation(.easeInOut(duration: 0.18)) {
                self.usesSatelliteMap.toggle()
            }
        } label: {
            Label(
                self.usesSatelliteMap ? "Map" : "Satellite",
                systemImage: self.usesSatelliteMap ? "map" : "globe.americas.fill"
            )
            .font(.caption.weight(.medium))
            .padding(.horizontal, 10)
            .padding(.vertical, 7)
            .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 8))
        }
        .buttonStyle(.plain)
        .accessibilityLabel("Map style")
        .accessibilityValue(self.usesSatelliteMap ? "Satellite" : "Standard")
        .accessibilityIdentifier("mapStyleToggleButton")
    }

    private func content(_ project: Project) -> some View {
        VStack(spacing: 0) {
            ProjectViewModePicker(selection: self.$viewMode)
                .padding(.horizontal, 16)
                .padding(.top, 8)
                .padding(.bottom, 10)

            // Keep the map alive underneath so its camera survives a trip to the list,
            // and slide the other surfaces in over it for the segment swap.
            ZStack {
                self.mapContent(project)
                    .opacity(self.viewMode == .map ? 1 : 0)
                    .allowsHitTesting(self.viewMode == .map)

                if self.viewMode == .list {
                    ProjectZonesView(project: project) { zoneID in
                        self.routeFromMap(zoneID: zoneID, in: project)
                    }
                    .transition(.move(edge: .trailing).combined(with: .opacity))
                }

                if self.viewMode == .overview {
                    ProjectOverviewView(project: project)
                        .transition(.move(edge: .leading).combined(with: .opacity))
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
        .background(Color("Background"))
        .navigationTitle(project.name)
        .navigationBarTitleDisplayMode(.inline)
        .toolbarBackground(.hidden, for: .navigationBar)
        .navigationDestination(item: self.$zoneDestination) { destination in
            self.destinationView(for: destination, projectID: project.id)
        }
        .task(id: self.archiveRefreshTaskID(for: project)) {
            await self.refreshRemoteScanArchives(for: project)
        }
    }

    private func mapContent(_ project: Project) -> some View {
        ZStack(alignment: .topTrailing) {
            ProjectZoneMapView(project: project, useSatellite: self.usesSatelliteMap) { zoneID in
                self.routeFromMap(zoneID: zoneID, in: project)
            }
            .accessibilityIdentifier("projectZoneMap")
            .ignoresSafeArea(edges: .bottom)

            self.mapStyleToggle
                .padding(.top, 12)
                .padding(.trailing, 16)
        }
    }

    @ViewBuilder
    private func destinationView(for destination: ZoneDestination, projectID: UUID) -> some View {
        let project = self.projectStore.project(withID: projectID)

        switch destination {
        case let .detail(zoneID):
            if let project, let zone = project.zones.first(where: { $0.id == zoneID }) {
                ZoneDetailView(
                    projectID: project.id,
                    zoneID: zone.id,
                    onReturnToProjectMap: {
                        self.returnToProjectMap()
                    }
                )
            } else {
                ContentUnavailableView("Zone Missing", systemImage: "exclamationmark.triangle")
            }
        case let .scan(zoneID, presentation):
            if let project, let zone = project.zones.first(where: { $0.id == zoneID }) {
                ZoneScannerContainerView(
                    projectID: project.id,
                    projectName: project.name,
                    zoneID: zone.id,
                    zoneName: zone.name,
                    scanProjectID: presentation == .start ? nil : zone.scanProjectID,
                    presentation: presentation,
                    onReturnToProjectMap: {
                        self.returnToProjectMap()
                    }
                )
            } else {
                ContentUnavailableView("Zone Missing", systemImage: "exclamationmark.triangle")
            }
        }
    }

    /// Map taps jump straight to the most useful screen: the render for completed zones,
    /// the scanner for zones that still need (or are mid-) capture.
    private func routeFromMap(zoneID: UUID, in project: Project) {
        guard let zone = project.zones.first(where: { $0.id == zoneID }) else { return }
        switch zone.scanState {
        case .complete:
            self.zoneDestination = .detail(zoneID: zoneID)
        case .notStarted:
            self.zoneDestination = .scan(zoneID: zoneID, presentation: .start)
        case .inProgress:
            self.zoneDestination = .scan(zoneID: zoneID, presentation: .resume)
        }
    }

    private func returnToProjectMap() {
        self.viewMode = .map
        self.zoneDestination = nil
    }

    private func archiveRefreshTaskID(for project: Project) -> String {
        [
            project.id.uuidString,
            project.remoteID ?? "local",
            self.remoteOrganizationID(for: project) ?? "none",
        ].joined(separator: "|")
    }

    private func refreshRemoteScanArchives(for project: Project) async {
        guard let remoteProjectID = project.remoteID,
              let organizationID = self.remoteOrganizationID(for: project)
        else {
            return
        }

        for zone in project.zones {
            guard !Task.isCancelled else { return }

            do {
                _ = try await self.zoneScanArchiveCacheService.refreshPreviewIfNeeded(
                    localProjectID: project.id,
                    organizationID: organizationID,
                    remoteProjectID: remoteProjectID,
                    zoneID: zone.id,
                    currentScanProjectID: zone.scanProjectID
                )
            } catch is CancellationError {
                return
            } catch {
                // Archive refresh is opportunistic; keep the project usable if a zone fails.
                continue
            }
        }
    }

    private func remoteOrganizationID(for project: Project) -> String? {
        project.owningRemoteOrganizationID
            ?? self.remoteProjectsDataCoordinator.selectedOrganizationID
    }
}

// MARK: - ProjectViewMode

/// The ways of looking at a project: the management overview, the spatial map grid, or a
/// scrollable zone list.
private enum ProjectViewMode: String, CaseIterable, Identifiable {
    case overview
    case map
    case list

    // MARK: Internal

    var id: Self {
        self
    }

    var label: String {
        switch self {
        case .overview: "Overview"
        case .map: "Map"
        case .list: "Zones"
        }
    }

    var icon: String {
        switch self {
        case .overview: "square.text.square"
        case .map: "map.fill"
        case .list: "list.bullet"
        }
    }
}

// MARK: - ProjectViewModePicker

/// Segmented toggle between the overview, map, and zone-list views, styled to match the role
/// picker in the invite flow: a sliding glass indicator that animates between the segments.
private struct ProjectViewModePicker: View {
    // MARK: Internal

    @Binding var selection: ProjectViewMode

    var body: some View {
        HStack(spacing: 4) {
            ForEach(ProjectViewMode.allCases) { mode in
                self.segment(for: mode)
            }
        }
        .padding(4)
        .background(
            Color(red: 60 / 255, green: 60 / 255, blue: 67 / 255).opacity(0.06),
            in: RoundedRectangle(cornerRadius: 12, style: .continuous)
        )
        // Light tick as the highlighted mode changes.
        .sensoryFeedback(.selection, trigger: self.selection)
    }

    // MARK: Private

    @Namespace private var indicator

    private func segment(for mode: ProjectViewMode) -> some View {
        let isOn = self.selection == mode
        return Button {
            withAnimation(.spring(response: 0.3, dampingFraction: 0.8)) {
                self.selection = mode
            }
        } label: {
            Label(mode.label, systemImage: mode.icon)
                .font(.system(size: 14, weight: isOn ? .semibold : .medium))
                .foregroundStyle(isOn ? Color("TextPrimary") : Color("TextSecondary"))
                .frame(maxWidth: .infinity)
                .padding(.vertical, 8)
                .background {
                    if isOn {
                        RoundedRectangle(cornerRadius: 9, style: .continuous)
                            .fill(Color("Surface"))
                            .glassEffect(.regular, in: .rect(cornerRadius: 9))
                            .shadow(color: .black.opacity(0.12), radius: 2, x: 0, y: 1)
                            .matchedGeometryEffect(id: "projectViewModeIndicator", in: self.indicator)
                    }
                }
        }
        .buttonStyle(.plain)
        .accessibilityIdentifier("projectViewMode_\(mode.rawValue)")
    }
}

// MARK: - ZoneDestination

private enum ZoneDestination: Hashable {
    /// The new scanned-zone render surface.
    case detail(zoneID: UUID)
    /// A direct push into the scanner for zones needing capture.
    case scan(zoneID: UUID, presentation: ZoneScannerPresentation)
}
