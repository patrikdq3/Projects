import MapKit
import SwiftUI

// MARK: - CreateProjectView

struct CreateProjectView: View {
    // MARK: Lifecycle

    init(organizationID: String? = nil, onCreated: @escaping (Project) -> Void) {
        self.organizationID = organizationID
        self.onCreated = onCreated
    }

    // MARK: Internal

    let organizationID: String?
    let onCreated: (Project) -> Void

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                self.nameSection
                self.locationSection
                self.boundarySection
                self.createButton
            }
            .padding(20)
        }
        .background(Color("Background"))
        .navigationTitle("New Project")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarLeading) {
                Button("Close") {
                    if self.hasProgress {
                        self.isShowingCloseConfirmation = true
                    } else {
                        self.dismiss()
                    }
                }
            }
        }
        .sheet(isPresented: self.$isShowingBoundarySelector) {
            BoundaryMapSelectionView(
                startingPoint: self.locationChoice,
                startingCoordinate: self.resolvedAddressCoordinate,
                existingBoundary: self.selectedBoundary
            ) { selection in
                self.selectedBoundary = selection.boundary
            }
        }
        .alert("Couldn’t Create Project", isPresented: Binding(
            get: { self.errorMessage != nil },
            set: { isPresented in
                if !isPresented {
                    self.errorMessage = nil
                }
            }
        )) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(self.errorMessage ?? "")
        }
        .alert("Discard Progress?", isPresented: self.$isShowingCloseConfirmation) {
            Button("Discard", role: .destructive) { self.dismiss() }
            Button("Cancel", role: .cancel) {}
        } message: {
            Text("Your project name and boundary selection will be lost.")
        }
        .alert("Reset Boundary?", isPresented: self.$isShowingToggleConfirmation) {
            Button("Reset", role: .destructive) { self.performLocationToggle() }
            Button("Cancel", role: .cancel) {}
        } message: {
            Text("Changing the starting point will clear your selected boundary. You will need to select a new one.")
        }
    }

    // MARK: Private

    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var projectStore: ProjectStore

    @State private var projectName = ""
    @State private var selectedBoundary: ProjectBoundary?
    @State private var useCustomAddress = false
    @State private var resolvedAddressCoordinate: GeoCoordinate?
    @State private var resolvedAddressTitle: String?
    @State private var isShowingBoundarySelector = false
    @State private var errorMessage: String?
    @State private var isShowingCloseConfirmation = false
    @State private var isShowingToggleConfirmation = false
    @State private var hasAttemptedCreate = false
    @State private var isCreating = false
    @FocusState private var isAddressFieldFocused: Bool
    @StateObject private var addressSearch = AddressSearchService()

    private let projectsService = ProjectsService()
    private let defaultZoneSize = 9

    private var locationChoice: ProjectLocationChoice {
        self.useCustomAddress ? .address : .currentLocation
    }

    private var canCreateProject: Bool {
        ProjectCreationValidator.canCreateProject(named: self.projectName, boundary: self.selectedBoundary)
    }

    private var hasProgress: Bool {
        !self.projectName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
            || self.selectedBoundary != nil
    }

    private var validationHint: String? {
        let trimmedName = self.projectName.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmedName.isEmpty {
            return "Enter a project name to continue."
        }
        guard let boundary = self.selectedBoundary else {
            return "Select a boundary on the map."
        }
        let count = boundary.vertices.count
        if count < ProjectCreationValidator.minimumVertexCount {
            return "Boundary needs at least \(ProjectCreationValidator.minimumVertexCount) vertices."
        }
        if count > ProjectCreationValidator.maximumVertexCount {
            return "Boundary exceeds the \(ProjectCreationValidator.maximumVertexCount)-vertex limit."
        }
        let area = boundary.areaSquareMeters
        if area <= 0 {
            return "Boundary area is invalid."
        }
        if area > ProjectCreationValidator.maximumAreaSquareMeters {
            return """
            This zone is too big. Your selected area is \(area.areaText), and zones must be \
            \(ProjectCreationValidator.maximumAreaSquareMeters.areaText) or smaller.
            """
        }
        return nil
    }

    private var nameSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Project Name")
                .font(.headline)
            TextField("Example: North Plaza Survey", text: self.$projectName)
                .textInputAutocapitalization(.words)
                .padding(.horizontal, 16)
                .padding(.vertical, 14)
                .background(Color("SurfaceSecondary"))
                .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                .accessibilityIdentifier("projectNameField")
        }
    }

    private var locationSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text("Map Starting Point")
                    .font(.headline)
                Spacer()
                Button {
                    let generator = UIImpactFeedbackGenerator(style: .light)
                    generator.impactOccurred()
                    if self.selectedBoundary != nil {
                        self.isShowingToggleConfirmation = true
                    } else {
                        self.performLocationToggle()
                    }
                } label: {
                    Label(
                        self.useCustomAddress ? "Using Address" : "Using GPS",
                        systemImage: self.useCustomAddress ? "magnifyingglass" : "location.fill"
                    )
                    .font(.caption.weight(.semibold))
                    .padding(.horizontal, 10)
                    .padding(.vertical, 6)
                    .foregroundStyle(self.useCustomAddress ? Color("Primary") : .secondary)
                    .background(
                        self.useCustomAddress
                            ? Color("Primary").opacity(0.12)
                            : Color("SurfaceSecondary"),
                        in: Capsule()
                    )
                }
                .buttonStyle(.plain)
            }

            VStack(alignment: .leading, spacing: 0) {
                TextField("Search address...", text: self.$addressSearch.queryFragment)
                    .textContentType(.fullStreetAddress)
                    .padding(.horizontal, 16)
                    .padding(.vertical, 14)
                    .background(Color("SurfaceSecondary"))
                    .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                    .disabled(!self.useCustomAddress)
                    .focused(self.$isAddressFieldFocused)
                    .opacity(self.useCustomAddress ? 1.0 : 0.4)
                    .accessibilityIdentifier("addressSearchField")
                    .onChange(of: self.addressSearch.queryFragment) { _, newValue in
                        guard self.useCustomAddress else { return }
                        guard let resolvedAddressTitle else { return }
                        if newValue != resolvedAddressTitle {
                            withAnimation(.easeInOut(duration: 0.2)) {
                                self.resolvedAddressTitle = nil
                                self.resolvedAddressCoordinate = nil
                            }
                        }
                    }

                if self.useCustomAddress, !self.addressSearch.suggestions.isEmpty {
                    AddressSuggestionsOverlay(
                        suggestions: self.addressSearch.suggestions
                    ) { completion in
                        let selectedText = self.addressSearch.displayText(for: completion)
                        withAnimation(.easeInOut(duration: 0.2)) {
                            self.addressSearch.selectSuggestion(completion)
                            self.resolvedAddressTitle = nil
                            self.resolvedAddressCoordinate = nil
                        }
                        self.isAddressFieldFocused = false
                        Task {
                            let coordinate = try? await self.addressSearch.resolveCoordinate(for: completion)
                            await MainActor.run {
                                withAnimation(.spring(response: 0.3, dampingFraction: 0.85)) {
                                    self.resolvedAddressCoordinate = coordinate
                                    self.resolvedAddressTitle = coordinate == nil ? nil : selectedText
                                }
                            }
                        }
                    }
                    .transition(.move(edge: .top).combined(with: .opacity))
                    .zIndex(1)
                }
            }
            .zIndex(1)
            .animation(.easeInOut(duration: 0.2), value: self.addressSearch.suggestions.isEmpty)

            if !self.useCustomAddress {
                Text("The map will center on your current GPS location.")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
            } else if let resolvedAddressTitle {
                Label(resolvedAddressTitle, systemImage: "checkmark.circle.fill")
                    .font(.footnote)
                    .foregroundStyle(.green)
                    .transition(.move(edge: .top).combined(with: .opacity))
            }
        }
    }

    private var boundarySection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Boundary")
                .font(.headline)

            Text(
                """
                Open the map, drop and shape vertices to outline the building or area, then confirm the
                live dimensions and total area.
                """
            )
            .font(.subheadline)
            .foregroundStyle(.secondary)

            Button {
                self.isShowingBoundarySelector = true
            } label: {
                HStack {
                    Image(systemName: selectedBoundary == nil ? "map.fill" : "mappin.and.ellipse")
                    Text(selectedBoundary == nil ? "Open Boundary Map" : "Adjust Boundary on Map")
                        .fontWeight(.semibold)
                    Spacer()
                    Text(selectedBoundary == nil ? "Next" : "Edit")
                        .font(.caption.weight(.bold))
                        .padding(.horizontal, 10)
                        .padding(.vertical, 6)
                        .background(Color("Primary").opacity(0.12))
                        .foregroundStyle(Color("Primary"))
                        .clipShape(Capsule())
                }
                .padding(18)
                .background(Color("Primary").opacity(0.08))
                .overlay {
                    RoundedRectangle(cornerRadius: 20, style: .continuous)
                        .stroke(Color("Primary").opacity(0.25), lineWidth: 1)
                }
                .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
            }
            .buttonStyle(.plain)
            .accessibilityIdentifier("chooseBoundaryButton")

            if let selectedBoundary {
                BoundarySummaryCard(boundary: selectedBoundary)
            }
        }
    }

    private var createButton: some View {
        VStack(spacing: 10) {
            if self.hasAttemptedCreate, let hint = self.validationHint {
                Text(hint)
                    .font(.footnote)
                    .foregroundStyle(.red)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }

            Button {
                guard self.canCreateProject else {
                    let generator = UINotificationFeedbackGenerator()
                    generator.notificationOccurred(.warning)
                    self.hasAttemptedCreate = true
                    return
                }

                Task {
                    await self.createProject()
                }
            } label: {
                Text(self.isCreating ? "Creating..." : "Create Project")
                    .font(.headline)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 16)
                    .background(self.canCreateProject ? Color("Primary") : Color("TextTertiary"))
                    .foregroundStyle(.white)
                    .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
            }
            .buttonStyle(.plain)
            .disabled(self.isCreating)
            .accessibilityIdentifier("createProjectSubmitButton")
        }
    }

    private func createProject() async {
        guard let selectedBoundary else { return }

        self.isCreating = true
        defer { self.isCreating = false }

        do {
            try self.projectStore.validateProjectCreation(
                named: self.projectName,
                boundary: selectedBoundary
            )

            guard let organizationID else {
                throw ProjectStoreError.invalidProjectConfiguration
            }

            let request = CreateProjectsAPIProjectRequest(
                name: self.projectName.trimmingCharacters(in: .whitespacesAndNewlines),
                description: nil,
                initialLat: selectedBoundary.center.latitude,
                initialLong: selectedBoundary.center.longitude,
                zoneSize: self.defaultZoneSize,
                boundary: selectedBoundary.vertices.map(ProjectsAPICoordinate.init(coordinate:))
            )
            let remoteProject: ProjectsAPIProject
            do {
                remoteProject = try await self.projectsService.createProject(
                    organizationID: organizationID,
                    request: request
                )
            } catch RequestServiceError.network {
                let project = try self.projectStore.createLocalProject(
                    named: self.projectName,
                    boundary: selectedBoundary,
                    pendingRemoteOrganizationID: organizationID
                )
                self.onCreated(project)
                return
            }

            let zonesService = ZonesService(
                organizationID: remoteProject.organizationID,
                projectID: remoteProject.id
            )
            let apiZones = await (try? zonesService.listZones()) ?? []

            let project = try self.projectStore.createProject(
                named: self.projectName,
                boundary: selectedBoundary,
                remoteID: remoteProject.id,
                remoteOrganizationID: remoteProject.organizationID,
                apiZones: apiZones
            )

            self.onCreated(project)
        } catch {
            self.errorMessage = self.errorMessage(for: error)
        }
    }

    private func errorMessage(for error: Error) -> String {
        switch error {
        case RequestServiceError.missingAuthToken, RequestServiceError.unauthorized:
            return "Sign in again to create remote projects."
        case RequestServiceError.forbidden:
            return "You do not have access to create projects in this organization."
        default:
            return error.localizedDescription
        }
    }

    private func performLocationToggle() {
        self.useCustomAddress.toggle()
        self.selectedBoundary = nil
        self.addressSearch.queryFragment = ""
        self.addressSearch.clearResults()
        self.resolvedAddressCoordinate = nil
        self.resolvedAddressTitle = nil
    }
}

// MARK: - BoundarySummaryCard

private struct BoundarySummaryCard: View {
    let boundary: ProjectBoundary

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("Selected Footprint")
                .font(.headline)

            HStack(spacing: 12) {
                MeasurementStat(title: "Width", value: self.boundary.widthMeters.lengthText)
                MeasurementStat(title: "Height", value: self.boundary.heightMeters.lengthText)
                MeasurementStat(title: "Area", value: self.boundary.areaSquareMeters.areaText)
            }
        }
        .padding(18)
        .background(Color("SurfaceSecondary"))
        .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
    }
}

// MARK: - AddressSuggestionsOverlay

private struct AddressSuggestionsOverlay: View {
    let suggestions: [MKLocalSearchCompletion]
    let onSelect: (MKLocalSearchCompletion) -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            ForEach(Array(self.suggestions.prefix(5).enumerated()), id: \.offset) { index, suggestion in
                Button {
                    self.onSelect(suggestion)
                } label: {
                    VStack(alignment: .leading, spacing: 2) {
                        Text(suggestion.title)
                            .font(.subheadline)
                            .foregroundStyle(.primary)
                        if !suggestion.subtitle.isEmpty {
                            Text(suggestion.subtitle)
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.horizontal, 16)
                    .padding(.vertical, 10)
                }
                .buttonStyle(.plain)

                if index < min(self.suggestions.count, 5) - 1 {
                    Divider().padding(.leading, 16)
                }
            }
        }
        .background(Color("SurfaceSecondary"))
        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
        .shadow(color: .black.opacity(0.12), radius: 8, y: 4)
        .padding(.top, 4)
    }
}

// MARK: - MeasurementStat

struct MeasurementStat: View {
    let title: String
    let value: String

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(self.title.uppercased())
                .font(.caption.weight(.semibold))
                .foregroundStyle(.secondary)
            Text(self.value)
                .font(.title3.weight(.semibold))
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}
