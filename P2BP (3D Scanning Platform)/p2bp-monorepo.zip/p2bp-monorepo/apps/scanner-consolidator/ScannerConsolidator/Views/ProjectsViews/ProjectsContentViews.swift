import SwiftUI

// MARK: - ProjectsErrorBanner

/// Inline banner surfacing a load/management error above the project list or empty state.
struct ProjectsErrorBanner: View {
    let message: String

    var body: some View {
        Text(self.message)
            .font(.footnote)
            .foregroundStyle(Color("Error"))
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(12)
            .background(Color("Error").opacity(0.10), in: RoundedRectangle(cornerRadius: 12))
    }
}

// MARK: - ProjectsLoadingView

struct ProjectsLoadingView: View {
    var body: some View {
        VStack(spacing: 14) {
            ProgressView()
                .controlSize(.regular)
                .tint(Color("Primary"))

            Text("Loading Projects")
                .font(.system(size: 17, weight: .semibold))
                .foregroundStyle(Color("TextPrimary"))
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color("Background"))
    }
}

// MARK: - ProjectsEmptyStateView

/// Shown when the selected organization has no projects (or the user has no organizations yet),
/// inviting the user to create their first project.
struct ProjectsEmptyStateView: View {
    let title: String
    let message: String
    let errorMessage: String?
    let canCreateProject: Bool
    let onCreate: () -> Void

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                if let errorMessage = self.errorMessage {
                    ProjectsErrorBanner(message: errorMessage)
                }

                VStack(alignment: .leading, spacing: 10) {
                    Text(self.title)
                        .font(.title2.weight(.semibold))
                    Text(self.message)
                        .foregroundStyle(.secondary)
                }
                .padding(.horizontal, 6)

                Button(action: self.onCreate) {
                    HStack {
                        Image(systemName: "plus.circle.fill")
                        Text("Create First Project")
                            .fontWeight(.semibold)
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 16)
                    .background(Color("Primary"))
                    .foregroundStyle(.white)
                    .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                }
                .disabled(!self.canCreateProject)
                .accessibilityIdentifier("createProjectButton")
            }
            .padding(20)
        }
    }
}

// MARK: - ProjectsListView

/// The scrollable list of project cards. Local-backed rows push their detail route, openable
/// remote rows materialize on tap, and not-yet-openable rows render as static cards.
struct ProjectsListView: View {
    let rows: [ProjectRowModel]
    /// Org-role permission for remote-backed rows. Local-only rows are always manageable.
    let canManageRemoteProjects: Bool
    let isManaging: Bool
    let errorMessage: String?
    let onOpenRemote: (ProjectRowModel) -> Void
    let onRename: (ProjectRowModel) -> Void
    let onDelete: (ProjectRowModel) -> Void

    var body: some View {
        ScrollView {
            LazyVStack(spacing: 10) {
                if let errorMessage = self.errorMessage {
                    ProjectsErrorBanner(message: errorMessage)
                }

                ForEach(self.rows) { project in
                    // Local-only rows (no remote ID) need no org permission to rename/delete;
                    // remote-backed rows stay gated behind the viewer's org role.
                    let row = ProjectRow(
                        project: project,
                        canManage: project.remoteID == nil || self.canManageRemoteProjects,
                        onRename: self.onRename,
                        onDelete: self.onDelete
                    )
                    if project.canOpen {
                        Button {
                            self.onOpenRemote(project)
                        } label: {
                            row
                        }
                        .buttonStyle(.plain)
                    } else {
                        row
                    }
                }
            }
            .disabled(self.isManaging)
            .padding(.horizontal, 16)
            .padding(.top, 4)
            .padding(.bottom, 24)
        }
    }
}
