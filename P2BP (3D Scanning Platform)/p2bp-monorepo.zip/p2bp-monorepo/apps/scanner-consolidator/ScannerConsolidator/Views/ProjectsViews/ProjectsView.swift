import SwiftUI

// MARK: - ProjectRoute

enum ProjectRoute: Hashable {
    case detail(UUID)
}

// MARK: - ProjectsSheet

/// The multiple sheet states that could be presented in the projects view at a given time
enum ProjectsSheet: Int, Identifiable {
    case profile
    case createProject
    case createOrganization
    case manageOrganizations
    case invitations

    // MARK: Internal

    var id: Int {
        self.rawValue
    }
}

// MARK: - ProjectsView

// swiftlint:disable:next type_body_length
struct ProjectsView: View {
    // MARK: Lifecycle

    init(currentUser: User? = nil, onLoggedOut: @escaping () -> Void = {}) {
        self.onLoggedOut = onLoggedOut
        _currentUser = State(initialValue: currentUser)
    }

    // MARK: Internal

    /// Invoked when the user signs out, so the host can route back to the auth view.
    let onLoggedOut: () -> Void

    var body: some View {
        NavigationStack(path: self.$navigationPath) {
            Group {
                if self.isInitialLoading {
                    ProjectsLoadingView()
                } else if self.projectRows.isEmpty {
                    ProjectsEmptyStateView(
                        title: self.emptyTitle,
                        message: self.emptyMessage,
                        errorMessage: self.displayedLoadErrorMessage,
                        canCreateProject: self.canCreateProjects,
                        onCreate: self.beginCreateProject
                    )
                } else {
                    ProjectsListView(
                        rows: self.projectRows,
                        canManageRemoteProjects: self.canManageRemoteProjects,
                        isManaging: self.isManagingProject,
                        errorMessage: self.displayedLoadErrorMessage,
                        onOpenRemote: self.openRemoteProject,
                        onRename: self.beginRename,
                        onDelete: { row in
                            self.beginDelete(row)
                        }
                    )
                }
            }
            .navigationTitle("Projects")
            .toolbar {
                ProjectsToolbar(
                    organizations: self.remoteProjectsDataCoordinator.organizations,
                    selection: self.$remoteProjectsDataCoordinator.selectedOrganizationID,
                    invitationCount: self.pendingInvitations.count,
                    currentUser: self.currentUser,
                    canCreateProject: self.canCreateProjects,
                    onCreateProject: self.beginCreateProject,
                    onProfile: { self.activeSheet = .profile },
                    onCreateOrganization: { self.activeSheet = .createOrganization },
                    onManageOrganizations: { self.activeSheet = .manageOrganizations },
                    onInvitations: { self.activeSheet = .invitations }
                )
            }
            .task {
                await self.loadInitialData()
            }
            .task(id: self.remoteProjectsDataCoordinator.selectedOrganizationID) {
                await self.loadProjectsForSelectedOrganization()
            }
            .refreshable {
                // .refreshable cancels its task if the scroll view rebuilds mid-gesture; run the
                // network work in an unstructured task so a UI update can't abort the requests.
                await Task {
                    await self.remoteProjectsDataCoordinator.warmAllOrganizations(user: self.currentUser)
                    await self.loadProjectsForSelectedOrganization()
                    await self.publishPendingLocalProjects()
                    await self.zoneScanArchiveCacheService.flushPendingUploads()
                }.value
            }
            .sheet(item: self.$activeSheet) { sheet in
                ProjectsSheetRouter(
                    sheet: sheet,
                    currentUser: self.currentUser,
                    selectedOrganizationID: self.remoteProjectsDataCoordinator.selectedOrganizationID,
                    pendingInvitations: self.pendingInvitations,
                    onSignOut: self.handleSignOut,
                    onProjectCreated: self.handleProjectCreated,
                    onOrganizationCreated: self.handleOrganizationCreated,
                    onInvitationsChanged: self.handleInvitationsChanged
                )
            }
            .alert("Rename Project", isPresented: self.renameAlertBinding) {
                TextField("Project name", text: self.$renameProjectName)
                Button("Save") {
                    self.commitRename()
                }
                Button("Cancel", role: .cancel) {
                    self.projectPendingRename = nil
                }
            } message: {
                Text("Enter a new name for this project.")
            }
            .confirmationPrompt(self.$deleteConfirmation)
            // Warning buzz when the delete confirmation is opened.
            .sensoryFeedback(.warning, trigger: self.didOpenDeleteConfirmation)
            .navigationDestination(for: ProjectRoute.self) { route in
                self.destination(for: route)
            }
            .background(Color("Background"))
            .overlay(alignment: .bottom) {
                if let message = self.invitationBannerMessage {
                    InvitationBanner(message: message) {
                        self.invitationBannerMessage = nil
                        self.activeSheet = .invitations
                    }
                    .padding(.horizontal, 16)
                    .padding(.bottom, 12)
                    .transition(.move(edge: .bottom).combined(with: .opacity))
                    .task(id: message) {
                        try? await Task.sleep(for: .seconds(8))
                        withAnimation(.spring(response: 0.4, dampingFraction: 0.85)) {
                            self.invitationBannerMessage = nil
                        }
                    }
                }
            }
            .animation(.spring(response: 0.4, dampingFraction: 0.85), value: self.invitationBannerMessage)
            .onChange(of: self.scenePhase) { _, newValue in
                self.handleScenePhaseChange(newValue)
            }
        }
    }

    // MARK: Private

    @EnvironmentObject private var projectStore: ProjectStore
    @EnvironmentObject private var zoneScanArchiveCacheService: ZoneScanArchiveCacheService
    @EnvironmentObject private var remoteProjectsDataCoordinator: RemoteProjectsDataCoordinator
    @Environment(\.scenePhase) private var scenePhase

    @State private var navigationPath: [ProjectRoute] = []
    @State private var activeSheet: ProjectsSheet?
    @State private var currentUser: User?
    @State private var localErrorMessage: String?
    @State private var hydrationErrorMessage: String?
    @State private var projectPendingRename: ProjectRowModel?
    @State private var deleteConfirmation: ConfirmationPrompt?
    @State private var didOpenDeleteConfirmation = false
    @State private var renameProjectName = ""
    @State private var isManagingProject = false
    @State private var publishingLocalProjectIDs: Set<UUID> = []
    @State private var pendingInvitations: [OrganizationsAPIInvitation] = []
    @State private var invitationBannerMessage: String?
    /// Flips true once the initial remote load has settled (a successful org fetch or a surfaced
    /// failure), allowing the empty state to replace the first-load spinner.
    @State private var didCompleteInitialRemoteLoad = false

    private let organizationsService = OrganizationsService()
    private let invitationSeenStore = InvitationSeenStore()
    private let defaultZoneSize = 9

    private var displayedLoadErrorMessage: String? {
        if let localErrorMessage {
            return localErrorMessage
        }
        if let hydrationErrorMessage {
            return hydrationErrorMessage
        }
        guard !self.isRemoteLoading else { return nil }
        return self.remoteProjectsDataCoordinator.loadErrorMessage
    }

    private var projectManager: ProjectManagementController {
        ProjectManagementController(
            projectStore: self.projectStore,
            coordinator: self.remoteProjectsDataCoordinator
        )
    }

    private var renameAlertBinding: Binding<Bool> {
        Binding(
            get: { self.projectPendingRename != nil },
            set: { isPresented in
                if !isPresented {
                    self.projectPendingRename = nil
                }
            }
        )
    }

    /// The viewer's role in the selected organization, parsed from the cached membership role.
    /// Only owners and admins may rename or delete remote-backed projects.
    private var canManageRemoteProjects: Bool {
        self.canManage(organizationID: self.remoteProjectsDataCoordinator.selectedOrganizationID)
    }

    private var canCreateProjects: Bool {
        !self.remoteProjectsDataCoordinator.organizations.isEmpty
    }

    private var projectRows: [ProjectRowModel] {
        let remoteProjects = self.remoteProjectsDataCoordinator.projects(
            for: self.remoteProjectsDataCoordinator.selectedOrganizationID
        )
        let selectedOrganizationID = self.remoteProjectsDataCoordinator.selectedOrganizationID
        let remoteProjectIDs = Set(remoteProjects.map(\.id))

        // Keep remote rows authoritative while attaching local scan progress when available.
        let localByRemoteID = Dictionary(
            self.projectStore.projects.compactMap { project in
                project.remoteID.map { ($0, project) }
            },
            uniquingKeysWith: { existing, _ in existing }
        )
        let remoteRows = remoteProjects.map { apiProject in
            ProjectRowModel(apiProject: apiProject, localProject: localByRemoteID[apiProject.id])
        }

        guard self.didCompleteInitialRemoteLoad else { return remoteRows }

        let localRows = self.projectStore.projects.compactMap { project -> ProjectRowModel? in
            if let remoteID = project.remoteID {
                if remoteProjectIDs.contains(remoteID) {
                    return nil
                }
                // A nil owner means the row predates owner tracking; keep it visible until
                // materializeProject backfills the organization.
                if let ownerID = project.remoteOrganizationID, ownerID != selectedOrganizationID {
                    return nil
                }
            } else if let pendingOwnerID = project.pendingRemoteOrganizationID {
                guard pendingOwnerID == selectedOrganizationID else { return nil }
            }
            return ProjectRowModel(localProject: project)
        }

        return remoteRows + localRows
    }

    /// True while the first batch of organizations/projects is still in flight and we have
    /// nothing to show yet. Drives the bare spinner instead of the text-heavy empty state.
    /// Never true once the org has loaded, so a pull-to-refresh on an empty org can't swap
    /// the scroll view for the spinner and cancel its own refresh gesture.
    private var isInitialLoading: Bool {
        self.isRemoteLoading && self.projectRows.isEmpty
            && !self.remoteProjectsDataCoordinator.hasLoadedProjects(
                for: self.remoteProjectsDataCoordinator.selectedOrganizationID
            )
    }

    private var isRemoteLoading: Bool {
        self.remoteProjectsDataCoordinator.isLoadingOrganizations
            || self.remoteProjectsDataCoordinator.isLoadingProjects(
                for: self.remoteProjectsDataCoordinator.selectedOrganizationID
            )
    }

    private var emptyTitle: String {
        if self.remoteProjectsDataCoordinator.organizations.isEmpty {
            return "No Organizations Yet"
        }
        return "No Projects Yet"
    }

    private var emptyMessage: String {
        if self.remoteProjectsDataCoordinator.organizations.isEmpty {
            return "Join or create an organization to access shared projects from the API."
        }
        return """
        Start with a named project and a map-selected footprint. Zones load from the API once
        the project is online.
        """
    }

    @ViewBuilder
    private func destination(for route: ProjectRoute) -> some View {
        switch route {
        case let .detail(projectID):
            ProjectDetailView(projectID: projectID)
        }
    }

    private func handleScenePhaseChange(_ newValue: ScenePhase) {
        guard newValue == .active else { return }

        Task {
            await self.publishPendingLocalProjects()
            await self.zoneScanArchiveCacheService.flushPendingUploads()
        }
    }

    /// Whether the viewer is an owner/admin of the given organization, and so may rename or
    /// delete its projects.
    private func canManage(organizationID: String?) -> Bool {
        guard let organization = self.remoteProjectsDataCoordinator.organizations.first(where: {
            $0.id == organizationID
        }) else {
            return false
        }
        let role = OrgRole(apiValue: organization.role)
        return role == .owner || role == .admin
    }

    private func loadInitialData() async {
        if self.currentUser == nil {
            self.currentUser = await AuthService.shared.getSession()?.user
        }
        await self.remoteProjectsDataCoordinator.warmAllOrganizations(user: self.currentUser)
        self.didCompleteInitialRemoteLoad = true
        await self.publishPendingLocalProjects()
        await self.zoneScanArchiveCacheService.flushPendingUploads()
        await self.loadInvitations(notify: true)
    }

    // MARK: Sheet completions

    private func handleSignOut() {
        self.activeSheet = nil
        // Let the sheet finish sliding away before the root cross-fades to auth.
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) {
            self.onLoggedOut()
        }
    }

    private func handleProjectCreated(_ project: Project) {
        self.activeSheet = nil
        Task {
            if project.remoteID == nil {
                self.localErrorMessage = "Project saved. Connect to the internet to generate zones."
            } else if project.zones.isEmpty {
                self.localErrorMessage = "Project uploaded. Zones are still loading."
            } else {
                self.localErrorMessage = nil
                self.navigationPath.append(.detail(project.id))
            }
            await self.loadProjectsForSelectedOrganization()
        }
    }

    private func handleOrganizationCreated(_ organization: ProjectsAPIOrganization) {
        self.activeSheet = nil
        self.remoteProjectsDataCoordinator.selectedOrganizationID = organization.id
        Task {
            await self.remoteProjectsDataCoordinator.warmAllOrganizations(user: self.currentUser)
            await self.loadProjectsForSelectedOrganization()
        }
    }

    private func beginCreateProject() {
        guard self.canCreateProjects else { return }
        self.activeSheet = .createProject
    }

    private func handleInvitationsChanged() {
        Task {
            await self.remoteProjectsDataCoordinator.warmAllOrganizations(user: self.currentUser)
            await self.loadInvitations(notify: false)
        }
    }

    /// Fetches the user's pending invitations. When `notify` is set (the session-check pass), a
    /// tappable banner surfaces only invitations that are new since the last notification — an
    /// invitation whose ID isn't already in the user's persisted "seen" JSON.
    private func loadInvitations(notify: Bool) async {
        guard let invitations = try? await self.organizationsService.listUserInvitations() else { return }
        let pending = invitations.filter(\.isActivePending)
        self.pendingInvitations = pending

        guard notify, let userID = self.currentUser?.id else { return }

        let currentIDs = Set(pending.map(\.id))
        let seenIDs = self.invitationSeenStore.loadSeenIDs(userID: userID)
        let hasNewInvitation = !currentIDs.subtracting(seenIDs).isEmpty
        self.invitationSeenStore.saveSeenIDs(currentIDs, userID: userID)

        guard hasNewInvitation, !pending.isEmpty else { return }
        self.invitationBannerMessage = pending.count == 1
            ? "You've been invited to join an organization. Tap to view."
            : "You have \(pending.count) pending invitations. Tap to view."
    }

    private func loadProjectsForSelectedOrganization() async {
        guard let organizationID = self.remoteProjectsDataCoordinator.selectedOrganizationID else { return }
        self.hydrationErrorMessage = nil

        guard let refreshContext = await self.remoteProjectsDataCoordinator.refreshProjects(
            organizationID: organizationID
        ) else { return }
        let isCurrent = {
            self.remoteProjectsDataCoordinator.isCurrentProjectRefresh(refreshContext)
                && self.remoteProjectsDataCoordinator.selectedOrganizationID == organizationID
        }
        guard isCurrent() else { return }

        let localProjectsBeingPublished = self.projectStore.projects.filter {
            self.publishingLocalProjectIDs.contains($0.id)
        }
        let hydrationErrorMessage = await ProjectHydrator(
            organizationID: organizationID,
            projects: self.remoteProjectsDataCoordinator.projects(for: organizationID),
            localProjectsBeingPublished: localProjectsBeingPublished,
            projectStore: self.projectStore,
            isCurrent: isCurrent
        ).hydrate()
        guard isCurrent() else { return }
        self.hydrationErrorMessage = hydrationErrorMessage
    }

    private func publishPendingLocalProjects() async {
        let pendingProjects = self.projectStore.projects.filter {
            $0.owningRemoteOrganizationID != nil && ($0.remoteID == nil || $0.zones.isEmpty)
        }

        for project in pendingProjects {
            _ = await self.publishLocalProject(project)
        }
    }

    @discardableResult
    private func publishLocalProject(_ project: Project) async -> Project? {
        guard project.remoteID == nil || project.zones.isEmpty else { return project }
        guard let organizationID = project.owningRemoteOrganizationID else { return nil }
        guard !self.publishingLocalProjectIDs.contains(project.id) else { return nil }

        self.publishingLocalProjectIDs.insert(project.id)
        defer { self.publishingLocalProjectIDs.remove(project.id) }

        do {
            let remoteID: String
            let remoteOrganizationID: String
            if let existingRemoteID = project.remoteID {
                remoteID = existingRemoteID
                remoteOrganizationID = project.remoteOrganizationID ?? organizationID
            } else {
                let remoteProject = try await self.remoteProjectsDataCoordinator.createProject(
                    organizationID: organizationID,
                    request: CreateProjectsAPIProjectRequest(
                        name: project.name,
                        description: nil,
                        initialLat: project.boundary.center.latitude,
                        initialLong: project.boundary.center.longitude,
                        zoneSize: self.defaultZoneSize,
                        boundary: project.boundary.vertices.map(ProjectsAPICoordinate.init(coordinate:))
                    )
                )
                remoteID = remoteProject.id
                remoteOrganizationID = remoteProject.organizationID

                _ = try self.projectStore.attachRemoteProject(
                    remoteID: remoteID,
                    remoteOrganizationID: remoteOrganizationID,
                    apiZones: [],
                    toProject: project.id
                )
            }

            let apiZones = await (try? ZonesService(
                organizationID: remoteOrganizationID,
                projectID: remoteID
            ).listZones()) ?? []

            let publishedProject = try self.projectStore.attachRemoteProject(
                remoteID: remoteID,
                remoteOrganizationID: remoteOrganizationID,
                apiZones: apiZones,
                toProject: project.id
            )
            await self.remoteProjectsDataCoordinator.refreshProjects(organizationID: remoteOrganizationID)
            self.localErrorMessage = publishedProject.zones.isEmpty
                ? "Project uploaded. Zones are still loading."
                : nil
            return publishedProject
        } catch RequestServiceError.network {
            return nil
        } catch {
            self.localErrorMessage = self.managementErrorMessage(for: error)
            return nil
        }
    }

    private func beginRename(_ row: ProjectRowModel) {
        self.renameProjectName = row.name
        self.projectPendingRename = row
    }

    private func beginDelete(_ row: ProjectRowModel) {
        self.didOpenDeleteConfirmation.toggle()
        self.deleteConfirmation = ConfirmationPrompt(
            icon: "trash",
            title: "Delete \(row.name)?",
            message: """
            This removes the project from this workspace and deletes any local scan \
            artifacts on this device.
            """,
            confirmTitle: "Delete project",
            confirmIcon: "trash"
        ) {
            Task { await self.deleteProject(row) }
        }
    }

    private func commitRename() {
        guard let project = self.projectPendingRename else { return }
        let trimmedName = self.renameProjectName.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmedName.isEmpty else {
            self.localErrorMessage = ProjectStoreError.invalidProjectName.localizedDescription
            return
        }

        self.projectPendingRename = nil
        Task {
            await self.editProject(project, edit: UpdateProjectsAPIProjectRequest(name: trimmedName))
        }
    }

    /// Materializes remote zones before opening a project that does not have them yet.
    private func openRemoteProject(_ row: ProjectRowModel) {
        Task {
            await self.openProject(row)
        }
    }

    @MainActor
    private func openProject(_ row: ProjectRowModel) async {
        var resolvedRemoteID = row.remoteID
        var resolvedOrganizationID = row.remoteOrganizationID
            ?? self.remoteProjectsDataCoordinator.selectedOrganizationID
        var resolvedBoundary = row.remoteBoundary

        if let localID = row.localID, let project = self.projectStore.project(withID: localID) {
            resolvedRemoteID = resolvedRemoteID ?? project.remoteID
            resolvedOrganizationID = project.owningRemoteOrganizationID ?? resolvedOrganizationID
            resolvedBoundary = resolvedBoundary ?? project.boundary

            if !project.zones.isEmpty {
                self.localErrorMessage = nil
                self.navigationPath.append(.detail(localID))
                return
            }
            if let publishedProject = await self.publishLocalProject(project) {
                resolvedRemoteID = publishedProject.remoteID
                resolvedOrganizationID = publishedProject.owningRemoteOrganizationID ?? resolvedOrganizationID
                resolvedBoundary = publishedProject.boundary
                if !publishedProject.zones.isEmpty {
                    self.localErrorMessage = nil
                    self.navigationPath.append(.detail(localID))
                    return
                }
            }
        }

        guard let remoteID = resolvedRemoteID else {
            UINotificationFeedbackGenerator().notificationOccurred(.warning)
            self.localErrorMessage = "Connect to the internet to generate zones for this project."
            return
        }
        guard let organizationID = resolvedOrganizationID else { return }
        guard let boundary = resolvedBoundary else {
            return
        }

        self.isManagingProject = true
        defer { self.isManagingProject = false }

        do {
            let apiZones = try await ZonesService(
                organizationID: organizationID,
                projectID: remoteID
            ).listZones()
            let (project, _) = try self.projectStore.materializeRemoteProject(
                remoteID: remoteID,
                remoteOrganizationID: organizationID,
                name: row.name,
                boundary: boundary,
                apiZones: apiZones
            )
            self.localErrorMessage = nil
            self.navigationPath.append(.detail(project.id))
        } catch RequestServiceError.network {
            UINotificationFeedbackGenerator().notificationOccurred(.warning)
            self.localErrorMessage = "Connect to the internet to finish setting up this project’s zones."
        } catch {
            self.localErrorMessage = self.managementErrorMessage(for: error)
        }
    }

    @MainActor
    private func editProject(_ row: ProjectRowModel, edit: UpdateProjectsAPIProjectRequest) async {
        guard let newName = edit.name else { return }
        self.isManagingProject = true
        defer { self.isManagingProject = false }

        do {
            try await self.projectManager.rename(
                localID: row.localID,
                remoteID: row.remoteID,
                organizationID: row.remoteOrganizationID
                    ?? self.remoteProjectsDataCoordinator.selectedOrganizationID,
                currentName: row.name,
                to: newName
            )
            self.localErrorMessage = nil
        } catch {
            self.localErrorMessage = self.managementErrorMessage(for: error)
        }
    }

    @MainActor
    private func deleteProject(_ row: ProjectRowModel) async {
        self.isManagingProject = true
        defer { self.isManagingProject = false }

        do {
            try await self.projectManager.delete(
                localID: row.localID,
                remoteID: row.remoteID,
                organizationID: row.remoteOrganizationID
                    ?? self.remoteProjectsDataCoordinator.selectedOrganizationID
            )
            self.localErrorMessage = nil
        } catch {
            self.localErrorMessage = self.managementErrorMessage(for: error)
        }
    }

    private func managementErrorMessage(for error: Error) -> String {
        switch error {
        case RequestServiceError.missingAuthToken, RequestServiceError.unauthorized:
            return "Sign in again to manage remote projects."
        case RequestServiceError.forbidden:
            return "You do not have access to manage this project."
        case RequestServiceError.notFound:
            return "The selected project could not be found."
        case let RequestServiceError.invalidInput(message):
            return message ?? "The project update is invalid."
        default:
            return error.localizedDescription
        }
    }
}

#Preview {
    ProjectsView()
        .environmentObject(AppDependencies.preview.projectStore)
        .environmentObject(AppDependencies.preview.zoneScanArchiveCacheService)
        .environmentObject(AppDependencies.preview.remoteProjectsDataCoordinator)
        .environmentObject(AppDependencies.preview.organizationDataCoordinator)
}
