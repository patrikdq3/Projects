import MapKit
import SwiftUI
import UIKit

// MARK: - ProjectZoneMapView

struct ProjectZoneMapView: UIViewRepresentable {
    // MARK: Lifecycle

    init(
        project: Project,
        focusedZoneID: UUID? = nil,
        isInteractive: Bool = true,
        allowsMapGestures: Bool? = nil,
        useSatellite: Bool = false,
        onZoneTap: ((UUID) -> Void)? = nil
    ) {
        self.project = project
        self.focusedZoneID = focusedZoneID
        self.isInteractive = isInteractive
        self.allowsMapGestures = allowsMapGestures ?? isInteractive
        self.useSatellite = useSatellite
        self.onZoneTap = onZoneTap
    }

    // MARK: Internal

    let project: Project
    /// When set, the map frames tightly on this zone and renders it as the hero while the
    /// surrounding zones recede.
    let focusedZoneID: UUID?
    /// Disables panning/zooming/taps for static previews.
    let isInteractive: Bool
    /// Allows callers to keep zone taps active while letting a parent scroll view own swipes.
    let allowsMapGestures: Bool
    let useSatellite: Bool
    let onZoneTap: ((UUID) -> Void)?

    func makeUIView(context _: Context) -> ProjectZoneMapContainerView {
        let view = ProjectZoneMapContainerView()
        view.onZoneTap = self.onZoneTap
        view.isInteractive = self.isInteractive
        view.allowsMapGestures = self.allowsMapGestures
        view.setMapType(self.useSatellite ? .satellite : .mutedStandard)
        view.render(project: self.project, focusedZoneID: self.focusedZoneID)
        return view
    }

    func updateUIView(_ uiView: ProjectZoneMapContainerView, context _: Context) {
        uiView.onZoneTap = self.onZoneTap
        uiView.isInteractive = self.isInteractive
        uiView.allowsMapGestures = self.allowsMapGestures
        uiView.setMapType(self.useSatellite ? .satellite : .mutedStandard)
        uiView.render(project: self.project, focusedZoneID: self.focusedZoneID)
    }
}

// MARK: - ZonePolygon

private final nonisolated class ZonePolygon: MKPolygon {
    var zoneID: UUID = .init()
    var statusColor: UIColor = .systemBlue
    var isFocused = false
    var isDimmed = false
}

// MARK: - BoundaryOutlinePolygon

private final nonisolated class BoundaryOutlinePolygon: MKPolygon {}

// MARK: - ProjectZoneMapContainerView

final class ProjectZoneMapContainerView: UIView, MKMapViewDelegate {
    // MARK: Lifecycle

    override init(frame: CGRect) {
        super.init(frame: frame)
        self.setup()
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        self.setup()
    }

    // MARK: Internal

    var onZoneTap: ((UUID) -> Void)? {
        didSet {
            // The recognizer is gated on `onZoneTap != nil`, and this is the only setter the
            // representable reliably re-runs — so re-evaluate interactivity whenever it changes.
            self.applyInteractivity()
        }
    }

    var isInteractive = true {
        didSet {
            guard self.isInteractive != oldValue else { return }
            self.applyInteractivity()
        }
    }

    var allowsMapGestures = true {
        didSet {
            guard self.allowsMapGestures != oldValue else { return }
            self.applyInteractivity()
        }
    }

    func render(project: Project, focusedZoneID: UUID?) {
        let needsReframe = self.renderedProjectID != project.id || self.renderedFocusID != focusedZoneID
        self.renderedProjectID = project.id
        self.renderedFocusID = focusedZoneID

        self.mapView.removeOverlays(self.mapView.overlays)

        if focusedZoneID == nil {
            let boundaryCoords = project.boundary.vertices.map(\.clCoordinate)
            let boundaryPolygon = BoundaryOutlinePolygon(coordinates: boundaryCoords, count: boundaryCoords.count)
            self.mapView.addOverlay(boundaryPolygon, level: .aboveRoads)
        }

        let boundaryLocal = project.boundary.vertices.map {
            BoundaryGeometry.localPoint(of: $0, in: project.boundary)
        }

        for zone in project.sortedZones {
            // Trim each zone's footprint to the project boundary so the grid never spills past
            // the drawn perimeter; the server emits a full rectangular grid over the bounding box.
            let clipped = BoundaryGeometry.clip(polygon: zone.footprint.points, to: boundaryLocal)
            guard clipped.count >= 3 else { continue }
            let coords = clipped.map { point in
                BoundaryGeometry.coordinate(from: project.boundary, atLocal: point).clCoordinate
            }
            let polygon = ZonePolygon(coordinates: coords, count: coords.count)
            polygon.zoneID = zone.id
            polygon.statusColor = UIColor(zone.status.color)
            polygon.isFocused = zone.id == focusedZoneID
            polygon.isDimmed = focusedZoneID != nil && zone.id != focusedZoneID
            self.mapView.addOverlay(polygon, level: .aboveRoads)
        }

        if needsReframe {
            self.reframe(project: project, focusedZoneID: focusedZoneID)
        }
    }

    func setMapType(_ type: MKMapType) {
        guard self.mapView.mapType != type else { return }
        self.mapView.mapType = type
    }

    // MARK: MKMapViewDelegate

    func mapView(_: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        if let zonePolygon = overlay as? ZonePolygon {
            let renderer = MKPolygonRenderer(polygon: zonePolygon)
            let fillAlpha: CGFloat = zonePolygon.isDimmed ? 0.18 : (zonePolygon.isFocused ? 0.6 : 0.45)
            renderer.fillColor = zonePolygon.statusColor.withAlphaComponent(fillAlpha)
            renderer.strokeColor = zonePolygon.isDimmed
                ? zonePolygon.statusColor.withAlphaComponent(0.4)
                : zonePolygon.statusColor
            renderer.lineWidth = zonePolygon.isFocused ? 3 : 2
            return renderer
        }
        if let boundary = overlay as? BoundaryOutlinePolygon {
            let renderer = MKPolygonRenderer(polygon: boundary)
            renderer.fillColor = .clear
            renderer.strokeColor = UIColor.white.withAlphaComponent(0.85)
            renderer.lineWidth = 2
            renderer.lineDashPattern = [4, 4]
            return renderer
        }
        return MKOverlayRenderer(overlay: overlay)
    }

    // MARK: Private

    private let mapView = MKMapView(frame: .zero)
    private var renderedProjectID: UUID?
    private var renderedFocusID: UUID?

    private var tapRecognizer = UITapGestureRecognizer()

    private func setup() {
        backgroundColor = .systemBackground

        self.mapView.translatesAutoresizingMaskIntoConstraints = false
        self.mapView.delegate = self
        self.mapView.mapType = .mutedStandard
        self.mapView.pointOfInterestFilter = .excludingAll
        self.mapView.showsCompass = false
        self.mapView.showsScale = true
        self.mapView.isPitchEnabled = false
        self.mapView.showsUserLocation = false
        self.mapView.cameraZoomRange = MKMapView.CameraZoomRange(minCenterCoordinateDistance: 5)

        addSubview(self.mapView)

        NSLayoutConstraint.activate([
            self.mapView.leadingAnchor.constraint(equalTo: leadingAnchor),
            self.mapView.trailingAnchor.constraint(equalTo: trailingAnchor),
            self.mapView.topAnchor.constraint(equalTo: topAnchor),
            self.mapView.bottomAnchor.constraint(equalTo: bottomAnchor),
        ])

        self.tapRecognizer = UITapGestureRecognizer(target: self, action: #selector(self.handleTap(_:)))
        self.mapView.addGestureRecognizer(self.tapRecognizer)

        self.applyInteractivity()
    }

    private func applyInteractivity() {
        self.mapView.isScrollEnabled = self.allowsMapGestures
        self.mapView.isZoomEnabled = self.allowsMapGestures
        self.mapView.isRotateEnabled = self.allowsMapGestures
        self.mapView.showsScale = self.allowsMapGestures
        self.tapRecognizer.isEnabled = self.isInteractive && self.onZoneTap != nil
    }

    private func reframe(project: Project, focusedZoneID: UUID?) {
        if let focusedZoneID, let zone = project.zones.first(where: { $0.id == focusedZoneID }) {
            self.frame(zone: zone, in: project)
        } else {
            self.frame(project: project)
        }
    }

    private func frame(project: Project) {
        let mapPoints = project.boundary.vertices.map { MKMapPoint($0.clCoordinate) }
        self.setVisible(mapPoints: mapPoints, padding: 32)
    }

    private func frame(zone: Zone, in project: Project) {
        let mapPoints = zone.footprint.points.map { point in
            MKMapPoint(BoundaryGeometry.coordinate(from: project.boundary, atLocal: point).clCoordinate)
        }
        self.setVisible(mapPoints: mapPoints, padding: 60)
    }

    private func setVisible(mapPoints: [MKMapPoint], padding: CGFloat) {
        guard let first = mapPoints.first else { return }

        var rect = MKMapRect(origin: first, size: MKMapSize(width: 0, height: 0))
        for point in mapPoints.dropFirst() {
            rect = rect.union(MKMapRect(origin: point, size: MKMapSize(width: 0, height: 0)))
        }

        self.mapView.setVisibleMapRect(
            rect,
            edgePadding: UIEdgeInsets(top: padding, left: padding, bottom: padding, right: padding),
            animated: false
        )
    }

    @objc
    private func handleTap(_ recognizer: UITapGestureRecognizer) {
        let tapPoint = recognizer.location(in: self.mapView)
        let coordinate = self.mapView.convert(tapPoint, toCoordinateFrom: self.mapView)
        let mapPoint = MKMapPoint(coordinate)

        for overlay in self.mapView.overlays.reversed() {
            guard let zonePolygon = overlay as? ZonePolygon else { continue }
            guard zonePolygon.boundingMapRect.contains(mapPoint) else { continue }
            guard self.polygon(zonePolygon, contains: mapPoint) else { continue }

            self.onZoneTap?(zonePolygon.zoneID)
            return
        }
    }

    private func polygon(_ polygon: MKPolygon, contains point: MKMapPoint) -> Bool {
        let count = polygon.pointCount
        guard count >= 3 else { return false }

        let points = polygon.points()
        var inside = false
        var j = count - 1
        for i in 0 ..< count {
            let pi = points[i]
            let pj = points[j]
            let intersects = (pi.y > point.y) != (pj.y > point.y)
                && point.x < (pj.x - pi.x) * (point.y - pi.y) / (pj.y - pi.y) + pi.x
            if intersects {
                inside.toggle()
            }
            j = i
        }
        return inside
    }
}
