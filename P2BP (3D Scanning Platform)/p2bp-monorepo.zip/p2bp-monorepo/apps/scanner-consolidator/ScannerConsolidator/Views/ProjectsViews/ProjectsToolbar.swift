import SwiftUI

// MARK: - ProjectsToolbar

/// The Projects screen nav bar: the organization switcher pill, the new-project button, and the
/// profile avatar. All actions are delegated back to `ProjectsView` via closures.
struct ProjectsToolbar: ToolbarContent {
    // MARK: Internal

    let organizations: [Organization]
    @Binding var selection: Organization.ID?

    let invitationCount: Int
    let currentUser: User?
    let canCreateProject: Bool
    let onCreateProject: () -> Void
    let onProfile: () -> Void
    let onCreateOrganization: () -> Void
    let onManageOrganizations: () -> Void
    let onInvitations: () -> Void

    var body: some ToolbarContent {
        ToolbarItem(placement: .topBarLeading) {
            OrgPicker(
                organizations: self.organizations,
                selection: self.$selection,
                invitationCount: self.invitationCount,
                onCreateOrganization: self.onCreateOrganization,
                onManageOrganizations: self.onManageOrganizations,
                onInvitations: self.onInvitations
            )
            .accessibilityIdentifier("orgPicker")
        }
        ToolbarItem(placement: .topBarLeading) {
            Button(action: self.onCreateProject) {
                Image(systemName: "plus")
                    .font(.system(size: 17, weight: .regular))
                    .foregroundStyle(Color("Primary"))
                    .frame(width: 34, height: 34)
                    .background(Self.bubbleFill, in: .circle)
            }
            .buttonStyle(.plain)
            .disabled(!self.canCreateProject)
            .accessibilityLabel("New Project")
            .accessibilityIdentifier("createProjectButton")
        }
        ToolbarItem(placement: .topBarTrailing) {
            Button(action: self.onProfile) {
                ProfileAvatar(user: self.currentUser, size: 30)
            }
            .accessibilityLabel("Profile")
            .accessibilityIdentifier("profileButton")
        }
    }

    // MARK: Private

    /// Neutral bubble fill behind the new-project button so it reads as a matched pair with the
    /// org pill.
    private static let bubbleFill = Color(red: 60 / 255, green: 60 / 255, blue: 67 / 255).opacity(0.06)
}
