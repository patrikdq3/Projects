import CryptoKit
import SwiftUI

// MARK: - MergedPointCloudSource

enum MergedPointCloudSource: String, Hashable, Identifiable {
    case previewLAZ
    case laz

    // MARK: Internal

    var id: String {
        self.rawValue
    }

    var title: String {
        switch self {
        case .previewLAZ: "Preview LAZ"
        case .laz: "Full LAZ"
        }
    }

    /// Resolution the source shows, used to name its downloads ("Preview E57", "Full LAZ").
    var qualifier: String {
        switch self {
        case .previewLAZ: "Preview"
        case .laz: "Full"
        }
    }

    var loadingMessage: String {
        switch self {
        case .previewLAZ: "Downloading merged preview LAZ…"
        case .laz: "Downloading merged full LAZ…"
        }
    }

    /// The cloud rendered by the viewer.
    var lazArtifact: MeshArtifactKind {
        switch self {
        case .previewLAZ: .previewLAZ
        case .laz: .fullLAZ
        }
    }

    /// The same cloud as E57, for CAD tools such as Rhino that import it natively.
    var e57Artifact: MeshArtifactKind {
        switch self {
        case .previewLAZ: .previewE57
        case .laz: .fullE57
        }
    }
}

// MARK: - MergedMeshView

/// Renders the project-selected result and completed historical mesh-job versions. The selected
/// version is preserved while switching among the merged point cloud artifacts (preview and
/// full LAZ today; `MergedPointCloudSource` is where another format would be added).
struct MergedMeshView: View {
    // MARK: Internal

    let project: Project
    let organizationID: String

    var body: some View {
        Group {
            switch self.loadState {
            case .loading:
                ProgressView(self.source.loadingMessage)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .background(Color("Background"))
            case let .failed(message):
                ContentUnavailableView(
                    "Merged Point Cloud Unavailable",
                    systemImage: "cube.transparent",
                    description: Text(message)
                )
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .background(Color("Background"))
            case let .laz(cloud):
                LAZMetalPointCloudView(fileURL: cloud.fileURL, metadataURL: cloud.metadataURL)
                    .id(cloud.fileURL)
                    .accessibilityIdentifier("mergedPointCloudLAZ")
                    .ignoresSafeArea(edges: .bottom)
            }
        }
        .overlay(alignment: .topTrailing) {
            self.standaloneViewerControls
                .padding(.top, 12)
                .padding(.trailing, 16)
        }
        .pointCloudMovementGuide(isPresented: self.$isShowingMovementGuide)
        .navigationTitle("Merged Point Cloud")
        .navigationBarTitleDisplayMode(.inline)
        .toolbarBackground(.visible, for: .navigationBar)
        .toolbar {
            ToolbarItemGroup(placement: .topBarTrailing) {
                if let lazFileURL = self.lazFileURL {
                    self.downloadMenu(lazFileURL: lazFileURL)
                }
                self.sourceMenu
            }
        }
        .exportedFileShareSheet(self.$exportedFile)
        .alert(
            "Download Failed",
            isPresented: Binding(
                get: { self.downloadErrorMessage != nil },
                set: {
                    if !$0 {
                        self.downloadErrorMessage = nil
                    }
                }
            ),
            presenting: self.downloadErrorMessage
        ) { _ in
            Button("OK", role: .cancel) { self.downloadErrorMessage = nil }
        } message: { message in
            Text(message)
        }
        .task(id: MeshLoadRequest(source: self.source, version: self.selectedVersion)) {
            await self.load()
        }
        .onDisappear {
            self.stopMeshJobPolling()
        }
    }

    // MARK: Private

    /// The merged cloud on screen, plus which merge actually served it. The project-level
    /// endpoints resolve that server-side (selected-scan job, then newest completed job, then
    /// the legacy key), so it is not always the version the user picked -- and every other
    /// artifact of the same cloud has to be fetched from the job it names, not from
    /// `selectedVersion`, or the viewer and the download would disagree.
    private struct LoadedCloud: Equatable {
        let fileURL: URL
        let metadataURL: URL?
        let identity: MergedArtifactIdentity?
    }

    private enum LoadState {
        case loading
        case failed(String)
        case laz(LoadedCloud)
    }

    private enum SelectedMeshVersion: Hashable {
        case current
        case job(String)

        // MARK: Internal

        var jobID: String? {
            guard case let .job(jobID) = self else { return nil }
            return jobID
        }
    }

    private struct MeshLoadRequest: Hashable {
        let source: MergedPointCloudSource
        let version: SelectedMeshVersion
    }

    private static let currentVersionID = "current-result"
    private static let fractionalDateFormatter: ISO8601DateFormatter = {
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        return formatter
    }()

    private static let dateFormatter: ISO8601DateFormatter = {
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime]
        return formatter
    }()

    @State private var source = MergedPointCloudSource.previewLAZ
    @State private var loadState: LoadState = .loading
    @State private var selectedVersion = SelectedMeshVersion.current
    @State private var meshJobs: [MeshJob] = []
    @State private var isLoadingMeshJobs = false
    @State private var meshJobsErrorMessage: String?
    @State private var selectingVersionID: String?
    @State private var meshJobPollingTask: Task<Void, Never>?
    @State private var isShowingStandaloneVersionSelector = false
    @State private var isShowingMovementGuide = false
    @State private var isDownloadingE57 = false
    @State private var exportedFile: ExportedFile?
    @State private var downloadErrorMessage: String?

    private var displayedCloud: LoadedCloud? {
        guard case let .laz(cloud) = self.loadState else { return nil }
        return cloud
    }

    private var lazFileURL: URL? {
        self.displayedCloud?.fileURL
    }

    private var versionSelector: PointCloudVersionSelectorConfiguration {
        PointCloudVersionSelectorConfiguration(
            title: "Merge Jobs",
            options: self.versionOptions,
            isLoading: self.isLoadingMeshJobs,
            selectingID: self.selectingVersionID,
            errorMessage: self.meshJobsErrorMessage,
            accessibilityLabel: "Merged point cloud versions",
            onRefresh: self.startMeshJobPolling,
            onSelect: self.selectVersion,
            onPresentationChanged: { isPresented in
                if isPresented {
                    self.startMeshJobPolling()
                } else {
                    self.stopMeshJobPolling()
                }
            }
        )
    }

    private var versionOptions: [PointCloudVersionOption] {
        let isCurrent = self.selectedVersion == .current
        let current = PointCloudVersionOption(
            id: Self.currentVersionID,
            title: "Current result",
            subtitle: isCurrent ? "Currently shown" : "Best available project result",
            icon: isCurrent ? "checkmark.circle.fill" : "scope",
            tint: isCurrent ? Color("Success") : Color("Primary"),
            isCurrent: isCurrent,
            isSelectable: true
        )
        return [current] + self.meshJobs.map(self.versionOption)
    }

    private var standaloneViewerControls: some View {
        VStack(alignment: .trailing, spacing: 8) {
            self.versionButton

            if self.lazFileURL != nil {
                PointCloudMovementGuideButton(
                    isPresented: self.$isShowingMovementGuide,
                    accessibilityIdentifier: "mergedPointCloudMovementGuideButton"
                )
            }

            if self.isShowingStandaloneVersionSelector {
                self.versionOverlay
                    .transition(.scale(scale: 0.94, anchor: .topTrailing).combined(with: .opacity))
            }
        }
    }

    private var versionButton: some View {
        Button {
            withAnimation(.spring(response: 0.28, dampingFraction: 0.85)) {
                self.isShowingStandaloneVersionSelector.toggle()
            }
            if self.isShowingStandaloneVersionSelector {
                self.startMeshJobPolling()
            } else {
                self.stopMeshJobPolling()
            }
        } label: {
            Image(systemName: "clock.arrow.circlepath")
                .font(.system(size: PointCloudViewerControlStyle.iconSize, weight: .semibold))
                .foregroundStyle(Color("TextPrimary"))
                .frame(width: PointCloudViewerControlStyle.size, height: PointCloudViewerControlStyle.size)
                .background(.regularMaterial, in: Circle())
                .overlay(Circle().stroke(Color.white.opacity(0.28), lineWidth: 0.75))
                .shadow(color: .black.opacity(0.18), radius: 12, x: 0, y: 5)
        }
        .buttonStyle(.plain)
        .accessibilityLabel("Merged point cloud versions")
        .accessibilityValue(self.isShowingStandaloneVersionSelector ? "Shown" : "Hidden")
    }

    private var versionOverlay: some View {
        PointCloudVersionOverlay(
            title: self.versionSelector.title,
            options: self.versionSelector.options,
            isLoading: self.versionSelector.isLoading,
            selectingID: self.versionSelector.selectingID,
            errorMessage: self.versionSelector.errorMessage,
            pagination: nil,
            onRefresh: self.versionSelector.onRefresh,
            onSelect: { versionID in
                withAnimation(.spring(response: 0.28, dampingFraction: 0.85)) {
                    self.isShowingStandaloneVersionSelector = false
                }
                self.stopMeshJobPolling()
                self.selectVersion(id: versionID)
            }
        )
    }

    private var sourceMenu: some View {
        Menu {
            Button { self.source = .previewLAZ } label: { self.sourceLabel(for: .previewLAZ) }
            Button { self.source = .laz } label: { self.sourceLabel(for: .laz) }
        } label: {
            Label(self.source.title, systemImage: "cube.transparent")
        }
        .accessibilityLabel("Point cloud format")
        .accessibilityValue(self.source.title)
    }

    /// Downloads for the cloud currently on screen: the LAZ is already cached by the viewer, so
    /// it shares straight from disk; the E57 (what Rhino and other CAD tools import) is fetched
    /// on demand and handed to the share sheet.
    private func downloadMenu(lazFileURL: URL) -> some View {
        Menu {
            ShareLink(item: lazFileURL) {
                Label("Download \(self.source.qualifier) LAZ", systemImage: "arrow.down.document")
            }
            Button {
                self.downloadE57()
            } label: {
                Label("Download \(self.source.qualifier) E57", systemImage: "arrow.down.document")
            }
            .disabled(self.isDownloadingE57)
        } label: {
            if self.isDownloadingE57 {
                ProgressView()
            } else {
                Image(systemName: "square.and.arrow.down")
            }
        }
        .accessibilityLabel("Download merged point cloud")
        .accessibilityIdentifier("mergedPointCloudDownloadMenu")
    }

    @ViewBuilder
    private func sourceLabel(for source: MergedPointCloudSource) -> some View {
        if self.source == source {
            Label(source.title, systemImage: "checkmark")
        } else {
            Text(source.title)
        }
    }

    private static func previewID(for value: String) -> UUID {
        let digest = Insecure.MD5.hash(data: Data(value.utf8))
        let bytes = Array(digest)
        return UUID(uuid: (
            bytes[0], bytes[1], bytes[2], bytes[3],
            bytes[4], bytes[5], bytes[6], bytes[7],
            bytes[8], bytes[9], bytes[10], bytes[11],
            bytes[12], bytes[13], bytes[14], bytes[15]
        ))
    }

    private static func date(from value: String) -> Date? {
        self.fractionalDateFormatter.date(from: value) ?? self.dateFormatter.date(from: value)
    }

    /// The E57 exports are optional job outputs, so a merge that predates them has none. That
    /// reads as a 404 and needs its own wording -- the LAZ it sits next to loaded fine.
    private static func e57Message(for error: Error) -> String {
        switch error {
        case ProjectsServiceError.noMergeJobForProject,
             ProjectsServiceError.noMergeJobAvailableForProject:
            "This merge has no E57 export. Re-run the merge job to produce one."
        default:
            self.message(for: error)
        }
    }

    private static func message(for error: Error) -> String {
        switch error {
        case ProjectsServiceError.noMergeJobForProject,
             ProjectsServiceError.noMergeJobAvailableForProject:
            "No merged point cloud is ready yet. Launch a merge job first, then check back shortly."
        case RequestServiceError.missingAuthToken, RequestServiceError.unauthorized:
            "Sign in again to download the merged point cloud."
        case RequestServiceError.forbidden:
            "You do not have access to this project's merged point cloud."
        case RequestServiceError.network:
            "Couldn’t reach the server. Check your connection and try again."
        default:
            error.localizedDescription
        }
    }

    private func versionOption(_ job: MeshJob) -> PointCloudVersionOption {
        let isCurrent = self.selectedVersion == .job(job.id)
        return PointCloudVersionOption(
            id: job.id,
            title: Self.date(from: job.createdAt)?.formatted(date: .abbreviated, time: .shortened)
                ?? "Job \(job.id.prefix(8))",
            subtitle: self.subtitle(for: job, isCurrent: isCurrent),
            icon: isCurrent ? "checkmark.circle.fill" : self.icon(for: job.status),
            tint: isCurrent ? Color("Success") : self.tint(for: job.status),
            isCurrent: isCurrent,
            isSelectable: job.status == .completed
        )
    }

    private func subtitle(for job: MeshJob, isCurrent: Bool) -> String {
        if isCurrent {
            return "Currently shown • \(self.zoneCountText(job.zoneScanObjectKeys.count))"
        }
        if job.status == .failed {
            let error = job.error?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
            if !error.isEmpty {
                return "Failed: \(error)"
            }
        }
        return "\(self.displayName(for: job.status)) • \(self.zoneCountText(job.zoneScanObjectKeys.count))"
    }

    private func zoneCountText(_ count: Int) -> String {
        count == 1 ? "1 zone scan" : "\(count) zone scans"
    }

    private func displayName(for status: MeshJobStatus) -> String {
        switch status {
        case .queued: "Queued"
        case .running: "Running"
        case .completed: "Completed"
        case .failed: "Failed"
        case .unknown: "Unknown"
        }
    }

    private func icon(for status: MeshJobStatus) -> String {
        switch status {
        case .queued: "clock"
        case .running: "arrow.triangle.2.circlepath"
        case .completed: "checkmark.circle"
        case .failed: "xmark.octagon"
        case .unknown: "questionmark.circle"
        }
    }

    private func tint(for status: MeshJobStatus) -> Color {
        switch status {
        case .queued: Color("TextSecondary")
        case .running: Color("Primary")
        case .completed: Color("Success")
        case .failed: Color("Error")
        case .unknown: Color("Warning")
        }
    }

    private func selectVersion(id: String) {
        let version: SelectedMeshVersion
        if id == Self.currentVersionID {
            version = .current
        } else {
            guard self.meshJobs.contains(where: { $0.id == id && $0.status == .completed }) else { return }
            version = .job(id)
        }
        guard version != self.selectedVersion else { return }

        self.selectingVersionID = id
        self.selectedVersion = version
    }

    /// Cache path for one artifact of one merge version. Each version gets its own directory so
    /// artifacts keep their contract filenames -- a file shared out of the app then arrives as
    /// `merged-point-cloud.e57` rather than a cache key.
    private func cacheFileURL(for version: SelectedMeshVersion, artifact: MeshArtifactKind) -> URL {
        let versionKey = version.jobID.map { Self.previewID(for: $0).uuidString } ?? Self.currentVersionID
        return FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)[0]
            .appending(path: "MergedPointCloudCache", directoryHint: .isDirectory)
            .appending(path: self.project.id.uuidString, directoryHint: .isDirectory)
            .appending(path: versionKey, directoryHint: .isDirectory)
            .appending(path: artifact.filename)
    }

    /// Fetches the E57 export for the cloud on screen and hands it to the share sheet, so it can
    /// be saved to Files or sent to a desktop for import into Rhino.
    private func downloadE57() {
        guard !self.isDownloadingE57 else { return }
        guard let remoteProjectID = self.project.remoteID else {
            self.downloadErrorMessage = "This project isn't connected to the server yet."
            return
        }

        let artifact = self.source.e57Artifact
        let version = self.selectedVersion
        // Ask the job that served the LAZ on screen for its E57, so the file the user saves is
        // the cloud they are looking at. Going through the project-level endpoint instead would
        // let it skip this job's missing E57 and hand back a different merge's cloud. A legacy
        // (pre-versioning) cloud has no job-scoped endpoint, so it stays on the project route.
        let jobID = self.displayedCloud?.identity?.jobID ?? version.jobID
        self.isDownloadingE57 = true

        Task {
            defer { self.isDownloadingE57 = false }
            do {
                let downloaded = try await ProjectsService().fetchMergedArtifactFile(
                    organizationID: self.organizationID,
                    projectID: remoteProjectID,
                    jobID: jobID,
                    artifact: artifact,
                    destinationURL: self.cacheFileURL(for: version, artifact: artifact)
                )
                self.exportedFile = ExportedFile(fileURL: downloaded.fileURL)
            } catch is CancellationError {
                return
            } catch {
                self.downloadErrorMessage = Self.e57Message(for: error)
            }
        }
    }

    private func load() async {
        guard let remoteProjectID = self.project.remoteID else {
            self.loadState = .failed("This project isn't connected to the server yet.")
            return
        }

        self.loadState = .loading
        let request = MeshLoadRequest(source: self.source, version: self.selectedVersion)
        let requestVersionID = request.version.jobID ?? Self.currentVersionID
        defer {
            if self.selectingVersionID == requestVersionID {
                self.selectingVersionID = nil
            }
        }

        do {
            let service = ProjectsService()
            let loadState = try await self.loadLAZ(
                service: service,
                remoteProjectID: remoteProjectID,
                request: request,
                artifact: request.source.lazArtifact
            )
            try Task.checkCancellation()
            guard request == MeshLoadRequest(source: self.source, version: self.selectedVersion) else { return }
            self.isShowingStandaloneVersionSelector = false
            self.stopMeshJobPolling()
            self.loadState = loadState
        } catch is CancellationError {
            return
        } catch {
            guard request == MeshLoadRequest(source: self.source, version: self.selectedVersion) else { return }
            self.loadState = .failed(Self.message(for: error))
        }
    }

    private func loadLAZ(
        service: ProjectsService,
        remoteProjectID: String,
        request: MeshLoadRequest,
        artifact: MeshArtifactKind
    ) async throws -> LoadState {
        let pointCloud = try await service.fetchMergedArtifactFile(
            organizationID: self.organizationID,
            projectID: remoteProjectID,
            jobID: request.version.jobID,
            artifact: artifact,
            destinationURL: self.cacheFileURL(for: request.version, artifact: artifact)
        )
        let metadataURL: URL? = if let pointCloudIdentity = pointCloud.identity {
            if let metadata = try? await service.fetchMergedArtifactFile(
                organizationID: self.organizationID,
                projectID: remoteProjectID,
                jobID: pointCloudIdentity.jobID,
                artifact: .viewerMetadata,
                destinationURL: self.cacheFileURL(
                    for: request.version,
                    artifact: .viewerMetadata
                )
            ), metadata.identity == pointCloudIdentity {
                metadata.fileURL
            } else {
                nil
            }
        } else {
            nil
        }
        return .laz(
            LoadedCloud(
                fileURL: pointCloud.fileURL,
                metadataURL: metadataURL,
                identity: pointCloud.identity
            )
        )
    }

    private func loadMeshJobs() async {
        guard !self.isLoadingMeshJobs, let remoteProjectID = self.project.remoteID else { return }
        self.isLoadingMeshJobs = true
        self.meshJobsErrorMessage = nil
        defer { self.isLoadingMeshJobs = false }

        do {
            let jobs = try await ProjectsService().listMeshJobs(
                organizationID: self.organizationID,
                projectID: remoteProjectID,
                limit: 100
            )
            self.meshJobs = jobs.sorted {
                (Self.date(from: $0.createdAt) ?? .distantPast) > (Self.date(from: $1.createdAt) ?? .distantPast)
            }
        } catch is CancellationError {
            return
        } catch {
            self.meshJobsErrorMessage = "Couldn’t refresh merge jobs."
        }
    }

    private func startMeshJobPolling() {
        self.stopMeshJobPolling()
        self.meshJobPollingTask = Task { @MainActor in
            await self.loadMeshJobs()
            while !Task.isCancelled, self.meshJobs.contains(where: { $0.status.isInFlight }) {
                do {
                    try await Task.sleep(for: .seconds(5))
                } catch {
                    return
                }
                await self.loadMeshJobs()
            }
        }
    }

    private func stopMeshJobPolling() {
        self.meshJobPollingTask?.cancel()
        self.meshJobPollingTask = nil
    }
}
