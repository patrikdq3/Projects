import SwiftUI

// MARK: - OrgPicker

/// Workspace switcher: a compact nav pill showing the active organization that opens into a
/// frosted Liquid Glass dropdown of the organizations the user belongs to.
struct OrgPicker: View {
    // MARK: Lifecycle

    init(
        organizations: [Organization],
        selection: Binding<Organization.ID?>,
        invitationCount: Int = 0,
        onCreateOrganization: (() -> Void)? = nil,
        onManageOrganizations: (() -> Void)? = nil,
        onInvitations: (() -> Void)? = nil
    ) {
        self.organizations = organizations
        self._selection = selection
        self.invitationCount = invitationCount
        self.onCreateOrganization = onCreateOrganization
        self.onManageOrganizations = onManageOrganizations
        self.onInvitations = onInvitations
    }

    // MARK: Internal

    let organizations: [Organization]

    var body: some View {
        Button {
            self.isOpen = true
        } label: {
            self.pill
        }
        .buttonStyle(.plain)
        .popover(isPresented: self.$isOpen) {
            self.dropdown
                .presentationCompactAdaptation(.popover)
                .presentationBackground(.clear)
        }
        // Firm impact when the user switches orgs. Guarded so the initial
        // nil -> first-org assignment on load stays silent.
        .sensoryFeedback(trigger: self.selection) { oldValue, newValue in
            oldValue != nil && oldValue != newValue ? .impact(weight: .heavy, intensity: 1.0) : nil
        }
    }

    // MARK: Private

    /// Subtle neutral fill matching the design's `rgba(60,60,67,0.06)`.
    private static let fill = Color(red: 60 / 255, green: 60 / 255, blue: 67 / 255).opacity(0.06)

    /// Top/bottom fade so the org list dissolves into the glass as it scrolls.
    private static let fadeMask = LinearGradient(
        stops: [
            .init(color: .clear, location: 0),
            .init(color: .black, location: 0.04),
            .init(color: .black, location: 0.96),
            .init(color: .clear, location: 1),
        ],
        startPoint: .top,
        endPoint: .bottom
    )

    @Binding private var selection: Organization.ID?
    @State private var isOpen = false

    private let invitationCount: Int
    private let onCreateOrganization: (() -> Void)?
    private let onManageOrganizations: (() -> Void)?
    private let onInvitations: (() -> Void)?

    private var activeOrganization: Organization? {
        self.organizations.first { $0.id == self.selection } ?? self.organizations.first
    }

    // MARK: Collapsed pill (top-left nav)

    private var pill: some View {
        HStack(spacing: 8) {
            OrgMark(
                text: self.activeOrganization?.mark ?? "?",
                tint: self.activeOrganization?.tint ?? Color("Primary"),
                size: 24,
                corner: 7
            )

            Text(self.activeOrganization?.shortName ?? "Select Org")
                .font(.system(size: 15, weight: .semibold))
                .foregroundStyle(Color("TextPrimary"))
                .lineLimit(1)
                .tracking(-0.3)

            Image(systemName: "chevron.down")
                .font(.system(size: 9, weight: .semibold))
                .foregroundStyle(.secondary)
        }
        .padding(.leading, 6)
        .padding(.trailing, 10)
        .padding(.vertical, 5)
        .frame(maxWidth: 168)
        .background(Self.fill, in: .capsule)
    }

    // MARK: Expanded dropdown

    private var dropdown: some View {
        VStack(spacing: 0) {
            if !self.organizations.isEmpty {
                Text("Your Organizations")
                    .font(.system(size: 12, weight: .semibold))
                    .textCase(.uppercase)
                    .tracking(0.5)
                    .foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.horizontal, 18)
                    .padding(.top, 13)
                    .padding(.bottom, 8)
            }

            if self.organizations.isEmpty {
                Text("You're not part of any organizations yet. Create one below to get started.")
                    .font(.system(size: 13))
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
                    .frame(maxWidth: .infinity)
                    .padding(.horizontal, 18)
                    .padding(.vertical, 22)
            } else {
                ScrollView {
                    LazyVStack(spacing: 2) {
                        ForEach(self.organizations) { organization in
                            OrgRow(
                                organization: organization,
                                isSelected: organization.id == self.activeOrganization?.id
                            ) {
                                self.selection = organization.id
                                self.isOpen = false
                            }
                        }
                    }
                    .padding(.horizontal, 8)
                    .padding(.top, 2)
                    .padding(.bottom, 6)
                }
                .scrollBounceBehavior(.basedOnSize)
                .frame(maxHeight: 320)
                .mask(Self.fadeMask)
            }

            self.footer
        }
        .frame(width: 292)
        .glassEffect(.regular, in: .rect(cornerRadius: 22))
    }

    private var footer: some View {
        VStack(spacing: 0) {
            OrgActionRow(
                systemImage: "plus",
                title: "Create organization",
                tinted: true,
                showsChevron: false
            ) {
                self.dismissThen(self.onCreateOrganization)
            }

            OrgActionRow(
                systemImage: "envelope",
                title: "Invitations",
                tinted: false,
                showsChevron: true,
                badge: self.invitationCount
            ) {
                self.dismissThen(self.onInvitations)
            }

            OrgActionRow(
                systemImage: "gearshape",
                title: "Manage organizations",
                tinted: false,
                showsChevron: true
            ) {
                self.dismissThen(self.onManageOrganizations)
            }
        }
        .padding(6)
        .background(.white.opacity(0.18))
        .overlay(alignment: .top) {
            Rectangle()
                .fill(Color.primary.opacity(0.14))
                .frame(height: 0.5)
        }
    }

    /// Closes the popover, then runs `action` once it has finished dismissing. Presenting a
    /// sheet in the same turn the popover is dismissed leaves SwiftUI mid-transition and the
    /// sheet silently fails to appear, so the handoff is deferred a beat.
    private func dismissThen(_ action: (() -> Void)?) {
        self.isOpen = false
        guard let action else { return }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
            action()
        }
    }
}

// MARK: - OrgRow

private struct OrgRow: View {
    let organization: Organization
    let isSelected: Bool
    let onSelect: () -> Void

    var body: some View {
        Button(action: self.onSelect) {
            HStack(spacing: 12) {
                OrgMark(text: self.organization.mark, tint: self.organization.tint, size: 34)

                VStack(alignment: .leading, spacing: 1) {
                    Text(self.organization.name)
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundStyle(Color("TextPrimary"))
                        .tracking(-0.3)
                        .lineLimit(1)

                    Text("\(self.organization.role) · ^[\(self.organization.projectCount) project](inflect: true)")
                        .font(.system(size: 12))
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                }

                Spacer(minLength: 8)

                if self.isSelected {
                    Image(systemName: "checkmark")
                        .font(.system(size: 14, weight: .bold))
                        .foregroundStyle(Color("Primary"))
                }
            }
            .padding(.horizontal, 10)
            .padding(.vertical, 8)
            .frame(minHeight: 52)
            .background {
                RoundedRectangle(cornerRadius: 13, style: .continuous)
                    .fill(self.isSelected ? Color("Primary").opacity(0.12) : .clear)
            }
            .overlay {
                if self.isSelected {
                    RoundedRectangle(cornerRadius: 13, style: .continuous)
                        .strokeBorder(Color("Primary").opacity(0.25), lineWidth: 0.5)
                }
            }
            .contentShape(.rect(cornerRadius: 13))
        }
        .buttonStyle(.plain)
        .accessibilityElement(children: .combine)
        .accessibilityAddTraits(self.isSelected ? [.isButton, .isSelected] : .isButton)
    }
}

// MARK: - OrgActionRow

/// A pinned utility row beneath the scrollable org list (Create / Manage).
private struct OrgActionRow: View {
    let systemImage: String
    let title: String
    let tinted: Bool
    let showsChevron: Bool
    var badge = 0
    let action: () -> Void

    var body: some View {
        Button(action: self.action) {
            HStack(spacing: 12) {
                ZStack {
                    Circle()
                        .fill(self.tinted
                            ? Color("Primary").opacity(0.12)
                            : Color.primary.opacity(0.06))
                    Image(systemName: self.systemImage)
                        .font(.system(size: self.tinted ? 15 : 13, weight: .regular))
                        .foregroundStyle(self.tinted ? Color("Primary") : Color.secondary)
                }
                .frame(width: 26, height: 26)

                Text(self.title)
                    .font(.system(size: 15))
                    .foregroundStyle(Color("TextPrimary"))

                Spacer(minLength: 8)

                if self.badge > 0 {
                    Text("\(self.badge)")
                        .font(.system(size: 12, weight: .bold))
                        .foregroundStyle(.white)
                        .padding(.horizontal, 7)
                        .frame(minWidth: 20, minHeight: 20)
                        .background(Color("Primary"), in: .capsule)
                }

                if self.showsChevron {
                    Image(systemName: "chevron.right")
                        .font(.system(size: 11, weight: .semibold))
                        .foregroundStyle(.tertiary)
                }
            }
            .padding(.horizontal, 10)
            .padding(.vertical, 9)
            .frame(minHeight: 42)
            .contentShape(.rect)
        }
        .buttonStyle(.plain)
    }
}

// MARK: - OrgMark

/// Rounded-square monogram badge tinted with the organization's color.
private struct OrgMark: View {
    let text: String
    let tint: Color
    var size: CGFloat = 36
    var corner: CGFloat?

    var body: some View {
        Text(self.text)
            .font(.system(size: self.size * 0.38, weight: .semibold))
            .tracking(-0.4)
            .foregroundStyle(.white)
            .frame(width: self.size, height: self.size)
            .background(self.tint)
            .clipShape(RoundedRectangle(
                cornerRadius: self.corner ?? (self.size * 0.28),
                style: .continuous
            ))
            .shadow(color: .black.opacity(0.10), radius: 1, x: 0, y: 1)
    }
}
