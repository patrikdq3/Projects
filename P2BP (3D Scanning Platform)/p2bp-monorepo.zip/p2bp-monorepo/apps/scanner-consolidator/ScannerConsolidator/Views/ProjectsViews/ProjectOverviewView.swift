import SwiftUI

// MARK: - ProjectOverviewView

struct ProjectOverviewView: View {
    // MARK: Internal

    let project: Project

    var body: some View {
        ScrollView {
            VStack(spacing: 18) {
                self.header
                self.metadata
                self.mergeJobSection

                if self.canManage {
                    self.managementSection
                }
            }
            .padding(.horizontal, 16)
            .padding(.top, 4)
            .padding(.bottom, 28)
        }
        .scrollBounceBehavior(.basedOnSize)
        .background(Color("Background"))
        .alert("Rename Project", isPresented: self.$isRenaming) {
            TextField("Project name", text: self.$renameText)
            Button("Save") {
                self.commitRename()
            }
            Button("Cancel", role: .cancel) {}
        } message: {
            Text("Enter a new name for this project.")
        }
        .alert("Couldn’t complete that", isPresented: self.managementErrorBinding) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(self.managementError ?? "")
        }
        .alert(
            self.meshJobAlert?.title ?? "",
            isPresented: self.meshJobAlertBinding,
            presenting: self.meshJobAlert
        ) { _ in
            Button("OK", role: .cancel) {}
        } message: { alert in
            Text(alert.message)
        }
        .choicePrompt(self.$meshJobLaunchChoice)
        .confirmationPrompt(self.$deleteConfirmation)
        .navigationDestination(item: self.$meshDestination) { _ in
            self.mergedMeshDestination
        }
        .sensoryFeedback(.warning, trigger: self.didOpenDeleteConfirmation)
        .sensoryFeedback(.success, trigger: self.meshJobSucceeded)
        .sensoryFeedback(.error, trigger: self.meshJobFailed)
        .sensoryFeedback(.warning, trigger: self.meshJobWarned)
    }

    // MARK: Private

    @EnvironmentObject private var projectStore: ProjectStore
    @EnvironmentObject private var remoteProjectsDataCoordinator: RemoteProjectsDataCoordinator
    @Environment(\.dismiss) private var dismiss

    // Management state, owned by this screen.
    @State private var isRenaming = false
    @State private var renameText = ""
    @State private var deleteConfirmation: ConfirmationPrompt?
    @State private var didOpenDeleteConfirmation = false
    @State private var isManaging = false
    @State private var managementError: String?

    // Mesh-job state, owned by this screen.
    @State private var isLaunchingMeshJob = false
    @State private var meshJobAlert: MeshJobAlert?
    @State private var meshJobSucceeded = false
    @State private var meshJobFailed = false
    @State private var meshJobWarned = false
    @State private var meshJobLaunchChoice: ChoicePrompt?
    @State private var meshDestination: MergedPointCloudSource?

    private var manager: ProjectManagementController {
        ProjectManagementController(
            projectStore: self.projectStore,
            coordinator: self.remoteProjectsDataCoordinator
        )
    }

    private var managementErrorBinding: Binding<Bool> {
        Binding(
            get: { self.managementError != nil },
            set: { isPresented in
                if !isPresented {
                    self.managementError = nil
                }
            }
        )
    }

    private var meshJobAlertBinding: Binding<Bool> {
        Binding(
            get: { self.meshJobAlert != nil },
            set: { isPresented in
                if !isPresented {
                    self.meshJobAlert = nil
                }
            }
        )
    }

    private var completedCount: Int {
        self.project.zoneCountSummary[.complete] ?? 0
    }

    /// Whether the viewer is an owner/admin of the org that owns this project, and so may rename
    /// or delete it. Resolved here so the hub owns its own permission.
    private var canManage: Bool {
        guard let organizationID = self.project.owningRemoteOrganizationID,
              let organization = self.remoteProjectsDataCoordinator.organizations.first(where: {
                  $0.id == organizationID
              })
        else {
            return false
        }
        let role = OrgRole(apiValue: organization.role)
        return role == .owner || role == .admin
    }

    /// Only owners and admins may launch a merge job; members and scanners see it greyed out.
    private var canLaunchMergeJob: Bool {
        self.canManage
    }

    private var organizationName: String? {
        guard let organizationID = self.project.owningRemoteOrganizationID else { return nil }
        return self.remoteProjectsDataCoordinator.organizations.first { $0.id == organizationID }?.name
    }

    /// The organization to address for remote edits/deletes: the project's owner, falling back
    /// to the currently selected workspace.
    private var managementOrganizationID: String? {
        self.project.owningRemoteOrganizationID ?? self.remoteProjectsDataCoordinator.selectedOrganizationID
    }

    private var launchMergeJobSubtitle: String {
        if !self.canLaunchMergeJob {
            return "Only owners and admins can launch"
        }
        if self.isLaunchingMeshJob {
            return "Starting…"
        }
        return "Combine this project's zone scans"
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(alignment: .firstTextBaseline, spacing: 10) {
                Text(self.project.name)
                    .font(.system(size: 26, weight: .bold))
                    .tracking(-0.5)
                    .foregroundStyle(Color("TextPrimary"))
                    .lineLimit(2)

                Spacer(minLength: 8)
            }

            Text("Created \(self.project.createdAt.formatted(.relative(presentation: .numeric)))")
                .font(.system(size: 13, weight: .medium))
                .foregroundStyle(Color("TextSecondary"))
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private var metadata: some View {
        VStack(spacing: 0) {
            if let organizationName = self.organizationName {
                self.metadataRow(icon: "building.2", title: "Organization", value: organizationName)
                Divider().padding(.leading, 44)
            }
            self.metadataRow(
                icon: "square.dashed",
                title: "Area",
                value: self.project.boundary.areaSquareMeters.areaText
            )
            Divider().padding(.leading, 44)
            self.metadataRow(
                icon: "square.grid.3x3",
                title: "Zones",
                value: "\(self.completedCount) of \(self.project.zones.count) scanned"
            )
        }
        .padding(.vertical, 4)
        .background(Color("Surface"), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 16, style: .continuous)
                .stroke(Color("TextTertiary").opacity(0.1), lineWidth: 1)
        )
    }

    private var mergeJobSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Merge Job")
                .font(.system(size: 13, weight: .semibold))
                .foregroundStyle(Color("TextTertiary"))
                .textCase(.uppercase)
                .tracking(0.4)
                .padding(.leading, 4)

            VStack(spacing: 0) {
                self.managementRow(ProjectManagementRow(
                    icon: "square.stack.3d.up",
                    title: "Launch merge job",
                    subtitle: self.launchMergeJobSubtitle,
                    tint: Color("TextPrimary"),
                    showsChevron: false,
                    isLoading: self.isLaunchingMeshJob,
                    action: self.canLaunchMergeJob && !self.isLaunchingMeshJob
                        ? { self.presentMeshJobLaunchChoice() }
                        : nil
                ))
                Divider().padding(.leading, 48)
                self.managementRow(ProjectManagementRow(
                    icon: "cube.transparent",
                    title: "View merged point clouds",
                    subtitle: "Preview or full LAZ",
                    tint: Color("TextPrimary"),
                    showsChevron: true,
                    action: { self.meshDestination = .laz }
                ))
            }
            .background(Color("Surface"), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 16, style: .continuous)
                    .stroke(Color("TextTertiary").opacity(0.1), lineWidth: 1)
            )
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.top, 4)
    }

    private var managementSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Management")
                .font(.system(size: 13, weight: .semibold))
                .foregroundStyle(Color("TextTertiary"))
                .textCase(.uppercase)
                .tracking(0.4)
                .padding(.leading, 4)

            VStack(spacing: 0) {
                self.managementRow(ProjectManagementRow(
                    icon: "pencil",
                    title: "Edit name",
                    subtitle: nil,
                    tint: Color("TextPrimary"),
                    showsChevron: true,
                    action: { self.beginRename() }
                ))
                Divider().padding(.leading, 48)
                self.managementRow(ProjectManagementRow(
                    icon: "trash",
                    title: "Delete project",
                    subtitle: nil,
                    tint: Color("Error"),
                    showsChevron: false,
                    action: { self.beginDelete() }
                ))
            }
            .background(Color("Surface"), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 16, style: .continuous)
                    .stroke(Color("TextTertiary").opacity(0.1), lineWidth: 1)
            )
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.top, 4)
    }

    @ViewBuilder
    private var mergedMeshDestination: some View {
        if let organizationID = self.managementOrganizationID {
            MergedMeshView(project: self.project, organizationID: organizationID)
        } else {
            ContentUnavailableView(
                "Merged Point Cloud Unavailable",
                systemImage: "cube.transparent",
                description: Text("This project isn't connected to an organization.")
            )
        }
    }

    private func metadataRow(icon: String, title: String, value: String) -> some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .font(.system(size: 14, weight: .semibold))
                .foregroundStyle(Color("TextSecondary"))
                .frame(width: 20)

            Text(title)
                .font(.system(size: 14.5, weight: .medium))
                .foregroundStyle(Color("TextSecondary"))

            Spacer(minLength: 8)

            Text(value)
                .font(.system(size: 14.5, weight: .semibold))
                .foregroundStyle(Color("TextPrimary"))
                .multilineTextAlignment(.trailing)
                .lineLimit(1)
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 13)
    }

    private func managementRow(_ row: ProjectManagementRow) -> some View {
        Button {
            row.action?()
        } label: {
            HStack(spacing: 12) {
                Image(systemName: row.icon)
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundStyle(row.tint)
                    .frame(width: 24)

                VStack(alignment: .leading, spacing: 2) {
                    Text(row.title)
                        .font(.system(size: 15.5, weight: .semibold))
                        .foregroundStyle(row.tint)
                    if let subtitle = row.subtitle {
                        Text(subtitle)
                            .font(.system(size: 12))
                            .foregroundStyle(Color("TextTertiary"))
                    }
                }

                Spacer(minLength: 8)

                if row.isLoading {
                    ProgressView()
                        .controlSize(.small)
                } else if row.showsChevron {
                    Image(systemName: "chevron.right")
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundStyle(Color("TextTertiary"))
                }
            }
            .padding(.horizontal, 14)
            .padding(.vertical, 13)
            .contentShape(.rect)
        }
        .buttonStyle(.plain)
        .disabled(row.action == nil)
        .opacity(row.action == nil && !row.isLoading ? 0.5 : 1)
        .accessibilityIdentifier("projectManagement_\(row.title)")
    }

    // MARK: Management actions

    private func beginRename() {
        self.renameText = self.project.name
        self.isRenaming = true
    }

    private func commitRename() {
        let trimmedName = self.renameText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmedName.isEmpty else {
            self.managementError = ProjectStoreError.invalidProjectName.localizedDescription
            return
        }
        guard trimmedName != self.project.name else { return }

        Task {
            self.isManaging = true
            defer { self.isManaging = false }
            do {
                try await self.manager.rename(
                    localID: self.project.id,
                    remoteID: self.project.remoteID,
                    organizationID: self.managementOrganizationID,
                    currentName: self.project.name,
                    to: trimmedName
                )
            } catch {
                self.managementError = self.managementErrorMessage(for: error)
            }
        }
    }

    private func beginDelete() {
        self.didOpenDeleteConfirmation.toggle()
        self.deleteConfirmation = ConfirmationPrompt(
            icon: "trash",
            title: "Delete \(self.project.name)?",
            message: """
            This removes the project from this workspace and deletes any local scan \
            artifacts on this device.
            """,
            confirmTitle: "Delete project",
            confirmIcon: "trash"
        ) {
            self.performDelete()
        }
    }

    private func performDelete() {
        Task {
            self.isManaging = true
            defer { self.isManaging = false }
            do {
                try await self.manager.delete(
                    localID: self.project.id,
                    remoteID: self.project.remoteID,
                    organizationID: self.managementOrganizationID
                )
                // Project is gone — return to the list.
                self.dismiss()
            } catch {
                self.managementError = self.managementErrorMessage(for: error)
            }
        }
    }

    // MARK: Mesh-job actions

    /// Fetches the project's zones first; with none, surfaces the error without launching. Otherwise
    /// starts a merge job and reports success or failure with matching haptics and a message.
    private func presentMeshJobLaunchChoice() {
        self.meshJobLaunchChoice = ChoicePrompt(
            icon: "square.stack.3d.up",
            title: "Launch merge job",
            message: "Choose whether matching completed work may be reused.",
            options: [
                ChoicePromptOption(
                    icon: "arrow.triangle.2.circlepath",
                    title: "Launch or reuse",
                    subtitle: "Reuse an identical completed result"
                ) {
                    self.launchMeshJob(force: false)
                },
                ChoicePromptOption(
                    icon: "plus.square.on.square",
                    title: "Run again",
                    subtitle: "Create a fresh version when possible"
                ) {
                    self.launchMeshJob(force: true)
                },
            ]
        )
    }

    private func launchMeshJob(force: Bool) {
        guard let organizationID = self.managementOrganizationID,
              let remoteProjectID = self.project.remoteID
        else {
            self.presentMeshJobAlert(
                title: "Can’t launch merge job",
                message: "This project isn’t connected to the server yet.",
                feedback: .failure
            )
            return
        }

        Task {
            self.isLaunchingMeshJob = true
            defer { self.isLaunchingMeshJob = false }

            do {
                let zonesService = ZonesService(organizationID: organizationID, projectID: remoteProjectID)
                let zones = try await zonesService.listZones()

                guard !zones.isEmpty else {
                    self.presentMeshJobAlert(
                        title: "No zones to merge",
                        message: "Add and scan at least one zone before launching a merge job.",
                        feedback: .warning
                    )
                    return
                }

                let response = try await ProjectsService().launchMeshJob(
                    organizationID: organizationID,
                    projectID: remoteProjectID,
                    force: force
                )

                self.presentMeshJobLaunchResult(response)
            } catch {
                self.presentMeshJobAlert(
                    title: "Couldn’t start merge job",
                    message: self.meshJobErrorMessage(for: error),
                    feedback: .failure
                )
            }
        }
    }

    private func presentMeshJobLaunchResult(_ response: LaunchMeshJobResponse) {
        if response.reused {
            switch response.job.status {
            case .queued, .running:
                self.presentMeshJobAlert(
                    title: "Merge already in progress",
                    message: "An identical merge job is already \(response.job.status.rawValue).",
                    feedback: .warning
                )
            case .completed:
                self.presentMeshJobAlert(
                    title: "Existing merge ready",
                    message: "The selected zone scans already have a completed merged result.",
                    feedback: .success
                )
            case .failed, .unknown:
                self.presentMeshJobAlert(
                    title: "Existing merge job reused",
                    message: "The server reused an existing merge job with status \(response.job.status.rawValue).",
                    feedback: .warning
                )
            }
            return
        }

        self.presentMeshJobAlert(
            title: "Merge job started",
            message: "We’re merging this project’s active zone scans. Open the merged viewer to monitor progress.",
            feedback: .success
        )
    }

    private func presentMeshJobAlert(title: String, message: String, feedback: MeshJobFeedback) {
        self.meshJobAlert = MeshJobAlert(title: title, message: message)
        switch feedback {
        case .success: self.meshJobSucceeded.toggle()
        case .failure: self.meshJobFailed.toggle()
        case .warning: self.meshJobWarned.toggle()
        }
    }

    private func meshJobErrorMessage(for error: Error) -> String {
        switch error {
        case ProjectsServiceError.noUploadedScansAvailable:
            "No uploaded zone scans are available to merge yet."
        case RequestServiceError.missingAuthToken, RequestServiceError.unauthorized:
            "Sign in again to launch a merge job."
        case RequestServiceError.forbidden:
            "You do not have access to launch a merge job for this project."
        case RequestServiceError.network:
            "Couldn’t reach the server. Check your connection and try again."
        case let RequestServiceError.invalidInput(message):
            message ?? "The merge job request is invalid."
        default:
            error.localizedDescription
        }
    }

    private func managementErrorMessage(for error: Error) -> String {
        switch error {
        case RequestServiceError.missingAuthToken, RequestServiceError.unauthorized:
            "Sign in again to manage remote projects."
        case RequestServiceError.forbidden:
            "You do not have access to manage this project."
        case RequestServiceError.notFound:
            "The selected project could not be found."
        case let RequestServiceError.invalidInput(message):
            message ?? "The project update is invalid."
        default:
            error.localizedDescription
        }
    }
}

// MARK: - MeshJobAlert

/// A one-off informational alert shown after a merge-job attempt.
private struct MeshJobAlert: Identifiable {
    let id = UUID()
    let title: String
    let message: String
}

// MARK: - MeshJobFeedback

/// The haptic tone paired with a merge-job alert.
private enum MeshJobFeedback {
    case success
    case failure
    case warning
}

// MARK: - ProjectManagementRow

private struct ProjectManagementRow {
    let icon: String
    let title: String
    let subtitle: String?
    let tint: Color
    let showsChevron: Bool
    var isLoading = false
    let action: (() -> Void)?
}
