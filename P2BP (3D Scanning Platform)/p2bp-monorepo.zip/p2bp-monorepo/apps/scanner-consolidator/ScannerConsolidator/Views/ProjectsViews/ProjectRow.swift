import SwiftUI

// MARK: - ProjectRow

struct ProjectRow: View {
    // MARK: Internal

    let project: ProjectRowModel
    /// Whether this row may be renamed/deleted. Remote-backed rows require an org owner/admin
    /// role; local-only rows are always manageable. Computed per row by the parent list.
    let canManage: Bool
    let onRename: (ProjectRowModel) -> Void
    let onDelete: (ProjectRowModel) -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            VStack(alignment: .leading, spacing: 3) {
                HStack {
                    Text(self.project.name)
                        .font(.headline)
                        .foregroundStyle(Color("TextPrimary"))

                    Spacer()

                    Menu {
                        Button("Rename") {
                            self.onRename(self.project)
                        }
                        .disabled(!self.canManage)

                        Button("Delete", role: .destructive) {
                            self.onDelete(self.project)
                        }
                        .disabled(!self.canManage)
                    } label: {
                        Image(systemName: "ellipsis")
                            .font(.system(size: 18, weight: .semibold))
                            .foregroundStyle(.primary)
                            .frame(width: 28, height: 28)
                            .background(.ultraThinMaterial)
                            .clipShape(Circle())
                            .shadow(radius: 6)
                    }
                }

                HStack(spacing: 8) {
                    Text(self.project.detailText)
                    Text("·").foregroundStyle(.tertiary)
                    Text(self.project.metricText)
                }
                .font(.footnote)
                .foregroundStyle(.secondary)
            }

            VStack(spacing: 10) {
                ProjectProgressBar(
                    notStarted: self.project.notStarted,
                    inProgress: self.project.inProgress,
                    complete: self.project.complete
                )

                HStack(spacing: 0) {
                    HStack(spacing: 14) {
                        self.statLabel(self.project.complete, "done", color: ZoneStatus.complete.color)
                        if self.project.inProgress > 0 {
                            self.statLabel(self.project.inProgress, "scanning", color: ZoneStatus.inProgress.color)
                        }
                        self.statLabel(self.project.notStarted, "to go", color: Color("TextPrimary"))
                    }
                    Spacer(minLength: 8)
                    Text("\(self.project.percentComplete)%")
                        .foregroundStyle(.secondary)
                        .contentTransition(.numericText(value: Double(self.project.percentComplete)))
                }
                .font(.footnote)
                .animation(.easeInOut(duration: 0.6), value: self.progressCounts)
            }
        }
        .padding(16)
        .background(Color("Surface"))
        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
        .shadow(color: .black.opacity(0.04), radius: 1, x: 0, y: 1)
    }

    // MARK: Private

    private var progressCounts: [Int] {
        [self.project.notStarted, self.project.inProgress, self.project.complete]
    }

    private func statLabel(_ count: Int, _ label: String, color: Color) -> some View {
        HStack(spacing: 4) {
            Text("\(count)")
                .fontWeight(.semibold)
                .foregroundStyle(color)
                .contentTransition(.numericText(value: Double(count)))
            Text(label)
                .foregroundStyle(.secondary)
        }
    }
}

// MARK: - ProjectProgressBar

struct ProjectProgressBar: View {
    // MARK: Internal

    let notStarted: Int
    let inProgress: Int
    let complete: Int

    var body: some View {
        GeometryReader { geo in
            HStack(spacing: 0) {
                Rectangle()
                    .fill(ZoneStatus.complete.color)
                    .frame(width: self.width(for: self.complete, in: geo.size.width))
                Rectangle()
                    .fill(ZoneStatus.inProgress.color)
                    .frame(width: self.width(for: self.inProgress, in: geo.size.width))
                Spacer(minLength: 0)
            }
        }
        .frame(height: 6)
        .background(Color.primary.opacity(0.06))
        .clipShape(Capsule())
        .animation(.easeInOut(duration: 0.6), value: self.progressCounts)
    }

    // MARK: Private

    private var progressCounts: [Int] {
        [self.notStarted, self.inProgress, self.complete]
    }

    private var total: Int {
        max(self.notStarted + self.inProgress + self.complete, 1)
    }

    private func width(for count: Int, in fullWidth: CGFloat) -> CGFloat {
        fullWidth * CGFloat(count) / CGFloat(self.total)
    }
}
