import SwiftUI

// MARK: - ProjectZonesView

struct ProjectZonesView: View {
    // MARK: Internal

    let project: Project
    /// Invoked when a zone row is tapped, with the selected zone's identifier.
    let onSelectZone: (UUID) -> Void

    var body: some View {
        VStack(spacing: 0) {
            self.header
            self.list
        }
    }

    // MARK: Private

    @State private var showsColorKey = false

    private var completedCount: Int {
        self.project.zoneCountSummary[.complete] ?? 0
    }

    private var header: some View {
        VStack(spacing: 0) {
            HStack(alignment: .center, spacing: 8) {
                Text("Zones")
                    .font(.system(size: 19, weight: .bold))
                    .tracking(-0.3)
                    .foregroundStyle(Color("TextPrimary"))

                Text("\(self.project.zones.count)")
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundStyle(Color("TextSecondary"))
                    .padding(.horizontal, 7)
                    .padding(.vertical, 2)
                    .background(Color("SurfaceSecondary"), in: Capsule())

                Spacer(minLength: 8)

                Text("\(self.completedCount) of \(self.project.zones.count) scanned")
                    .font(.system(size: 12.5, weight: .medium))
                    .foregroundStyle(Color("TextTertiary"))
            }
            .padding(.horizontal, 18)

            if self.showsColorKey {
                ZoneColorKey()
                    .padding(.horizontal, 18)
                    .padding(.top, 12)
                    .transition(.move(edge: .top).combined(with: .opacity))
            }
        }
        .padding(.bottom, 12)
    }

    private var list: some View {
        ScrollView {
            LazyVStack(spacing: 9) {
                ForEach(self.project.sortedZones) { zone in
                    Button {
                        self.onSelectZone(zone.id)
                    } label: {
                        ZoneRow(zone: zone)
                    }
                    .buttonStyle(.plain)
                    .accessibilityIdentifier("zoneRow_\(zone.name)")
                }
            }
            .padding(.horizontal, 16)
            .padding(.top, 2)
            .padding(.bottom, 28)
        }
        .scrollBounceBehavior(.basedOnSize)
    }
}

// MARK: - ZoneRow

struct ZoneRow: View {
    // MARK: Internal

    let zone: Zone

    var body: some View {
        HStack(spacing: 13) {
            VStack(alignment: .leading, spacing: 2) {
                Text(self.zone.name)
                    .font(.system(size: 15.5, weight: .semibold))
                    .foregroundStyle(Color("TextPrimary"))
                    .lineLimit(1)
                Text(self.metaText)
                    .font(.system(size: 12.5))
                    .foregroundStyle(Color("TextSecondary"))
                    .lineLimit(1)
            }

            Spacer(minLength: 8)

            VStack(alignment: .trailing, spacing: 2) {
                Text(self.zone.status.displayName)
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundStyle(self.zone.status.color)
                    .lineLimit(1)
                Text(self.detailText)
                    .font(.system(size: 11))
                    .foregroundStyle(Color("TextTertiary"))
                    .lineLimit(1)
            }

            Image(systemName: "chevron.right")
                .font(.system(size: 13, weight: .semibold))
                .foregroundStyle(Color("TextTertiary"))
        }
        .padding(.horizontal, 13)
        .padding(.vertical, 11)
        .background(Color("Surface"), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .stroke(Color("TextTertiary").opacity(0.1), lineWidth: 1)
        )
    }

    // MARK: Private

    private var metaText: String {
        let position = "Row \(self.zone.rowIndex + 1) · Col \(self.zone.columnIndex + 1)"
        return "\(position) · \(self.zone.footprint.areaSquareMeters.areaText)"
    }

    private var detailText: String {
        switch self.zone.scanState {
        case .notStarted:
            "Ready"
        case .inProgress:
            self.zone.scanStartedAt.map { $0.formatted(.relative(presentation: .numeric)) } ?? "Started"
        case .complete:
            self.zone.scanCompletedAt.map { $0.formatted(.relative(presentation: .numeric)) } ?? "Done"
        }
    }
}

// MARK: - ZoneColorKey

/// A compact legend that maps each zone status to the color it renders as on the map grid.
struct ZoneColorKey: View {
    var body: some View {
        HStack(spacing: 16) {
            ForEach(ZoneStatus.allCases) { status in
                HStack(spacing: 6) {
                    RoundedRectangle(cornerRadius: 4, style: .continuous)
                        .fill(status.color.opacity(0.45))
                        .overlay(
                            RoundedRectangle(cornerRadius: 4, style: .continuous)
                                .stroke(status.color, lineWidth: 1.5)
                        )
                        .frame(width: 14, height: 14)

                    Text(status.displayName)
                        .font(.system(size: 12, weight: .medium))
                        .foregroundStyle(Color("TextSecondary"))
                        .lineLimit(1)
                }
            }

            Spacer(minLength: 0)
        }
    }
}
