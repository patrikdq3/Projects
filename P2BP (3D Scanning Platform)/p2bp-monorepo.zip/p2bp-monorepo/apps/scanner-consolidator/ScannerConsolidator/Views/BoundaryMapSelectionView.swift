import MapKit
import SwiftUI
import UIKit

// MARK: - BoundaryMapSelectionView

struct BoundaryMapSelectionView: View {
    // MARK: Lifecycle

    init(
        startingPoint: ProjectLocationChoice,
        startingCoordinate: GeoCoordinate? = nil,
        existingBoundary: ProjectBoundary?,
        onSelect: @escaping (MapSelectionResult) -> Void
    ) {
        self.startingPoint = startingPoint
        self.startingCoordinate = startingCoordinate
        self.existingBoundary = existingBoundary
        self.onSelect = onSelect

        let center = startingCoordinate ?? Self.fallbackCenter
        let initialVertices: [GeoCoordinate] = if let existing = existingBoundary, existing.vertices.count >= 3 {
            existing.vertices
        } else {
            Self.defaultSquare(around: center)
        }
        _draftBoundary = State(initialValue: ProjectBoundary(vertices: initialVertices))
    }

    // MARK: Internal

    let startingPoint: ProjectLocationChoice
    let startingCoordinate: GeoCoordinate?
    let existingBoundary: ProjectBoundary?
    let onSelect: (MapSelectionResult) -> Void

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                if let statusMessage = locationManager.statusMessage, startingPoint == .currentLocation {
                    Text(statusMessage)
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(.horizontal, 16)
                        .padding(.vertical, 12)
                        .background(Color("SurfaceSecondary"))
                }

                ZStack(alignment: .topTrailing) {
                    PolygonEditingMapRepresentable(
                        boundary: self.$draftBoundary,
                        requestedCenter: self.requestedCenter ?? self.startingCoordinate ?? self.existingBoundary?
                            .center ?? Self.fallbackCenter,
                        showsUserLocation: self.startingPoint == .currentLocation,
                        useSatellite: self.useSatellite
                    )

                    Button {
                        self.useSatellite.toggle()
                    } label: {
                        Label(
                            self.useSatellite ? "Map" : "Satellite",
                            systemImage: self.useSatellite ? "map" : "globe.americas.fill"
                        )
                        .font(.caption.weight(.medium))
                        .padding(.horizontal, 10)
                        .padding(.vertical, 7)
                        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 8))
                    }
                    .padding(12)
                }
                .ignoresSafeArea(edges: .bottom)

                VStack(alignment: .leading, spacing: 10) {
                    HStack(spacing: 12) {
                        MeasurementStat(title: "Width", value: self.draftBoundary.widthMeters.lengthText)
                        MeasurementStat(title: "Height", value: self.draftBoundary.heightMeters.lengthText)
                        MeasurementStat(title: "Area", value: self.draftBoundary.areaSquareMeters.areaText)
                    }
                    Text(self.helperText)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                }
                .padding(16)
                .background(.ultraThinMaterial)
            }
            .navigationTitle("Select Boundary")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button("Cancel") {
                        self.dismiss()
                    }
                }

                ToolbarItem(placement: .topBarTrailing) {
                    Button("Use Boundary") {
                        self.onSelect(MapSelectionResult(boundary: self.draftBoundary))
                        self.dismiss()
                    }
                    .fontWeight(.semibold)
                    .disabled(self.draftBoundary.vertices.count < ProjectCreationValidator.minimumVertexCount)
                    .accessibilityIdentifier("confirmBoundaryButton")
                }
            }
        }
        .onAppear {
            if self.startingPoint == .currentLocation {
                self.locationManager.requestCurrentLocation()
            }
        }
        .onReceive(self.locationManager.$currentCoordinate) { coordinate in
            guard self.startingPoint == .currentLocation, let coordinate else { return }
            self.requestedCenter = coordinate
            if self.draftBoundary.vertices == Self.defaultSquare(around: Self.fallbackCenter) {
                self.draftBoundary = ProjectBoundary(vertices: Self.defaultSquare(around: coordinate))
            }
        }
    }

    // MARK: Private

    private static let fallbackCenter = GeoCoordinate(latitude: 37.3349, longitude: -122.0090)

    @Environment(\.dismiss) private var dismiss

    @StateObject private var locationManager = LocationAuthorizationManager()
    @State private var draftBoundary: ProjectBoundary
    @State private var requestedCenter: GeoCoordinate?
    @State private var useSatellite = true

    private var helperText: String {
        let count = self.draftBoundary.vertices.count
        let max = ProjectCreationValidator.maximumVertexCount
        return """
        Vertices: \(count) / \(max)  •  Long-press the map to add a point, double-tap a point to delete it, \
        or drag a point to move it.
        """
    }

    private static func defaultSquare(around center: GeoCoordinate) -> [GeoCoordinate] {
        let halfEdge = 9.0
        return [
            BoundaryGeometry.coordinate(from: center, movingEast: -halfEdge, movingNorth: halfEdge),
            BoundaryGeometry.coordinate(from: center, movingEast: halfEdge, movingNorth: halfEdge),
            BoundaryGeometry.coordinate(from: center, movingEast: halfEdge, movingNorth: -halfEdge),
            BoundaryGeometry.coordinate(from: center, movingEast: -halfEdge, movingNorth: -halfEdge),
        ]
    }
}

// MARK: - PolygonEditingMapRepresentable

private struct PolygonEditingMapRepresentable: UIViewRepresentable {
    @Binding var boundary: ProjectBoundary

    let requestedCenter: GeoCoordinate
    let showsUserLocation: Bool
    let useSatellite: Bool

    func makeUIView(context: Context) -> PolygonEditingMapContainerView {
        let view = PolygonEditingMapContainerView()
        view.onBoundaryChange = { newBoundary in
            self.boundary = newBoundary
        }
        view.configure(
            initialVertices: self.boundary.vertices,
            center: self.requestedCenter,
            showsUserLocation: self.showsUserLocation
        )
        view.setMapType(self.useSatellite ? .satellite : .mutedStandard)
        return view
    }

    func updateUIView(_ uiView: PolygonEditingMapContainerView, context _: Context) {
        uiView.configure(
            initialVertices: self.boundary.vertices,
            center: self.requestedCenter,
            showsUserLocation: self.showsUserLocation
        )
        uiView.setMapType(self.useSatellite ? .satellite : .mutedStandard)
    }
}

// MARK: - VertexAnnotation

private final nonisolated class VertexAnnotation: MKPointAnnotation {
    var index = 0
}

// MARK: - VertexAnnotationView

private final class VertexAnnotationView: MKAnnotationView {
    // MARK: Lifecycle

    override init(annotation: MKAnnotation?, reuseIdentifier: String?) {
        super.init(annotation: annotation, reuseIdentifier: reuseIdentifier)
        self.frame = CGRect(x: 0, y: 0, width: 32, height: 32)
        self.backgroundColor = .clear
        self.canShowCallout = false
        self.centerOffset = .zero

        let circle = UIView(frame: self.bounds)
        circle.backgroundColor = .white
        circle.layer.cornerRadius = 16
        circle.layer.borderWidth = 2
        circle.layer.borderColor = UIColor.systemBlue.cgColor
        circle.isUserInteractionEnabled = false
        self.addSubview(circle)

        let pan = UIPanGestureRecognizer(target: self, action: #selector(handlePan(_:)))
        self.addGestureRecognizer(pan)

        let doubleTap = UITapGestureRecognizer(target: self, action: #selector(handleDoubleTap(_:)))
        doubleTap.numberOfTapsRequired = 2
        self.addGestureRecognizer(doubleTap)
    }

    @available(*, unavailable)
    required init?(coder _: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    // MARK: Internal

    static let reuseIdentifier = "VertexAnnotationView"

    // gesture handler declaration
    var onPan: ((UIPanGestureRecognizer) -> Void)?
    var onDoubleTap: (() -> Void)?

    override func point(inside point: CGPoint, with _: UIEvent?) -> Bool {
        self.bounds.insetBy(dx: -8, dy: -8).contains(point)
    }

    // MARK: Private

    @objc
    private func handlePan(_ recognizer: UIPanGestureRecognizer) {
        self.onPan?(recognizer)
    }

    @objc
    private func handleDoubleTap(_: UITapGestureRecognizer) {
        self.onDoubleTap?()
    }
}

// MARK: - MutablePolygonOverlay

private final nonisolated class MutablePolygonOverlay: NSObject, MKOverlay {
    var coordinates: [CLLocationCoordinate2D] = []

    var coordinate: CLLocationCoordinate2D {
        self.coordinates.first ?? CLLocationCoordinate2D(latitude: 0, longitude: 0)
    }

    var boundingMapRect: MKMapRect {
        .world
    }
}

// MARK: - MutablePolygonRenderer

private final class MutablePolygonRenderer: MKOverlayPathRenderer {
    // MARK: Lifecycle

    override nonisolated init(overlay: any MKOverlay) {
        super.init(overlay: overlay)
    }

    // MARK: Internal

    override nonisolated func createPath() {
        guard let overlay = overlay as? MutablePolygonOverlay,
              overlay.coordinates.count >= 3
        else {
            path = nil
            return
        }
        let bezier = UIBezierPath()
        bezier.move(to: point(for: MKMapPoint(overlay.coordinates[0])))
        for coord in overlay.coordinates.dropFirst() {
            bezier.addLine(to: point(for: MKMapPoint(coord)))
        }
        bezier.close()
        path = bezier.cgPath
    }

    func update(with coordinates: [CLLocationCoordinate2D]) {
        (overlay as? MutablePolygonOverlay)?.coordinates = coordinates
        invalidatePath()
        setNeedsDisplay()
    }
}

// MARK: - PolygonEditingMapContainerView

private final class PolygonEditingMapContainerView: UIView, MKMapViewDelegate, UIGestureRecognizerDelegate {
    // MARK: Lifecycle

    override init(frame: CGRect) {
        super.init(frame: frame)
        self.setup()
    }

    @available(*, unavailable)
    required init?(coder _: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    // MARK: Internal

    var onBoundaryChange: ((ProjectBoundary) -> Void)?

    func configure(initialVertices: [GeoCoordinate], center: GeoCoordinate, showsUserLocation: Bool) {
        if !self.hasConfigured {
            self.hasConfigured = true
            self.vertices = initialVertices.map(\.clCoordinate)
            self.refreshOverlay()
            self.refreshAnnotations()

            let region = MKCoordinateRegion(
                center: center.clCoordinate,
                latitudinalMeters: 80,
                longitudinalMeters: 80
            )
            self.mapView.setRegion(region, animated: false)
            self.lastCenteredCoordinate = center
        } else if self.lastCenteredCoordinate != center {
            self.lastCenteredCoordinate = center
            let region = MKCoordinateRegion(
                center: center.clCoordinate,
                latitudinalMeters: 80,
                longitudinalMeters: 80
            )
            self.mapView.setRegion(region, animated: true)
            // Re-anchor the polygon at the new center if the parent reset it via binding.
            let parentVertices = initialVertices.map(\.clCoordinate)
            if !self.coordinatesEqual(parentVertices, self.vertices) {
                self.vertices = parentVertices
                self.refreshOverlay()
                self.refreshAnnotations()
            }
        }

        self.mapView.showsUserLocation = showsUserLocation
    }

    func setMapType(_ type: MKMapType) {
        guard self.mapView.mapType != type else { return }
        self.mapView.mapType = type
    }

    // MARK: MKMapViewDelegate

    func mapView(_: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        if let mutableOverlay = overlay as? MutablePolygonOverlay {
            let renderer = MutablePolygonRenderer(overlay: mutableOverlay)
            renderer.fillColor = UIColor.systemBlue.withAlphaComponent(0.16)
            renderer.strokeColor = UIColor.white.withAlphaComponent(0.9)
            renderer.lineWidth = 3
            self.polygonRenderer = renderer
            return renderer
        }
        return MKOverlayRenderer(overlay: overlay)
    }

    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        guard annotation is VertexAnnotation else { return nil }

        let view: VertexAnnotationView
        if let dequeued = mapView.dequeueReusableAnnotationView(
            withIdentifier: VertexAnnotationView.reuseIdentifier
        ) as? VertexAnnotationView {
            dequeued.annotation = annotation
            view = dequeued
        } else {
            view = VertexAnnotationView(
                annotation: annotation,
                reuseIdentifier: VertexAnnotationView.reuseIdentifier
            )
        }
        view.onPan = { [weak self, weak view] recognizer in
            self?.handleVertexPan(recognizer, on: view)
        }
        view.onDoubleTap = { [weak self, weak view] in
            guard let self, let vertex = view?.annotation as? VertexAnnotation,
                  self.vertices.indices.contains(vertex.index) else { return }
            self.handleVertexDeletion(at: vertex.index)
        }
        return view
    }

    // MARK: UIGestureRecognizerDelegate

    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldReceive touch: UITouch) -> Bool {
        guard gestureRecognizer.view === self.mapView else { return true }

        var touchedView: UIView? = touch.view
        while let view = touchedView {
            if view is VertexAnnotationView {
                return false
            }
            touchedView = view.superview
        }
        return true
    }

    // MARK: Private

    private let mapView = MKMapView(frame: .zero)
    private let warningFeedback = UINotificationFeedbackGenerator()
    private let impactFeedback = UIImpactFeedbackGenerator(style: .medium)

    private var vertices: [CLLocationCoordinate2D] = []
    private let polygonOverlay = MutablePolygonOverlay()
    private weak var polygonRenderer: MutablePolygonRenderer?
    private var vertexAnnotations: [VertexAnnotation] = []
    private var hasConfigured = false
    private var lastCenteredCoordinate: GeoCoordinate?

    private func setup() {
        backgroundColor = .systemBackground

        self.mapView.translatesAutoresizingMaskIntoConstraints = false
        self.mapView.delegate = self
        self.mapView.mapType = .satellite
        self.mapView.pointOfInterestFilter = .excludingAll
        self.mapView.showsCompass = false
        self.mapView.showsScale = true
        self.mapView.isPitchEnabled = false
        self.mapView.isRotateEnabled = false
        self.mapView.cameraZoomRange = MKMapView.CameraZoomRange(minCenterCoordinateDistance: 5)

        addSubview(self.mapView)
        NSLayoutConstraint.activate([
            self.mapView.leadingAnchor.constraint(equalTo: leadingAnchor),
            self.mapView.trailingAnchor.constraint(equalTo: trailingAnchor),
            self.mapView.topAnchor.constraint(equalTo: topAnchor),
            self.mapView.bottomAnchor.constraint(equalTo: bottomAnchor),
        ])

        self.mapView.addOverlay(self.polygonOverlay, level: .aboveRoads)

        let longPress = UILongPressGestureRecognizer(target: self, action: #selector(handleLongPress(_:)))
        longPress.minimumPressDuration = 0.45
        longPress.delegate = self
        self.mapView.addGestureRecognizer(longPress)
    }

    private func refreshOverlay() {
        let coords = self.vertices.count >= 3 ? self.vertices : []
        if let renderer = self.polygonRenderer {
            renderer.update(with: coords)
        } else {
            self.polygonOverlay.coordinates = coords
        }
    }

    private func refreshAnnotations() {
        if !self.vertexAnnotations.isEmpty {
            self.mapView.removeAnnotations(self.vertexAnnotations)
            self.vertexAnnotations = []
        }

        for (index, coordinate) in self.vertices.enumerated() {
            let annotation = VertexAnnotation()
            annotation.coordinate = coordinate
            annotation.index = index
            self.vertexAnnotations.append(annotation)
        }
        self.mapView.addAnnotations(self.vertexAnnotations)
    }

    private func publishBoundary() {
        let geoVertices = self.vertices.map(GeoCoordinate.init)
        self.onBoundaryChange?(ProjectBoundary(vertices: geoVertices))
    }

    @objc
    private func handleLongPress(_ recognizer: UILongPressGestureRecognizer) {
        guard recognizer.state == .began else { return }

        let pressPoint = recognizer.location(in: self.mapView)
        self.handleVertexInsertion(at: pressPoint)
    }

    private func handleVertexDeletion(at index: Int) {
        if self.vertices.count <= ProjectCreationValidator.minimumVertexCount {
            self.warningFeedback.notificationOccurred(.warning)
            return
        }
        self.vertices.remove(at: index)
        self.impactFeedback.impactOccurred()
        self.refreshOverlay()
        self.refreshAnnotations()
        self.publishBoundary()
    }

    private func handleVertexInsertion(at pressPoint: CGPoint) {
        if self.vertices.count >= ProjectCreationValidator.maximumVertexCount {
            self.warningFeedback.notificationOccurred(.warning)
            return
        }

        let newCoordinate = self.mapView.convert(pressPoint, toCoordinateFrom: self.mapView)
        let insertIndex = self.nearestEdgeInsertIndex(for: pressPoint)
        self.vertices.insert(newCoordinate, at: insertIndex)
        self.impactFeedback.impactOccurred()
        self.refreshOverlay()
        self.refreshAnnotations()
        self.publishBoundary()
    }

    private func nearestEdgeInsertIndex(for point: CGPoint) -> Int {
        guard self.vertices.count >= 2 else { return self.vertices.count }

        var bestIndex = 0
        var bestDistance = CGFloat.infinity
        for i in 0 ..< self.vertices.count {
            let a = self.mapView.convert(self.vertices[i], toPointTo: self.mapView)
            let b = self.mapView.convert(self.vertices[(i + 1) % self.vertices.count], toPointTo: self.mapView)
            let distance = self.distance(from: point, toSegmentFrom: a, to: b)
            if distance < bestDistance {
                bestDistance = distance
                bestIndex = (i + 1) % self.vertices.count
            }
        }
        return bestIndex == 0 ? self.vertices.count : bestIndex
    }

    private func distance(from point: CGPoint, toSegmentFrom a: CGPoint, to b: CGPoint) -> CGFloat {
        let dx = b.x - a.x
        let dy = b.y - a.y
        let lenSq = dx * dx + dy * dy
        if lenSq < 0.0001 {
            return hypot(point.x - a.x, point.y - a.y)
        }
        let t = max(0, min(1, ((point.x - a.x) * dx + (point.y - a.y) * dy) / lenSq))
        let projX = a.x + t * dx
        let projY = a.y + t * dy
        return hypot(point.x - projX, point.y - projY)
    }

    private func handleVertexPan(_ recognizer: UIPanGestureRecognizer, on view: VertexAnnotationView?) {
        guard let view, let vertex = view.annotation as? VertexAnnotation else { return }
        let location = recognizer.location(in: self.mapView)
        let newCoordinate = self.mapView.convert(location, toCoordinateFrom: self.mapView)

        switch recognizer.state {
        case .began:
            self.impactFeedback.impactOccurred()
        case .changed:
            guard self.vertices.indices.contains(vertex.index) else { return }
            self.vertices[vertex.index] = newCoordinate
            vertex.coordinate = newCoordinate
            self.refreshOverlay()
        case .ended, .cancelled, .failed:
            self.publishBoundary()
        default:
            break
        }
    }

    private func coordinatesEqual(_ lhs: [CLLocationCoordinate2D], _ rhs: [CLLocationCoordinate2D]) -> Bool {
        guard lhs.count == rhs.count else { return false }
        for (a, b) in zip(lhs, rhs) {
            if abs(a.latitude - b.latitude) > 1e-9 || abs(a.longitude - b.longitude) > 1e-9 {
                return false
            }
        }
        return true
    }
}

extension Double {
    var lengthText: String {
        String(format: "%.1f m", self)
    }

    var areaText: String {
        String(format: "%.1f m²", self)
    }
}
