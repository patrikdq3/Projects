import Combine
import SwiftUI

// MARK: - OTPView

/// Six-digit one-time-code verification, shown after a user creates an account.
struct OTPView: View {
    // MARK: Internal

    @Binding var code: String
    @Binding var errorMessage: String?

    let email: String
    let submitting: Bool
    /// Bumped by the parent on every incorrect code to retrigger the shake.
    let shakeTrigger: Int
    let onVerify: (String) -> Void
    let onResend: () async -> Bool
    let onChangeEmail: () -> Void

    var body: some View {
        VStack(spacing: 0) {
            self.iconHeader

            Text("Check your email")
                .font(.system(size: 26, weight: .bold))
                .foregroundStyle(Color("TextPrimary"))
                .padding(.top, 20)

            self.subtitle
                .multilineTextAlignment(.center)
                .frame(maxWidth: 300)
                .padding(.top, 8)

            self.codeBoxes
                .padding(.top, 28)

            if let errorMessage {
                Text(errorMessage)
                    .font(.system(size: 13))
                    .foregroundStyle(Color("Error"))
                    .padding(.top, 12)
            }

            self.verifyButton
                .padding(.top, 24)

            self.resendRow
                .padding(.top, 16)

            self.backButton
                .padding(.top, 14)
        }
        .modifier(ShakeEffect(animatableData: self.shakeAmount))
        .onChange(of: self.shakeTrigger) { _, _ in
            self.isFocused = true
            self.shakeAmount = 0
            withAnimation(.linear(duration: 0.46)) { self.shakeAmount = 1 }
        }
        .onReceive(self.timer) { _ in
            if self.resendSeconds > 0 {
                self.resendSeconds -= 1
            }
        }
        .onAppear {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.22) {
                self.isFocused = true
            }
        }
    }

    // MARK: Private

    private static let codeLength = 6
    private static let resendCountdown = 30

    @FocusState private var isFocused: Bool
    @State private var shakeAmount: CGFloat = 0
    @State private var resendSeconds = OTPView.resendCountdown
    @State private var submittedCode: String?
    @State private var isResending = false

    private let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()

    private var isComplete: Bool {
        self.code.count == Self.codeLength
    }

    private var subtitle: Text {
        let recipient = Text(self.email.isEmpty ? "your email" : self.email)
            .fontWeight(.semibold)
            .foregroundColor(Color("TextPrimary"))
        return Text("We sent a 6-digit code to \(recipient).")
    }

    // MARK: Subviews

    private var iconHeader: some View {
        RoundedRectangle(cornerRadius: 18, style: .continuous)
            .fill(Color("Primary").opacity(0.12))
            .frame(width: 64, height: 64)
            .overlay {
                Image(systemName: "envelope")
                    .font(.system(size: 28, weight: .regular))
                    .foregroundStyle(Color("Primary"))
                    .overlay(alignment: .topTrailing) {
                        Circle()
                            .fill(Color("Accent"))
                            .frame(width: 12, height: 12)
                            .overlay(
                                Circle().strokeBorder(Color("Background"), lineWidth: 1.5)
                            )
                            .offset(x: 6, y: -4)
                    }
            }
    }

    private var codeBoxes: some View {
        ZStack {
            HStack(spacing: 9) {
                ForEach(0 ..< Self.codeLength, id: \.self) { index in
                    self.digitBox(at: index)
                }
            }

            // Invisible field that captures the keyboard: digits-only, paste-to-fill,
            // and one-time-code autofill. Tapping the boxes focuses it.
            TextField("", text: self.$code)
                .keyboardType(.numberPad)
                .textContentType(.oneTimeCode)
                .focused(self.$isFocused)
                .foregroundStyle(.clear)
                .tint(.clear)
                .disabled(self.submitting)
                .onChange(of: self.code) { _, newValue in
                    self.handleCodeChange(newValue)
                }
        }
        .contentShape(Rectangle())
        .onTapGesture { self.isFocused = true }
    }

    private var verifyButton: some View {
        Button { self.submitIfNeeded(self.code) } label: {
            Group {
                if self.submitting {
                    ProgressView().tint(.white)
                } else {
                    Text("Verify & continue")
                        .font(.system(size: 16, weight: .semibold))
                }
            }
            .foregroundStyle(self.isComplete ? .white : Color("Primary"))
            .frame(maxWidth: .infinity, minHeight: 52)
            .background(
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .fill(self.isComplete ? Color("Primary") : Color("Primary").opacity(0.12))
            )
        }
        .buttonStyle(PressableButtonStyle())
        .disabled(!self.isComplete || self.submitting || self.submittedCode == self.code)
        .animation(.easeInOut(duration: 0.2), value: self.isComplete)
    }

    @ViewBuilder
    private var resendRow: some View {
        if self.resendSeconds > 0 {
            let countdown = Text("0:\(String(format: "%02d", self.resendSeconds))")
                .fontWeight(.semibold)
                .foregroundColor(Color("TextPrimary"))
            Text("Resend code in \(countdown)")
                .font(.system(size: 14))
                .foregroundStyle(Color("TextSecondary"))
        } else {
            Button {
                guard !self.isResending else { return }
                self.isFocused = true
                Task {
                    self.isResending = true
                    let succeeded = await self.onResend()
                    self.isResending = false
                    if succeeded {
                        self.resendSeconds = Self.resendCountdown
                    }
                }
            } label: {
                Group {
                    if self.isResending {
                        ProgressView()
                            .tint(Color("Primary"))
                    } else {
                        Text("Resend code")
                    }
                }
                .font(.system(size: 14, weight: .semibold))
                .foregroundStyle(Color("Primary"))
            }
            .buttonStyle(.plain)
            .disabled(self.isResending)
        }
    }

    private var backButton: some View {
        Button(action: self.onChangeEmail) {
            HStack(spacing: 4) {
                Image(systemName: "arrow.left")
                    .font(.system(size: 13, weight: .medium))
                Text("Use a different email")
                    .font(.system(size: 14, weight: .medium))
            }
            .foregroundStyle(Color("TextSecondary"))
        }
        .buttonStyle(.plain)
        .disabled(self.submitting)
    }

    private func digitBox(at index: Int) -> some View {
        let characters = Array(self.code)
        let hasDigit = index < characters.count
        let isActive = self.isFocused && index == characters.count && !self.submitting
        let isHighlighted = self.errorMessage != nil || isActive || hasDigit

        let ringColor: Color = if self.errorMessage != nil {
            Color("Error")
        } else if isActive || hasDigit {
            Color("Primary")
        } else {
            .clear
        }

        return Text(hasDigit ? String(characters[index]) : "")
            .font(.system(size: 24, weight: .semibold))
            .foregroundStyle(Color("TextPrimary"))
            .frame(width: 46, height: 56)
            .background(
                RoundedRectangle(cornerRadius: 13, style: .continuous)
                    .fill(Color.white.opacity(0.06))
            )
            .overlay(
                RoundedRectangle(cornerRadius: 13, style: .continuous)
                    .strokeBorder(ringColor, lineWidth: isHighlighted ? 1.5 : 1)
            )
            .animation(.easeOut(duration: 0.14), value: isHighlighted)
    }

    private func handleCodeChange(_ newValue: String) {
        let digits = String(newValue.filter(\.isNumber).prefix(Self.codeLength))
        if digits != self.code {
            self.code = digits
        }
        if self.errorMessage != nil, !digits.isEmpty {
            self.errorMessage = nil
        }
        if digits.count < Self.codeLength {
            self.submittedCode = nil
            return
        }
        self.submitIfNeeded(digits)
    }

    private func submitIfNeeded(_ value: String) {
        let digits = String(value.filter(\.isNumber).prefix(Self.codeLength))
        guard digits.count == Self.codeLength,
              self.submittedCode != digits,
              !self.submitting
        else {
            return
        }

        self.submittedCode = digits
        self.isFocused = false
        self.onVerify(digits)
    }
}

// MARK: - ShakeEffect

/// Damped horizontal shake driven by `animatableData` running 0 → 1.
struct ShakeEffect: GeometryEffect {
    var travel: CGFloat = 9
    var shakes: CGFloat = 3
    var animatableData: CGFloat

    func effectValue(size _: CGSize) -> ProjectionTransform {
        let decay = 1 - self.animatableData
        let offset = self.travel * decay * sin(self.animatableData * .pi * 2 * self.shakes)
        return ProjectionTransform(CGAffineTransform(translationX: offset, y: 0))
    }
}
