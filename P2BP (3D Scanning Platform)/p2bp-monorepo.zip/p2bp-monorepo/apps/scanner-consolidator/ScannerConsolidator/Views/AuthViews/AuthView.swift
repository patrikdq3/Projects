import SwiftUI
import UIKit

// MARK: - AuthPhase

enum AuthPhase: Equatable {
    case provider
    case appleSignInSubmitting
    case emailSignIn
    case emailSignInSubmitting
    case emailSignUp
    case emailSignUpSubmitting
    case otp
    case otpSubmitting
}

// MARK: - AuthField

enum AuthField: Hashable {
    case email
    case name
    case password
}

// MARK: - AuthView

struct AuthView: View {
    // MARK: Lifecycle

    /// - Parameter unverifiedEmail: when supplied, the view launches straight into
    ///   email-verification (OTP) for that address — e.g. a restored session whose
    ///   email isn't verified yet — and requests a fresh code on appear.
    init(unverifiedEmail: String? = nil, onAuthenticated: @escaping (User?) -> Void = { _ in }) {
        self.onAuthenticated = onAuthenticated
        self.unverifiedEmail = unverifiedEmail
        if let unverifiedEmail {
            _email = State(initialValue: unverifiedEmail)
            _phase = State(initialValue: .otp)
        }
    }

    // MARK: Internal

    let onAuthenticated: (User?) -> Void

    var body: some View {
        ZStack {
            Color("Background").ignoresSafeArea()

            VStack(spacing: 0) {
                Spacer().frame(height: 60)

                if !self.isOTPPhase {
                    AuthBrandHeader()
                        .padding(.bottom, 36)
                }

                self.authContent
                    .frame(maxWidth: .infinity)

                Spacer(minLength: 0)

                if !self.isOTPPhase {
                    AuthFooter()
                        .padding(.top, 24)
                        .padding(.bottom, 8)
                }
            }
            .padding(.horizontal, 28)
        }
        .preferredColorScheme(.dark)
        .animation(.easeInOut(duration: 0.2), value: self.phase)
        .task {
            // When launched directly into verification (unverified restored session),
            // request the first code so the user has one waiting.
            if self.unverifiedEmail != nil {
                await self.sendInitialVerificationCode()
            }
        }
    }

    // MARK: Private

    @State private var phase: AuthPhase = .provider
    @State private var email = ""
    @State private var name = ""
    @State private var password = ""
    @State private var emailError: String?
    @State private var nameError: String?
    @State private var passwordError: String?
    @State private var formError: String?

    @State private var otpCode = ""
    @State private var otpError: String?
    @State private var otpShake = 0
    @State private var otpEntryPhase: AuthPhase = .emailSignIn

    @FocusState private var focusedField: AuthField?

    private let unverifiedEmail: String?

    private var isOTPPhase: Bool {
        self.phase == .otp || self.phase == .otpSubmitting
    }

    @ViewBuilder
    private var authContent: some View {
        switch self.phase {
        case .provider, .appleSignInSubmitting:
            AuthProviderOptionsView(
                formError: self.formError,
                appleSubmitting: self.phase == .appleSignInSubmitting,
                onAppleSignIn: { credential in Task { await self.submitAppleSignIn(credential) } },
                onAppleSignInFailure: self.handleAppleSignInFailure,
                onEmailSignIn: self.startEmailSignIn,
                onEmailSignUp: self.startEmailSignUp
            )
        case .emailSignIn, .emailSignInSubmitting:
            EmailSignInView(
                email: self.$email,
                password: self.$password,
                emailError: self.emailError,
                passwordError: self.passwordError,
                formError: self.formError,
                submitting: self.phase == .emailSignInSubmitting,
                focusedField: self.$focusedField,
                onSubmit: { Task { await self.submitEmailSignIn() } },
                onCreateAccount: self.startEmailSignUp,
                onCancel: self.cancelEmail
            )
        case .emailSignUp, .emailSignUpSubmitting:
            EmailSignUpView(
                email: self.$email,
                name: self.$name,
                password: self.$password,
                emailError: self.emailError,
                nameError: self.nameError,
                passwordError: self.passwordError,
                formError: self.formError,
                submitting: self.phase == .emailSignUpSubmitting,
                focusedField: self.$focusedField,
                onSubmit: { Task { await self.submitEmailSignUp() } },
                onSignIn: self.startEmailSignIn,
                onCancel: self.cancelEmail
            )
        case .otp, .otpSubmitting:
            OTPView(
                code: self.$otpCode,
                errorMessage: self.$otpError,
                email: self.email,
                submitting: self.phase == .otpSubmitting,
                shakeTrigger: self.otpShake,
                onVerify: { code in Task { await self.verifyOTP(code) } },
                onResend: { await self.resendOTP() },
                onChangeEmail: self.backFromOTP
            )
        }
    }
}

// MARK: - Actions

private extension AuthView {
    static func message(for error: AuthError) -> String {
        switch error {
        case .unauthorized:
            "Invalid email or password."
        case .passwordTooShort:
            "Use at least 8 characters."
        case .invalidResponse:
            "The server returned an invalid response."
        case .storeAuthTokenError, .keychainSaveFailed:
            "Could not save your sign-in session."
        case let .appleSignInFailed(message):
            message.isEmpty ? "Could not complete Sign in with Apple. Try again." : message
        case let .loginFailed(message), let .signUpFailed(message):
            message.isEmpty ? "Something went wrong. Try again." : message
        default:
            "Something went wrong. Try again."
        }
    }

    static func otpMessage(for error: Error) -> String {
        switch error {
        case AuthError.incorrectOtp, AuthError.unauthorized:
            "That code didn’t match. Try again."
        case AuthError.tooManyOtpAttempts:
            "Too many incorrect attempts. Please request a new code."
        case let AuthError.otpVerificationFailed(message):
            message.isEmpty ? "Couldn’t verify the code. Try again." : message
        default:
            "Couldn’t verify the code. Try again."
        }
    }

    static func resendOTPMessage(for error: Error) -> String {
        switch error {
        case let AuthError.resendOtpFailed(message):
            message.isEmpty ? "Couldn’t send a code. Tap resend to try again." : message
        default:
            "Couldn’t send a code. Tap resend to try again."
        }
    }

    static func isValidEmail(_ value: String) -> Bool {
        let pattern = #"^\S+@\S+\.\S+$"#
        return value.range(of: pattern, options: .regularExpression) != nil
    }

    func startEmailSignIn() {
        self.resetFormErrors()
        self.phase = .emailSignIn
        self.focusEmailAfterTransition()
    }

    func startEmailSignUp() {
        self.resetFormErrors()
        self.phase = .emailSignUp
        self.focusEmailAfterTransition()
    }

    func submitAppleSignIn(_ credential: AppleSignInCredential) async {
        guard self.phase != .appleSignInSubmitting else { return }

        self.resetFormErrors()
        self.phase = .appleSignInSubmitting

        do {
            let response = try await AuthService.shared.signInWithApple(credential: credential)
            UIImpactFeedbackGenerator(style: .light).impactOccurred()
            self.proceed(with: response.user, sendInitialCode: false)
        } catch let error as AuthError {
            self.phase = .provider
            self.formError = Self.message(for: error)
            self.playErrorHaptic()
        } catch {
            self.phase = .provider
            self.formError = error.localizedDescription
            self.playErrorHaptic()
        }
    }

    func handleAppleSignInFailure(_ error: AuthError) {
        self.phase = .provider
        self.formError = Self.message(for: error)
    }

    func cancelEmail() {
        self.phase = .provider
        self.resetFormErrors()
        self.focusedField = nil
    }

    func submitEmailSignIn() async {
        guard self.validateSignInForm() else {
            self.playErrorHaptic()
            return
        }

        self.formError = nil
        self.phase = .emailSignInSubmitting

        do {
            let response = try await AuthService.shared.emailLogin(
                email: self.email,
                password: self.password
            )
            self.proceed(with: response.user, sendInitialCode: true)
        } catch let error as AuthError {
            if case .emailNotVerified = error {
                self.beginEmailVerification(for: self.email, sendInitialCode: true)
            } else {
                self.phase = .emailSignIn
                self.formError = Self.message(for: error)
                self.playErrorHaptic()
            }
        } catch {
            self.phase = .emailSignIn
            self.formError = error.localizedDescription
            self.playErrorHaptic()
        }
    }

    func submitEmailSignUp() async {
        guard self.validateSignUpForm() else {
            self.playErrorHaptic()
            return
        }

        self.formError = nil
        self.phase = .emailSignUpSubmitting

        do {
            _ = try await AuthService.shared.emailSignUp(
                email: self.email,
                name: self.name,
                password: self.password
            )
            self.beginEmailVerification(for: self.email, sendInitialCode: false)
        } catch let error as AuthError {
            self.phase = .emailSignUp
            if case .passwordTooShort = error {
                self.passwordError = Self.message(for: error)
            } else {
                self.formError = Self.message(for: error)
            }
            self.playErrorHaptic()
        } catch {
            self.phase = .emailSignUp
            self.formError = error.localizedDescription
            self.playErrorHaptic()
        }
    }

    /// Enter the app if the email is already verified, otherwise gate on an OTP.
    func proceed(with user: User, sendInitialCode: Bool) {
        if user.emailVerified {
            self.onAuthenticated(user)
        } else {
            self.beginEmailVerification(for: user.email, sendInitialCode: sendInitialCode)
        }
    }

    func beginEmailVerification(for email: String, sendInitialCode: Bool) {
        switch self.phase {
        case .emailSignUpSubmitting, .emailSignUp:
            self.otpEntryPhase = .emailSignUp
        default:
            self.otpEntryPhase = .emailSignIn
        }
        self.email = email
        self.otpCode = ""
        self.otpError = nil
        self.otpShake = 0
        self.phase = .otp
        if sendInitialCode {
            Task { await self.sendInitialVerificationCode() }
        }
    }

    func verifyOTP(_ rawCode: String) async {
        guard self.phase != .otpSubmitting else { return }

        let code = String(rawCode.filter(\.isNumber).prefix(6))
        guard code.count == 6 else {
            self.handleOTPFailure(message: "Enter all 6 digits.", clearCode: false)
            return
        }

        self.otpError = nil
        self.phase = .otpSubmitting

        do {
            let response = try await AuthService.shared.verifyEmailOTP(email: self.email, code: code)
            // Correct code — a small confirming tap, then in.
            UIImpactFeedbackGenerator(style: .light).impactOccurred()
            self.onAuthenticated(response.user)
        } catch AuthError.incorrectOtp, AuthError.unauthorized {
            self.playErrorHaptic()
            self.otpCode = ""
            self.otpShake += 1
            self.phase = .otp
        } catch {
            self.handleOTPFailure(message: Self.otpMessage(for: error), clearCode: true)
        }
    }

    func handleOTPFailure(message: String, clearCode: Bool) {
        self.playErrorHaptic()
        self.otpError = message
        if clearCode {
            self.otpCode = ""
        }
        self.otpShake += 1
        self.phase = .otp
    }

    /// Strong error notification haptic, signalling a failed sign-in/sign-up/verify.
    func playErrorHaptic() {
        UINotificationFeedbackGenerator().notificationOccurred(.error)
    }

    func resendOTP() async -> Bool {
        self.otpCode = ""
        self.otpError = nil
        do {
            _ = try await AuthService.shared.resendEmailOTP(email: self.email)
            return true
        } catch {
            self.handleOTPFailure(message: Self.resendOTPMessage(for: error), clearCode: false)
            return false
        }
    }

    func sendInitialVerificationCode() async {
        do {
            _ = try await AuthService.shared.resendEmailOTP(email: self.email)
        } catch {
            self.otpError = Self.resendOTPMessage(for: error)
        }
    }

    func backFromOTP() {
        self.phase = self.otpEntryPhase
        self.otpCode = ""
        self.otpError = nil
        self.focusEmailAfterTransition()
    }
}

// MARK: - Validation

private extension AuthView {
    func validateSignInForm() -> Bool {
        let emailIsValid = self.validateEmail()
        let passwordIsValid = self.validatePassword()
        return emailIsValid && passwordIsValid
    }

    func validateSignUpForm() -> Bool {
        let emailIsValid = self.validateEmail()
        let nameIsValid = self.validateName()
        let passwordIsValid = self.validateSignUpPassword()
        return emailIsValid && nameIsValid && passwordIsValid
    }

    func validateEmail() -> Bool {
        if !Self.isValidEmail(self.email) {
            self.emailError = "Enter a valid email."
            return false
        }

        self.emailError = nil
        return true
    }

    func validateName() -> Bool {
        if self.name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            self.nameError = "Enter your name."
            return false
        }

        self.nameError = nil
        return true
    }

    func validatePassword() -> Bool {
        if self.password.isEmpty {
            self.passwordError = "Enter your password."
            return false
        }

        self.passwordError = nil
        return true
    }

    func validateSignUpPassword() -> Bool {
        guard self.validatePassword() else { return false }

        if self.password.count < 8 {
            self.passwordError = Self.message(for: .passwordTooShort)
            return false
        }

        self.passwordError = nil
        return true
    }

    func resetFormErrors() {
        self.emailError = nil
        self.nameError = nil
        self.passwordError = nil
        self.formError = nil
    }

    func focusEmailAfterTransition() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.18) {
            self.focusedField = .email
        }
    }
}
