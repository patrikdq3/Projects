import SwiftUI

// MARK: - EmailSignInView

struct EmailSignInView: View {
    // MARK: Internal

    @Binding var email: String
    @Binding var password: String

    let emailError: String?
    let passwordError: String?
    let formError: String?
    let submitting: Bool
    var focusedField: FocusState<AuthField?>.Binding
    let onSubmit: () -> Void
    let onCreateAccount: () -> Void
    let onCancel: () -> Void

    var body: some View {
        VStack(spacing: 10) {
            AuthFormField(
                label: "Email",
                placeholder: "you@field.co",
                text: self.$email,
                hasError: self.emailError != nil,
                textContentType: .emailAddress,
                keyboard: .emailAddress,
                autocapitalization: .never
            )
            .focused(self.focusedField, equals: .email)
            .submitLabel(.next)
            .onSubmit { self.focusedField.wrappedValue = .password }
            .disabled(self.submitting)

            if let emailError {
                AuthFieldErrorText(emailError)
            }

            AuthPasswordField(
                text: self.$password,
                hasError: self.passwordError != nil,
                showPassword: self.$showPassword
            )
            .focused(self.focusedField, equals: .password)
            .submitLabel(.go)
            .onSubmit(self.onSubmit)
            .disabled(self.submitting)

            if let passwordError {
                AuthFieldErrorText(passwordError)
            }

            if let formError {
                AuthErrorText(formError)
                    .padding(.top, 2)
            }

            AuthSubmitButton(
                title: "Sign in",
                submitting: self.submitting,
                action: self.onSubmit
            )
            .padding(.top, 6)

            Button(action: self.onCreateAccount) {
                Text("Need an account? Sign up")
                    .font(.system(size: 14, weight: .medium))
                    .foregroundStyle(Color("Primary"))
            }
            .buttonStyle(.plain)
            .disabled(self.submitting)
            .padding(.top, 4)

            AuthBackButton(action: self.onCancel)
                .disabled(self.submitting)
                .padding(.top, 2)
        }
    }

    // MARK: Private

    @State private var showPassword = false
}

// MARK: - EmailSignUpView

struct EmailSignUpView: View {
    // MARK: Internal

    @Binding var email: String
    @Binding var name: String
    @Binding var password: String

    let emailError: String?
    let nameError: String?
    let passwordError: String?
    let formError: String?
    let submitting: Bool
    var focusedField: FocusState<AuthField?>.Binding
    let onSubmit: () -> Void
    let onSignIn: () -> Void
    let onCancel: () -> Void

    var body: some View {
        VStack(spacing: 10) {
            AuthFormField(
                label: "Email",
                placeholder: "you@field.co",
                text: self.$email,
                hasError: self.emailError != nil,
                textContentType: .emailAddress,
                keyboard: .emailAddress,
                autocapitalization: .never
            )
            .focused(self.focusedField, equals: .email)
            .submitLabel(.next)
            .onSubmit { self.focusedField.wrappedValue = .name }
            .disabled(self.submitting)

            if let emailError {
                AuthFieldErrorText(emailError)
            }

            AuthFormField(
                label: "Name",
                placeholder: "Your name",
                text: self.$name,
                hasError: self.nameError != nil,
                textContentType: .name,
                autocapitalization: .words
            )
            .focused(self.focusedField, equals: .name)
            .submitLabel(.next)
            .onSubmit { self.focusedField.wrappedValue = .password }
            .disabled(self.submitting)

            if let nameError {
                AuthFieldErrorText(nameError)
            }

            AuthPasswordField(
                text: self.$password,
                hasError: self.passwordError != nil,
                showPassword: self.$showPassword
            )
            .focused(self.focusedField, equals: .password)
            .submitLabel(.go)
            .onSubmit(self.onSubmit)
            .disabled(self.submitting)

            if let passwordError {
                AuthFieldErrorText(passwordError)
            }

            if let formError {
                AuthErrorText(formError)
                    .padding(.top, 2)
            }

            AuthSubmitButton(
                title: "Create account",
                submitting: self.submitting,
                action: self.onSubmit
            )
            .padding(.top, 6)

            Button(action: self.onSignIn) {
                Text("Already have an account? Sign in")
                    .font(.system(size: 14, weight: .medium))
                    .foregroundStyle(Color("Primary"))
            }
            .buttonStyle(.plain)
            .disabled(self.submitting)
            .padding(.top, 4)

            AuthBackButton(action: self.onCancel)
                .disabled(self.submitting)
                .padding(.top, 2)
        }
    }

    // MARK: Private

    @State private var showPassword = false
}
