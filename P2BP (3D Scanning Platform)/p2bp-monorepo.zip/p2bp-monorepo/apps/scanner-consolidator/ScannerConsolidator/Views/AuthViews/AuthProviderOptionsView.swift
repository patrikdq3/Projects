import AuthenticationServices
import Security
import SwiftUI
import UIKit

// MARK: - AuthProviderOptionsView

struct AuthProviderOptionsView: View {
    // MARK: Internal

    let formError: String?
    let appleSubmitting: Bool
    let onAppleSignIn: (AppleSignInCredential) -> Void
    let onAppleSignInFailure: (AuthError) -> Void
    let onEmailSignIn: () -> Void
    let onEmailSignUp: () -> Void

    var body: some View {
        VStack(spacing: 10) {
            SignInWithAppleButton(
                .continue,
                onRequest: self.configureAppleRequest,
                onCompletion: self.handleAppleCompletion
            )
            .signInWithAppleButtonStyle(.white)
            .frame(height: 52)
            .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
            .disabled(self.appleSubmitting)
            .overlay {
                if self.appleSubmitting {
                    ProgressView()
                        .tint(Color("TextPrimary"))
                }
            }

            AuthDivider()
                .padding(.vertical, 4)

            Button(action: self.onEmailSignIn) {
                HStack(spacing: 10) {
                    Image(systemName: "envelope")
                        .font(.system(size: 16, weight: .semibold))
                    Text("Continue with email")
                        .font(.system(size: 16, weight: .semibold))
                }
                .foregroundStyle(Color("Primary"))
                .frame(maxWidth: .infinity, minHeight: 52)
                .background(
                    RoundedRectangle(cornerRadius: 14, style: .continuous)
                        .fill(Color("Primary").opacity(0.12))
                )
            }
            .buttonStyle(PressableButtonStyle())
            .disabled(self.appleSubmitting)

            Button(action: self.onEmailSignUp) {
                Text("Create an account")
                    .font(.system(size: 14, weight: .medium))
                    .foregroundStyle(Color("TextSecondary"))
            }
            .buttonStyle(.plain)
            .padding(.top, 6)
            .disabled(self.appleSubmitting)

            if let formError {
                AuthErrorText(formError)
                    .padding(.top, 4)
            }
        }
    }

    // MARK: Private

    @State private var appleNonce: String?

    private static func randomNonce(length: Int = 32) -> String {
        precondition(length > 0)

        let charset = Array("0123456789ABCDEFGHIJKLMNOPQRSTUVXYZabcdefghijklmnopqrstuvwxyz-._")
        var result = ""
        var remainingLength = length

        while remainingLength > 0 {
            var randoms = [UInt8](repeating: 0, count: 16)
            let status = SecRandomCopyBytes(kSecRandomDefault, randoms.count, &randoms)
            guard status == errSecSuccess else {
                result.append(charset[Int.random(in: 0 ..< charset.count)])
                remainingLength -= 1
                continue
            }

            for random in randoms where remainingLength > 0 {
                if Int(random) < charset.count {
                    result.append(charset[Int(random)])
                    remainingLength -= 1
                }
            }
        }

        return result
    }

    private func configureAppleRequest(_ request: ASAuthorizationAppleIDRequest) {
        let nonce = Self.randomNonce()
        self.appleNonce = nonce

        request.requestedScopes = [.fullName, .email]
        request.nonce = nonce
    }

    private func handleAppleCompletion(_ result: Result<ASAuthorization, Error>) {
        switch result {
        case let .failure(error):
            guard (error as? ASAuthorizationError)?.code != .canceled else {
                return
            }
            self.failAppleSignIn(message: "Could not complete Sign in with Apple. Try again.")
        case let .success(authorization):
            guard let appleCredential = authorization.credential as? ASAuthorizationAppleIDCredential,
                  let identityToken = appleCredential.identityToken,
                  let token = String(data: identityToken, encoding: .utf8)
            else {
                self.failAppleSignIn(message: "Apple did not return a valid sign-in credential.")
                return
            }

            self.onAppleSignIn(
                AppleSignInCredential(
                    identityToken: token,
                    nonce: self.appleNonce,
                    email: appleCredential.email,
                    firstName: appleCredential.fullName?.givenName,
                    lastName: appleCredential.fullName?.familyName
                )
            )
        }
    }

    private func failAppleSignIn(message: String) {
        UINotificationFeedbackGenerator().notificationOccurred(.error)
        self.onAppleSignInFailure(.appleSignInFailed(message))
    }
}
