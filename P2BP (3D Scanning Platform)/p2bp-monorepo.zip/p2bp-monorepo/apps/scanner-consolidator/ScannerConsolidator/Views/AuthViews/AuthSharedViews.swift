import SwiftUI
import UIKit

// MARK: - AuthBrandHeader

struct AuthBrandHeader: View {
    var body: some View {
        VStack(spacing: 18) {
            BrandMark().frame(width: 64, height: 64)
            VStack(spacing: 10) {
                Text("P2BP")
                    .font(.system(size: 36, weight: .bold))
                    .foregroundStyle(Color("TextPrimary"))
                Text("Pipeline to Better Placemaking")
                    .font(.system(size: 15))
                    .foregroundStyle(Color("TextSecondary"))
                    .multilineTextAlignment(.center)
                    .frame(maxWidth: 280)
            }
        }
    }
}

// MARK: - AuthFooter

struct AuthFooter: View {
    var body: some View {
        let terms = Text("Terms")
            .foregroundColor(Color("TextSecondary"))
            .underline()
        let privacyPolicy = Text("Privacy Policy")
            .foregroundColor(Color("TextSecondary"))
            .underline()
        let body = Text("By continuing you agree to the \(terms) & \(privacyPolicy).")

        return body
            .font(.system(size: 12))
            .foregroundStyle(Color("TextTertiary"))
            .multilineTextAlignment(.center)
            .frame(maxWidth: .infinity)
    }
}

// MARK: - AuthDivider

struct AuthDivider: View {
    var body: some View {
        HStack(spacing: 12) {
            Rectangle().fill(Color.white.opacity(0.08)).frame(height: 1)
            Text("OR")
                .font(.system(size: 12, weight: .medium))
                .foregroundStyle(Color("TextTertiary"))
            Rectangle().fill(Color.white.opacity(0.08)).frame(height: 1)
        }
    }
}

// MARK: - AuthFormField

struct AuthFormField: View {
    let label: String
    let placeholder: String
    @Binding var text: String

    let hasError: Bool
    var textContentType: UITextContentType?
    var keyboard: UIKeyboardType = .default
    var autocapitalization: TextInputAutocapitalization = .sentences

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(self.label.uppercased())
                .font(.system(size: 11, weight: .semibold))
                .foregroundStyle(Color("TextSecondary"))

            TextField(self.placeholder, text: self.$text)
                .font(.system(size: 16))
                .foregroundStyle(Color("TextPrimary"))
                .textContentType(self.textContentType)
                .keyboardType(self.keyboard)
                .textInputAutocapitalization(self.autocapitalization)
                .autocorrectionDisabled()
                .tint(Color("Primary"))
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .authFieldContainer(hasError: self.hasError)
    }
}

// MARK: - AuthPasswordField

struct AuthPasswordField: View {
    // MARK: Internal

    @Binding var text: String
    let hasError: Bool

    @Binding var showPassword: Bool

    var body: some View {
        HStack(alignment: .bottom, spacing: 12) {
            VStack(alignment: .leading, spacing: 4) {
                Text("PASSWORD")
                    .font(.system(size: 11, weight: .semibold))
                    .foregroundStyle(Color("TextSecondary"))

                Group {
                    if self.showPassword {
                        TextField("Your password", text: self.$text)
                    } else {
                        SecureField("Your password", text: self.$text)
                    }
                }
                .font(.system(size: 16))
                .foregroundStyle(Color("TextPrimary"))
                .textContentType(.password)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .tint(Color("Primary"))
            }

            Button(action: self.togglePasswordVisibility) {
                Image(systemName: self.showPassword ? "eye.slash" : "eye")
                    .font(.system(size: 18, weight: .regular))
                    .foregroundStyle(Color("TextSecondary"))
            }
            .buttonStyle(.plain)
            .padding(.bottom, 2)
            .accessibilityLabel(self.showPassword ? "Hide password" : "Show password")
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .authFieldContainer(hasError: self.hasError)
    }

    // MARK: Private

    private func togglePasswordVisibility() {
        self.showPassword.toggle()
    }
}

// MARK: - AuthSubmitButton

struct AuthSubmitButton: View {
    let title: String
    let submitting: Bool
    let action: () -> Void

    var body: some View {
        Button(action: self.action) {
            Group {
                if self.submitting {
                    ProgressView().tint(.white)
                } else {
                    Text(self.title)
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundStyle(.white)
                }
            }
            .frame(maxWidth: .infinity, minHeight: 52)
            .background(
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .fill(Color("Primary"))
            )
        }
        .buttonStyle(PressableButtonStyle())
        .disabled(self.submitting)
    }
}

// MARK: - AuthBackButton

struct AuthBackButton: View {
    let action: () -> Void

    var body: some View {
        Button(action: self.action) {
            HStack(spacing: 4) {
                Image(systemName: "arrow.left")
                    .font(.system(size: 13, weight: .medium))
                Text("Back to sign-in options")
                    .font(.system(size: 14, weight: .medium))
            }
            .foregroundStyle(Color("TextSecondary"))
        }
        .buttonStyle(.plain)
    }
}

// MARK: - AuthErrorText

struct AuthErrorText: View {
    // MARK: Lifecycle

    init(_ text: String) {
        self.text = text
    }

    // MARK: Internal

    let text: String

    var body: some View {
        Text(self.text)
            .font(.system(size: 13))
            .foregroundStyle(Color("Error"))
            .multilineTextAlignment(.leading)
            .frame(maxWidth: .infinity, alignment: .leading)
    }
}

// MARK: - AuthFieldErrorText

struct AuthFieldErrorText: View {
    // MARK: Lifecycle

    init(_ text: String) {
        self.text = text
    }

    // MARK: Internal

    let text: String

    var body: some View {
        Text(self.text)
            .font(.system(size: 13))
            .foregroundStyle(Color("Error"))
            .padding(.leading, 4)
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.top, -2)
    }
}

// MARK: - PressableButtonStyle

struct PressableButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.985 : 1.0)
            .animation(.easeOut(duration: 0.12), value: configuration.isPressed)
    }
}

// MARK: - BrandMark

private struct BrandMark: View {
    // MARK: Internal

    var body: some View {
        GeometryReader { geo in
            let scale = geo.size.width / 56
            ZStack {
                Path { path in
                    path.move(to: self.points[0].scaled(by: scale))
                    self.points.dropFirst().forEach { path.addLine(to: $0.scaled(by: scale)) }
                    path.closeSubpath()
                }
                .stroke(Color("Primary"), style: .init(lineWidth: 2.2, lineJoin: .round))

                ForEach(0 ..< self.points.count, id: \.self) { index in
                    Circle().fill(Color("Primary"))
                        .frame(width: 6, height: 6)
                        .position(self.points[index].scaled(by: scale))
                }
            }
        }
    }

    // MARK: Private

    private let points: [CGPoint] = [
        .init(x: 16, y: 18), .init(x: 36, y: 14), .init(x: 42, y: 30),
        .init(x: 30, y: 42), .init(x: 14, y: 34),
    ]
}

private extension CGPoint {
    func scaled(by scale: CGFloat) -> CGPoint {
        .init(x: self.x * scale, y: self.y * scale)
    }
}

private extension View {
    func authFieldContainer(hasError: Bool) -> some View {
        self
            .padding(.horizontal, 16)
            .padding(.vertical, 12)
            .background(
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .fill(Color.white.opacity(0.06))
            )
            .overlay(
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .strokeBorder(hasError ? Color("Error") : Color.clear, lineWidth: 1)
            )
    }
}
