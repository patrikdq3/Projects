import SwiftUI

// MARK: - ConfirmationPrompt

/// Describes a single destructive confirmation (e.g. "Delete organization?", "Remove member?").
struct ConfirmationPrompt: Identifiable {
    let id = UUID()
    /// SF Symbol shown in the tinted header circle.
    var icon: String
    /// Accent for the icon and the confirm button. Defaults to the destructive red.
    var tint = Color("Error")
    var title: String
    var message: String
    var confirmTitle: String
    var confirmIcon: String?
    var cancelTitle = "Cancel"
    /// Run when the user taps the confirm button.
    var onConfirm: () -> Void
}

// MARK: - ConfirmationPromptView

/// A centered confirmation card — tinted icon, title, message, and a full-width confirm action
/// over a cancel button. Floats above a dimmed, tap-to-cancel backdrop with a spring in/out; a
/// cleaner replacement for the system action sheet.
struct ConfirmationPromptView: View {
    // MARK: Internal

    let prompt: ConfirmationPrompt
    let onClose: () -> Void

    var body: some View {
        ZStack {
            // Dimmed, tap-to-cancel backdrop.
            Color.black.opacity(self.shown ? 0.5 : 0)
                .ignoresSafeArea()
                .contentShape(.rect)
                .onTapGesture { self.close(running: nil) }

            self.card
                .scaleEffect(self.shown ? 1 : 0.92)
                .opacity(self.shown ? 1 : 0)
        }
        .onAppear {
            withAnimation(.spring(response: 0.34, dampingFraction: 0.82)) { self.shown = true }
        }
    }

    // MARK: Private

    @State private var shown = false

    private var card: some View {
        VStack(spacing: 0) {
            ZStack {
                Circle()
                    .fill(self.prompt.tint.opacity(0.12))
                    .frame(width: 56, height: 56)
                Image(systemName: self.prompt.icon)
                    .font(.system(size: 23, weight: .semibold))
                    .foregroundStyle(self.prompt.tint)
            }
            .padding(.top, 28)
            .padding(.bottom, 16)

            Text(self.prompt.title)
                .font(.system(size: 19, weight: .bold))
                .tracking(-0.3)
                .foregroundStyle(Color("TextPrimary"))
                .multilineTextAlignment(.center)
                .padding(.horizontal, 24)
                .padding(.bottom, 8)

            Text(self.prompt.message)
                .font(.system(size: 14.5))
                .foregroundStyle(Color("TextSecondary"))
                .lineSpacing(3)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 24)
                .padding(.bottom, 24)

            VStack(spacing: 8) {
                self.confirmButton
                self.cancelButton
            }
            .padding(.horizontal, 16)
            .padding(.bottom, 16)
        }
        .frame(maxWidth: 360)
        .background(Color("Surface"), in: RoundedRectangle(cornerRadius: 24, style: .continuous))
        .shadow(color: .black.opacity(0.3), radius: 24, x: 0, y: 12)
        .padding(.horizontal, 36)
    }

    private var confirmButton: some View {
        Button {
            self.close(running: self.prompt.onConfirm)
        } label: {
            HStack(spacing: 8) {
                if let confirmIcon = self.prompt.confirmIcon {
                    Image(systemName: confirmIcon)
                        .font(.system(size: 16, weight: .semibold))
                }
                Text(self.prompt.confirmTitle)
                    .font(.system(size: 16, weight: .semibold))
                    .tracking(-0.2)
            }
            .frame(maxWidth: .infinity, minHeight: 52)
            .foregroundStyle(.white)
            .background(self.prompt.tint, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
        }
        .buttonStyle(.plain)
    }

    private var cancelButton: some View {
        Button {
            self.close(running: nil)
        } label: {
            Text(self.prompt.cancelTitle)
                .font(.system(size: 16, weight: .semibold))
                .foregroundStyle(Color("TextSecondary"))
                .frame(maxWidth: .infinity, minHeight: 48)
                .contentShape(.rect)
        }
        .buttonStyle(.plain)
    }

    /// Springs the card out, then runs the optional action and clears the binding.
    private func close(running action: (() -> Void)?) {
        withAnimation(.spring(response: 0.3, dampingFraction: 0.9)) { self.shown = false }
        Task {
            try? await Task.sleep(for: .seconds(0.25))
            action?()
            self.onClose()
        }
    }
}

// MARK: - View + confirmationPrompt

extension View {
    /// Presents a custom confirmation card bound to an optional `ConfirmationPrompt`.
    func confirmationPrompt(_ prompt: Binding<ConfirmationPrompt?>) -> some View {
        self.overlay {
            if let item = prompt.wrappedValue {
                ConfirmationPromptView(prompt: item) {
                    prompt.wrappedValue = nil
                }
                .id(item.id)
            }
        }
    }
}
