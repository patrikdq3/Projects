import SwiftUI
import UIKit

// MARK: - ExportedFile

/// A downloaded file waiting to be handed to the system share sheet. `ShareLink` covers files that
/// are already on disk when the view renders; this carries one that arrives from an async download.
struct ExportedFile: Identifiable, Equatable {
    let fileURL: URL

    var id: URL {
        self.fileURL
    }
}

// MARK: - ExportedFileShareSheet

/// `UIActivityViewController` wrapper, so "Save to Files", AirDrop and the rest are available for a
/// file downloaded on demand.
struct ExportedFileShareSheet: UIViewControllerRepresentable {
    let fileURL: URL

    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: [self.fileURL], applicationActivities: nil)
    }

    func updateUIViewController(_ controller: UIActivityViewController, context: Context) {}
}

extension View {
    /// Presents the share sheet for `file` once a download completes.
    func exportedFileShareSheet(_ file: Binding<ExportedFile?>) -> some View {
        self.sheet(item: file) { exported in
            ExportedFileShareSheet(fileURL: exported.fileURL)
        }
    }
}
