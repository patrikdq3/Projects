import SwiftUI

// MARK: - ChoicePromptOption

/// One selectable row in a `ChoicePrompt` — an icon, title, optional subtitle, and an action.
struct ChoicePromptOption: Identifiable {
    let id = UUID()
    /// SF Symbol shown in the leading tinted circle.
    var icon: String
    var title: String
    var subtitle: String?
    /// Accent for the icon; falls back to the prompt's tint when nil.
    var tint: Color?
    /// Whether the row can be tapped. Disabled rows render dimmed.
    var isEnabled = true
    /// Run when the user taps this option.
    var action: () -> Void
}

// MARK: - ChoicePrompt

/// Describes a card that offers the user a short list of choices (e.g. "View preview" vs.
/// "View full scan"), a friendlier replacement for the system action sheet / menu.
struct ChoicePrompt: Identifiable {
    let id = UUID()
    /// SF Symbol shown in the tinted header circle.
    var icon: String
    /// Accent for the header icon and the option icons by default.
    var tint = Color("Accent")
    var title: String
    var message: String?
    var options: [ChoicePromptOption]
    var cancelTitle = "Cancel"
}

// MARK: - ChoicePromptView

/// A centered choice card — tinted icon, title, optional message, and a stack of option rows
/// over a cancel button. Floats above a dimmed, tap-to-cancel backdrop with a spring in/out,
/// matching `ConfirmationPromptView`.
struct ChoicePromptView: View {
    // MARK: Internal

    let prompt: ChoicePrompt
    let onClose: () -> Void

    var body: some View {
        ZStack {
            // Dimmed, tap-to-cancel backdrop.
            Color.black.opacity(self.shown ? 0.5 : 0)
                .ignoresSafeArea()
                .contentShape(.rect)
                .onTapGesture { self.close(running: nil) }

            self.card
                .scaleEffect(self.shown ? 1 : 0.92)
                .opacity(self.shown ? 1 : 0)
        }
        .onAppear {
            withAnimation(.spring(response: 0.34, dampingFraction: 0.82)) { self.shown = true }
        }
    }

    // MARK: Private

    @State private var shown = false

    private var card: some View {
        VStack(spacing: 0) {
            ZStack {
                Circle()
                    .fill(self.prompt.tint.opacity(0.12))
                    .frame(width: 56, height: 56)
                Image(systemName: self.prompt.icon)
                    .font(.system(size: 23, weight: .semibold))
                    .foregroundStyle(self.prompt.tint)
            }
            .padding(.top, 28)
            .padding(.bottom, 16)

            Text(self.prompt.title)
                .font(.system(size: 19, weight: .bold))
                .tracking(-0.3)
                .foregroundStyle(Color("TextPrimary"))
                .multilineTextAlignment(.center)
                .padding(.horizontal, 24)
                .padding(.bottom, self.prompt.message == nil ? 20 : 8)

            if let message = self.prompt.message {
                Text(message)
                    .font(.system(size: 14.5))
                    .foregroundStyle(Color("TextSecondary"))
                    .lineSpacing(3)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 24)
                    .padding(.bottom, 24)
            }

            VStack(spacing: 8) {
                ForEach(self.prompt.options) { option in
                    self.optionRow(option)
                }
                self.cancelButton
            }
            .padding(.horizontal, 16)
            .padding(.bottom, 16)
        }
        .frame(maxWidth: 360)
        .background(Color("Surface"), in: RoundedRectangle(cornerRadius: 24, style: .continuous))
        .shadow(color: .black.opacity(0.3), radius: 24, x: 0, y: 12)
        .padding(.horizontal, 36)
    }

    private var cancelButton: some View {
        Button {
            self.close(running: nil)
        } label: {
            Text(self.prompt.cancelTitle)
                .font(.system(size: 16, weight: .semibold))
                .foregroundStyle(Color("TextSecondary"))
                .frame(maxWidth: .infinity, minHeight: 48)
                .contentShape(.rect)
        }
        .buttonStyle(.plain)
    }

    private func optionRow(_ option: ChoicePromptOption) -> some View {
        let tint = option.tint ?? self.prompt.tint
        return Button {
            self.close(running: option.action)
        } label: {
            HStack(spacing: 12) {
                ZStack {
                    Circle()
                        .fill(tint.opacity(0.12))
                        .frame(width: 38, height: 38)
                    Image(systemName: option.icon)
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundStyle(tint)
                }

                VStack(alignment: .leading, spacing: 2) {
                    Text(option.title)
                        .font(.system(size: 16, weight: .semibold))
                        .tracking(-0.2)
                        .foregroundStyle(Color("TextPrimary"))
                    if let subtitle = option.subtitle {
                        Text(subtitle)
                            .font(.system(size: 12.5))
                            .foregroundStyle(Color("TextSecondary"))
                    }
                }

                Spacer(minLength: 8)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.horizontal, 12)
            .padding(.vertical, 10)
            .background(
                Color("SurfaceSecondary"),
                in: RoundedRectangle(cornerRadius: 14, style: .continuous)
            )
            .contentShape(.rect)
        }
        .buttonStyle(.plain)
        .disabled(!option.isEnabled)
        .opacity(option.isEnabled ? 1 : 0.5)
    }

    /// Springs the card out, then runs the optional action and clears the binding.
    private func close(running action: (() -> Void)?) {
        withAnimation(.spring(response: 0.3, dampingFraction: 0.9)) { self.shown = false }
        Task {
            try? await Task.sleep(for: .seconds(0.25))
            action?()
            self.onClose()
        }
    }
}

// MARK: - View + choicePrompt

extension View {
    /// Presents a custom choice card bound to an optional `ChoicePrompt`.
    func choicePrompt(_ prompt: Binding<ChoicePrompt?>) -> some View {
        self.overlay {
            if let item = prompt.wrappedValue {
                ChoicePromptView(prompt: item) {
                    prompt.wrappedValue = nil
                }
                .id(item.id)
            }
        }
    }
}
