import SwiftUI

// MARK: - MemberDetailSheet

/// Bottom sheet for a single member: change their role (`organization.updateMemberRole`) or
/// remove them (`organization.removeMember`). Permission-gated by the viewer's role; the
/// owner row is protected.
struct MemberDetailSheet: View {
    // MARK: Lifecycle

    init(
        member: OrgMember,
        viewerRole: OrgRole,
        onChangeRole: @escaping (_ memberID: String, _ role: OrgRole) -> Void,
        onRemove: @escaping (OrgMember) -> Void
    ) {
        self.member = member
        self.viewerRole = viewerRole
        self.onChangeRole = onChangeRole
        self.onRemove = onRemove
        self._role = State(initialValue: member.role)
    }

    // MARK: Internal

    let member: OrgMember
    let viewerRole: OrgRole
    let onChangeRole: (_ memberID: String, _ role: OrgRole) -> Void
    let onRemove: (OrgMember) -> Void

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 0) {
                    self.identity
                        .padding(.horizontal, 24)
                        .padding(.top, 18)
                        .padding(.bottom, 18)

                    if self.isOwnerTarget {
                        self
                            .notice(
                                "This person owns the organization. Transfer ownership from organization settings "
                                    + "to change their role."
                            )
                    } else if self.canManage {
                        OrgFieldLabel(text: "Role")
                        RolePicker(selection: self.$role)

                        Button(role: .destructive) {
                            self.confirmRemove()
                        } label: {
                            HStack(spacing: 8) {
                                Image(systemName: "xmark")
                                    .font(.system(size: 15, weight: .semibold))
                                Text("Remove from organization")
                                    .font(.system(size: 16, weight: .semibold))
                            }
                            .frame(maxWidth: .infinity, minHeight: 50)
                            .foregroundStyle(Color("Error"))
                            .background(
                                Color("Error").opacity(0.08),
                                in: RoundedRectangle(cornerRadius: 14, style: .continuous)
                            )
                        }
                        .buttonStyle(.plain)
                        .padding(.horizontal, 16)
                        .padding(.top, 22)
                        .padding(.bottom, 16)
                    } else {
                        VStack(alignment: .leading, spacing: 14) {
                            RoleBadge(role: self.member.role)
                            Text("You don't have permission to manage this member.")
                                .font(.system(size: 14))
                                .foregroundStyle(Color("TextSecondary"))
                                .lineSpacing(3)
                        }
                        .padding(.horizontal, 24)
                        .padding(.bottom, 18)
                    }
                }
            }
            .scrollBounceBehavior(.basedOnSize)
            .background(Color("Background"))
            .navigationTitle("Member")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Done") { self.dismiss() }
                }
                if self.canManage, self.role != self.member.role {
                    ToolbarItem(placement: .confirmationAction) {
                        Button("Save") { self.saveRole() }
                            .fontWeight(.semibold)
                    }
                }
            }
        }
        .presentationDetents([.medium, .large])
        .presentationDragIndicator(.visible)
        .presentationBackground(.regularMaterial)
        .confirmationPrompt(self.$confirmation)
        // Warning buzz when the remove confirmation is opened.
        .sensoryFeedback(.warning, trigger: self.didOpenDestructive)
    }

    // MARK: Private

    @Environment(\.dismiss) private var dismiss

    @State private var role: OrgRole
    @State private var confirmation: ConfirmationPrompt?
    @State private var didOpenDestructive = false

    private var isOwnerTarget: Bool {
        self.member.role == .owner
    }

    /// Owners can manage anyone; admins can manage members and scanners; everyone else is
    /// read-only.
    private var canManage: Bool {
        switch self.viewerRole {
        case .owner: !self.isOwnerTarget
        case .admin: self.member.role == .member || self.member.role == .scanner
        case .scanner, .member: false
        }
    }

    private var identity: some View {
        HStack(spacing: 14) {
            PersonAvatar(name: self.member.name, tint: self.member.tint, size: 52)
            VStack(alignment: .leading, spacing: 1) {
                HStack(spacing: 4) {
                    Text(self.member.name)
                        .font(.system(size: 18, weight: .semibold))
                        .tracking(-0.3)
                        .foregroundStyle(Color("TextPrimary"))
                    if self.member.isYou {
                        Text("· You")
                            .font(.system(size: 18))
                            .foregroundStyle(Color("TextSecondary"))
                    }
                }
                Text(self.member.email)
                    .font(.system(size: 14))
                    .foregroundStyle(Color("TextSecondary"))
            }
            Spacer(minLength: 0)
        }
    }

    private func notice(_ text: String) -> some View {
        Text(text)
            .font(.system(size: 14))
            .foregroundStyle(Color("TextSecondary"))
            .lineSpacing(3)
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.horizontal, 24)
            .padding(.bottom, 18)
    }

    /// Opens the shared confirmation for removing this member, with a warning haptic.
    private func confirmRemove() {
        self.didOpenDestructive.toggle()
        self.confirmation = ConfirmationPrompt(
            icon: "person.fill.xmark",
            title: "Remove \(self.member.name)?",
            message: "They'll lose access to this organization. You can invite them again later.",
            confirmTitle: "Remove from organization",
            confirmIcon: "xmark"
        ) {
            self.onRemove(self.member)
            self.dismiss()
        }
    }

    private func saveRole() {
        self.onChangeRole(self.member.id, self.role)
        self.dismiss()
    }
}
