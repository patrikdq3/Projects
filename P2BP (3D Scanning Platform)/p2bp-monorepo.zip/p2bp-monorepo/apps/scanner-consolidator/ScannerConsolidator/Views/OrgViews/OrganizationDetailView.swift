import SwiftUI

// MARK: - OrganizationDetailView

/// The core management screen for one organization: header, members (with role/remove),
/// pending invitations (resend/cancel), and a role-gated danger zone (leave/delete).
struct OrganizationDetailView: View {
    // MARK: Lifecycle

    init(organization: ManageableOrganization, onLeaveOrDelete: @escaping () -> Void) {
        self.organization = organization
        self.onLeaveOrDelete = onLeaveOrDelete
        self._members = State(initialValue: [])
        self._invites = State(initialValue: Self.seededInvites)
        self._viewerRole = State(initialValue: organization.viewerRole)
    }

    // MARK: Internal

    let organization: ManageableOrganization
    /// Invoked after the viewer leaves or deletes the org, so the host can pop the stack.
    let onLeaveOrDelete: () -> Void

    var body: some View {
        ScrollView {
            VStack(spacing: 0) {
                self.header
                    .padding(.top, 24)
                    .padding(.horizontal, 24)
                    .padding(.bottom, 20)

                if self.isLoadingMembers {
                    ProgressView()
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 32)
                } else {
                    self.membersSection
                }

                if let loadErrorMessage {
                    self.errorText(loadErrorMessage)
                        .padding(.bottom, 22)
                }

                if self.canManage, !self.pendingInvites.isEmpty {
                    self.invitesSection
                }

                self.dangerZone
                    .padding(.bottom, 44)
            }
        }
        .background(Color("Background"))
        .navigationTitle(self.organization.name)
        .navigationBarTitleDisplayMode(.inline)
        .task {
            await self.loadOrganizationDetails()
        }
        .sheet(item: self.$invitingSheet) { _ in
            InviteMemberSheet(organizationName: self.organization.name) { email, role in
                self.inviteMember(email: email, role: role)
            }
        }
        .sheet(item: self.$selectedMember) { member in
            MemberDetailSheet(
                member: member,
                viewerRole: self.viewerRole,
                onChangeRole: { id, role in
                    Task {
                        await self.updateMemberRole(id: id, role: role)
                    }
                },
                onRemove: { member in
                    Task {
                        await self.removeMember(member)
                    }
                }
            )
        }
        .orgToast(self.$toast)
        .confirmationPrompt(self.$confirmation)
        // Heavy thunk when the viewer leaves or deletes the org.
        .sensoryFeedback(.impact(weight: .heavy), trigger: self.didLeaveOrDelete)
        // Warning buzz when a destructive confirmation (delete org / cancel invite) is opened.
        .sensoryFeedback(.warning, trigger: self.didOpenDestructive)
        // Success when an invite is sent or resent; a softer impact when one is canceled.
        .sensoryFeedback(.success, trigger: self.didSendInvite)
        .sensoryFeedback(.success, trigger: self.didResendInvite)
        .sensoryFeedback(.impact(weight: .medium), trigger: self.didCancelInvite)
    }

    // MARK: Private

    private static let seededInvites: [OrgInvitation] = []

    @EnvironmentObject private var organizationDataCoordinator: OrganizationDataCoordinator

    @State private var members: [OrgMember]
    @State private var invites: [OrgInvitation]
    /// The viewer's role, derived from authoritative member data once loaded. Seeded from the
    /// list snapshot, which can be stale when the list endpoint omits members.
    @State private var viewerRole: OrgRole
    @State private var invitingSheet: InviteSheetToken?
    @State private var selectedMember: OrgMember?
    @State private var confirmation: ConfirmationPrompt?
    @State private var didLeaveOrDelete = false
    @State private var didOpenDestructive = false
    @State private var didSendInvite = false
    @State private var didResendInvite = false
    @State private var didCancelInvite = false
    @State private var toast: String?
    @State private var currentUserID: String?
    @State private var isLoadingMembers = false
    @State private var isMutating = false
    @State private var resendingInviteIDs: Set<String> = []
    @State private var loadErrorMessage: String?

    private let organizationsService = OrganizationsService()

    private var isOwner: Bool {
        self.viewerRole == .owner
    }

    private var canManage: Bool {
        self.viewerRole == .owner || self.viewerRole == .admin
    }

    private var pendingInvites: [OrgInvitation] {
        self.invites
    }

    // MARK: Header

    private var header: some View {
        VStack(spacing: 12) {
            OrgMarkBadge(text: self.organization.mark, tint: self.organization.tint, size: 76, corner: 22)

            VStack(spacing: 4) {
                Text(self.organization.name)
                    .font(.system(size: 22, weight: .bold))
                    .tracking(-0.5)
                    .foregroundStyle(Color("TextPrimary"))
                    .multilineTextAlignment(.center)

                Text("p2bp.app/\(self.organization.slug) · ^[\(self.members.count) member](inflect: true)")
                    .font(.system(size: 14))
                    .foregroundStyle(Color("TextSecondary"))
            }

            HStack(spacing: 6) {
                Text("You're \(self.viewerRole.article)")
                    .font(.system(size: 13))
                    .foregroundStyle(Color("TextSecondary"))
                RoleBadge(role: self.viewerRole)
            }
            .padding(.top, 4)
        }
        .frame(maxWidth: .infinity)
    }

    // MARK: Members

    private var membersSection: some View {
        VStack(spacing: 0) {
            OrgSectionHeader(title: "Members · \(self.members.count)") {
                if self.canManage {
                    Button {
                        self.invitingSheet = InviteSheetToken()
                    } label: {
                        HStack(spacing: 4) {
                            Image(systemName: "plus")
                                .font(.system(size: 12, weight: .bold))
                            Text("Invite")
                                .font(.system(size: 13, weight: .semibold))
                        }
                        .foregroundStyle(Color("Primary"))
                        .padding(.leading, 9)
                        .padding(.trailing, 12)
                        .padding(.vertical, 5)
                        .background(Color("Primary").opacity(0.1), in: .capsule)
                    }
                    .buttonStyle(.plain)
                }
            }

            OrgGroupCard {
                if self.members.isEmpty {
                    Text("No members found.")
                        .font(.system(size: 14))
                        .foregroundStyle(Color("TextSecondary"))
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(.horizontal, 16)
                        .padding(.vertical, 14)
                } else {
                    ForEach(Array(self.members.enumerated()), id: \.element.id) { index, member in
                        Button {
                            self.selectedMember = member
                        } label: {
                            self.memberRow(member)
                        }
                        .buttonStyle(.plain)

                        if index < self.members.count - 1 {
                            OrgRowDivider(leadingInset: 68)
                        }
                    }
                }
            }
        }
        .padding(.bottom, 22)
    }

    // MARK: Pending invitations

    private var invitesSection: some View {
        VStack(spacing: 0) {
            OrgSectionHeader("Pending invitations · \(self.pendingInvites.count)")

            OrgGroupCard {
                ForEach(Array(self.pendingInvites.enumerated()), id: \.element.id) { index, invite in
                    self.inviteRow(invite)
                    if index < self.pendingInvites.count - 1 {
                        OrgRowDivider(leadingInset: 68)
                    }
                }
            }

            OrgFooterText(text: "Invites expire after 48 hours. Resend to send a fresh link.")
        }
        .padding(.bottom, 22)
    }

    // MARK: Danger zone

    private var dangerZone: some View {
        VStack(spacing: 0) {
            OrgSectionHeader("Danger zone")
            OrgGroupCard {
                Button {
                    self.confirmLeaveOrDelete()
                } label: {
                    HStack(spacing: 12) {
                        Text(self.isOwner ? "Delete organization" : "Leave organization")
                            .font(.system(size: 16, weight: .medium))
                            .foregroundStyle(Color("Error"))
                        Spacer(minLength: 8)
                        Image(systemName: self.isOwner ? "trash" : "rectangle.portrait.and.arrow.right")
                            .font(.system(size: 15, weight: .medium))
                            .foregroundStyle(Color("Error"))
                    }
                    .padding(.horizontal, 16)
                    .padding(.vertical, 12)
                    .frame(minHeight: 56)
                    .contentShape(.rect)
                }
                .buttonStyle(.plain)
            }
        }
    }

    private func memberRow(_ member: OrgMember) -> some View {
        HStack(spacing: 12) {
            PersonAvatar(name: member.name, tint: member.tint, size: 40)
            VStack(alignment: .leading, spacing: 1) {
                HStack(spacing: 4) {
                    Text(member.name)
                        .font(.system(size: 15.5, weight: .semibold))
                        .tracking(-0.2)
                        .foregroundStyle(Color("TextPrimary"))
                        .lineLimit(1)
                    if member.isYou {
                        Text("· You")
                            .font(.system(size: 15.5))
                            .foregroundStyle(Color("TextSecondary"))
                    }
                }
                Text(member.email)
                    .font(.system(size: 13))
                    .foregroundStyle(Color("TextSecondary"))
                    .lineLimit(1)
            }
            Spacer(minLength: 8)
            RoleBadge(role: member.role)
            if self.canManage {
                OrgChevron()
            }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
        .frame(minHeight: 56)
        .contentShape(.rect)
    }

    private func inviteRow(_ invite: OrgInvitation) -> some View {
        let expired = invite.status == .expired
        let isResending = self.resendingInviteIDs.contains(invite.id)
        return HStack(spacing: 12) {
            Image(systemName: "envelope")
                .font(.system(size: 16))
                .foregroundStyle(expired ? Color("Error") : Color("Warning"))
                .frame(width: 40, height: 40)
                .background(
                    (expired ? Color("Error") : Color("Warning")).opacity(expired ? 0.08 : 0.12),
                    in: .circle
                )

            VStack(alignment: .leading, spacing: 1) {
                Text(invite.email)
                    .font(.system(size: 15, weight: .medium))
                    .foregroundStyle(Color("TextPrimary"))
                    .lineLimit(1)
                Text(expired ? "Expired \(invite.expiresText)" : "Pending · expires \(invite.expiresText)")
                    .font(.system(size: 13))
                    .foregroundStyle(expired ? Color("Error") : Color("TextSecondary"))
            }

            Spacer(minLength: 6)
            RoleBadge(role: invite.role)

            HStack(spacing: 2) {
                Button {
                    self.resendInvite(invite)
                } label: {
                    Group {
                        if isResending {
                            ProgressView()
                                .controlSize(.mini)
                        } else {
                            Image(systemName: "arrow.clockwise")
                                .font(.system(size: 16, weight: .medium))
                                .foregroundStyle(Color("Primary"))
                        }
                    }
                    .frame(width: 30, height: 30)
                    .contentShape(.rect)
                }
                .buttonStyle(.plain)
                .disabled(isResending)
                .accessibilityLabel("Resend invite")

                Button {
                    self.confirmCancelInvite(invite)
                } label: {
                    Image(systemName: "xmark.circle.fill")
                        .font(.system(size: 18))
                        .foregroundStyle(Color("TextSecondary"))
                        .frame(width: 30, height: 30)
                        .contentShape(.rect)
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Cancel invite")
            }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
        .frame(minHeight: 56)
    }

    private func errorText(_ message: String) -> some View {
        Text(message)
            .font(.system(size: 13))
            .foregroundStyle(Color("Error"))
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.horizontal, 24)
    }

    private static func errorMessage(for error: Error) -> String {
        switch error {
        case RequestServiceError.missingAuthToken, RequestServiceError.unauthorized:
            return "Sign in again to manage this organization."
        case RequestServiceError.forbidden:
            return "You do not have permission to manage this organization."
        case RequestServiceError.notFound:
            return "This organization could not be found."
        case let RequestServiceError.invalidInput(message), let RequestServiceError.requestFailed(_, message):
            return message ?? "The organization could not be updated."
        default:
            return "The organization could not be updated."
        }
    }

    private func loadOrganizationDetails() async {
        if self.currentUserID == nil {
            self.currentUserID = await AuthService.shared.getSession()?.user.id
        }

        if let cachedDetail = self.organizationDataCoordinator.cachedOrganizationDetail(id: self.organization.id) {
            self.applyOrganizationDetail(cachedDetail)
            self.loadErrorMessage = nil
            await Task.yield()
        }

        self.isLoadingMembers = self.members.isEmpty
        defer { self.isLoadingMembers = false }

        do {
            let detail = try await self.organizationDataCoordinator.refreshOrganizationDetail(
                id: self.organization.id
            )
            self.applyOrganizationDetail(detail)
            self.loadErrorMessage = nil
        } catch {
            self.loadErrorMessage = Self.errorMessage(for: error)
        }

        await self.reloadInvitations()
    }

    /// Pulls the org's outstanding invitations from the server so they survive leaving and
    /// reopening the screen. Only admins/owners may list them, so non-managers skip the call.
    private func reloadInvitations() async {
        guard self.canManage else { return }
        guard let invitations = try? await self.organizationsService.listInvitations(
            organizationID: self.organization.id
        ) else { return }

        self.invites = invitations
            .filter(\.isPending)
            .map(OrgInvitation.init(apiInvitation:))
    }

    private func applyOrganizationDetail(_ detail: OrganizationsAPIFullOrganization) {
        self.members = detail.members.enumerated().map { index, member in
            OrgMember(
                apiMember: member,
                currentUserID: self.currentUserID,
                tint: ManageableOrganization.tint(for: index)
            )
        }

        // Resolve the viewer's role from authoritative member data; the list snapshot can be
        // stale (e.g. when the list endpoint returns no members and defaults everyone to member).
        if let mine = detail.members.first(where: { $0.userID == self.currentUserID }) {
            self.viewerRole = OrgRole(apiValue: mine.role)
        }
    }

    /// Opens the custom confirmation for leaving or deleting the org, with a warning haptic.
    private func confirmLeaveOrDelete() {
        self.didOpenDestructive.toggle()
        self.confirmation = ConfirmationPrompt(
            icon: self.isOwner ? "trash" : "rectangle.portrait.and.arrow.right",
            title: self.isOwner ? "Delete \(self.organization.name)?" : "Leave \(self.organization.name)?",
            message: self.isOwner
                ? "This permanently removes the organization, its members, and all projects. This can't be undone."
                : "You'll lose access to its projects and scans.",
            confirmTitle: self.isOwner ? "Delete organization" : "Leave organization",
            confirmIcon: self.isOwner ? "trash" : "rectangle.portrait.and.arrow.right"
        ) {
            Task { await self.leaveOrDelete() }
        }
    }

    /// Opens the custom confirmation for canceling a pending invite, with a warning haptic.
    private func confirmCancelInvite(_ invite: OrgInvitation) {
        self.didOpenDestructive.toggle()
        self.confirmation = ConfirmationPrompt(
            icon: "envelope.badge.shield.half.filled",
            title: "Cancel invitation?",
            message: "\(invite.email) will no longer be able to join with this invite.",
            confirmTitle: "Cancel invite",
            confirmIcon: "xmark",
            cancelTitle: "Keep invite"
        ) {
            self.cancelInvite(invite)
        }
    }

    private func inviteMember(email: String, role: OrgRole) {
        // Optimistically show the invite, then confirm with the API and roll back on failure.
        let invitation = OrgInvitation(
            id: "i_\(UUID().uuidString)",
            email: email,
            role: role,
            status: .pending,
            expiresText: "in 2 days"
        )
        self.invites.insert(invitation, at: 0)
        self.didSendInvite.toggle()
        self.toast = "Invite sent to \(email)"

        Task {
            do {
                try await self.organizationsService.inviteMember(
                    organizationID: self.organization.id,
                    email: email,
                    role: role
                )
                // Replace the optimistic placeholder with the authoritative server record
                // (real id, expiry) so it persists and can be canceled later.
                await self.reloadInvitations()
            } catch {
                self.invites.removeAll { $0.id == invitation.id }
                self.toast = Self.errorMessage(for: error)
            }
        }
    }

    private func updateMemberRole(id: String, role: OrgRole) async {
        guard let index = self.members.firstIndex(where: { $0.id == id }) else { return }

        do {
            try await self.organizationsService.updateMemberRole(
                organizationID: self.organization.id,
                memberID: id,
                role: role
            )
            self.members[index].role = role
            _ = try? await self.organizationDataCoordinator.refreshOrganizationDetail(id: self.organization.id)
            self.toast = "Role updated"
        } catch {
            self.toast = Self.errorMessage(for: error)
        }
    }

    private func removeMember(_ member: OrgMember) async {
        do {
            try await self.organizationsService.removeMember(
                organizationID: self.organization.id,
                memberIDOrEmail: member.id
            )
            self.members.removeAll { $0.id == member.id }
            _ = try? await self.organizationDataCoordinator.refreshOrganizationDetail(id: self.organization.id)
            self.toast = "\(member.name) removed"
        } catch {
            self.toast = Self.errorMessage(for: error)
        }
    }

    private func resendInvite(_ invite: OrgInvitation) {
        guard !self.resendingInviteIDs.contains(invite.id) else { return }
        self.resendingInviteIDs.insert(invite.id)

        Task {
            defer { self.resendingInviteIDs.remove(invite.id) }
            do {
                try await self.organizationsService.inviteMember(
                    organizationID: self.organization.id,
                    email: invite.email,
                    role: invite.role,
                    resend: true
                )
                await self.reloadInvitations()
                self.didResendInvite.toggle()
                self.toast = "Invite resent to \(invite.email)"
            } catch {
                self.toast = Self.errorMessage(for: error)
            }
        }
    }

    private func cancelInvite(_ invite: OrgInvitation) {
        self.invites.removeAll { $0.id == invite.id }
        self.didCancelInvite.toggle()
        self.toast = "Invitation canceled"

        Task {
            do {
                try await self.organizationsService.cancelInvitation(id: invite.id)
            } catch {
                self.toast = Self.errorMessage(for: error)
                await self.reloadInvitations()
            }
        }
    }

    private func leaveOrDelete() async {
        guard !self.isMutating else { return }

        self.isMutating = true
        defer { self.isMutating = false }

        do {
            if self.isOwner {
                try await self.organizationsService.deleteOrganization(id: self.organization.id)
            } else {
                try await self.organizationsService.leaveOrganization(id: self.organization.id)
            }
            self.didLeaveOrDelete.toggle()
            self.onLeaveOrDelete()
        } catch {
            self.toast = Self.errorMessage(for: error)
        }
    }
}

// MARK: - InviteSheetToken

/// Identifiable trigger so the invite sheet can be presented via `.sheet(item:)`.
private struct InviteSheetToken: Identifiable {
    let id = UUID()
}
