import SwiftUI

// MARK: - SlugAvailability

/// Result of a slug availability check. Mirrors the states surfaced by
/// `organization.checkSlug`.
private enum SlugAvailability {
    case unknown
    case checking
    case free
    case taken
}

// MARK: - CreateOrganizationView

/// Form for spinning up a new organization: name, a URL slug with live availability checking,
/// and an optional logo (the mark previews from the name as you type). Maps to
/// `organization.create`. The creator becomes the owner.
struct CreateOrganizationView: View {
    // MARK: Lifecycle

    init(
        ownerName: String = "You",
        ownerEmail: String = "",
        ownerTint: Color = Color("Primary"),
        onCreated: @escaping (ProjectsAPIOrganization) -> Void
    ) {
        self.ownerName = ownerName
        self.ownerEmail = ownerEmail
        self.ownerTint = ownerTint
        self.onCreated = onCreated
    }

    // MARK: Internal

    let ownerName: String
    let ownerEmail: String
    let ownerTint: Color
    let onCreated: (ProjectsAPIOrganization) -> Void

    var body: some View {
        ScrollView {
            VStack(spacing: 0) {
                self.logoPreview
                    .padding(.top, 26)
                    .padding(.bottom, 22)

                self.nameField
                    .padding(.bottom, 22)

                self.slugField

                self.ownerCard
                    .padding(.top, 18)

                PrimaryActionButton(
                    self.isCreating ? "Creating organization" : "Create organization",
                    isEnabled: self.isValid && !self.isCreating
                ) {
                    Task {
                        await self.create()
                    }
                }
                .padding(.horizontal, 16)
                .padding(.top, 8)
                .padding(.bottom, 40)
            }
        }
        .scrollBounceBehavior(.basedOnSize)
        .background(Color("Background"))
        .navigationTitle("New Organization")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .cancellationAction) {
                Button("Cancel") { self.dismiss() }
            }
            ToolbarItem(placement: .confirmationAction) {
                Button("Create") {
                    Task {
                        await self.create()
                    }
                }
                .fontWeight(.semibold)
                .disabled(!self.isValid || self.isCreating)
            }
        }
        .alert("Couldn’t Create Organization", isPresented: Binding(
            get: { self.errorMessage != nil },
            set: { isPresented in
                if !isPresented {
                    self.errorMessage = nil
                }
            }
        )) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(self.errorMessage ?? "")
        }
        // Light tick the moment a typed slug becomes available.
        .sensoryFeedback(.selection, trigger: self.slugAvailability == .free)
        // Success buzz when the org is created.
        .sensoryFeedback(.success, trigger: self.didCreate)
        .onAppear { self.nameFocused = true }
        .task(id: self.effectiveSlug) {
            await self.checkSlugAvailability()
        }
    }

    // MARK: Private

    @Environment(\.dismiss) private var dismiss

    @State private var name = ""
    @State private var slug = ""
    @State private var slugEdited = false
    @State private var slugAvailability: SlugAvailability = .unknown
    @State private var isCreating = false
    @State private var errorMessage: String?
    @State private var didCreate = false
    @FocusState private var nameFocused: Bool

    private let organizationsService = OrganizationsService()

    /// The effective slug: a slugified name until the user edits the slug directly.
    private var effectiveSlug: String {
        self.slugEdited ? self.slug : Self.slugify(self.name)
    }

    private var isValid: Bool {
        self.name.trimmingCharacters(in: .whitespaces).count >= 2
            && self.effectiveSlug.count >= 3
            && self.slugAvailability == .free
    }

    private var hasName: Bool {
        !self.name.trimmingCharacters(in: .whitespaces).isEmpty
    }

    private var markText: String {
        let initials = self.name.trimmingCharacters(in: .whitespaces)
            .split(separator: " ").prefix(2)
            .compactMap { $0.first.map(String.init) }
            .joined()
            .uppercased()
        return String(initials.prefix(2))
    }

    private var slugHint: String {
        switch self.slugAvailability {
        case .checking: "Checking availability..."
        case .taken: "That slug is already taken. Try another."
        case .free: "This slug is available."
        case .unknown: "Used in links and invites. Letters, numbers, and dashes."
        }
    }

    // MARK: Logo + live mark preview

    private var logoPreview: some View {
        VStack(spacing: 12) {
            ZStack(alignment: .bottomTrailing) {
                Group {
                    if self.hasName {
                        Text(self.markText)
                            .font(.system(size: 34, weight: .semibold))
                            .tracking(-0.5)
                            .foregroundStyle(.white)
                    } else {
                        Image(systemName: "plus")
                            .font(.system(size: 28, weight: .medium))
                            .foregroundStyle(Color(red: 60 / 255, green: 60 / 255, blue: 67 / 255).opacity(0.35))
                    }
                }
                .frame(width: 84, height: 84)
                .background(
                    self.hasName
                        ? AnyShapeStyle(Color("Primary"))
                        : AnyShapeStyle(Color(red: 60 / 255, green: 60 / 255, blue: 67 / 255).opacity(0.08))
                )
                .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
                .shadow(color: self.hasName ? Color("Primary").opacity(0.28) : .clear, radius: 9, x: 0, y: 6)
                .animation(.easeOut(duration: 0.2), value: self.hasName)

                // Camera affordance badge.
                Image(systemName: "camera.fill")
                    .font(.system(size: 12))
                    .foregroundStyle(Color("Primary"))
                    .frame(width: 30, height: 30)
                    .background(Color("Surface"), in: .circle)
                    .shadow(color: .black.opacity(0.2), radius: 2, x: 0, y: 1)
                    .offset(x: 4, y: 4)
            }

            Text("Add a logo (optional)")
                .font(.system(size: 13))
                .foregroundStyle(Color("TextSecondary"))
        }
    }

    // MARK: Name field

    private var nameField: some View {
        VStack(spacing: 0) {
            OrgFieldLabel(text: "Name")
            TextField("Stanford Civil Engineering", text: self.$name)
                .textFieldStyle(OrgTextFieldStyle())
                .focused(self.$nameFocused)
                .submitLabel(.next)
                .padding(.horizontal, 16)
        }
    }

    // MARK: Slug field with live availability

    private var slugField: some View {
        VStack(spacing: 0) {
            OrgFieldLabel(text: "URL slug")
            HStack(spacing: 8) {
                Text("p2bp.app/")
                    .font(.system(size: 16))
                    .foregroundStyle(Color("TextTertiary"))
                TextField("slug", text: Binding(
                    get: { self.effectiveSlug },
                    set: { self.slugEdited = true; self.slug = Self.slugify($0) }
                ))
                .font(.system(size: 16))
                .foregroundStyle(Color("TextPrimary"))
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()

                switch self.slugAvailability {
                case .free:
                    Image(systemName: "checkmark.circle.fill")
                        .foregroundStyle(Color("Success"))
                case .taken:
                    Image(systemName: "xmark.circle.fill")
                        .foregroundStyle(Color("Error"))
                case .checking:
                    ProgressView()
                        .controlSize(.mini)
                case .unknown:
                    EmptyView()
                }
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 14)
            .background(Color("Surface"), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
            .shadow(color: .black.opacity(0.04), radius: 1, x: 0, y: 1)
            .padding(.horizontal, 16)

            Text(self.slugHint)
                .font(.system(size: 12.5))
                .foregroundStyle(self.slugAvailability == .taken ? Color("Error") : Color("TextSecondary"))
                .lineSpacing(2)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.horizontal, 24)
                .padding(.top, 7)
        }
    }

    // MARK: Owner card

    private var ownerCard: some View {
        VStack(spacing: 0) {
            OrgGroupCard {
                HStack(spacing: 12) {
                    PersonAvatar(name: self.ownerName, email: self.ownerEmail, tint: self.ownerTint, size: 34)
                    VStack(alignment: .leading, spacing: 1) {
                        Text(self.ownerName)
                            .font(.system(size: 15, weight: .medium))
                            .foregroundStyle(Color("TextPrimary"))
                        if !self.ownerEmail.isEmpty {
                            Text(self.ownerEmail)
                                .font(.system(size: 13))
                                .foregroundStyle(Color("TextSecondary"))
                        }
                    }
                    Spacer(minLength: 8)
                    RoleBadge(role: .owner)
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 12)
                .frame(minHeight: 56)
            }
            OrgFooterText(text: "You'll be set as the owner and can invite teammates once it's created.")
        }
    }

    /// Lowercases, trims, and dash-joins a free-text name into a URL-safe slug.
    private static func slugify(_ input: String) -> String {
        let lowered = input.lowercased()
        let dashed = lowered.replacing(#/[^a-z0-9]+/#, with: "-")
        return dashed.trimmingCharacters(in: CharacterSet(charactersIn: "-"))
    }

    private static func errorMessage(for error: Error) -> String {
        switch error {
        case RequestServiceError.missingAuthToken, RequestServiceError.unauthorized:
            return "Sign in again to create an organization."
        case let RequestServiceError.invalidInput(message), let RequestServiceError.requestFailed(_, message):
            return message ?? "The organization could not be created."
        case RequestServiceError.forbidden:
            return "You do not have permission to create an organization."
        default:
            return "The organization could not be created."
        }
    }

    private func checkSlugAvailability() async {
        let slugToCheck = self.effectiveSlug
        guard slugToCheck.count >= 3 else {
            self.slugAvailability = .unknown
            return
        }

        self.slugAvailability = .checking
        try? await Task.sleep(nanoseconds: 300_000_000)
        guard !Task.isCancelled, slugToCheck == self.effectiveSlug else { return }

        do {
            let isAvailable = try await self.organizationsService.checkSlugAvailable(slugToCheck)
            guard slugToCheck == self.effectiveSlug else { return }
            self.slugAvailability = isAvailable ? .free : .taken
        } catch {
            guard slugToCheck == self.effectiveSlug else { return }
            self.slugAvailability = .unknown
        }
    }

    private func create() async {
        guard self.isValid, !self.isCreating else { return }

        self.isCreating = true
        defer { self.isCreating = false }

        do {
            let organization = try await self.organizationsService.createOrganization(
                name: self.name.trimmingCharacters(in: .whitespaces),
                slug: self.effectiveSlug
            )
            self.didCreate.toggle()
            self.onCreated(organization)
            self.dismiss()
        } catch {
            self.errorMessage = Self.errorMessage(for: error)
        }
    }
}
