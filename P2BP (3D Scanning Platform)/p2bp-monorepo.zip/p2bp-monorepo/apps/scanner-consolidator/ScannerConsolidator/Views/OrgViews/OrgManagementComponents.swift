import SwiftUI

// MARK: - OrgMarkBadge

/// Rounded-square monogram badge tinted with the organization's color. The management
/// counterpart to the switcher's mark, sized up for headers.
struct OrgMarkBadge: View {
    let text: String
    let tint: Color
    var size: CGFloat = 40
    var corner: CGFloat?

    var body: some View {
        Text(self.text)
            .font(.system(size: self.size * 0.38, weight: .semibold))
            .tracking(-0.4)
            .foregroundStyle(.white)
            .frame(width: self.size, height: self.size)
            .background(self.tint)
            .clipShape(RoundedRectangle(
                cornerRadius: self.corner ?? (self.size * 0.28),
                style: .continuous
            ))
            .shadow(color: self.tint.opacity(0.28), radius: self.size > 60 ? 9 : 1, x: 0, y: self.size > 60 ? 5 : 1)
    }
}

// MARK: - PersonAvatar

/// Circular initials avatar tinted per-member. Falls back to a neutral fill when no name is
/// available (e.g. an invite that hasn't been accepted).
struct PersonAvatar: View {
    // MARK: Internal

    var name: String?
    var email: String?
    var tint = Color("Primary")
    var size: CGFloat = 40

    var body: some View {
        Text(self.label)
            .font(.system(size: self.size * 0.4, weight: .semibold))
            .tracking(-0.2)
            .foregroundStyle(self.hasName ? .white : Color("TextSecondary"))
            .frame(width: self.size, height: self.size)
            .background(self.hasName ? self.tint : Color(red: 60 / 255, green: 60 / 255, blue: 67 / 255).opacity(0.12))
            .clipShape(.circle)
            .shadow(color: .black.opacity(self.hasName ? 0.08 : 0), radius: 1, x: 0, y: 1)
    }

    // MARK: Private

    private var hasName: Bool {
        !(self.name ?? "").isEmpty
    }

    private var label: String {
        if let name = self.name, !name.isEmpty {
            return name.split(separator: " ").prefix(2)
                .compactMap { $0.first.map(String.init) }
                .joined()
                .uppercased()
        }
        if let email = self.email, let first = email.first {
            return String(first).uppercased()
        }
        return "?"
    }
}

// MARK: - RoleBadge

/// Pill tag showing a member or invite's role, colored per `OrgRole`.
struct RoleBadge: View {
    let role: OrgRole

    var body: some View {
        Text(self.role.label)
            .font(.system(size: 12, weight: .semibold))
            .tracking(-0.1)
            .foregroundStyle(self.role.badgeForeground)
            .padding(.horizontal, 9)
            .padding(.vertical, 3)
            .background(self.role.badgeBackground, in: .capsule)
            .fixedSize()
    }
}

// MARK: - OrgSectionHeader

/// Uppercase grouped-list section header with an optional trailing action (e.g. "Invite").
struct OrgSectionHeader<Action: View>: View {
    let title: String
    @ViewBuilder var action: () -> Action

    var body: some View {
        HStack(alignment: .bottom, spacing: 8) {
            Text(self.title)
                .font(.system(size: 13, weight: .semibold))
                .textCase(.uppercase)
                .tracking(0.4)
                .foregroundStyle(Color("TextSecondary"))
            Spacer(minLength: 8)
            self.action()
        }
        .padding(.horizontal, 20)
        .padding(.bottom, 7)
    }
}

extension OrgSectionHeader where Action == EmptyView {
    init(_ title: String) {
        self.init(title: title) { EmptyView() }
    }
}

// MARK: - OrgGroupCard

/// White rounded card that wraps grouped rows, matching the design's 16pt-radius surface
/// over the `Background` fill.
struct OrgGroupCard<Content: View>: View {
    @ViewBuilder var content: () -> Content

    var body: some View {
        VStack(spacing: 0) {
            self.content()
        }
        .background(Color("Surface"))
        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
        .shadow(color: .black.opacity(0.04), radius: 1, x: 0, y: 1)
        .padding(.horizontal, 16)
    }
}

// MARK: - OrgRowDivider

/// Hairline separator inset to align under a row's text, drawn between grouped rows.
struct OrgRowDivider: View {
    var leadingInset: CGFloat = 0

    var body: some View {
        Rectangle()
            .fill(Color(red: 60 / 255, green: 60 / 255, blue: 67 / 255).opacity(0.1))
            .frame(height: 0.5)
            .padding(.leading, self.leadingInset)
    }
}

// MARK: - OrgFooterText

/// Muted explanatory caption shown beneath a grouped card.
struct OrgFooterText: View {
    let text: String

    var body: some View {
        Text(self.text)
            .font(.system(size: 12.5))
            .foregroundStyle(Color("TextSecondary"))
            .lineSpacing(2)
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.horizontal, 24)
            .padding(.top, 7)
    }
}

// MARK: - OrgFieldLabel

/// Uppercase field label sitting above a text field in the create / invite forms.
struct OrgFieldLabel: View {
    let text: String

    var body: some View {
        Text(self.text)
            .font(.system(size: 13, weight: .semibold))
            .textCase(.uppercase)
            .tracking(0.4)
            .foregroundStyle(Color("TextSecondary"))
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.horizontal, 20)
            .padding(.bottom, 7)
    }
}

// MARK: - OrgChevron

/// Trailing disclosure chevron matching the grouped-row style.
struct OrgChevron: View {
    var body: some View {
        Image(systemName: "chevron.right")
            .font(.system(size: 12, weight: .semibold))
            .foregroundStyle(Color(red: 60 / 255, green: 60 / 255, blue: 67 / 255).opacity(0.3))
    }
}

// MARK: - PrimaryActionButton

/// Full-width pill button used as the primary CTA across the org flows.
struct PrimaryActionButton: View {
    // MARK: Lifecycle

    init(
        _ title: String,
        systemImage: String? = nil,
        isEnabled: Bool = true,
        isDestructive: Bool = false,
        action: @escaping () -> Void
    ) {
        self.title = title
        self.systemImage = systemImage
        self.isEnabled = isEnabled
        self.isDestructive = isDestructive
        self.action = action
    }

    // MARK: Internal

    var body: some View {
        Button(action: self.action) {
            HStack(spacing: 8) {
                if let systemImage {
                    Image(systemName: systemImage)
                        .font(.system(size: 16, weight: .semibold))
                }
                Text(self.title)
                    .font(.system(size: 16, weight: .semibold))
                    .tracking(-0.2)
            }
            .frame(maxWidth: .infinity, minHeight: 52)
            .foregroundStyle(self.isEnabled ? .white : Color("TextTertiary"))
            .background(self.background, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
        }
        .buttonStyle(.plain)
        .disabled(!self.isEnabled)
    }

    // MARK: Private

    private let title: String
    private let systemImage: String?
    private let isEnabled: Bool
    private let isDestructive: Bool
    private let action: () -> Void

    private var background: Color {
        guard self.isEnabled else {
            return Color(red: 60 / 255, green: 60 / 255, blue: 67 / 255).opacity(0.12)
        }
        return self.isDestructive ? Color("Error") : Color("Primary")
    }
}

// MARK: - OrgToast

/// Transient confirmation pill (e.g. "Invite sent") shown above the safe area. Uses Liquid
/// Glass so it floats cleanly over whatever content is behind it.
struct OrgToast: View {
    let message: String

    var body: some View {
        Text(self.message)
            .font(.system(size: 14, weight: .medium))
            .foregroundStyle(.white)
            .lineLimit(1)
            .padding(.horizontal, 18)
            .padding(.vertical, 11)
            .background(Color(red: 28 / 255, green: 28 / 255, blue: 30 / 255).opacity(0.92), in: .capsule)
            .glassEffect(.regular, in: .capsule)
            .shadow(color: .black.opacity(0.3), radius: 15, x: 0, y: 8)
    }
}

// MARK: - View + orgToast

extension View {
    /// Presents an auto-dismissing toast bound to an optional message string.
    func orgToast(_ message: Binding<String?>) -> some View {
        self.overlay(alignment: .bottom) {
            if let text = message.wrappedValue {
                OrgToast(message: text)
                    .padding(.bottom, 38)
                    .transition(.move(edge: .bottom).combined(with: .opacity))
                    .task(id: text) {
                        try? await Task.sleep(for: .seconds(2.2))
                        withAnimation(.spring(response: 0.35, dampingFraction: 0.9)) {
                            message.wrappedValue = nil
                        }
                    }
            }
        }
        .animation(.spring(response: 0.35, dampingFraction: 0.9), value: message.wrappedValue)
    }
}
