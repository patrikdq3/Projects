import SwiftUI

// MARK: - RolePicker

/// Segmented role selector with a live description of the highlighted role. By default it
/// offers Member / Scanner / Admin; pass `allowsOwner` to expose the Owner option (e.g.
/// ownership transfer flows).
struct RolePicker: View {
    // MARK: Lifecycle

    init(selection: Binding<OrgRole>, allowsOwner: Bool = false) {
        self._selection = selection
        self.options = allowsOwner ? [.member, .scanner, .admin, .owner] : [.member, .scanner, .admin]
    }

    // MARK: Internal

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack(spacing: 4) {
                ForEach(self.options) { role in
                    self.segment(for: role)
                }
            }
            .padding(4)
            .background(
                Color(red: 60 / 255, green: 60 / 255, blue: 67 / 255).opacity(0.06),
                in: RoundedRectangle(cornerRadius: 12, style: .continuous)
            )
            .padding(.horizontal, 16)

            Text(self.selection.blurb)
                .font(.system(size: 13))
                .foregroundStyle(Color("TextSecondary"))
                .lineSpacing(2)
                .frame(maxWidth: .infinity, minHeight: 38, alignment: .topLeading)
                .padding(.horizontal, 24)
                .padding(.top, 10)
        }
        // Light tick as the highlighted role changes.
        .sensoryFeedback(.selection, trigger: self.selection)
    }

    // MARK: Private

    @Binding private var selection: OrgRole
    @Namespace private var indicator

    private let options: [OrgRole]

    private func segment(for role: OrgRole) -> some View {
        let isOn = self.selection == role
        return Button {
            withAnimation(.spring(response: 0.3, dampingFraction: 0.8)) {
                self.selection = role
            }
        } label: {
            Text(role.label)
                .font(.system(size: 14, weight: isOn ? .semibold : .medium))
                .foregroundStyle(isOn ? Color("TextPrimary") : Color("TextSecondary"))
                .frame(maxWidth: .infinity)
                .padding(.vertical, 8)
                .background {
                    if isOn {
                        RoundedRectangle(cornerRadius: 9, style: .continuous)
                            .fill(Color("Surface"))
                            .glassEffect(.regular, in: .rect(cornerRadius: 9))
                            .shadow(color: .black.opacity(0.12), radius: 2, x: 0, y: 1)
                            .matchedGeometryEffect(id: "rolePickerIndicator", in: self.indicator)
                    }
                }
        }
        .buttonStyle(.plain)
    }
}
