import SwiftUI

// MARK: - InvitationBanner

/// Tappable notification shown beneath the nav bar after sign-in when the user has new
/// organization invitations. Tapping it opens the invitations list. Matches the app's Liquid
/// Glass theming.
struct InvitationBanner: View {
    let message: String
    let onTap: () -> Void

    var body: some View {
        Button(action: self.onTap) {
            HStack(spacing: 12) {
                ZStack {
                    Circle().fill(Color("Primary").opacity(0.14))
                    Image(systemName: "envelope.badge.fill")
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundStyle(Color("Primary"))
                }
                .frame(width: 38, height: 38)

                VStack(alignment: .leading, spacing: 2) {
                    Text("New invitation")
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundStyle(Color("TextPrimary"))
                    Text(self.message)
                        .font(.system(size: 13))
                        .foregroundStyle(Color("TextSecondary"))
                        .lineLimit(2)
                        .multilineTextAlignment(.leading)
                }

                Spacer(minLength: 8)

                Image(systemName: "chevron.right")
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundStyle(.tertiary)
            }
            .padding(.vertical, 11)
            .padding(.horizontal, 14)
            .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
            .glassEffect(.regular, in: .rect(cornerRadius: 18))
            .overlay(
                RoundedRectangle(cornerRadius: 18, style: .continuous)
                    .strokeBorder(Color("Primary").opacity(0.18), lineWidth: 0.5)
            )
            .shadow(color: .black.opacity(0.12), radius: 14, x: 0, y: 6)
        }
        .buttonStyle(.plain)
        .accessibilityHint("Opens your pending invitations")
    }
}
