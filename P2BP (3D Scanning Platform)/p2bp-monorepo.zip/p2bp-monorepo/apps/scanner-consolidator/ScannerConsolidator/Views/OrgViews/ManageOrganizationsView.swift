import SwiftUI

// MARK: - OrgManageRoute

private enum OrgManageRoute: Hashable {
    case detail(String)
    case create
}

// MARK: - ManageOrganizationsView

/// Entry point for the org-management flow: a list of every organization the user belongs to,
/// each tagged with their role. Tapping one opens its detail; the toolbar "+" opens the create
/// flow. Maps to `organization.list`.
///
/// Hosts its own `NavigationStack`, so present it from a sheet or push it into an existing
/// stack via its body.
struct ManageOrganizationsView: View {
    // MARK: Lifecycle

    init(
        organizations: [ManageableOrganization]? = nil,
        currentUser: User? = nil,
        showsDoneButton: Bool = false
    ) {
        self._organizations = State(initialValue: organizations ?? [])
        self._currentUser = State(initialValue: currentUser)
        self.showsDoneButton = showsDoneButton
        self.shouldLoadFromAPI = organizations == nil
    }

    // MARK: Internal

    var body: some View {
        NavigationStack(path: self.$path) {
            ScrollView {
                VStack(spacing: 0) {
                    if self.isShowingInitialLoading {
                        ProgressView()
                            .frame(maxWidth: .infinity)
                            .padding(.top, 44)
                    } else if self.displayedOrganizations.isEmpty {
                        self.emptyState
                    } else {
                        OrgGroupCard {
                            ForEach(
                                Array(self.displayedOrganizations.enumerated()),
                                id: \.element.id
                            ) { index, organization in
                                NavigationLink(value: OrgManageRoute.detail(organization.id)) {
                                    self.organizationRow(organization)
                                }
                                .buttonStyle(.plain)

                                if index < self.displayedOrganizations.count - 1 {
                                    OrgRowDivider(leadingInset: 68)
                                }
                            }
                        }
                        .padding(.top, 14)

                        OrgFooterText(
                            text: """
                            You belong to these organizations. Tap one to manage its members, invites, and settings.
                            """
                        )
                    }

                    if let loadErrorMessage = self.displayedLoadErrorMessage {
                        self.errorText(loadErrorMessage)
                    }
                }
                .padding(.bottom, 40)
            }
            .background(Color("Background"))
            .navigationTitle("Organizations")
            .navigationBarTitleDisplayMode(.large)
            .task {
                await self.loadOrganizationsIfNeeded()
            }
            .toolbar {
                if self.showsDoneButton {
                    ToolbarItem(placement: .topBarLeading) {
                        Button("Done") { self.dismiss() }
                    }
                }
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        self.path.append(.create)
                    } label: {
                        Image(systemName: "plus")
                            .font(.system(size: 17, weight: .regular))
                            .foregroundStyle(Color("Primary"))
                    }
                    .accessibilityLabel("New Organization")
                }
            }
            .navigationDestination(for: OrgManageRoute.self) { route in
                switch route {
                case let .detail(id):
                    if let organization = self.displayedOrganizations.first(where: { $0.id == id }) {
                        OrganizationDetailView(organization: organization) {
                            // Leaving or deleting pops back to the list.
                            if self.shouldLoadFromAPI {
                                self.organizationDataCoordinator.removeCachedOrganization(id: id)
                                Task {
                                    await self.remoteProjectsDataCoordinator
                                        .refreshOrganizations(user: self.currentUser)
                                }
                            } else {
                                self.organizations.removeAll { $0.id == id }
                            }
                            self.path.removeLast()
                        }
                    }
                case .create:
                    CreateOrganizationView(
                        ownerName: self.currentUser?.name ?? "You",
                        ownerEmail: self.currentUser?.email ?? ""
                    ) { organization in
                        if self.shouldLoadFromAPI {
                            self.organizationDataCoordinator.cacheCreatedOrganization(
                                organization,
                                currentUser: self.currentUser
                            )
                            Task {
                                await self.remoteProjectsDataCoordinator.refreshOrganizations(user: self.currentUser)
                            }
                        } else {
                            self.organizations.append(
                                ManageableOrganization(
                                    id: organization.id,
                                    name: organization.name,
                                    slug: organization.slug,
                                    tint: ManageableOrganization.tint(for: self.organizations.count),
                                    viewerRole: .owner,
                                    memberCount: 1
                                )
                            )
                        }
                    }
                }
            }
        }
    }

    // MARK: Private

    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var organizationDataCoordinator: OrganizationDataCoordinator
    @EnvironmentObject private var remoteProjectsDataCoordinator: RemoteProjectsDataCoordinator

    @State private var organizations: [ManageableOrganization]
    @State private var path: [OrgManageRoute] = []
    @State private var currentUser: User?
    @State private var loadErrorMessage: String?

    /// Whether to show a leading "Done" button (used when presented as a sheet).
    private let showsDoneButton: Bool
    private let shouldLoadFromAPI: Bool

    private var displayedOrganizations: [ManageableOrganization] {
        self.shouldLoadFromAPI ? self.organizationDataCoordinator.manageableOrganizations : self.organizations
    }

    private var isShowingInitialLoading: Bool {
        self.shouldLoadFromAPI
            ? self.organizationDataCoordinator.isLoadingOrganizations && self.displayedOrganizations.isEmpty
            : false
    }

    private var displayedLoadErrorMessage: String? {
        self.shouldLoadFromAPI ? self.organizationDataCoordinator.loadErrorMessage : self.loadErrorMessage
    }

    private var emptyState: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("No Organizations")
                .font(.system(size: 18, weight: .semibold))
                .foregroundStyle(Color("TextPrimary"))
            Text("Create an organization to manage members and shared projects.")
                .font(.system(size: 14))
                .foregroundStyle(Color("TextSecondary"))
                .lineSpacing(3)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.horizontal, 20)
        .padding(.top, 32)
    }

    private func organizationRow(_ organization: ManageableOrganization) -> some View {
        HStack(spacing: 12) {
            OrgMarkBadge(text: organization.mark, tint: organization.tint, size: 40)

            VStack(alignment: .leading, spacing: 1) {
                Text(organization.name)
                    .font(.system(size: 16, weight: .semibold))
                    .tracking(-0.3)
                    .foregroundStyle(Color("TextPrimary"))
                    .lineLimit(1)
                Text("^[\(organization.memberCount) member](inflect: true)")
                    .font(.system(size: 13))
                    .foregroundStyle(Color("TextSecondary"))
            }

            Spacer(minLength: 8)
            RoleBadge(role: organization.viewerRole)
            OrgChevron()
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
        .frame(minHeight: 56)
        .contentShape(.rect)
    }

    private func errorText(_ message: String) -> some View {
        Text(message)
            .font(.system(size: 13))
            .foregroundStyle(Color("Error"))
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.horizontal, 24)
            .padding(.top, 12)
    }

    private func loadOrganizationsIfNeeded() async {
        guard self.shouldLoadFromAPI else { return }

        if self.currentUser == nil {
            self.currentUser = await AuthService.shared.getSession()?.user
        }

        await self.organizationDataCoordinator.loadCachedThenRefresh(user: self.currentUser)
    }
}
