import SwiftUI

// MARK: - InviteMemberSheet

/// Bottom sheet for inviting a teammate by email with a role. Maps to
/// `organization.inviteMember`.
struct InviteMemberSheet: View {
    // MARK: Lifecycle

    init(organizationName: String, onSend: @escaping (_ email: String, _ role: OrgRole) -> Void) {
        self.organizationName = organizationName
        self.onSend = onSend
    }

    // MARK: Internal

    let organizationName: String
    let onSend: (_ email: String, _ role: OrgRole) -> Void

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 0) {
                    Text(
                        """
                        We'll send an invite to join \
                        \(Text(self.organizationName).fontWeight(.semibold).foregroundColor(Color("TextPrimary"))). \
                        It expires in 48 hours.
                        """
                    )
                    .font(.system(size: 14))
                    .foregroundStyle(Color("TextSecondary"))
                    .lineSpacing(3)
                    .padding(.horizontal, 24)
                    .padding(.top, 18)
                    .padding(.bottom, 20)

                    OrgFieldLabel(text: "Email address")
                    TextField("name@company.com", text: self.$email)
                        .textFieldStyle(OrgTextFieldStyle())
                        .textContentType(.emailAddress)
                        .keyboardType(.emailAddress)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .focused(self.$emailFocused)
                        .padding(.horizontal, 16)
                        .padding(.bottom, 22)

                    OrgFieldLabel(text: "Role")
                    RolePicker(selection: self.$role)

                    PrimaryActionButton(
                        "Send invite",
                        systemImage: "arrow.right",
                        isEnabled: self.isValid
                    ) {
                        self.send()
                    }
                    .padding(.horizontal, 16)
                    .padding(.top, 24)
                    .padding(.bottom, 16)
                }
            }
            .scrollBounceBehavior(.basedOnSize)
            .background(Color("Background"))
            .navigationTitle("Invite")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { self.dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Send") { self.send() }
                        .fontWeight(.semibold)
                        .disabled(!self.isValid)
                }
            }
        }
        .presentationDetents([.medium, .large])
        .presentationDragIndicator(.visible)
        .presentationBackground(.regularMaterial)
        // The "invite sent" success buzz is fired by the presenting view once delivery is recorded.
        .onAppear { self.emailFocused = true }
    }

    // MARK: Private

    @Environment(\.dismiss) private var dismiss

    @State private var email = ""
    @State private var role: OrgRole = .member
    @FocusState private var emailFocused: Bool

    private var isValid: Bool {
        let trimmed = self.email.trimmingCharacters(in: .whitespaces)
        // Simple shape check; the backend remains the source of truth.
        return trimmed.range(of: #"^[^@\s]+@[^@\s]+\.[^@\s]+$"#, options: .regularExpression) != nil
    }

    private func send() {
        guard self.isValid else { return }
        // Invitation delivery stays local until the email service is implemented.
        self.onSend(self.email.trimmingCharacters(in: .whitespaces), self.role)
        self.dismiss()
    }
}

// MARK: - OrgTextFieldStyle

/// Rounded, surface-filled field matching the create / invite forms.
struct OrgTextFieldStyle: TextFieldStyle {
    func _body(configuration: TextField<Self._Label>) -> some View {
        configuration
            .font(.system(size: 16))
            .foregroundStyle(Color("TextPrimary"))
            .padding(.horizontal, 16)
            .padding(.vertical, 14)
            .background(Color("Surface"), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
            .shadow(color: .black.opacity(0.04), radius: 1, x: 0, y: 1)
    }
}
