import SwiftUI

// MARK: - InvitationsView

/// Lists the organization invitations the signed-in user has received, letting them accept or
/// decline each one. Maps to `organization.acceptInvitation` / `organization.rejectInvitation`.
struct InvitationsView: View {
    // MARK: Lifecycle

    init(invitations: [OrganizationsAPIInvitation] = [], onChanged: @escaping () -> Void) {
        self._invitations = State(initialValue: invitations.filter(\.isActivePending))
        self.onChanged = onChanged
    }

    // MARK: Internal

    /// Invoked after an invitation is accepted or declined so the host can refresh the org list.
    let onChanged: () -> Void

    var body: some View {
        NavigationStack {
            ScrollView {
                if self.invitations.isEmpty {
                    self.emptyState
                } else {
                    VStack(spacing: 16) {
                        ForEach(Array(self.invitations.enumerated()), id: \.element.id) { index, invitation in
                            self.card(for: invitation, tint: ManageableOrganization.tint(for: index))
                        }
                    }
                    .padding(.vertical, 18)
                }
            }
            .scrollBounceBehavior(.basedOnSize)
            .background(Color("Background"))
            .navigationTitle("Invitations")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Done") { self.dismiss() }
                }
            }
        }
        .orgToast(self.$toast)
        .sensoryFeedback(.success, trigger: self.didAcceptInvitation)
        .task { await self.reload() }
    }

    // MARK: Private

    @Environment(\.dismiss) private var dismiss

    @State private var invitations: [OrganizationsAPIInvitation]
    @State private var toast: String?
    @State private var busyID: String?
    @State private var didAcceptInvitation = false

    private let organizationsService = OrganizationsService()

    private var emptyState: some View {
        VStack(spacing: 10) {
            Image(systemName: "envelope.open")
                .font(.system(size: 34, weight: .regular))
                .foregroundStyle(Color("TextTertiary"))
            Text("No pending invitations")
                .font(.system(size: 17, weight: .semibold))
                .foregroundStyle(Color("TextPrimary"))
            Text("When someone invites you to an organization, it'll show up here.")
                .font(.system(size: 14))
                .foregroundStyle(Color("TextSecondary"))
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding(.horizontal, 40)
        .padding(.top, 80)
    }

    private func card(for invitation: OrganizationsAPIInvitation, tint: Color) -> some View {
        OrgGroupCard {
            VStack(alignment: .leading, spacing: 14) {
                HStack(spacing: 12) {
                    OrgMarkBadge(text: invitation.mark, tint: tint, size: 44)

                    VStack(alignment: .leading, spacing: 3) {
                        Text(invitation.displayName)
                            .font(.system(size: 16, weight: .semibold))
                            .foregroundStyle(Color("TextPrimary"))
                            .lineLimit(1)

                        Text(self.subtitle(for: invitation))
                            .font(.system(size: 13))
                            .foregroundStyle(Color("TextSecondary"))
                            .lineLimit(1)
                    }

                    Spacer(minLength: 8)

                    RoleBadge(role: OrgRole(apiValue: invitation.role))
                }

                HStack(spacing: 10) {
                    Button("Decline") { self.respond(to: invitation, accept: false) }
                        .buttonStyle(InvitationActionStyle(kind: .secondary))

                    Button("Accept") { self.respond(to: invitation, accept: true) }
                        .buttonStyle(InvitationActionStyle(kind: .primary))
                }
                .disabled(self.busyID != nil)
                .opacity(self.busyID == invitation.id ? 0.5 : 1)
            }
            .padding(16)
        }
    }

    private func subtitle(for invitation: OrganizationsAPIInvitation) -> String {
        if let inviter = invitation.inviterEmail, !inviter.isEmpty {
            return "Invited by \(inviter)"
        }
        return "Invited as \(OrgRole(apiValue: invitation.role).label)"
    }

    private func reload() async {
        guard let fetched = try? await self.organizationsService.listUserInvitations() else { return }
        self.invitations = fetched.filter(\.isActivePending)
    }

    private func respond(to invitation: OrganizationsAPIInvitation, accept: Bool) {
        guard self.busyID == nil else { return }
        self.busyID = invitation.id

        Task {
            defer { self.busyID = nil }
            do {
                if accept {
                    try await self.organizationsService.acceptInvitation(id: invitation.id)
                } else {
                    try await self.organizationsService.rejectInvitation(id: invitation.id)
                }
                self.invitations.removeAll { $0.id == invitation.id }
                self.toast = accept ? "Joined \(invitation.displayName)" : "Invitation declined"
                if accept {
                    self.didAcceptInvitation.toggle()
                }
                self.onChanged()
            } catch {
                self.toast = "Couldn't update the invitation. Try again."
            }
        }
    }
}

// MARK: - InvitationActionStyle

/// The paired Accept (filled) / Decline (tinted-surface) buttons on an invitation card.
private struct InvitationActionStyle: ButtonStyle {
    enum Kind {
        case primary
        case secondary
    }

    let kind: Kind

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(size: 15, weight: .semibold))
            .frame(maxWidth: .infinity, minHeight: 44)
            .foregroundStyle(self.kind == .primary ? .white : Color("TextPrimary"))
            .background(
                self.kind == .primary
                    ? Color("Primary")
                    : Color(red: 60 / 255, green: 60 / 255, blue: 67 / 255).opacity(0.08),
                in: RoundedRectangle(cornerRadius: 12, style: .continuous)
            )
            .opacity(configuration.isPressed ? 0.7 : 1)
    }
}
