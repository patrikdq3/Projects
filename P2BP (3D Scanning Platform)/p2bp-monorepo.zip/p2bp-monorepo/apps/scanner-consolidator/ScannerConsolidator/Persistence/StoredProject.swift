import Foundation
import SwiftData

// MARK: - StoredProject

@Model
final class StoredProject {
    // MARK: Lifecycle

    init(
        id: UUID,
        name: String,
        createdAt: Date,
        centerLatitude: Double,
        centerLongitude: Double,
        widthMeters: Double,
        heightMeters: Double,
        boundaryVerticesJSON: String = "",
        remoteID: String? = nil,
        remoteOrganizationID: String? = nil,
        pendingRemoteOrganizationID: String? = nil,
        zones: [StoredZone] = []
    ) {
        self.id = id
        self.name = name
        self.createdAt = createdAt
        self.centerLatitude = centerLatitude
        self.centerLongitude = centerLongitude
        self.widthMeters = widthMeters
        self.heightMeters = heightMeters
        self.boundaryVerticesJSON = boundaryVerticesJSON
        self.remoteID = remoteID
        self.remoteOrganizationID = remoteOrganizationID
        self.pendingRemoteOrganizationID = pendingRemoteOrganizationID
        self.zones = zones
    }

    // MARK: Internal

    @Attribute(.unique) var id: UUID
    var name: String
    var createdAt: Date
    var centerLatitude: Double
    var centerLongitude: Double
    var widthMeters: Double
    var heightMeters: Double
    /// JSON-encoded `[GeoCoordinate]`. Empty for legacy rectangle rows; the read path
    /// reconstructs four corners from `centerLatitude/centerLongitude/widthMeters/heightMeters`.
    var boundaryVerticesJSON = ""
    /// Identifier of the remote API project this row was materialized from, when applicable.
    /// Used to dedupe so tapping the same remote project twice reuses one local copy.
    var remoteID: String?
    var remoteOrganizationID: String?
    var pendingRemoteOrganizationID: String?

    @Relationship(deleteRule: .cascade, inverse: \StoredZone.project)
    var zones: [StoredZone]
}

// MARK: - StoredZone

@Model
final class StoredZone {
    // MARK: Lifecycle

    init(
        id: UUID,
        remoteID: String? = nil,
        name: String,
        rowIndex: Int,
        columnIndex: Int,
        originXMeters: Double,
        originYMeters: Double,
        widthMeters: Double,
        heightMeters: Double,
        footprintPointsJSON: String = "",
        scanProjectID: UUID? = nil,
        scanStateRawValue: String,
        scanStartedAt: Date? = nil,
        scanCompletedAt: Date? = nil,
        project: StoredProject? = nil
    ) {
        self.id = id
        self.remoteID = remoteID
        self.name = name
        self.rowIndex = rowIndex
        self.columnIndex = columnIndex
        self.originXMeters = originXMeters
        self.originYMeters = originYMeters
        self.widthMeters = widthMeters
        self.heightMeters = heightMeters
        self.footprintPointsJSON = footprintPointsJSON
        self.scanProjectID = scanProjectID
        self.scanStateRawValue = scanStateRawValue
        self.scanStartedAt = scanStartedAt
        self.scanCompletedAt = scanCompletedAt
        self.project = project
    }

    // MARK: Internal

    @Attribute(.unique) var id: UUID
    var remoteID: String?
    var name: String
    var rowIndex: Int
    var columnIndex: Int
    var originXMeters: Double
    var originYMeters: Double
    var widthMeters: Double
    var heightMeters: Double
    /// JSON-encoded `[LocalPoint]`. Empty for legacy rectangle rows; the read path
    /// reconstructs four corners from the `originX/originY/width/height` fields.
    var footprintPointsJSON = ""
    var scanProjectID: UUID?
    var scanStateRawValue: String
    var scanStartedAt: Date?
    var scanCompletedAt: Date?
    var project: StoredProject?
}
