import Combine
import Foundation
import SwiftData

// MARK: - ProjectStore

@MainActor
// swiftlint:disable:next type_body_length
final class ProjectStore: ObservableObject {
    // MARK: Lifecycle

    init(
        container: ModelContainer,
        scanProjectStore: ScanProjectStore? = nil
    ) {
        self.modelContainer = container
        self.modelContext = ModelContext(container)
        self.scanProjectStore = scanProjectStore ?? ScanProjectStore()

        do {
            try self.reload()
        } catch {
            assertionFailure("Failed to load persisted projects: \(error.localizedDescription)")
        }
    }

    // MARK: Internal

    @Published private(set) var projects: [Project] = []

    /// creates a new project and stores it on disk
    func createProject(
        named name: String,
        boundary: ProjectBoundary,
        remoteID: String,
        remoteOrganizationID: String,
        apiZones: [ZonesAPIZone]
    ) throws -> Project {
        try self.insertProject(
            named: name,
            boundary: boundary,
            remoteID: remoteID,
            remoteOrganizationID: remoteOrganizationID,
            zones: Self.makeZones(from: apiZones, boundary: boundary)
        )
    }

    /// Creates a local-only project shell when remote creation is unavailable. Zones remain empty
    /// until the server can generate them.
    func createLocalProject(
        named name: String,
        boundary: ProjectBoundary,
        pendingRemoteOrganizationID: String? = nil
    ) throws -> Project {
        try self.insertProject(
            named: name,
            boundary: boundary,
            remoteID: nil,
            remoteOrganizationID: nil,
            pendingRemoteOrganizationID: pendingRemoteOrganizationID,
            zones: []
        )
    }

    func validateProjectCreation(named name: String, boundary: ProjectBoundary) throws {
        try self.validateProject(named: name, boundary: boundary)
    }

    /// Returns the local project backing a remote API project, creating and persisting it
    /// with API-provided zones on first access. Subsequent calls with the same `remoteID`
    /// reuse the existing local copy so scan progress is never duplicated.
    ///
    /// Batch callers can pass `reloadsStore: false` to persist changes without republishing
    /// `projects`, coalescing the full store reload instead of paying it once per project;
    /// such callers must invoke `reload()` themselves once their batch settles.
    func materializeRemoteProject(
        remoteID: String,
        remoteOrganizationID: String,
        name: String,
        boundary: ProjectBoundary,
        apiZones: [ZonesAPIZone],
        reloadsStore: Bool = true
    ) throws -> (project: Project, didChange: Bool) {
        let descriptor = FetchDescriptor<StoredProject>(
            predicate: #Predicate { $0.remoteID == remoteID }
        )
        if let existing = try self.modelContext.fetch(descriptor).first {
            var didUpdate = false
            if existing.remoteOrganizationID != remoteOrganizationID {
                existing.remoteOrganizationID = remoteOrganizationID
                didUpdate = true
            }
            if existing.pendingRemoteOrganizationID != nil {
                existing.pendingRemoteOrganizationID = nil
                didUpdate = true
            }
            let didReconcileZones = try !apiZones.isEmpty && (Self.reconcileStoredZones(
                in: existing,
                with: apiZones,
                boundary: boundary
            ))
            if didReconcileZones {
                didUpdate = true
            }
            if didUpdate {
                try self.modelContext.save()
                if reloadsStore {
                    try self.reload()
                }
            }
            return (Self.makeProject(from: existing), didUpdate)
        }

        let project = try self.insertProject(
            named: name,
            boundary: boundary,
            remoteID: remoteID,
            remoteOrganizationID: remoteOrganizationID,
            zones: Self.makeZones(from: apiZones, boundary: boundary),
            reloadsStore: reloadsStore
        )
        return (project, true)
    }

    /// Converts an offline-created local shell into a remote-backed project once the API create
    /// and server-side zone generation have succeeded.
    func attachRemoteProject(
        remoteID: String,
        remoteOrganizationID: String,
        apiZones: [ZonesAPIZone],
        toProject projectID: UUID
    ) throws -> Project {
        let storedProject = try self.storedProject(projectID: projectID)
        let boundary = Self.makeProject(from: storedProject).boundary
        let storedZones = try Self.makeStoredZones(from: apiZones, boundary: boundary)

        storedProject.remoteID = remoteID
        storedProject.remoteOrganizationID = remoteOrganizationID
        storedProject.pendingRemoteOrganizationID = nil
        if storedProject.zones.isEmpty {
            storedProject.zones = storedZones
            for zone in storedZones {
                zone.project = storedProject
            }
        } else {
            _ = try Self.reconcileStoredZones(
                in: storedProject,
                with: apiZones,
                boundary: boundary
            )
        }

        try self.modelContext.save()
        try self.reload()

        guard let project = self.project(withID: projectID) else {
            throw ProjectStoreError.projectNotFound
        }
        return project
    }

    func project(withID id: UUID) -> Project? {
        self.projects.first { $0.id == id }
    }

    func renameProject(projectID: UUID, name: String) throws {
        let trimmedName = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmedName.isEmpty else {
            throw ProjectStoreError.invalidProjectName
        }

        let storedProject = try self.storedProject(projectID: projectID)
        storedProject.name = trimmedName

        try self.modelContext.save()
        try self.reload()
    }

    func deleteProject(projectID: UUID) throws {
        let storedProject = try self.storedProject(projectID: projectID)
        let scanProjectIDs = Set(storedProject.zones.compactMap(\.scanProjectID))

        for scanProjectID in scanProjectIDs {
            do {
                try self.scanProjectStore.deleteProject(id: scanProjectID)
            } catch {
                throw ProjectStoreError.scanArtifactDeletionFailed
            }
        }

        self.modelContext.delete(storedProject)
        try self.modelContext.save()
        try self.reload()
    }

    /// Replaces an existing zone point cloud with a new one the user will record
    func updateZoneScan(
        projectID: UUID,
        zoneID: UUID,
        scanProjectID: UUID?,
        scanState: ZoneStatus
    ) throws {
        let storedZone = try self.storedZone(projectID: projectID, zoneID: zoneID)

        let now = Date()
        storedZone.scanProjectID = scanProjectID
        storedZone.scanStateRawValue = scanState.rawValue

        if scanState == .notStarted {
            storedZone.scanStartedAt = nil
            storedZone.scanCompletedAt = nil
        } else {
            storedZone.scanStartedAt = storedZone.scanStartedAt ?? now
            storedZone.scanCompletedAt = scanState == .complete ? now : nil
        }

        try self.modelContext.save()
        try self.reload()
    }

    /// Replaces an existing zone point cloud with a new one the user will record
    func replaceZoneScan(projectID: UUID, zoneID: UUID) throws {
        let storedZone = try self.storedZone(projectID: projectID, zoneID: zoneID)
        let existingScanProjectID = storedZone.scanProjectID

        if let existingScanProjectID {
            do {
                try self.scanProjectStore.deleteProject(id: existingScanProjectID)
            } catch { throw PointCloudScanReplaceError.failedScanDeletion }
        }

        storedZone.scanProjectID = nil
        storedZone.scanStateRawValue = ZoneStatus.notStarted.rawValue
        storedZone.scanStartedAt = nil
        storedZone.scanCompletedAt = nil

        do {
            try self.modelContext.save()
        } catch { throw PointCloudScanReplaceError.failedScanStore }

        try self.reload()
    }

    @discardableResult
    func reconcileRemoteZones(
        remoteID: String,
        remoteOrganizationID: String,
        apiZones: [ZonesAPIZone],
        toProject projectID: UUID
    ) throws -> Project {
        let storedProject = try self.storedProject(projectID: projectID)
        let boundary = Self.makeProject(from: storedProject).boundary

        storedProject.remoteID = remoteID
        storedProject.remoteOrganizationID = remoteOrganizationID
        storedProject.pendingRemoteOrganizationID = nil
        try Self.reconcileStoredZones(in: storedProject, with: apiZones, boundary: boundary)

        try self.modelContext.save()
        try self.reload()

        guard let project = self.project(withID: projectID) else {
            throw ProjectStoreError.projectNotFound
        }
        return project
    }

    func reload() throws {
        let descriptor = FetchDescriptor<StoredProject>(
            sortBy: [SortDescriptor(\StoredProject.createdAt, order: .reverse)]
        )
        let storedProjects = try modelContext.fetch(descriptor)
        if Self.normalizeStoredZoneIndexes(in: storedProjects) {
            try self.modelContext.save()
        }
        self.projects = storedProjects.map(Self.makeProject(from:))
    }

    // MARK: Private

    private let modelContainer: ModelContainer
    private let modelContext: ModelContext
    private let scanProjectStore: ScanProjectStore

    private static func makeProject(from storedProject: StoredProject) -> Project {
        let zones = storedProject.zones.map { storedZone -> Zone in
            let points = Self.decodeLocalPoints(storedZone.footprintPointsJSON)
                ?? Self.legacyRectanglePoints(
                    originXMeters: storedZone.originXMeters,
                    originYMeters: storedZone.originYMeters,
                    widthMeters: storedZone.widthMeters,
                    heightMeters: storedZone.heightMeters
                )

            return Zone(
                id: storedZone.id,
                remoteID: storedZone.remoteID,
                name: storedZone.name,
                rowIndex: storedZone.rowIndex,
                columnIndex: storedZone.columnIndex,
                footprint: ZoneFootprint(points: points),
                scanProjectID: storedZone.scanProjectID,
                scanState: ZoneStatus(rawValue: storedZone.scanStateRawValue) ?? .notStarted,
                scanStartedAt: storedZone.scanStartedAt,
                scanCompletedAt: storedZone.scanCompletedAt
            )
        }

        let vertices = Self.decodeGeoCoordinates(storedProject.boundaryVerticesJSON)
            ?? Self.legacyRectangleVertices(
                center: GeoCoordinate(
                    latitude: storedProject.centerLatitude,
                    longitude: storedProject.centerLongitude
                ),
                widthMeters: storedProject.widthMeters,
                heightMeters: storedProject.heightMeters
            )

        return Project(
            id: storedProject.id,
            name: storedProject.name,
            createdAt: storedProject.createdAt,
            boundary: ProjectBoundary(vertices: vertices),
            zones: zones,
            remoteID: storedProject.remoteID,
            remoteOrganizationID: storedProject.remoteOrganizationID,
            pendingRemoteOrganizationID: storedProject.pendingRemoteOrganizationID
        )
    }

    private static func encodeGeoCoordinates(_ values: [GeoCoordinate]) -> String {
        guard let data = try? JSONEncoder().encode(values),
              let string = String(data: data, encoding: .utf8)
        else {
            return ""
        }
        return string
    }

    private static func decodeGeoCoordinates(_ json: String) -> [GeoCoordinate]? {
        guard !json.isEmpty, let data = json.data(using: .utf8) else { return nil }
        let decoded = try? JSONDecoder().decode([GeoCoordinate].self, from: data)
        guard let decoded, decoded.count >= 3 else { return nil }
        return decoded
    }

    private static func encodeLocalPoints(_ values: [LocalPoint]) -> String {
        guard let data = try? JSONEncoder().encode(values),
              let string = String(data: data, encoding: .utf8)
        else {
            return ""
        }
        return string
    }

    private static func decodeLocalPoints(_ json: String) -> [LocalPoint]? {
        guard !json.isEmpty, let data = json.data(using: .utf8) else { return nil }
        let decoded = try? JSONDecoder().decode([LocalPoint].self, from: data)
        guard let decoded, decoded.count >= 3 else { return nil }
        return decoded
    }

    private static func legacyRectangleVertices(
        center: GeoCoordinate,
        widthMeters: Double,
        heightMeters: Double
    ) -> [GeoCoordinate] {
        let halfWidth = widthMeters / 2.0
        let halfHeight = heightMeters / 2.0
        return [
            BoundaryGeometry.coordinate(from: center, movingEast: -halfWidth, movingNorth: halfHeight),
            BoundaryGeometry.coordinate(from: center, movingEast: halfWidth, movingNorth: halfHeight),
            BoundaryGeometry.coordinate(from: center, movingEast: halfWidth, movingNorth: -halfHeight),
            BoundaryGeometry.coordinate(from: center, movingEast: -halfWidth, movingNorth: -halfHeight),
        ]
    }

    private static func legacyRectanglePoints(
        originXMeters: Double,
        originYMeters: Double,
        widthMeters: Double,
        heightMeters: Double
    ) -> [LocalPoint] {
        [
            LocalPoint(xMeters: originXMeters, yMeters: originYMeters),
            LocalPoint(xMeters: originXMeters + widthMeters, yMeters: originYMeters),
            LocalPoint(xMeters: originXMeters + widthMeters, yMeters: originYMeters + heightMeters),
            LocalPoint(xMeters: originXMeters, yMeters: originYMeters + heightMeters),
        ]
    }

    private static func makeStoredZones(
        from apiZones: [ZonesAPIZone],
        boundary: ProjectBoundary
    ) throws -> [StoredZone] {
        try self.makeZones(from: apiZones, boundary: boundary).map(self.makeStoredZone(from:))
    }

    @discardableResult
    private static func reconcileStoredZones(
        in storedProject: StoredProject,
        with apiZones: [ZonesAPIZone],
        boundary: ProjectBoundary
    ) throws -> Bool {
        let remoteZones = try self.makeZones(from: apiZones, boundary: boundary)
        guard !remoteZones.isEmpty else {
            let preservedZones = storedProject.zones.filter(self.hasLocalScanState)
            if storedProject.zones.map(\.id) == preservedZones.map(\.id) {
                return false
            }
            storedProject.zones = preservedZones
            return true
        }

        var remainingStoredZones = storedProject.zones
        var reconciledZones: [StoredZone] = []
        var didUpdate = false

        for remoteZone in remoteZones {
            if let matchIndex = remainingStoredZones.firstIndex(where: { storedZone in
                self.storedZone(storedZone, matches: remoteZone)
            }) {
                let storedZone = remainingStoredZones.remove(at: matchIndex)
                if self.applyRemoteZone(remoteZone, to: storedZone) {
                    didUpdate = true
                }
                reconciledZones.append(storedZone)
            } else {
                let storedZone = self.makeStoredZone(from: remoteZone)
                storedZone.project = storedProject
                reconciledZones.append(storedZone)
                didUpdate = true
            }
        }

        reconciledZones.append(contentsOf: remainingStoredZones.filter(self.hasLocalScanState))

        if storedProject.zones.map(\.id) != reconciledZones.map(\.id) {
            storedProject.zones = reconciledZones
            didUpdate = true
        }

        for storedZone in reconciledZones where storedZone.project !== storedProject {
            storedZone.project = storedProject
            didUpdate = true
        }

        return didUpdate
    }

    private static func storedZone(_ storedZone: StoredZone, matches remoteZone: Zone) -> Bool {
        if let remoteID = remoteZone.remoteID {
            if storedZone.remoteID == remoteID {
                return true
            }
            if storedZone.id.uuidString.caseInsensitiveCompare(remoteID) == .orderedSame {
                return true
            }
        }

        return storedZone.rowIndex == remoteZone.rowIndex
            && storedZone.columnIndex == remoteZone.columnIndex
    }

    private static func hasLocalScanState(_ storedZone: StoredZone) -> Bool {
        storedZone.scanProjectID != nil
            || (ZoneStatus(rawValue: storedZone.scanStateRawValue) ?? .notStarted) != .notStarted
    }

    @discardableResult
    private static func applyRemoteZone(_ remoteZone: Zone, to storedZone: StoredZone) -> Bool {
        let preservesLocalScan = self.hasLocalScanState(storedZone)
        var didUpdate = false

        didUpdate = self.setIfNeeded(&storedZone.remoteID, remoteZone.remoteID) || didUpdate
        didUpdate = self.setIfNeeded(&storedZone.name, remoteZone.name) || didUpdate
        didUpdate = self.setIfNeeded(&storedZone.rowIndex, remoteZone.rowIndex) || didUpdate
        didUpdate = self.setIfNeeded(&storedZone.columnIndex, remoteZone.columnIndex) || didUpdate
        didUpdate = self.setIfNeeded(&storedZone.originXMeters, remoteZone.footprint.originXMeters) || didUpdate
        didUpdate = self.setIfNeeded(&storedZone.originYMeters, remoteZone.footprint.originYMeters) || didUpdate
        didUpdate = self.setIfNeeded(&storedZone.widthMeters, remoteZone.footprint.widthMeters) || didUpdate
        didUpdate = self.setIfNeeded(&storedZone.heightMeters, remoteZone.footprint.heightMeters) || didUpdate
        didUpdate = self.setIfNeeded(
            &storedZone.footprintPointsJSON,
            self.encodeLocalPoints(remoteZone.footprint.points)
        ) || didUpdate

        if !preservesLocalScan {
            didUpdate = self.setIfNeeded(&storedZone.scanProjectID, remoteZone.scanProjectID) || didUpdate
            didUpdate = self.setIfNeeded(&storedZone.scanStateRawValue, remoteZone.scanState.rawValue) || didUpdate
            didUpdate = self.setIfNeeded(&storedZone.scanStartedAt, remoteZone.scanStartedAt) || didUpdate
            didUpdate = self.setIfNeeded(&storedZone.scanCompletedAt, remoteZone.scanCompletedAt) || didUpdate
        }

        return didUpdate
    }

    private static func makeStoredZone(from zone: Zone) -> StoredZone {
        StoredZone(
            id: zone.id,
            remoteID: zone.remoteID,
            name: zone.name,
            rowIndex: zone.rowIndex,
            columnIndex: zone.columnIndex,
            originXMeters: zone.footprint.originXMeters,
            originYMeters: zone.footprint.originYMeters,
            widthMeters: zone.footprint.widthMeters,
            heightMeters: zone.footprint.heightMeters,
            footprintPointsJSON: self.encodeLocalPoints(zone.footprint.points),
            scanProjectID: zone.scanProjectID,
            scanStateRawValue: zone.scanState.rawValue,
            scanStartedAt: zone.scanStartedAt,
            scanCompletedAt: zone.scanCompletedAt
        )
    }

    @discardableResult
    private static func setIfNeeded<Value: Equatable>(_ currentValue: inout Value, _ newValue: Value) -> Bool {
        guard currentValue != newValue else { return false }
        currentValue = newValue
        return true
    }

    @discardableResult
    private static func normalizeStoredZoneIndexes(in storedProjects: [StoredProject]) -> Bool {
        var didNormalize = false

        for storedProject in storedProjects where !storedProject.zones.isEmpty {
            let minimumRowIndex = storedProject.zones.map(\.rowIndex).min() ?? 0
            let minimumColumnIndex = storedProject.zones.map(\.columnIndex).min() ?? 0
            let rowOffset = min(0, minimumRowIndex)
            let columnOffset = min(0, minimumColumnIndex)

            for storedZone in storedProject.zones {
                let normalizedRowIndex = storedZone.rowIndex - rowOffset
                let normalizedColumnIndex = storedZone.columnIndex - columnOffset
                let normalizedName = self.zoneName(rowIndex: normalizedRowIndex, columnIndex: normalizedColumnIndex)

                if storedZone.rowIndex != normalizedRowIndex {
                    storedZone.rowIndex = normalizedRowIndex
                    didNormalize = true
                }
                if storedZone.columnIndex != normalizedColumnIndex {
                    storedZone.columnIndex = normalizedColumnIndex
                    didNormalize = true
                }
                if storedZone.name != normalizedName {
                    storedZone.name = normalizedName
                    didNormalize = true
                }
            }
        }

        return didNormalize
    }

    private static func makeZones(from apiZones: [ZonesAPIZone], boundary: ProjectBoundary) throws -> [Zone] {
        let minimumX = apiZones.map(\.x).min() ?? 0
        let minimumY = apiZones.map(\.y).min() ?? 0
        let columnOffset = min(0, minimumX)
        let rowOffset = min(0, minimumY)
        let boundaryLocalPoints = boundary.vertices.map {
            BoundaryGeometry.localPoint(of: $0, in: boundary)
        }

        var zones: [Zone] = []
        zones.reserveCapacity(apiZones.count)

        for apiZone in apiZones {
            guard let id = UUID(uuidString: apiZone.id) else {
                continue
            }

            let rowIndex = apiZone.y - rowOffset
            let columnIndex = apiZone.x - columnOffset
            let scanProjectID = ZonesService.scanArchiveID(from: apiZone.scanObjectKey)
            let rawFootprintPoints = apiZone.corners.map {
                BoundaryGeometry.localPoint(
                    of: GeoCoordinate(latitude: $0.latitude, longitude: $0.longitude),
                    in: boundary
                )
            }
            let clippedFootprintPoints = BoundaryGeometry.clip(
                polygon: rawFootprintPoints,
                to: boundaryLocalPoints
            )
            let footprintPoints = clippedFootprintPoints.count >= 3
                ? clippedFootprintPoints
                : (scanProjectID == nil ? [] : rawFootprintPoints)
            guard footprintPoints.count >= 3 else { continue }

            zones.append(Zone(
                id: id,
                remoteID: apiZone.id,
                name: Self.zoneName(rowIndex: rowIndex, columnIndex: columnIndex),
                rowIndex: rowIndex,
                columnIndex: columnIndex,
                footprint: ZoneFootprint(points: footprintPoints),
                scanProjectID: scanProjectID,
                scanState: scanProjectID == nil ? .notStarted : .complete,
                scanStartedAt: nil,
                scanCompletedAt: nil
            ))
        }

        return zones
    }

    private static func zoneName(rowIndex: Int, columnIndex: Int) -> String {
        "\(self.rowLabel(for: rowIndex))\(columnIndex + 1)"
    }

    private static func rowLabel(for rowIndex: Int) -> String {
        var remainder = rowIndex
        var label = ""

        repeat {
            let scalar = UnicodeScalar(65 + (remainder % 26)) ?? "A"
            label.insert(Character(scalar), at: label.startIndex)
            remainder = (remainder / 26) - 1
        } while remainder >= 0

        return label
    }

    /// Validates, persists, and reloads.
    private func insertProject(
        named name: String,
        boundary: ProjectBoundary,
        remoteID: String?,
        remoteOrganizationID: String? = nil,
        pendingRemoteOrganizationID: String? = nil,
        zones: [Zone],
        reloadsStore: Bool = true
    ) throws -> Project {
        let trimmedName = name.trimmingCharacters(in: .whitespacesAndNewlines)
        let projectID = UUID()
        try self.validateProject(named: trimmedName, boundary: boundary)
        let storedZones = zones.map { zone in
            StoredZone(
                id: zone.id,
                remoteID: zone.remoteID,
                name: zone.name,
                rowIndex: zone.rowIndex,
                columnIndex: zone.columnIndex,
                originXMeters: zone.footprint.originXMeters,
                originYMeters: zone.footprint.originYMeters,
                widthMeters: zone.footprint.widthMeters,
                heightMeters: zone.footprint.heightMeters,
                footprintPointsJSON: Self.encodeLocalPoints(zone.footprint.points),
                scanProjectID: zone.scanProjectID,
                scanStateRawValue: zone.scanState.rawValue,
                scanStartedAt: zone.scanStartedAt,
                scanCompletedAt: zone.scanCompletedAt
            )
        }

        let storedProject = StoredProject(
            id: projectID,
            name: trimmedName,
            createdAt: Date(),
            centerLatitude: boundary.center.latitude,
            centerLongitude: boundary.center.longitude,
            widthMeters: boundary.widthMeters,
            heightMeters: boundary.heightMeters,
            boundaryVerticesJSON: Self.encodeGeoCoordinates(boundary.vertices),
            remoteID: remoteID,
            remoteOrganizationID: remoteOrganizationID,
            pendingRemoteOrganizationID: pendingRemoteOrganizationID,
            zones: storedZones
        )

        for zone in storedZones {
            zone.project = storedProject
        }

        self.modelContext.insert(storedProject)
        try self.modelContext.save()

        guard reloadsStore else {
            return Self.makeProject(from: storedProject)
        }

        try self.reload()

        guard let createdProject = project(withID: projectID) else {
            throw ProjectStoreError.projectNotFound
        }

        return createdProject
    }

    /// fetches a stored zone based on a project and zone UUID
    private func storedZone(projectID: UUID, zoneID: UUID) throws -> StoredZone {
        let storedProject = try self.storedProject(projectID: projectID)

        guard let storedZone = storedProject.zones.first(where: { $0.id == zoneID }) else {
            throw ProjectStoreError.zoneNotFound
        }

        return storedZone
    }

    private func storedProject(projectID: UUID) throws -> StoredProject {
        let descriptor = FetchDescriptor<StoredProject>(
            predicate: #Predicate { $0.id == projectID }
        )

        guard let storedProject = try self.modelContext.fetch(descriptor).first else {
            throw ProjectStoreError.projectNotFound
        }

        return storedProject
    }

    private func validateProject(
        named name: String,
        boundary: ProjectBoundary
    ) throws {
        let trimmedName = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard ProjectCreationValidator.canCreateProject(named: trimmedName, boundary: boundary) else {
            throw ProjectStoreError.invalidProjectConfiguration
        }
    }
}

// MARK: - ProjectStoreError

enum ProjectStoreError: LocalizedError {
    case invalidProjectConfiguration
    case invalidProjectName
    case projectNotFound
    case zoneNotFound
    case scanArtifactDeletionFailed
    case invalidRemoteZone

    // MARK: Internal

    var errorDescription: String? {
        switch self {
        case .invalidProjectConfiguration:
            "Projects need a name and a confirmed boundary before they can be created."
        case .invalidProjectName:
            "Projects need a name."
        case .projectNotFound:
            "The selected project could not be found."
        case .zoneNotFound:
            "The selected zone could not be found."
        case .scanArtifactDeletionFailed:
            "The project could not be deleted because one of its scan artifacts could not be removed."
        case .invalidRemoteZone:
            "The remote project contains a zone the app could not load."
        }
    }
}

// MARK: - PointCloudScanReplaceError

enum PointCloudScanReplaceError: LocalizedError {
    case failedScanDeletion
    case failedScanStore

    // MARK: Internal

    var errorDescription: String? {
        switch self {
        case .failedScanDeletion:
            "Failed to delete the existing point cloud scan, unable to replace with new point cloud scan"
        case .failedScanStore:
            "Failed to store new point cloud scan"
        }
    }
}
