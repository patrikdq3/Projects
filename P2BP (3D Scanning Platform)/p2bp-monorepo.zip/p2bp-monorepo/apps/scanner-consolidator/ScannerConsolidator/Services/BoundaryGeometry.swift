import Darwin

nonisolated enum BoundaryGeometry {
    // MARK: Internal

    struct BoundingBox {
        var center: GeoCoordinate
        var widthMeters: Double
        var heightMeters: Double
    }

    static func metersPerDegreeLongitude(at latitude: Double) -> Double {
        max(1.0, 111_320.0 * Darwin.cos(latitude * .pi / 180.0))
    }

    static func coordinate(
        from origin: GeoCoordinate,
        movingEast eastMeters: Double,
        movingNorth northMeters: Double
    ) -> GeoCoordinate {
        let latitudeDelta = northMeters / self.metersPerDegreeLatitude
        let longitudeDelta = eastMeters / self.metersPerDegreeLongitude(at: origin.latitude)

        return GeoCoordinate(
            latitude: origin.latitude + latitudeDelta,
            longitude: origin.longitude + longitudeDelta
        )
    }

    static func eastNorthMeters(
        of coordinate: GeoCoordinate,
        from origin: GeoCoordinate
    ) -> (east: Double, north: Double) {
        let northMeters = (coordinate.latitude - origin.latitude) * self.metersPerDegreeLatitude
        let eastMeters = (coordinate.longitude - origin.longitude)
            * self.metersPerDegreeLongitude(at: origin.latitude)
        return (eastMeters, northMeters)
    }

    /// Bounding-box center + width/height (in meters) of the supplied polygon vertices.
    static func boundingBox(of vertices: [GeoCoordinate]) -> BoundingBox {
        guard let first = vertices.first else {
            return BoundingBox(
                center: GeoCoordinate(latitude: 0, longitude: 0),
                widthMeters: 0,
                heightMeters: 0
            )
        }

        var minEast = Double.infinity
        var maxEast = -Double.infinity
        var minNorth = Double.infinity
        var maxNorth = -Double.infinity

        for vertex in vertices {
            let (east, north) = self.eastNorthMeters(of: vertex, from: first)
            minEast = Swift.min(minEast, east)
            maxEast = Swift.max(maxEast, east)
            minNorth = Swift.min(minNorth, north)
            maxNorth = Swift.max(maxNorth, north)
        }

        let widthMeters = maxEast - minEast
        let heightMeters = maxNorth - minNorth

        let center = self.coordinate(
            from: first,
            movingEast: (minEast + maxEast) / 2,
            movingNorth: (minNorth + maxNorth) / 2
        )

        return BoundingBox(center: center, widthMeters: widthMeters, heightMeters: heightMeters)
    }

    /// Shoelace area for a polygon described in geographic coordinates.
    static func polygonArea(of vertices: [GeoCoordinate]) -> Double {
        guard vertices.count >= 3, let origin = vertices.first else { return 0 }

        let local = vertices.map { vertex -> (Double, Double) in
            let (east, north) = self.eastNorthMeters(of: vertex, from: origin)
            return (east, north)
        }

        var sum = 0.0
        for i in 0 ..< local.count {
            let (xi, yi) = local[i]
            let (xj, yj) = local[(i + 1) % local.count]
            sum += (xi * yj) - (xj * yi)
        }
        return abs(sum) / 2.0
    }

    /// Shoelace area for a polygon expressed in local meters.
    static func polygonArea(of points: [LocalPoint]) -> Double {
        guard points.count >= 3 else { return 0 }
        var sum = 0.0
        for i in 0 ..< points.count {
            let a = points[i]
            let b = points[(i + 1) % points.count]
            sum += (a.xMeters * b.yMeters) - (b.xMeters * a.yMeters)
        }
        return abs(sum) / 2.0
    }

    /// Convert a geographic coordinate into a `LocalPoint` anchored at the boundary's
    /// north-west bounding-box corner. Inverse of `coordinate(from:atLocal:)`.
    static func localPoint(of coordinate: GeoCoordinate, in boundary: ProjectBoundary) -> LocalPoint {
        let halfWidth = boundary.widthMeters / 2.0
        let halfHeight = boundary.heightMeters / 2.0
        let (east, north) = self.eastNorthMeters(of: coordinate, from: boundary.center)
        return LocalPoint(xMeters: east + halfWidth, yMeters: halfHeight - north)
    }

    /// Inverse of `localPoint(of:in:)`.
    static func coordinate(from boundary: ProjectBoundary, atLocal point: LocalPoint) -> GeoCoordinate {
        let halfWidth = boundary.widthMeters / 2.0
        let halfHeight = boundary.heightMeters / 2.0
        return self.coordinate(
            from: boundary.center,
            movingEast: point.xMeters - halfWidth,
            movingNorth: halfHeight - point.yMeters
        )
    }

    /// Clips a subject polygon against a project boundary, both in local meters. Convex
    /// boundaries use a direct Sutherland-Hodgman pass. Concave boundaries are triangulated,
    /// clipped triangle-by-triangle, then stitched back into the largest resulting ring.
    /// Returns the clipped ring, or `[]` when the subject lies entirely outside the boundary.
    static func clip(polygon subject: [LocalPoint], to clipPolygon: [LocalPoint]) -> [LocalPoint] {
        let subject = self.sanitizedRing(subject)
        let clip = self.normalizedRing(clipPolygon)
        guard subject.count >= 3, clip.count >= 3 else { return [] }

        if self.isConvex(clip) {
            return self.clipConvex(polygon: subject, to: clip)
        }

        let pieces = self.triangulate(clip).compactMap { triangle -> [LocalPoint]? in
            let clipped = self.clipConvex(polygon: subject, to: triangle)
            return self.polygonArea(of: clipped) > self.areaEpsilon ? clipped : nil
        }

        return self.stitchedLargestRing(from: pieces)
    }

    // MARK: Private

    private struct PointKey: Hashable, Comparable {
        let x: Int64
        let y: Int64

        static func < (lhs: PointKey, rhs: PointKey) -> Bool {
            if lhs.x != rhs.x {
                return lhs.x < rhs.x
            }
            return lhs.y < rhs.y
        }
    }

    private struct EdgeKey: Hashable {
        // MARK: Lifecycle

        init(_ lhs: PointKey, _ rhs: PointKey) {
            if lhs < rhs {
                self.a = lhs
                self.b = rhs
            } else {
                self.a = rhs
                self.b = lhs
            }
        }

        // MARK: Internal

        let a: PointKey
        let b: PointKey
    }

    private struct DirectedEdge {
        let start: LocalPoint
        let end: LocalPoint
        let startKey: PointKey
        let endKey: PointKey
    }

    private static let metersPerDegreeLatitude = 111_132.0
    private static let pointEpsilon = 0.000001
    private static let areaEpsilon = 0.000001

    private static func signedArea(of points: [LocalPoint]) -> Double {
        var sum = 0.0
        for i in 0 ..< points.count {
            let a = points[i]
            let b = points[(i + 1) % points.count]
            sum += (a.xMeters * b.yMeters) - (b.xMeters * a.yMeters)
        }
        return sum / 2.0
    }

    private static func normalizedRing(_ points: [LocalPoint]) -> [LocalPoint] {
        let sanitized = self.sanitizedRing(points)
        return self.signedArea(of: sanitized) < 0 ? Array(sanitized.reversed()) : sanitized
    }

    private static func sanitizedRing(_ points: [LocalPoint]) -> [LocalPoint] {
        var result: [LocalPoint] = []
        result.reserveCapacity(points.count)

        for point in points where !self.samePoint(point, result.last) {
            result.append(point)
        }

        if result.count > 1, self.samePoint(result.first, result.last) {
            result.removeLast()
        }

        return result
    }

    private static func samePoint(_ lhs: LocalPoint?, _ rhs: LocalPoint?) -> Bool {
        guard let lhs, let rhs else { return false }
        return abs(lhs.xMeters - rhs.xMeters) <= self.pointEpsilon
            && abs(lhs.yMeters - rhs.yMeters) <= self.pointEpsilon
    }

    private static func isConvex(_ points: [LocalPoint]) -> Bool {
        guard points.count >= 3 else { return false }

        for i in 0 ..< points.count {
            let previous = points[(i + points.count - 1) % points.count]
            let current = points[i]
            let next = points[(i + 1) % points.count]
            if self.cross(previous, current, next) < -self.areaEpsilon {
                return false
            }
        }

        return true
    }

    private static func clipConvex(polygon subject: [LocalPoint], to clipPolygon: [LocalPoint]) -> [LocalPoint] {
        guard subject.count >= 3, clipPolygon.count >= 3 else { return [] }

        var output = subject
        var edgeStart = clipPolygon[clipPolygon.count - 1]
        for edgeEnd in clipPolygon {
            if output.isEmpty {
                break
            }
            let input = output
            output = []
            var previous = input[input.count - 1]
            for current in input {
                let currentInside = self.isLeftOfEdge(current, from: edgeStart, to: edgeEnd)
                let previousInside = self.isLeftOfEdge(previous, from: edgeStart, to: edgeEnd)
                if currentInside {
                    if !previousInside {
                        output.append(self.intersectSegments(previous, current, edgeStart, edgeEnd))
                    }
                    output.append(current)
                } else if previousInside {
                    output.append(self.intersectSegments(previous, current, edgeStart, edgeEnd))
                }
                previous = current
            }
            edgeStart = edgeEnd
        }

        return self.sanitizedRing(output)
    }

    private static func triangulate(_ polygon: [LocalPoint]) -> [[LocalPoint]] {
        let points = self.normalizedRing(polygon)
        guard points.count >= 3 else { return [] }
        if points.count == 3 {
            return [points]
        }

        var remaining = Array(points.indices)
        var triangles: [[LocalPoint]] = []
        var guardCount = 0
        let guardLimit = points.count * points.count

        while remaining.count > 3, guardCount < guardLimit {
            guardCount += 1
            var didClipEar = false

            for offset in remaining.indices {
                let previousIndex = remaining[(offset + remaining.count - 1) % remaining.count]
                let currentIndex = remaining[offset]
                let nextIndex = remaining[(offset + 1) % remaining.count]

                let previous = points[previousIndex]
                let current = points[currentIndex]
                let next = points[nextIndex]
                guard self.cross(previous, current, next) > self.areaEpsilon else { continue }

                let triangle = [previous, current, next]
                let containsOtherVertex = remaining.contains { candidateIndex in
                    guard candidateIndex != previousIndex,
                          candidateIndex != currentIndex,
                          candidateIndex != nextIndex
                    else {
                        return false
                    }
                    return self.point(points[candidateIndex], isInsideOrOn: triangle)
                }
                guard !containsOtherVertex else { continue }

                triangles.append(triangle)
                remaining.remove(at: offset)
                didClipEar = true
                break
            }

            if !didClipEar {
                break
            }
        }

        if remaining.count == 3 {
            triangles.append(remaining.map { points[$0] })
        }

        return triangles
    }

    private static func stitchedLargestRing(from pieces: [[LocalPoint]]) -> [LocalPoint] {
        guard !pieces.isEmpty else { return [] }

        let rings = self.stitchedRings(from: self.boundaryEdges(from: pieces))
        return rings.max { self.polygonArea(of: $0) < self.polygonArea(of: $1) } ?? []
    }

    private static func boundaryEdges(from pieces: [[LocalPoint]]) -> [DirectedEdge] {
        var boundaryEdgesByKey: [EdgeKey: DirectedEdge] = [:]
        for piece in pieces {
            let points = self.sanitizedRing(piece)
            guard points.count >= 3 else { continue }

            for i in 0 ..< points.count {
                let start = points[i]
                let end = points[(i + 1) % points.count]
                guard !self.samePoint(start, end) else { continue }

                let startKey = self.pointKey(start)
                let endKey = self.pointKey(end)
                let edgeKey = EdgeKey(startKey, endKey)
                if boundaryEdgesByKey[edgeKey] == nil {
                    boundaryEdgesByKey[edgeKey] = DirectedEdge(
                        start: start,
                        end: end,
                        startKey: startKey,
                        endKey: endKey
                    )
                } else {
                    boundaryEdgesByKey.removeValue(forKey: edgeKey)
                }
            }
        }

        return Array(boundaryEdgesByKey.values)
    }

    private static func stitchedRings(from edges: [DirectedEdge]) -> [[LocalPoint]] {
        var remainingEdges = edges
        var rings: [[LocalPoint]] = []

        while let first = remainingEdges.first {
            remainingEdges.removeFirst()
            if let sanitized = self.stitchedRing(startingWith: first, remainingEdges: &remainingEdges) {
                rings.append(sanitized)
            }
        }

        return rings
    }

    private static func stitchedRing(
        startingWith first: DirectedEdge,
        remainingEdges: inout [DirectedEdge]
    ) -> [LocalPoint]? {
        var ring = [first.start, first.end]
        var currentKey = first.endKey
        let startKey = first.startKey

        while currentKey != startKey {
            guard let nextIndex = remainingEdges.firstIndex(where: { $0.startKey == currentKey }) else {
                return nil
            }
            let next = remainingEdges.remove(at: nextIndex)
            ring.append(next.end)
            currentKey = next.endKey
        }

        if ring.count > 1, self.samePoint(ring.first, ring.last) {
            ring.removeLast()
        }

        let sanitized = self.sanitizedRing(ring)
        guard sanitized.count >= 3, self.polygonArea(of: sanitized) > self.areaEpsilon else { return nil }
        return sanitized
    }

    private static func pointKey(_ point: LocalPoint) -> PointKey {
        PointKey(
            x: Int64((point.xMeters / self.pointEpsilon).rounded()),
            y: Int64((point.yMeters / self.pointEpsilon).rounded())
        )
    }

    private static func cross(_ a: LocalPoint, _ b: LocalPoint, _ c: LocalPoint) -> Double {
        (b.xMeters - a.xMeters) * (c.yMeters - a.yMeters)
            - (b.yMeters - a.yMeters) * (c.xMeters - a.xMeters)
    }

    private static func point(_ point: LocalPoint, isInsideOrOn triangle: [LocalPoint]) -> Bool {
        guard triangle.count == 3 else { return false }
        return self.cross(triangle[0], triangle[1], point) >= -self.areaEpsilon
            && self.cross(triangle[1], triangle[2], point) >= -self.areaEpsilon
            && self.cross(triangle[2], triangle[0], point) >= -self.areaEpsilon
    }

    /// True when `point` lies on the interior (left) side of the directed edge `from`→`to`.
    private static func isLeftOfEdge(_ point: LocalPoint, from a: LocalPoint, to b: LocalPoint) -> Bool {
        let cross = (b.xMeters - a.xMeters) * (point.yMeters - a.yMeters)
            - (b.yMeters - a.yMeters) * (point.xMeters - a.xMeters)
        return cross >= -self.areaEpsilon
    }

    /// Intersection of segment `p1`→`p2` with the infinite line through `a`→`b`.
    private static func intersectSegments(
        _ p1: LocalPoint,
        _ p2: LocalPoint,
        _ a: LocalPoint,
        _ b: LocalPoint
    ) -> LocalPoint {
        let rX = p2.xMeters - p1.xMeters
        let rY = p2.yMeters - p1.yMeters
        let sX = b.xMeters - a.xMeters
        let sY = b.yMeters - a.yMeters
        let denominator = (rX * sY) - (rY * sX)
        guard abs(denominator) > .ulpOfOne else { return p2 }
        let t = ((a.xMeters - p1.xMeters) * sY - (a.yMeters - p1.yMeters) * sX) / denominator
        return LocalPoint(xMeters: p1.xMeters + t * rX, yMeters: p1.yMeters + t * rY)
    }
}
