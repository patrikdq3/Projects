import Combine
import Foundation

// swiftlint:disable:next unused_import
import OSLog
import SwiftUI

// MARK: - RemoteProjectsDataCoordinator

/// This class handles local cache loading and IO operations for data loading
@MainActor
final class RemoteProjectsDataCoordinator: ObservableObject {
    // MARK: Lifecycle

    init(
        cacheStore: RemoteProjectsCacheStore = RemoteProjectsCacheStore(),
        projectsService: ProjectsService = ProjectsService(),
        organizationsService: OrganizationsService = OrganizationsService()
    ) {
        self.cacheStore = cacheStore
        self.projectsService = projectsService
        self.organizationsService = organizationsService
    }

    // MARK: Internal

    struct SessionContext {
        let userID: String?
        let generation: Int
    }

    struct ProjectRefreshContext {
        fileprivate let organizationID: String
        fileprivate let generation: Int
        fileprivate let sessionContext: SessionContext
    }

    @Published private(set) var organizations: [Organization] = []
    @Published private(set) var projectsByOrganizationID: [String: [ProjectsAPIProject]] = [:]
    @Published private(set) var isLoadingOrganizations = false
    @Published private(set) var loadingProjectOrganizationIDs: Set<String> = []
    @Published private(set) var loadErrorMessage: String?

    @Published var selectedOrganizationID: Organization.ID? {
        didSet {
            guard oldValue != self.selectedOrganizationID else { return }
            guard !self.suppressesSnapshotPersistence else { return }
            self.persistSnapshot()
        }
    }

    static func errorMessage(for error: Error) -> String {
        switch error {
        case RequestServiceError.missingAuthToken, RequestServiceError.unauthorized:
            return "Sign in again to load remote projects."
        case RequestServiceError.forbidden:
            return "You do not have access to this organization."
        case RequestServiceError.notFound:
            return "The selected organization or project could not be found."
        default:
            self.logger
                .error("Remote projects could not be loaded, an unknown project occurred \(error.localizedDescription)")
            return "Remote projects could not be loaded. Offline projects remain available"
        }
    }

    func currentSessionContext() -> SessionContext {
        SessionContext(userID: self.currentUserID, generation: self.sessionGeneration)
    }

    func isCurrentSession(_ context: SessionContext) -> Bool {
        self.currentUserID == context.userID && self.sessionGeneration == context.generation
    }

    func isCurrentProjectRefresh(_ context: ProjectRefreshContext) -> Bool {
        self.isCurrentSession(context.sessionContext)
            && self.projectRefreshGenerations[context.organizationID] == context.generation
    }

    func warmAllOrganizations(user: User?) async {
        guard let user else { return }
        self.prepareForUserIfNeeded(user.id)
        self.loadCachedSnapshotIfNeeded(userID: user.id)
        let sessionContext = self.currentSessionContext()

        await self.refreshOrganizations(user: user)
        guard self.isCurrentSession(sessionContext) else { return }

        // Populate each org's project count up front with lightweight, boundary-free calls so
        // the organization dropdown is correct immediately. The full project lists (with
        // boundaries) hydrate lazily when an org is actually selected.
        let organizationIDs = self.cachedOrganizations.map(\.id)
        await self.refreshOrganizationSummaries(
            organizationIDs: organizationIDs,
            sessionContext: sessionContext
        )
        guard self.isCurrentSession(sessionContext) else { return }

        if let selectedOrganizationID {
            _ = try? await self.organizationsService.setActiveOrganization(id: selectedOrganizationID)
            guard self.isCurrentSession(sessionContext) else { return }
        }
    }

    func refreshOrganizations(user: User?) async {
        guard let user else { return }
        self.prepareForUserIfNeeded(user.id)
        guard !self.isLoadingOrganizations else { return }

        let sessionContext = self.currentSessionContext()
        self.isLoadingOrganizations = true
        self.loadErrorMessage = nil
        defer {
            if self.isCurrentSession(sessionContext) {
                self.isLoadingOrganizations = false
            }
        }

        do {
            let apiOrganizations = try await self.organizationsService.listOrganizations()
            guard self.isCurrentSession(sessionContext) else { return }

            let existingByID = Dictionary(
                self.cachedOrganizations.map { ($0.id, $0) },
                uniquingKeysWith: { existing, _ in existing }
            )

            self.cachedOrganizations = apiOrganizations.map { organization in
                let existing = existingByID[organization.id]
                return CachedRemoteOrganization(
                    apiOrganization: organization,
                    role: existing?.role ?? "Member",
                    projectCount: self.projectsByOrganizationID[organization.id]?.count ?? existing?.projectCount ?? 0
                )
            }

            let validOrganizationIDs = Set(self.cachedOrganizations.map(\.id))
            self.projectsByOrganizationID = self.projectsByOrganizationID.filter { organizationID, _ in
                validOrganizationIDs.contains(organizationID)
            }
            if self.selectedOrganizationID.map(validOrganizationIDs.contains) != true {
                self.selectedOrganizationID = self.cachedOrganizations.first?.id
            }
            self.organizations = self.makeOrganizations(from: self.cachedOrganizations)
            self.loadErrorMessage = nil
            self.persistSnapshot()
        } catch {
            guard self.isCurrentSession(sessionContext) else { return }
            self.loadErrorMessage = Self.errorMessage(for: error)
        }
    }

    @discardableResult
    func refreshProjects(organizationID: String?) async -> ProjectRefreshContext? {
        guard let organizationID else { return nil }
        guard self.currentUserID != nil else { return nil }
        guard !self.loadingProjectOrganizationIDs.contains(organizationID) else { return nil }

        let sessionContext = self.currentSessionContext()
        let refreshGeneration = (self.projectRefreshGenerations[organizationID] ?? 0) + 1
        self.projectRefreshGenerations[organizationID] = refreshGeneration
        let refreshContext = ProjectRefreshContext(
            organizationID: organizationID,
            generation: refreshGeneration,
            sessionContext: sessionContext
        )
        self.loadingProjectOrganizationIDs.insert(organizationID)
        self.loadErrorMessage = nil
        defer {
            if self.isCurrentSession(sessionContext) {
                self.loadingProjectOrganizationIDs.remove(organizationID)
            }
        }

        do {
            _ = try? await self.organizationsService.setActiveOrganization(id: organizationID)
            guard self.isCurrentProjectRefresh(refreshContext) else { return nil }

            let projects = try await self.projectsService.listProjects(organizationID: organizationID)
            guard self.isCurrentProjectRefresh(refreshContext) else { return nil }

            let (detailedProjects, boundaryError) = await self.projectsWithBoundaries(
                projects,
                organizationID: organizationID,
                sessionContext: sessionContext
            )
            guard self.isCurrentProjectRefresh(refreshContext) else { return nil }

            let activeMember = try? await self.organizationsService.getActiveOrganizationMember()
            guard self.isCurrentProjectRefresh(refreshContext) else { return nil }

            self.projectsByOrganizationID[organizationID] = detailedProjects
            self.updateCachedOrganization(
                id: organizationID,
                role: activeMember?.role.capitalized,
                projectCount: detailedProjects.count
            )
            self.organizations = self.makeOrganizations(from: self.cachedOrganizations)
            self.loadErrorMessage = boundaryError.map(Self.errorMessage(for:))
            self.persistSnapshot()
            return refreshContext
        } catch {
            guard self.isCurrentProjectRefresh(refreshContext) else { return nil }
            self.loadErrorMessage = Self.errorMessage(for: error)
            return nil
        }
    }

    /// Creates a remote project and folds the server's response into the cached list.
    @discardableResult
    func createProject(
        organizationID: String?,
        request: CreateProjectsAPIProjectRequest
    ) async throws -> ProjectsAPIProject {
        guard let organizationID else {
            throw RequestServiceError.invalidInput("Select an organization before creating this project.")
        }

        let sessionContext = self.currentSessionContext()
        let createdProject = try await self.projectsService.createProject(
            organizationID: organizationID,
            request: request
        )
        try self.validateSession(sessionContext)

        self.upsertProject(createdProject, organizationID: organizationID)
        self.loadErrorMessage = nil
        self.persistSnapshot()
        return createdProject
    }

    /// Applies a partial edit to a remote project and folds the server's response back into
    /// the cached list.
    @discardableResult
    func editProject(
        organizationID: String?,
        projectID: String,
        edit: UpdateProjectsAPIProjectRequest
    ) async throws -> ProjectsAPIProject {
        guard let organizationID else {
            throw RequestServiceError.invalidInput("Select an organization before editing this project.")
        }

        let sessionContext = self.currentSessionContext()
        let updatedProject = try await self.projectsService.updateProject(
            organizationID: organizationID,
            projectID: projectID,
            request: edit
        )
        try self.validateSession(sessionContext)

        self.upsertProject(updatedProject, organizationID: organizationID)
        self.loadErrorMessage = nil
        self.persistSnapshot()
        return updatedProject
    }

    func deleteProject(organizationID: String?, projectID: String) async throws {
        guard let organizationID else {
            throw RequestServiceError.invalidInput("Select an organization before deleting this project.")
        }

        let sessionContext = self.currentSessionContext()
        let didDelete = try await self.projectsService.deleteProject(
            organizationID: organizationID,
            projectID: projectID
        )
        try self.validateSession(sessionContext)

        guard didDelete else {
            throw RequestServiceError.requestFailed(statusCode: 200, message: "Project deletion was not confirmed.")
        }

        self.removeProject(projectID: projectID, organizationID: organizationID)
        self.loadErrorMessage = nil
        self.persistSnapshot()
    }

    func projects(for organizationID: String?) -> [ProjectsAPIProject] {
        guard let organizationID else { return [] }
        return self.projectsByOrganizationID[organizationID] ?? []
    }

    func hasLoadedProjects(for organizationID: String?) -> Bool {
        guard let organizationID else { return false }
        return self.projectsByOrganizationID[organizationID] != nil
    }

    func isLoadingProjects(for organizationID: String?) -> Bool {
        guard let organizationID else { return false }
        return self.loadingProjectOrganizationIDs.contains(organizationID)
    }

    func resetInMemoryState(clearDiskCache: Bool = false) {
        if clearDiskCache, let currentUserID = self.currentUserID {
            try? self.cacheStore.deleteSnapshot(userID: currentUserID)
        }
        self.sessionGeneration += 1
        self.currentUserID = nil
        self.didLoadCachedSnapshot = false
        self.cachedOrganizations = []
        self.organizations = []
        self.projectsByOrganizationID = [:]
        self.selectedOrganizationID = nil
        self.isLoadingOrganizations = false
        self.loadingProjectOrganizationIDs = []
        self.projectRefreshGenerations = [:]
        self.loadErrorMessage = nil
    }

    // MARK: Private

    private static let logger = Logger(
        subsystem: Bundle.main.bundleIdentifier ?? "ScannerConsolidator",
        category: "RemoteProjectsDataCoordinator"
    )

    private let cacheStore: RemoteProjectsCacheStore
    private let projectsService: ProjectsService
    private let organizationsService: OrganizationsService

    private var currentUserID: String?
    private var sessionGeneration = 0
    private var projectRefreshGenerations: [String: Int] = [:]
    private var didLoadCachedSnapshot = false
    private var cachedOrganizations: [CachedRemoteOrganization] = []
    private var suppressesSnapshotPersistence = false

    private static func organizationTint(for index: Int) -> Color {
        let tints = [
            Color(red: 46 / 255, green: 125 / 255, blue: 107 / 255),
            Color(red: 59 / 255, green: 111 / 255, blue: 176 / 255),
            Color(red: 176 / 255, green: 122 / 255, blue: 46 / 255),
            Color(red: 31 / 255, green: 138 / 255, blue: 138 / 255),
            Color(red: 138 / 255, green: 75 / 255, blue: 46 / 255),
            Color(red: 91 / 255, green: 91 / 255, blue: 176 / 255),
        ]
        return tints[index % tints.count]
    }

    private func prepareForUserIfNeeded(_ userID: String) {
        guard self.currentUserID != userID else { return }
        self.sessionGeneration += 1
        self.suppressesSnapshotPersistence = true
        self.currentUserID = userID
        self.didLoadCachedSnapshot = false
        self.cachedOrganizations = []
        self.organizations = []
        self.projectsByOrganizationID = [:]
        self.projectRefreshGenerations = [:]
        self.selectedOrganizationID = nil
        self.loadErrorMessage = nil
        self.suppressesSnapshotPersistence = false
    }

    private func validateSession(_ context: SessionContext) throws {
        guard self.isCurrentSession(context) else {
            throw CancellationError()
        }
    }

    private func loadCachedSnapshotIfNeeded(userID: String) {
        guard !self.didLoadCachedSnapshot else { return }
        self.didLoadCachedSnapshot = true

        do {
            guard let snapshot = try self.cacheStore.loadSnapshot(userID: userID) else { return }
            self.cachedOrganizations = snapshot.organizations
            self.projectsByOrganizationID = snapshot.projectsByOrganizationID
            self.organizations = self.makeOrganizations(from: snapshot.organizations)

            let organizationIDs = Set(snapshot.organizations.map(\.id))
            self.suppressesSnapshotPersistence = true
            if let cachedSelection = snapshot.selectedOrganizationID, organizationIDs.contains(cachedSelection) {
                self.selectedOrganizationID = cachedSelection
            } else {
                self.selectedOrganizationID = snapshot.organizations.first?.id
            }
            self.suppressesSnapshotPersistence = false
        } catch {
            self.loadErrorMessage = "Cached projects could not be loaded."
        }
    }

    private func makeOrganizations(from cachedOrganizations: [CachedRemoteOrganization]) -> [Organization] {
        cachedOrganizations.enumerated().map { index, organization in
            Organization(
                id: organization.id,
                name: organization.name,
                tint: Self.organizationTint(for: index),
                role: organization.role,
                projectCount: organization.projectCount
            )
        }
    }

    private func updateCachedOrganization(id organizationID: String, role: String?, projectCount: Int) {
        self.cachedOrganizations = self.cachedOrganizations.map { organization in
            guard organization.id == organizationID else { return organization }
            var updated = organization
            updated.role = role ?? organization.role
            updated.projectCount = projectCount
            return updated
        }
    }

    /// updates existing project, inserts new server project
    private func upsertProject(_ project: ProjectsAPIProject, organizationID: String) {
        var projects = self.projectsByOrganizationID[organizationID] ?? []
        if let index = projects.firstIndex(where: { $0.id == project.id }) {
            projects[index] = project
        } else {
            projects.insert(project, at: 0)
        }

        self.projectsByOrganizationID[organizationID] = projects
        self.updateCachedOrganization(
            id: organizationID,
            role: nil,
            projectCount: projects.count
        )
        self.organizations = self.makeOrganizations(from: self.cachedOrganizations)
    }

    private func removeProject(projectID: String, organizationID: String) {
        guard var projects = self.projectsByOrganizationID[organizationID] else { return }
        projects.removeAll { $0.id == projectID }
        self.projectsByOrganizationID[organizationID] = projects
        self.updateCachedOrganization(
            id: organizationID,
            role: nil,
            projectCount: projects.count
        )
        self.organizations = self.makeOrganizations(from: self.cachedOrganizations)
    }

    private func projectsWithBoundaries(
        _ projects: [ProjectsAPIProject],
        organizationID: String,
        sessionContext: SessionContext
    ) async -> (projects: [ProjectsAPIProject], firstError: Error?) {
        var detailedProjects = projects
        var firstError: Error?

        await withTaskGroup(
            of: (index: Int, result: Result<ProjectsAPIProject, Error>).self
        ) { group in
            for (index, project) in projects.enumerated() where project.boundary == nil {
                group.addTask {
                    do {
                        let fetchedProject = try await self.projectsService.fetchProject(
                            organizationID: organizationID,
                            projectID: project.id
                        )
                        return (index, .success(fetchedProject))
                    } catch {
                        return (index, .failure(error))
                    }
                }
            }

            for await (index, result) in group {
                guard !Task.isCancelled, self.isCurrentSession(sessionContext) else {
                    group.cancelAll()
                    return
                }
                switch result {
                case let .success(project):
                    detailedProjects[index] = project
                case let .failure(error):
                    guard !(error is CancellationError) else { continue }
                    firstError = firstError ?? error
                }
            }
        }

        return (detailedProjects, firstError)
    }

    private func refreshOrganizationSummaries(
        organizationIDs: [String],
        sessionContext: SessionContext
    ) async {
        await withTaskGroup(
            of: (organizationID: String, result: Result<Int, Error>).self
        ) { group in
            for organizationID in organizationIDs {
                group.addTask {
                    do {
                        let projects = try await self.projectsService.listProjects(
                            organizationID: organizationID
                        )
                        return (organizationID, .success(projects.count))
                    } catch {
                        return (organizationID, .failure(error))
                    }
                }
            }

            for await (organizationID, result) in group {
                guard !Task.isCancelled, self.isCurrentSession(sessionContext) else {
                    group.cancelAll()
                    return
                }
                switch result {
                case let .success(projectCount):
                    self.updateCachedOrganization(
                        id: organizationID,
                        role: nil,
                        projectCount: projectCount
                    )
                case let .failure(error):
                    guard !(error is CancellationError) else { continue }
                    let errorDescription = error.localizedDescription
                    Self.logger.error(
                        "Count failed for \(organizationID, privacy: .public): \(errorDescription, privacy: .public)"
                    )
                }
            }
        }

        guard self.isCurrentSession(sessionContext) else { return }
        self.organizations = self.makeOrganizations(from: self.cachedOrganizations)
        self.persistSnapshot()
    }

    private func persistSnapshot() {
        guard let currentUserID else { return }
        let snapshot = RemoteProjectsCacheSnapshot(
            userID: currentUserID,
            selectedOrganizationID: self.selectedOrganizationID,
            organizations: self.cachedOrganizations,
            projectsByOrganizationID: self.projectsByOrganizationID
        )
        do { // a cache failure shouln't be a user informed error, but worth logging
            try self.cacheStore.saveSnapshot(snapshot)
        } catch {
            Self.logger
                .error(
                    "Failed to persist remote projects cache snapshot: \(error.localizedDescription, privacy: .public)"
                )
        }
    }
}
