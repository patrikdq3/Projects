import Combine
import Foundation
import Network

// MARK: - ZoneScanArchiveCacheService

@MainActor
// swiftlint:disable:next type_body_length
final class ZoneScanArchiveCacheService: ObservableObject {
    // MARK: Lifecycle

    init(
        projectStore: ProjectStore,
        scanProjectStore: ScanProjectStore = ScanProjectStore(),
        pendingStore: PendingZoneScanUploadStore = PendingZoneScanUploadStore()
    ) {
        self.projectStore = projectStore
        self.scanProjectStore = scanProjectStore
        self.pendingStore = pendingStore
        self.restoreQueuedUploadStatuses()
        self.networkMonitor.pathUpdateHandler = { [weak self] path in
            guard path.status == .satisfied else { return }
            Task { @MainActor in
                await self?.flushPendingUploads()
            }
        }
        self.networkMonitor.start(queue: self.networkQueue)
        Task {
            await self.flushPendingUploads()
        }
    }

    // MARK: Internal

    /// Rows per page of scan history, including the pinned active archive on the first page.
    static let scanArchivePageSize = 10

    @Published private(set) var uploadStatuses: [UUID: ZoneScanUploadStatus] = [:]

    /// Account whose queued scans may be flushed. Kept in sync with auth state by ContentView;
    /// while nil, user-scoped queue entries are held back rather than retried under an
    /// unknown session.
    var currentUserID: String?

    func uploadStatus(for zone: Zone) -> ZoneScanUploadStatus? {
        guard let status = self.uploadStatuses[zone.id] else { return nil }
        guard zone.scanState == .complete else { return nil }
        guard status.scanProjectID == nil || status.scanProjectID == zone.scanProjectID else { return nil }
        return status
    }

    func markUploadUnavailable(zoneID: UUID, scanProjectID: UUID?, reason: ZoneScanUploadUnavailableReason) {
        self.uploadStatuses[zoneID] = ZoneScanUploadStatus(
            scanProjectID: scanProjectID,
            state: .unavailable,
            detail: reason.detail,
            updatedAt: Date()
        )
    }

    func enqueueCompletedScan(
        localProjectID: UUID,
        organizationID: String,
        remoteProjectID: String,
        zone: Zone,
        scanProjectID: UUID
    ) {
        guard let userID = self.currentUserID else {
            self.markUploadUnavailable(
                zoneID: zone.id,
                scanProjectID: scanProjectID,
                reason: .notSignedIn
            )
            return
        }

        var uploads = self.pendingStore.load()
        uploads.insert(PendingZoneScanUpload(
            userID: userID,
            localProjectID: localProjectID,
            organizationID: organizationID,
            remoteProjectID: remoteProjectID,
            zoneID: zone.id.uuidString,
            remoteZoneID: zone.remoteID,
            scanProjectID: scanProjectID
        ))
        self.pendingStore.save(uploads)
        self.uploadStatuses[zone.id] = ZoneScanUploadStatus(
            scanProjectID: scanProjectID,
            state: .queued,
            detail: "Waiting to upload",
            updatedAt: Date()
        )

        Task {
            await self.flushPendingUploads()
        }
    }

    func flushPendingUploads() async {
        guard !self.isFlushingPendingUploads else {
            self.needsPendingUploadFlush = true
            return
        }
        self.isFlushingPendingUploads = true
        defer {
            self.isFlushingPendingUploads = false
        }

        repeat {
            self.needsPendingUploadFlush = false
            let uploads = self.pendingStore.load()
            for upload in uploads {
                // Hold back scans queued by a different account (or while signed out); they
                // resume when their owner signs back in.
                guard upload.userID == self.currentUserID else {
                    continue
                }
                let zoneUUID = UUID(uuidString: upload.zoneID)
                if let zoneUUID {
                    self.uploadStatuses[zoneUUID] = ZoneScanUploadStatus(
                        scanProjectID: upload.scanProjectID,
                        state: .uploading,
                        detail: "Uploading scan archive",
                        updatedAt: Date()
                    )
                }

                do {
                    guard let zoneUUID else {
                        throw ZoneScanArchiveCacheError.invalidLocalZoneID
                    }

                    let response = try await self.withRemoteZoneID(
                        localProjectID: upload.localProjectID,
                        organizationID: upload.organizationID,
                        remoteProjectID: upload.remoteProjectID,
                        zoneID: zoneUUID,
                        preferredRemoteZoneID: upload.remoteZoneID
                    ) { service, remoteZoneID in
                        try await service.uploadZone(
                            zoneID: remoteZoneID,
                            scanProjectDirectory: self.scanProjectStore.projectDirectory(for: upload.scanProjectID)
                        )
                    }

                    try await self.recordUploadedScan(upload: upload, zoneUUID: zoneUUID, response: response)

                    self.pendingStore.remove(upload)
                } catch ScanProjectStoreError.projectUnavailable, ZonesServiceError.scanProjectUnavailable {
                    self.pendingStore.remove(upload)
                    if let zoneUUID {
                        self.uploadStatuses[zoneUUID] = ZoneScanUploadStatus(
                            scanProjectID: upload.scanProjectID,
                            state: .failed,
                            detail: "Local scan files are missing",
                            updatedAt: Date()
                        )
                    }
                } catch {
                    self.handleUploadFailure(error, upload: upload, zoneUUID: zoneUUID)
                    continue
                }
            }
        } while self.needsPendingUploadFlush
    }

    @discardableResult
    func refreshPreviewIfNeeded(
        localProjectID: UUID,
        organizationID: String,
        remoteProjectID: String,
        zoneID: UUID,
        currentScanProjectID: UUID?
    ) async throws -> UUID? {
        let (remoteZone, archives) = try await self.withRemoteZoneID(
            localProjectID: localProjectID,
            organizationID: organizationID,
            remoteProjectID: remoteProjectID,
            zoneID: zoneID
        ) { service, remoteZoneID in
            // Max page size so an older server-selected active archive is still found.
            try await (
                service.fetchZone(zoneID: remoteZoneID),
                service.listScanArchives(zoneID: remoteZoneID, limit: Self.maxScanArchiveListLimit)
            )
        }
        if let currentScanProjectID {
            let hasPendingUpload = self.hasPendingUpload(
                localProjectID: localProjectID,
                zoneID: zoneID,
                scanProjectID: currentScanProjectID
            )
            if hasPendingUpload {
                return nil
            }
        }
        let hasPreview = currentScanProjectID.map(self.scanProjectStore.hasPreview(id:)) ?? false
        guard let archive = self.previewArchive(
            from: archives,
            activeScanProjectID: ZonesService.scanArchiveID(from: remoteZone.scanObjectKey),
            currentScanProjectID: currentScanProjectID,
            hasPreview: hasPreview
        ) else {
            return nil
        }
        guard let previewID = ZonesService.scanArchiveID(from: archive.objectKey) else { return nil }

        let preview = try await self.withRemoteZoneID(
            localProjectID: localProjectID,
            organizationID: organizationID,
            remoteProjectID: remoteProjectID,
            zoneID: zoneID
        ) { service, remoteZoneID in
            try await service.fetchPreviewFile(zoneID: remoteZoneID, archiveID: archive.id)
        }
        try self.scanProjectStore.storePreviewProject(id: previewID, previewData: preview.data)
        try self.projectStore.updateZoneScan(
            projectID: localProjectID,
            zoneID: zoneID,
            scanProjectID: previewID,
            scanState: .complete
        )
        return previewID
    }

    /// Serves one page of scan history. The API paginates only through `limit` (newest-first,
    /// max 100 rows), so each page fetches a window one row past the requested page to detect
    /// whether older scans remain. The active archive is pinned to the top of the first page
    /// and excluded from later pages, even when it is chronologically old.
    func listScanArchivePage(
        localProjectID: UUID,
        organizationID: String,
        remoteProjectID: String,
        zoneID: UUID,
        page: Int,
        pageSize: Int = ZoneScanArchiveCacheService.scanArchivePageSize
    ) async throws -> ZoneScanArchivePage {
        let requestedPageIndex = max(page, 0)
        let windowLimit = min((requestedPageIndex + 1) * pageSize + 1, Self.maxScanArchiveListLimit)

        let (remoteZone, fetchedArchives) = try await self.withRemoteZoneID(
            localProjectID: localProjectID,
            organizationID: organizationID,
            remoteProjectID: remoteProjectID,
            zoneID: zoneID
        ) { service, remoteZoneID in
            try await (
                service.fetchZone(zoneID: remoteZoneID),
                service.listScanArchives(zoneID: remoteZoneID, limit: windowLimit)
            )
        }

        // A pending/expired pointer is excluded from merge jobs, so don't pin or badge it.
        let activeScanProjectID = remoteZone.scanUploadStatus == .uploaded
            ? ZonesService.scanArchiveID(from: remoteZone.scanObjectKey)
            : nil

        var archives = fetchedArchives
        let isActiveInWindow = activeScanProjectID == nil || archives.contains {
            ZonesService.scanArchiveID(from: $0.objectKey) == activeScanProjectID
        }
        if !isActiveInWindow, windowLimit < Self.maxScanArchiveListLimit, archives.count == windowLimit {
            // The active archive is older than the fetched window; widen to the server's
            // maximum limit so it can still be pinned to the first page.
            archives = try await self.withRemoteZoneID(
                localProjectID: localProjectID,
                organizationID: organizationID,
                remoteProjectID: remoteProjectID,
                zoneID: zoneID
            ) { service, remoteZoneID in
                try await service.listScanArchives(zoneID: remoteZoneID, limit: Self.maxScanArchiveListLimit)
            }
        }

        var ordered = self.sortedByCreatedAt(archives)
        let activeIndex = activeScanProjectID.flatMap { activeID in
            ordered.firstIndex { ZonesService.scanArchiveID(from: $0.objectKey) == activeID }
        }
        if let activeIndex {
            let activeArchive = ordered.remove(at: activeIndex)
            ordered.insert(activeArchive, at: 0)
        }

        let lastPageIndex = ordered.isEmpty ? 0 : (ordered.count - 1) / pageSize
        let pageIndex = min(requestedPageIndex, lastPageIndex)
        let start = pageIndex * pageSize
        let end = min(start + pageSize, ordered.count)
        let options = start < end ? ordered[start ..< end].map(Self.scanArchiveOption) : []

        return ZoneScanArchivePage(
            pageIndex: pageIndex,
            options: options,
            hasNextPage: ordered.count > start + pageSize,
            activeScanProjectID: activeScanProjectID
        )
    }

    @discardableResult
    func selectScanArchivePreview(
        localProjectID: UUID,
        organizationID: String,
        remoteProjectID: String,
        zoneID: UUID,
        archive: ZoneScanArchiveOption
    ) async throws -> UUID {
        guard let previewID = archive.previewID else {
            throw ZonesServiceError.downloadUnavailable
        }

        let preview = try await self.withRemoteZoneID(
            localProjectID: localProjectID,
            organizationID: organizationID,
            remoteProjectID: remoteProjectID,
            zoneID: zoneID
        ) { service, remoteZoneID in
            try await service.fetchPreviewFile(zoneID: remoteZoneID, archiveID: archive.id)
        }
        try self.scanProjectStore.storePreviewProject(id: previewID, previewData: preview.data)
        try self.projectStore.updateZoneScan(
            projectID: localProjectID,
            zoneID: zoneID,
            scanProjectID: previewID,
            scanState: .complete
        )
        return previewID
    }

    func fetchActiveScanProjectID(
        localProjectID: UUID,
        organizationID: String,
        remoteProjectID: String,
        zoneID: UUID
    ) async throws -> UUID? {
        let zone = try await self.withRemoteZoneID(
            localProjectID: localProjectID,
            organizationID: organizationID,
            remoteProjectID: remoteProjectID,
            zoneID: zoneID
        ) { service, remoteZoneID in
            try await service.fetchZone(zoneID: remoteZoneID)
        }
        // A pending/expired pointer is excluded from merge jobs, so don't badge it as active.
        guard zone.scanUploadStatus == .uploaded else { return nil }
        return ZonesService.scanArchiveID(from: zone.scanObjectKey)
    }

    @discardableResult
    func selectScanArchiveForMerge(
        localProjectID: UUID,
        organizationID: String,
        remoteProjectID: String,
        zoneID: UUID,
        scanProjectID: UUID
    ) async throws -> UUID {
        let selectedZone = try await self.withRemoteZoneID(
            localProjectID: localProjectID,
            organizationID: organizationID,
            remoteProjectID: remoteProjectID,
            zoneID: zoneID
        ) { service, remoteZoneID in
            // Max page size so a scan selected from a deep history page is still found.
            let archives = try await service.listScanArchives(
                zoneID: remoteZoneID,
                limit: Self.maxScanArchiveListLimit
            )
            guard let archive = archives.first(where: {
                ZonesService.scanArchiveID(from: $0.objectKey) == scanProjectID
            }) else {
                throw ZoneScanArchiveCacheError.scanArchiveUnavailable
            }
            guard archive.uploadStatus == .uploaded else {
                throw ZoneScanArchiveCacheError.scanArchiveNotUploaded
            }
            return try await service.selectScanArchive(zoneID: remoteZoneID, archiveID: archive.id)
        }

        guard selectedZone.scanUploadStatus == .uploaded,
              let activeScanProjectID = ZonesService.scanArchiveID(from: selectedZone.scanObjectKey)
        else {
            throw ZoneScanArchiveCacheError.scanArchiveUnavailable
        }
        try? self.projectStore.updateZoneScan(
            projectID: localProjectID,
            zoneID: zoneID,
            scanProjectID: activeScanProjectID,
            scanState: .complete
        )
        return activeScanProjectID
    }

    // MARK: Private

    private static let fractionalDateFormatter: ISO8601DateFormatter = {
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        return formatter
    }()

    private static let dateFormatter: ISO8601DateFormatter = {
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime]
        return formatter
    }()

    /// The list endpoint's maximum `limit`; archives beyond this are unreachable until the
    /// API grows offset/cursor pagination.
    private static let maxScanArchiveListLimit = 100

    private let projectStore: ProjectStore
    private let scanProjectStore: ScanProjectStore
    private let pendingStore: PendingZoneScanUploadStore
    private let networkMonitor = NWPathMonitor()
    private let networkQueue = DispatchQueue(label: "ZoneScanArchiveCacheService.Network")
    private var isFlushingPendingUploads = false
    private var needsPendingUploadFlush = false

    private static func scanArchiveOption(_ archive: ZonesAPIScanArchive) -> ZoneScanArchiveOption {
        ZoneScanArchiveOption(
            id: archive.id,
            previewID: ZonesService.scanArchiveID(from: archive.objectKey),
            uploadStatus: archive.uploadStatus,
            previewUploadStatus: archive.previewUploadStatus,
            createdAt: self.date(from: archive.createdAt)
        )
    }

    private static func date(from value: String) -> Date? {
        if let date = self.fractionalDateFormatter.date(from: value) {
            return date
        }
        return self.dateFormatter.date(from: value)
    }

    private static func nonBlank(_ value: String?) -> String? {
        guard let value = value?.trimmingCharacters(in: .whitespacesAndNewlines),
              !value.isEmpty
        else {
            return nil
        }
        return value
    }

    private static func shouldRemovePendingUpload(for error: Error) -> Bool {
        if let cacheError = error as? ZoneScanArchiveCacheError {
            return self.shouldRemovePendingUpload(for: cacheError)
        }
        if let projectStoreError = error as? ProjectStoreError {
            return self.shouldRemovePendingUpload(for: projectStoreError)
        }
        if let requestError = error as? RequestServiceError {
            return self.shouldRemovePendingUpload(for: requestError)
        }
        if let zonesError = error as? ZonesServiceError {
            return self.shouldRemovePendingUpload(for: zonesError)
        }
        return error is ScanProjectStoreError
    }

    private static func shouldRemovePendingUpload(for error: ZoneScanArchiveCacheError) -> Bool {
        switch error {
        case .invalidLocalZoneID:
            return true
        case .remoteZoneUnavailable, .scanArchiveNotUploaded, .scanArchiveUnavailable:
            return false
        }
    }

    private static func shouldRemovePendingUpload(for error: ProjectStoreError) -> Bool {
        switch error {
        case .projectNotFound, .zoneNotFound:
            return true
        default:
            return false
        }
    }

    private static func shouldRemovePendingUpload(for error: RequestServiceError) -> Bool {
        switch error {
        case .invalidURL, .invalidPresignedURL, .invalidResponse, .invalidInput, .forbidden, .notFound, .conflict,
             .presignedDownloadFailed, .decodingFailed:
            return true
        case .missingAuthToken, .unauthorized, .requestFailed, .network:
            return false
        }
    }

    private static func shouldRemovePendingUpload(for error: ZonesServiceError) -> Bool {
        switch error {
        case .missingRequiredIdentifier, .invalidLimit, .invalidReconcileLimit, .invalidURL,
             .scanProjectUnavailable, .archiveCreationFailed, .downloadUnavailable, .downloadFailed:
            return true
        case let .uploadFailed(statusCode, _):
            guard let statusCode else { return false }
            return (400 ... 499).contains(statusCode) && statusCode != 408 && statusCode != 429
        }
    }

    private func restoreQueuedUploadStatuses() {
        var statuses: [UUID: ZoneScanUploadStatus] = [:]
        for upload in self.pendingStore.load() {
            guard let zoneID = UUID(uuidString: upload.zoneID) else { continue }
            statuses[zoneID] = ZoneScanUploadStatus(
                scanProjectID: upload.scanProjectID,
                state: .queued,
                detail: "Waiting to upload",
                updatedAt: Date()
            )
        }
        self.uploadStatuses = statuses
    }

    private func withRemoteZoneID<Value>(
        localProjectID: UUID,
        organizationID: String,
        remoteProjectID: String,
        zoneID: UUID,
        preferredRemoteZoneID: String? = nil,
        operation: (ZonesService, String) async throws -> Value
    ) async throws -> Value {
        let service = ZonesService(organizationID: organizationID, projectID: remoteProjectID)
        let context = RemoteZoneResolutionContext(
            localProjectID: localProjectID,
            organizationID: organizationID,
            remoteProjectID: remoteProjectID,
            zoneID: zoneID,
            preferredRemoteZoneID: preferredRemoteZoneID,
            service: service
        )
        let initialRemoteZoneID = try await self.remoteZoneID(context: context, refresh: false)

        do {
            return try await operation(service, initialRemoteZoneID)
        } catch RequestServiceError.notFound {
            let repairedRemoteZoneID = try await self.remoteZoneID(context: context, refresh: true)
            return try await operation(service, repairedRemoteZoneID)
        }
    }

    private func remoteZoneID(
        context: RemoteZoneResolutionContext,
        refresh: Bool
    ) async throws -> String {
        if !refresh {
            if let preferredRemoteZoneID = Self.nonBlank(context.preferredRemoteZoneID) {
                return preferredRemoteZoneID
            }
            if let cachedRemoteZoneID = self.cachedRemoteZoneID(
                localProjectID: context.localProjectID,
                zoneID: context.zoneID
            ) {
                return cachedRemoteZoneID
            }
            return context.zoneID.uuidString
        }

        let apiZones = try await context.service.listZones()
        let project = try self.projectStore.reconcileRemoteZones(
            remoteID: context.remoteProjectID,
            remoteOrganizationID: context.organizationID,
            apiZones: apiZones,
            toProject: context.localProjectID
        )

        guard let remoteZoneID = Self.nonBlank(project.zones.first(where: { $0.id == context.zoneID })?.remoteID) else {
            throw ZoneScanArchiveCacheError.remoteZoneUnavailable
        }
        return remoteZoneID
    }

    private func cachedRemoteZoneID(localProjectID: UUID, zoneID: UUID) -> String? {
        guard let zone = self.projectStore.project(withID: localProjectID)?.zones.first(where: { $0.id == zoneID })
        else {
            return nil
        }
        return Self.nonBlank(zone.remoteID)
    }

    /// Prefers the zone's server-selected active archive; falls back to newest-first when no
    /// active archive is set or the active archive has no viewable preview.
    private func previewArchive(
        from archives: [ZonesAPIScanArchive],
        activeScanProjectID: UUID?,
        currentScanProjectID: UUID?,
        hasPreview: Bool
    ) -> ZonesAPIScanArchive? {
        let uploadedArchives = archives.filter {
            $0.uploadStatus == .uploaded
                && ZonesService.scanArchiveID(from: $0.objectKey) != nil
                && ($0.previewUploadStatus == nil || $0.previewUploadStatus == .uploaded)
        }
        guard !uploadedArchives.isEmpty else { return nil }

        if let activeScanProjectID {
            if let activeArchive = uploadedArchives.first(where: {
                ZonesService.scanArchiveID(from: $0.objectKey) == activeScanProjectID
            }) {
                let isAlreadyShown = activeScanProjectID == currentScanProjectID && hasPreview
                return isAlreadyShown ? nil : activeArchive
            }
            if hasPreview {
                return nil
            }
            return self.sortedByCreatedAt(uploadedArchives).first
        }

        if !hasPreview {
            return self.sortedByCreatedAt(uploadedArchives).first
        }

        guard let currentScanProjectID else {
            return self.sortedByCreatedAt(uploadedArchives).first
        }

        let currentArchive = uploadedArchives.first {
            ZonesService.scanArchiveID(from: $0.objectKey) == currentScanProjectID
        }
        guard let currentDate = currentArchive.flatMap({ Self.date(from: $0.createdAt) }) else {
            return self.sortedByCreatedAt(uploadedArchives).first
        }

        return self.sortedByCreatedAt(uploadedArchives).first {
            guard let date = Self.date(from: $0.createdAt) else { return false }
            return date > currentDate
        }
    }

    private func sortedByCreatedAt(_ archives: [ZonesAPIScanArchive]) -> [ZonesAPIScanArchive] {
        archives.sorted {
            (Self.date(from: $0.createdAt) ?? .distantPast) > (Self.date(from: $1.createdAt) ?? .distantPast)
        }
    }

    /// Records a flushed upload's outcome, adopting it locally only if the server still points
    /// at it; an explicit archive selection may have displaced it while queued.
    private func recordUploadedScan(
        upload: PendingZoneScanUpload,
        zoneUUID: UUID,
        response: ZonesAPIScanArchiveUploadURLResponse
    ) async throws {
        let remoteScanID = ZonesService.scanArchiveID(from: response.objectKey)
        let uploadedZone = try? await self.withRemoteZoneID(
            localProjectID: upload.localProjectID,
            organizationID: upload.organizationID,
            remoteProjectID: upload.remoteProjectID,
            zoneID: zoneUUID,
            preferredRemoteZoneID: upload.remoteZoneID
        ) { service, remoteZoneID in
            try await service.fetchZone(zoneID: remoteZoneID)
        }
        let uploadIsActive = uploadedZone?.scanUploadStatus == .uploaded
            && uploadedZone?.scanObjectKey == response.objectKey
        if let remoteScanID, uploadIsActive {
            try self.projectStore.updateZoneScan(
                projectID: upload.localProjectID,
                zoneID: zoneUUID,
                scanProjectID: remoteScanID,
                scanState: .complete
            )
            _ = try? self.scanProjectStore.replaceProjectWithPreviewOnly(
                id: upload.scanProjectID,
                previewID: remoteScanID
            )
        }
        let detail = if remoteScanID == nil {
            "Uploaded; preview ID unavailable"
        } else if uploadIsActive {
            "Uploaded"
        } else {
            "Uploaded; a different scan is active for merge"
        }
        self.uploadStatuses[zoneUUID] = ZoneScanUploadStatus(
            scanProjectID: uploadIsActive ? (remoteScanID ?? upload.scanProjectID) : upload.scanProjectID,
            state: .uploaded,
            detail: detail,
            updatedAt: Date()
        )
    }

    private func hasPendingUpload(localProjectID: UUID, zoneID: UUID, scanProjectID: UUID) -> Bool {
        self.pendingStore.load().contains {
            $0.localProjectID == localProjectID
                && $0.zoneID == zoneID.uuidString
                && $0.scanProjectID == scanProjectID
        }
    }

    private func handleUploadFailure(_ error: Error, upload: PendingZoneScanUpload, zoneUUID: UUID?) {
        if let zoneUUID {
            self.uploadStatuses[zoneUUID] = ZoneScanUploadStatus(
                scanProjectID: upload.scanProjectID,
                state: .failed,
                detail: error.localizedDescription,
                updatedAt: Date()
            )
        }

        if Self.shouldRemovePendingUpload(for: error) {
            self.pendingStore.remove(upload)
        }
    }
}

// MARK: - PendingZoneScanUploadStore

nonisolated struct PendingZoneScanUploadStore {
    // MARK: Lifecycle

    init(rootDirectory: URL? = nil) {
        if let rootDirectory {
            self.rootDirectory = rootDirectory
        } else {
            let applicationSupportURL = FileManager.default.urls(
                for: .applicationSupportDirectory,
                in: .userDomainMask
            ).first ?? FileManager.default.temporaryDirectory
            self.rootDirectory = applicationSupportURL
                .appending(path: "ScannerConsolidator", directoryHint: .isDirectory)
                .appending(path: "ZoneScanArchiveCache", directoryHint: .isDirectory)
        }
    }

    // MARK: Internal

    let rootDirectory: URL

    func load() -> Set<PendingZoneScanUpload> {
        guard FileManager.default.fileExists(atPath: self.cacheURL.path),
              let data = try? Data(contentsOf: self.cacheURL),
              let uploads = try? JSONDecoder().decode(Set<PendingZoneScanUpload>.self, from: data)
        else {
            return []
        }

        return uploads
    }

    func save(_ uploads: Set<PendingZoneScanUpload>) {
        try? FileManager.default.createDirectory(at: self.rootDirectory, withIntermediateDirectories: true)
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.sortedKeys]
        let data = try? encoder.encode(uploads)
        try? data?.write(to: self.cacheURL, options: .atomic)
    }

    func remove(_ upload: PendingZoneScanUpload) {
        var uploads = self.load()
        uploads.remove(upload)
        self.save(uploads)
    }

    // MARK: Private

    private var cacheURL: URL {
        self.rootDirectory.appending(path: "pending-uploads.json")
    }
}
