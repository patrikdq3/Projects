import Combine
import Foundation

// swiftlint:disable:next unused_import
import OSLog
import SwiftUI

// MARK: - OrganizationDataCoordinator

@MainActor
final class OrganizationDataCoordinator: ObservableObject {
    // MARK: Lifecycle

    init(
        cacheStore: OrganizationCacheStore = OrganizationCacheStore(),
        organizationsService: OrganizationsService = OrganizationsService()
    ) {
        self.cacheStore = cacheStore
        self.organizationsService = organizationsService
    }

    // MARK: Internal

    @Published private(set) var manageableOrganizations: [ManageableOrganization] = []
    @Published private(set) var isLoadingOrganizations = false
    @Published private(set) var loadErrorMessage: String?

    static func errorMessage(for error: Error) -> String {
        switch error {
        case RequestServiceError.missingAuthToken, RequestServiceError.unauthorized:
            return "Sign in again to load organizations."
        case RequestServiceError.forbidden:
            return "You do not have access to manage these organizations."
        default:
            self.logger.error("Organizations could not be loaded: \(error.localizedDescription, privacy: .public)")
            return "Organizations could not be loaded."
        }
    }

    func loadCachedThenRefresh(user: User?) async {
        guard let user else { return }
        self.prepareForUserIfNeeded(user.id)
        self.loadCachedSnapshotIfNeeded(userID: user.id)
        let sessionContext = self.currentSessionContext()

        if !self.manageableOrganizations.isEmpty {
            await Task.yield()
            guard self.isCurrentSession(sessionContext) else { return }
        }
        await self.refreshOrganizations(user: user)
    }

    func refreshOrganizations(user: User?) async {
        guard let user else { return }
        self.prepareForUserIfNeeded(user.id)
        guard !self.isLoadingOrganizations else { return }

        let sessionContext = self.currentSessionContext()
        self.isLoadingOrganizations = true
        self.loadErrorMessage = nil
        defer {
            if self.isCurrentSession(sessionContext) {
                self.isLoadingOrganizations = false
            }
        }

        do {
            let details = try await self.organizationsService.listOrganizationDetails()
            guard self.isCurrentSession(sessionContext) else { return }

            self.cacheOrganizationDetails(details, currentUserID: user.id)
            self.loadErrorMessage = nil
            self.persistSnapshot()
        } catch {
            guard self.isCurrentSession(sessionContext) else { return }
            self.loadErrorMessage = Self.errorMessage(for: error)
        }
    }

    func cachedOrganizationDetail(id organizationID: String) -> OrganizationsAPIFullOrganization? {
        self.cachedOrganizationDetails.first { $0.id == organizationID }
    }

    func refreshOrganizationDetail(
        id organizationID: String,
        membersLimit: Int = 100
    ) async throws -> OrganizationsAPIFullOrganization {
        let sessionContext = self.currentSessionContext()
        var detail = try await self.organizationsService.getFullOrganization(
            id: organizationID,
            membersLimit: membersLimit
        )
        try self.validateSession(sessionContext)

        if detail.members.isEmpty {
            let members = try await self.organizationsService.listMembers(organizationID: organizationID)
            try self.validateSession(sessionContext)
            detail = OrganizationsAPIFullOrganization(organization: detail.organization, members: members)
        }

        if let currentUserID = self.currentUserID {
            _ = try? await self.organizationsService.setActiveOrganization(id: organizationID)
            try self.validateSession(sessionContext)

            if let activeMember = try? await self.organizationsService.getActiveOrganizationMember() {
                try self.validateSession(sessionContext)
                detail = Self.ensuringViewerMembership(activeMember, in: detail, currentUserID: currentUserID)
            }
        }

        self.upsertOrganizationDetail(detail, currentUserID: self.currentUserID)
        self.loadErrorMessage = nil
        self.persistSnapshot()
        return detail
    }

    @discardableResult
    func cacheCreatedOrganization(
        _ organization: ProjectsAPIOrganization,
        currentUser: User?
    ) -> ManageableOrganization {
        if let userID = currentUser?.id {
            self.prepareForUserIfNeeded(userID)
        }

        let ownerMember = OrganizationsAPIMember(
            id: currentUser?.id ?? organization.id,
            userID: currentUser?.id ?? "",
            organizationID: organization.id,
            role: OrgRole.owner.rawValue,
            user: OrganizationsAPIUser(
                id: currentUser?.id ?? "",
                name: currentUser?.name,
                email: currentUser?.email,
                image: currentUser?.image
            )
        )
        let detail = OrganizationsAPIFullOrganization(organization: organization, members: [ownerMember])
        self.upsertOrganizationDetail(detail, currentUserID: currentUser?.id)
        self.persistSnapshot()

        return ManageableOrganization(
            apiDetail: detail,
            currentUserID: currentUser?.id,
            tint: Self.organizationTint(for: max(self.cachedOrganizationDetails.count - 1, 0))
        )
    }

    func removeCachedOrganization(id organizationID: String) {
        self.cachedOrganizationDetails.removeAll { $0.id == organizationID }
        self.manageableOrganizations = self.makeManageableOrganizations(
            from: self.cachedOrganizationDetails,
            currentUserID: self.currentUserID
        )
        self.persistSnapshot()
    }

    func resetInMemoryState(clearDiskCache: Bool = false) {
        if clearDiskCache, let currentUserID = self.currentUserID {
            try? self.cacheStore.deleteSnapshot(userID: currentUserID)
        }

        self.sessionGeneration += 1
        self.currentUserID = nil
        self.didLoadCachedSnapshot = false
        self.cachedOrganizationDetails = []
        self.manageableOrganizations = []
        self.isLoadingOrganizations = false
        self.loadErrorMessage = nil
    }

    // MARK: Private

    private struct SessionContext {
        let userID: String?
        let generation: Int
    }

    private static let logger = Logger(
        subsystem: Bundle.main.bundleIdentifier ?? "ScannerConsolidator",
        category: "OrganizationDataCoordinator"
    )

    private let cacheStore: OrganizationCacheStore
    private let organizationsService: OrganizationsService

    private var currentUserID: String?
    private var sessionGeneration = 0
    private var didLoadCachedSnapshot = false
    private var cachedOrganizationDetails: [OrganizationsAPIFullOrganization] = []

    private static func organizationTint(for index: Int) -> Color {
        ManageableOrganization.tint(for: index)
    }

    private static func ensuringViewerMembership(
        _ activeMember: ProjectsAPIOrganizationMember,
        in detail: OrganizationsAPIFullOrganization,
        currentUserID: String
    ) -> OrganizationsAPIFullOrganization {
        guard !detail.members.contains(where: { $0.userID == currentUserID }) else {
            return detail
        }

        let viewer = OrganizationsAPIMember(
            id: activeMember.id,
            userID: currentUserID,
            organizationID: detail.organization.id,
            role: activeMember.role
        )
        return OrganizationsAPIFullOrganization(
            organization: detail.organization,
            members: detail.members + [viewer]
        )
    }

    private func prepareForUserIfNeeded(_ userID: String) {
        guard self.currentUserID != userID else { return }
        self.sessionGeneration += 1
        self.currentUserID = userID
        self.didLoadCachedSnapshot = false
        self.cachedOrganizationDetails = []
        self.manageableOrganizations = []
        self.loadErrorMessage = nil
    }

    private func currentSessionContext() -> SessionContext {
        SessionContext(userID: self.currentUserID, generation: self.sessionGeneration)
    }

    private func isCurrentSession(_ context: SessionContext) -> Bool {
        self.currentUserID == context.userID && self.sessionGeneration == context.generation
    }

    private func validateSession(_ context: SessionContext) throws {
        guard self.isCurrentSession(context) else {
            throw CancellationError()
        }
    }

    private func loadCachedSnapshotIfNeeded(userID: String) {
        guard !self.didLoadCachedSnapshot else { return }
        self.didLoadCachedSnapshot = true

        do {
            guard let snapshot = try self.cacheStore.loadSnapshot(userID: userID) else { return }
            self.cachedOrganizationDetails = snapshot.organizationDetails
            self.manageableOrganizations = self.makeManageableOrganizations(
                from: snapshot.organizationDetails,
                currentUserID: userID
            )
        } catch {
            self.loadErrorMessage = "Cached organizations could not be loaded."
        }
    }

    private func cacheOrganizationDetails(
        _ details: [OrganizationsAPIFullOrganization],
        currentUserID: String
    ) {
        self.cachedOrganizationDetails = details
        self.manageableOrganizations = self.makeManageableOrganizations(
            from: details,
            currentUserID: currentUserID
        )
    }

    private func upsertOrganizationDetail(
        _ detail: OrganizationsAPIFullOrganization,
        currentUserID: String?
    ) {
        if let index = self.cachedOrganizationDetails.firstIndex(where: { $0.id == detail.id }) {
            self.cachedOrganizationDetails[index] = detail
        } else {
            self.cachedOrganizationDetails.append(detail)
        }

        self.manageableOrganizations = self.makeManageableOrganizations(
            from: self.cachedOrganizationDetails,
            currentUserID: currentUserID
        )
    }

    private func makeManageableOrganizations(
        from details: [OrganizationsAPIFullOrganization],
        currentUserID: String?
    ) -> [ManageableOrganization] {
        details.enumerated().map { index, detail in
            ManageableOrganization(
                apiDetail: detail,
                currentUserID: currentUserID,
                tint: Self.organizationTint(for: index)
            )
        }
    }

    private func persistSnapshot() {
        guard let currentUserID else { return }
        let snapshot = OrganizationCacheSnapshot(
            userID: currentUserID,
            organizationDetails: self.cachedOrganizationDetails
        )
        do {
            try self.cacheStore.saveSnapshot(snapshot)
        } catch {
            Self.logger.error(
                "Failed to persist organization cache snapshot: \(error.localizedDescription, privacy: .public)"
            )
        }
    }
}
