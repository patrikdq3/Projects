import Foundation

// MARK: - OrganizationCacheSnapshot

nonisolated struct OrganizationCacheSnapshot: Codable, Equatable {
    // MARK: Lifecycle

    init(
        userID: String,
        organizationDetails: [OrganizationsAPIFullOrganization],
        updatedAt: Date = Date()
    ) {
        self.userID = userID
        self.organizationDetails = organizationDetails
        self.updatedAt = updatedAt
    }

    // MARK: Internal

    let userID: String
    var organizationDetails: [OrganizationsAPIFullOrganization]
    var updatedAt: Date
}

// MARK: - OrganizationCacheStore

nonisolated struct OrganizationCacheStore {
    // MARK: Lifecycle

    init(rootDirectory: URL? = nil) {
        if let rootDirectory {
            self.rootDirectory = rootDirectory
        } else {
            let applicationSupportURL = FileManager.default.urls(
                for: .applicationSupportDirectory,
                in: .userDomainMask
            ).first ?? FileManager.default.temporaryDirectory
            self.rootDirectory = applicationSupportURL
                .appending(path: "ScannerConsolidator", directoryHint: .isDirectory)
                .appending(path: "OrganizationCache", directoryHint: .isDirectory)
        }
    }

    // MARK: Internal

    let rootDirectory: URL

    func loadSnapshot(userID: String) throws -> OrganizationCacheSnapshot? {
        let url = self.cacheURL(userID: userID)
        guard FileManager.default.fileExists(atPath: url.path) else { return nil }

        let data = try Data(contentsOf: url)
        return try JSONDecoder().decode(OrganizationCacheSnapshot.self, from: data)
    }

    func saveSnapshot(_ snapshot: OrganizationCacheSnapshot) throws {
        try FileManager.default.createDirectory(
            at: self.rootDirectory,
            withIntermediateDirectories: true
        )

        let encoder = JSONEncoder()
        encoder.outputFormatting = [.sortedKeys]
        let data = try encoder.encode(snapshot)
        try data.write(to: self.cacheURL(userID: snapshot.userID), options: [.atomic])
    }

    func deleteSnapshot(userID: String) throws {
        let url = self.cacheURL(userID: userID)
        guard FileManager.default.fileExists(atPath: url.path) else { return }
        try FileManager.default.removeItem(at: url)
    }

    // MARK: Private

    private static func sanitizedCacheKey(_ value: String) -> String {
        let allowed = CharacterSet.alphanumerics.union(CharacterSet(charactersIn: "-_."))
        let scalars = value.unicodeScalars.map { scalar in
            allowed.contains(scalar) ? Character(scalar) : "-"
        }
        let sanitized = String(scalars)
        return sanitized.isEmpty ? "anonymous" : sanitized
    }

    private func cacheURL(userID: String) -> URL {
        self.rootDirectory.appending(path: "\(Self.sanitizedCacheKey(userID)).json")
    }
}
