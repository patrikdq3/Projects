import Foundation

// MARK: - InvitationSeenSnapshot

nonisolated struct InvitationSeenSnapshot: Codable, Equatable {
    // MARK: Lifecycle

    init(userID: String, invitationIDs: [String], updatedAt: Date = Date()) {
        self.userID = userID
        self.invitationIDs = invitationIDs
        self.updatedAt = updatedAt
    }

    // MARK: Internal

    let userID: String
    var invitationIDs: [String]
    var updatedAt: Date
}

// MARK: - InvitationSeenStore

/// Persists, per user, the set of invitation IDs the user has already been notified about. A
/// pending invitation whose ID is not yet in the stored JSON is considered "new" and triggers a
/// single login notification.
nonisolated struct InvitationSeenStore {
    // MARK: Lifecycle

    init(rootDirectory: URL? = nil) {
        if let rootDirectory {
            self.rootDirectory = rootDirectory
        } else {
            let applicationSupportURL = FileManager.default.urls(
                for: .applicationSupportDirectory,
                in: .userDomainMask
            ).first ?? FileManager.default.temporaryDirectory
            self.rootDirectory = applicationSupportURL
                .appending(path: "ScannerConsolidator", directoryHint: .isDirectory)
                .appending(path: "InvitationCache", directoryHint: .isDirectory)
        }
    }

    // MARK: Internal

    let rootDirectory: URL

    func loadSeenIDs(userID: String) -> Set<String> {
        let url = self.cacheURL(userID: userID)
        guard let data = try? Data(contentsOf: url),
              let snapshot = try? JSONDecoder().decode(InvitationSeenSnapshot.self, from: data)
        else {
            return []
        }
        return Set(snapshot.invitationIDs)
    }

    func saveSeenIDs(_ ids: Set<String>, userID: String) {
        let snapshot = InvitationSeenSnapshot(userID: userID, invitationIDs: ids.sorted())
        do {
            try FileManager.default.createDirectory(at: self.rootDirectory, withIntermediateDirectories: true)
            let encoder = JSONEncoder()
            encoder.outputFormatting = [.sortedKeys]
            let data = try encoder.encode(snapshot)
            try data.write(to: self.cacheURL(userID: userID), options: [.atomic])
        } catch {
            // Non-fatal: a failed write just means the user may be re-notified next launch.
        }
    }

    // MARK: Private

    private static func sanitizedCacheKey(_ value: String) -> String {
        let allowed = CharacterSet.alphanumerics.union(CharacterSet(charactersIn: "-_."))
        let scalars = value.unicodeScalars.map { scalar in
            allowed.contains(scalar) ? Character(scalar) : "-"
        }
        let sanitized = String(scalars)
        return sanitized.isEmpty ? "anonymous" : sanitized
    }

    private func cacheURL(userID: String) -> URL {
        self.rootDirectory.appending(path: "\(Self.sanitizedCacheKey(userID)).json")
    }
}
