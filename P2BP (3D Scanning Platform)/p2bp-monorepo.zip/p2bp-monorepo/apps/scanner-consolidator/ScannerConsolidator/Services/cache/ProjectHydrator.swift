import Foundation

@MainActor
struct ProjectHydrator {
    // MARK: Internal

    let organizationID: String
    let projects: [ProjectsAPIProject]
    let localProjectsBeingPublished: [Project]
    let projectStore: ProjectStore
    let isCurrent: () -> Bool

    func hydrate() async -> String? {
        var state = HydrationState()

        await withTaskGroup(
            of: (project: ProjectsAPIProject, result: Result<[ZonesAPIZone], Error>).self
        ) { group in
            for project in self.projects where project.boundary != nil && !self.hasPublishingLocalShell(for: project) {
                group.addTask {
                    await Self.loadZones(for: project, organizationID: self.organizationID)
                }
            }

            for await (project, result) in group {
                guard !Task.isCancelled, self.isCurrent() else {
                    group.cancelAll()
                    return
                }

                self.apply(result, for: project, to: &state)
            }
        }

        // Reload even if the session went stale mid-hydration: results are only applied
        // while current, so the persisted changes are valid and must be republished or
        // rows would show stale progress until the next unrelated store reload.
        if state.hasUnpublishedChanges {
            state.errorMessage = self.reloadStore() ?? state.errorMessage
        }
        guard self.isCurrent() else { return nil }
        return state.errorMessage
    }

    // MARK: Private

    private struct HydrationState {
        var errorMessage: String?
        var hasUnpublishedChanges = false
        var lastReloadDate: Date?
    }

    private static func zoneError(project: ProjectsAPIProject, error: Error) -> String {
        "Couldn’t load zones for \(project.name): \(error.localizedDescription)"
    }

    private static func loadZones(
        for project: ProjectsAPIProject,
        organizationID: String
    ) async -> (ProjectsAPIProject, Result<[ZonesAPIZone], Error>) {
        do {
            let zones = try await ZonesService(
                organizationID: organizationID,
                projectID: project.id
            ).listZones()
            return (project, .success(zones))
        } catch {
            return (project, .failure(error))
        }
    }

    private func hasPublishingLocalShell(for project: ProjectsAPIProject) -> Bool {
        guard let boundary = project.boundary else { return false }
        let remoteBoundary = ProjectBoundary(vertices: boundary.map(\.geoCoordinate))

        return self.localProjectsBeingPublished.contains { localProject in
            localProject.owningRemoteOrganizationID == self.organizationID
                && localProject.name == project.name
                && localProject.boundary == remoteBoundary
        }
    }

    private func apply(
        _ result: Result<[ZonesAPIZone], Error>,
        for project: ProjectsAPIProject,
        to state: inout HydrationState
    ) {
        switch result {
        case let .success(zones):
            guard let boundary = project.boundary else { return }
            do {
                let materialization = try self.projectStore.materializeRemoteProject(
                    remoteID: project.id,
                    remoteOrganizationID: self.organizationID,
                    name: project.name,
                    boundary: ProjectBoundary(vertices: boundary.map(\.geoCoordinate)),
                    apiZones: zones,
                    reloadsStore: false
                )
                guard materialization.didChange else { return }
                state.hasUnpublishedChanges = true

                let now = Date()
                let shouldReload = state.lastReloadDate.map {
                    now.timeIntervalSince($0) >= 0.25
                } ?? true
                if shouldReload {
                    state.errorMessage = self.reloadStore() ?? state.errorMessage
                    state.hasUnpublishedChanges = false
                    state.lastReloadDate = now
                }
            } catch {
                state.errorMessage = state.errorMessage ?? Self.zoneError(project: project, error: error)
            }
        case let .failure(error):
            guard !(error is CancellationError) else { return }
            state.errorMessage = state.errorMessage ?? Self.zoneError(project: project, error: error)
        }
    }

    private func reloadStore() -> String? {
        do {
            try self.projectStore.reload()
            return nil
        } catch {
            return "Local projects couldn’t be refreshed: \(error.localizedDescription)"
        }
    }
}
