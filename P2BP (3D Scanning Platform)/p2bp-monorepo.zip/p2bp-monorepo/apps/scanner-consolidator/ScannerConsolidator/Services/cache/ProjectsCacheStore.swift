import Foundation

// MARK: - CachedRemoteOrganization

nonisolated struct CachedRemoteOrganization: Codable, Equatable, Hashable, Identifiable {
    // MARK: Lifecycle

    init(
        id: String,
        name: String,
        slug: String,
        logo: String?,
        createdAt: String,
        metadata: String?,
        role: String,
        projectCount: Int
    ) {
        self.id = id
        self.name = name
        self.slug = slug
        self.logo = logo
        self.createdAt = createdAt
        self.metadata = metadata
        self.role = role
        self.projectCount = projectCount
    }

    init(apiOrganization: ProjectsAPIOrganization, role: String = "Member", projectCount: Int = 0) {
        self.id = apiOrganization.id
        self.name = apiOrganization.name
        self.slug = apiOrganization.slug
        self.logo = apiOrganization.logo
        self.createdAt = apiOrganization.createdAt
        self.metadata = apiOrganization.metadata
        self.role = role
        self.projectCount = projectCount
    }

    // MARK: Internal

    let id: String
    let name: String
    let slug: String
    let logo: String?
    let createdAt: String
    let metadata: String?
    var role: String
    var projectCount: Int
}

// MARK: - RemoteProjectsCacheSnapshot

nonisolated struct RemoteProjectsCacheSnapshot: Codable, Equatable {
    // MARK: Lifecycle

    init(
        userID: String,
        selectedOrganizationID: String?,
        organizations: [CachedRemoteOrganization],
        projectsByOrganizationID: [String: [ProjectsAPIProject]],
        updatedAt: Date = Date()
    ) {
        self.userID = userID
        self.selectedOrganizationID = selectedOrganizationID
        self.organizations = organizations
        self.projectsByOrganizationID = projectsByOrganizationID
        self.updatedAt = updatedAt
    }

    // MARK: Internal

    let userID: String
    var selectedOrganizationID: String?
    var organizations: [CachedRemoteOrganization]
    var projectsByOrganizationID: [String: [ProjectsAPIProject]]
    var updatedAt: Date
}

// MARK: - RemoteProjectsCacheStore

nonisolated struct RemoteProjectsCacheStore {
    // MARK: Lifecycle

    init(rootDirectory: URL? = nil) {
        if let rootDirectory {
            self.rootDirectory = rootDirectory
        } else {
            let applicationSupportURL = FileManager.default.urls(
                for: .applicationSupportDirectory,
                in: .userDomainMask
            ).first ?? FileManager.default.temporaryDirectory
            self.rootDirectory = applicationSupportURL
                .appending(path: "ScannerConsolidator", directoryHint: .isDirectory)
                .appending(path: "RemoteProjectsCache", directoryHint: .isDirectory)
        }
    }

    // MARK: Internal

    let rootDirectory: URL

    func loadSnapshot(userID: String) throws -> RemoteProjectsCacheSnapshot? {
        let url = self.cacheURL(userID: userID)
        guard FileManager.default.fileExists(atPath: url.path) else { return nil }

        let data = try Data(contentsOf: url)
        return try JSONDecoder().decode(RemoteProjectsCacheSnapshot.self, from: data)
    }

    func saveSnapshot(_ snapshot: RemoteProjectsCacheSnapshot) throws {
        try FileManager.default.createDirectory(
            at: self.rootDirectory,
            withIntermediateDirectories: true
        )

        let encoder = JSONEncoder()
        encoder.outputFormatting = [.sortedKeys]
        let data = try encoder.encode(snapshot)
        try data.write(to: self.cacheURL(userID: snapshot.userID), options: [.atomic])
    }

    func deleteSnapshot(userID: String) throws {
        let url = self.cacheURL(userID: userID)
        guard FileManager.default.fileExists(atPath: url.path) else { return }
        try FileManager.default.removeItem(at: url)
    }

    // MARK: Private

    private static func sanitizedCacheKey(_ value: String) -> String {
        let allowed = CharacterSet.alphanumerics.union(CharacterSet(charactersIn: "-_."))
        let scalars = value.unicodeScalars.map { scalar in
            allowed.contains(scalar) ? Character(scalar) : "-"
        }
        let sanitized = String(scalars)
        return sanitized.isEmpty ? "anonymous" : sanitized
    }

    private func cacheURL(userID: String) -> URL {
        self.rootDirectory.appending(path: "\(Self.sanitizedCacheKey(userID)).json")
    }
}
