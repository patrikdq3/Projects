import Combine
import CoreLocation

// MARK: - LocationAuthorizationManager

@MainActor
final class LocationAuthorizationManager: NSObject, ObservableObject {
    // MARK: Lifecycle

    override init() {
        super.init()
        self.locationManager.delegate = self
        self.locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
    }

    // MARK: Internal

    @Published private(set) var currentCoordinate: GeoCoordinate?
    @Published private(set) var statusMessage: String?

    func requestCurrentLocation() {
        switch self.locationManager.authorizationStatus {
        case .authorizedAlways, .authorizedWhenInUse:
            self.statusMessage = nil
            self.locationManager.requestLocation()
        case .notDetermined:
            self.locationManager.requestWhenInUseAuthorization()
        case .restricted, .denied:
            self.statusMessage = "Location access is unavailable, so the map is using a default starting area."
        @unknown default:
            self.statusMessage = "Current location is unavailable right now. You can still place the boundary manually."
        }
    }

    // MARK: Private

    private let locationManager = CLLocationManager()
}

// MARK: @preconcurrency CLLocationManagerDelegate

extension LocationAuthorizationManager: @preconcurrency CLLocationManagerDelegate {
    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        switch manager.authorizationStatus {
        case .authorizedAlways, .authorizedWhenInUse:
            self.statusMessage = nil
            manager.requestLocation()
        case .restricted, .denied:
            self.statusMessage = "Location access is unavailable, so the map is using a default starting area."
        case .notDetermined:
            break
        @unknown default:
            self.statusMessage = "Current location is unavailable right now. You can still place the boundary manually."
        }
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let location = locations.last else { return }
        self.currentCoordinate = GeoCoordinate(location.coordinate)
        self.statusMessage = nil
    }

    func locationManager(_ manager: CLLocationManager, didFailWithError error: any Error) {
        self.statusMessage = "Could not resolve your location. You can continue by positioning the map yourself."
    }
}
