import Combine
import MapKit

// MARK: - AddressSearchService

@MainActor
final class AddressSearchService: NSObject, ObservableObject {
    // MARK: Lifecycle

    override init() {
        super.init()

        self.completer.delegate = self
        self.completer
            .resultTypes =
            .address // focus auto-complete on only addresses this might be changed to not be so specific
        self.completer.pointOfInterestFilter = .excludingAll

        // React to queryFragment changes; wait 300ms of inactivity before acting
        self.$queryFragment
            .debounce(for: .milliseconds(300), scheduler: RunLoop.main)
            .removeDuplicates() // skip if value didn't actually change
            .sink { [weak self] fragment in // suscriber
                guard let self else { return }
                if fragment.isEmpty {
                    // User cleared the field — reset suppression and wipe suggestions
                    self.suppressedQueryFragment = nil
                    self.completer.cancel()
                    self.suggestions = []
                } else if fragment == self.suppressedQueryFragment {
                    // User just picked a suggestion; suppress autocomplete for that exact text
                    self.suppressedQueryFragment = nil
                    self.suggestions = []
                } else {
                    // New user-typed query — forward to MKLocalSearchCompleter
                    self.completer.queryFragment = fragment
                }
            }
            .store(in: &self.cancellables)
    }

    // MARK: Internal

    // publishers that notifies observers of changes made to them. Notifies swiftUI when changes are made to these
    // components
    @Published var queryFragment = ""
    @Published private(set) var suggestions: [MKLocalSearchCompletion] = []

    func displayText(for completion: MKLocalSearchCompletion) -> String {
        [completion.title, completion.subtitle]
            .filter { !$0.isEmpty }
            .joined(separator: ", ")
    }

    func selectSuggestion(_ completion: MKLocalSearchCompletion) {
        let selectedText = self.displayText(for: completion)
        self.suppressedQueryFragment = selectedText
        self.suggestions = []
        self.completer.cancel()
        self.queryFragment = selectedText
    }

    func resolveCoordinate(for completion: MKLocalSearchCompletion) async throws -> GeoCoordinate {
        let request = MKLocalSearch.Request(completion: completion)
        let search = MKLocalSearch(request: request)
        let response = try await search.start()

        guard let coordinate = response.mapItems.first?.location.coordinate else {
            throw AddressSearchError.noResults
        }
        return GeoCoordinate(coordinate)
    }

    func clearResults() {
        self.suggestions = []
        self.completer.cancel()
    }

    // MARK: Private

    private let completer = MKLocalSearchCompleter()
    private var cancellables = Set<AnyCancellable>()
    private var suppressedQueryFragment: String?
}

// MARK: @preconcurrency MKLocalSearchCompleterDelegate

extension AddressSearchService: @preconcurrency MKLocalSearchCompleterDelegate {
    func completerDidUpdateResults(_ completer: MKLocalSearchCompleter) {
        let results = completer.results
        if self.queryFragment == self.suppressedQueryFragment {
            self.suggestions = []
        } else {
            self.suggestions = results
        }
    }

    func completer(_: MKLocalSearchCompleter, didFailWithError _: Error) {
        self.suggestions = []
    }
}

// MARK: - AddressSearchError

enum AddressSearchError: LocalizedError {
    case noResults

    // MARK: Internal

    var errorDescription: String? {
        switch self {
        case .noResults:
            "Could not find a location for that address."
        }
    }
}
