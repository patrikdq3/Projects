import Foundation

// MARK: - OrganizationsService

nonisolated struct OrganizationsService {
    // MARK: Lifecycle

    init(
        requestService: RequestService? = nil,
        authService: AuthService = .shared,
        urlSession: URLSession = .shared,
        apiBaseURL: URL = RequestService.defaultAPIBaseURL,
        authBaseURL: URL = RequestService.defaultAuthBaseURL
    ) {
        self.requestService = requestService ?? RequestService(
            authService: authService,
            urlSession: urlSession,
            apiBaseURL: apiBaseURL,
            authBaseURL: authBaseURL
        )
    }

    // MARK: Internal

    let requestService: RequestService

    func listOrganizations() async throws -> [ProjectsAPIOrganization] {
        let request = try self.requestService.makeAuthRequest(
            pathComponents: ["organization", "list"],
            method: "GET"
        )

        return try await self.requestService.decode([ProjectsAPIOrganization].self, from: request)
    }

    func getActiveOrganizationMember() async throws -> ProjectsAPIOrganizationMember {
        let request = try self.requestService.makeAuthRequest(
            pathComponents: ["organization", "get-active-member"],
            method: "GET"
        )

        return try await self.requestService.decode(ProjectsAPIOrganizationMember.self, from: request)
    }

    func setActiveOrganization(id organizationID: String) async throws -> ProjectsAPIOrganization {
        let body = SetActiveProjectsAPIOrganizationRequest(
            organizationID: organizationID,
            organizationSlug: nil
        )

        let request = try self.requestService.makeAuthRequest(
            pathComponents: ["organization", "set-active"],
            method: "POST",
            body: body
        )

        return try await self.requestService.decode(ProjectsAPIOrganization.self, from: request)
    }

    func listOrganizationDetails(membersLimit: Int = 100) async throws -> [OrganizationsAPIFullOrganization] {
        let organizations = try await self.listOrganizations()

        // fetch all org details in multiple async operations instead of linearly
        return try await withThrowingTaskGroup(
            of: (Int, OrganizationsAPIFullOrganization).self
        ) { group in
            for (index, organization) in organizations.enumerated() {
                group.addTask {
                    await (index, self.detail(for: organization, membersLimit: membersLimit))
                }
            }

            var detailsByIndex = [Int: OrganizationsAPIFullOrganization]()
            for try await (index, detail) in group {
                detailsByIndex[index] = detail
            }
            return organizations.indices.compactMap { detailsByIndex[$0] }
        }
    }

    /// Fetches one organization's full detail, falling back to the dedicated members endpoint
    /// when `get-full-organization` omits members, and degrading to an empty-members record if
    /// the org can't be loaded so one failure doesn't sink the whole list.
    func detail(
        for organization: ProjectsAPIOrganization,
        membersLimit: Int = 100
    ) async -> OrganizationsAPIFullOrganization {
        do {
            let detail = try await self.getFullOrganization(id: organization.id, membersLimit: membersLimit)
            // `get-full-organization` can come back without members; fall back to the dedicated
            // members endpoint so the viewer's role can be resolved correctly.
            guard detail.members.isEmpty else { return detail }

            let members = try await self.listMembers(organizationID: organization.id, limit: membersLimit)
            return OrganizationsAPIFullOrganization(organization: detail.organization, members: members)
        } catch {
            return OrganizationsAPIFullOrganization(organization: organization, members: [])
        }
    }

    func getFullOrganization(
        id organizationID: String,
        membersLimit: Int = 100
    ) async throws -> OrganizationsAPIFullOrganization {
        let request = try self.requestService.makeAuthRequest(
            pathComponents: ["organization", "get-full-organization"],
            queryItems: [
                URLQueryItem(name: "organizationId", value: organizationID),
                URLQueryItem(name: "membersLimit", value: "\(membersLimit)"),
            ],
            method: "GET"
        )

        return try await self.requestService.decode(OrganizationsAPIFullOrganization.self, from: request)
    }

    func listMembers(
        organizationID: String,
        limit: Int = 100,
        offset: Int = 0
    ) async throws -> [OrganizationsAPIMember] {
        let request = try self.requestService.makeAuthRequest(
            pathComponents: ["organization", "list-members"],
            queryItems: [
                URLQueryItem(name: "organizationId", value: organizationID),
                URLQueryItem(name: "limit", value: "\(limit)"),
                URLQueryItem(name: "offset", value: "\(offset)"),
            ],
            method: "GET"
        )

        let data = try await self.requestService.data(from: request)
        return try Self.decodeMembers(from: data)
    }

    func checkSlugAvailable(_ slug: String) async throws -> Bool {
        let request = try self.requestService.makeAuthRequest(
            pathComponents: ["organization", "check-slug"],
            method: "POST",
            body: CheckOrganizationSlugRequest(slug: slug)
        )

        do {
            let data = try await self.requestService.data(from: request)
            return try Self.decodeSlugAvailability(from: data)
        } catch let RequestServiceError.invalidInput(message) where Self.isDuplicateSlugErrorMessage(message) {
            return false
        }
    }

    func createOrganization(name: String, slug: String, logo: String? = nil) async throws -> ProjectsAPIOrganization {
        let request = try self.requestService.makeAuthRequest(
            pathComponents: ["organization", "create"],
            method: "POST",
            body: CreateOrganizationRequest(
                name: name,
                slug: slug,
                logo: logo,
                keepCurrentActiveOrganization: true
            )
        )

        let data = try await self.requestService.data(from: request)
        return try Self.decodeOrganization(from: data)
    }

    func updateMemberRole(
        organizationID: String,
        memberID: String,
        role: OrgRole
    ) async throws {
        let request = try self.requestService.makeAuthRequest(
            pathComponents: ["organization", "update-member-role"],
            method: "POST",
            body: UpdateOrganizationMemberRoleRequest(
                role: role.rawValue,
                memberID: memberID,
                organizationID: organizationID
            )
        )

        try await self.requestService.send(request)
    }

    func removeMember(organizationID: String, memberIDOrEmail: String) async throws {
        let request = try self.requestService.makeAuthRequest(
            pathComponents: ["organization", "remove-member"],
            method: "POST",
            body: RemoveOrganizationMemberRequest(
                memberIDOrEmail: memberIDOrEmail,
                organizationID: organizationID
            )
        )

        try await self.requestService.send(request)
    }

    func deleteOrganization(id organizationID: String) async throws {
        let request = try self.requestService.makeAuthRequest(
            pathComponents: ["organization", "delete"],
            method: "POST",
            body: OrganizationIDRequest(organizationID: organizationID)
        )

        try await self.requestService.send(request)
    }

    func leaveOrganization(id organizationID: String) async throws {
        let request = try self.requestService.makeAuthRequest(
            pathComponents: ["organization", "leave"],
            method: "POST",
            body: OrganizationIDRequest(organizationID: organizationID)
        )

        try await self.requestService.send(request)
    }

    func inviteMember(organizationID: String, email: String, role: OrgRole, resend: Bool = false) async throws {
        let request = try self.requestService.makeAuthRequest(
            pathComponents: ["organization", "invite-member"],
            method: "POST",
            body: InviteOrganizationMemberRequest(
                email: email,
                role: role.rawValue,
                organizationID: organizationID,
                resend: resend ? true : nil
            )
        )

        try await self.requestService.send(request)
    }

    /// Outstanding invitations an organization has sent (admin/owner only).
    func listInvitations(organizationID: String) async throws -> [OrganizationsAPIInvitation] {
        let request = try self.requestService.makeAuthRequest(
            pathComponents: ["organization", "list-invitations"],
            queryItems: [URLQueryItem(name: "organizationId", value: organizationID)],
            method: "GET"
        )

        let data = try await self.requestService.data(from: request)
        return try Self.decodeInvitations(from: data)
    }

    func cancelInvitation(id invitationID: String) async throws {
        let request = try self.requestService.makeAuthRequest(
            pathComponents: ["organization", "cancel-invitation"],
            method: "POST",
            body: InvitationIDRequest(invitationID: invitationID)
        )

        try await self.requestService.send(request)
    }

    /// Invitations the signed-in user has received across every organization.
    func listUserInvitations() async throws -> [OrganizationsAPIInvitation] {
        let request = try self.requestService.makeAuthRequest(
            pathComponents: ["organization", "list-user-invitations"],
            method: "GET"
        )

        let data = try await self.requestService.data(from: request)
        return try Self.decodeInvitations(from: data)
    }

    func acceptInvitation(id invitationID: String) async throws {
        let request = try self.requestService.makeAuthRequest(
            pathComponents: ["organization", "accept-invitation"],
            method: "POST",
            body: InvitationIDRequest(invitationID: invitationID)
        )

        try await self.requestService.send(request)
    }

    func rejectInvitation(id invitationID: String) async throws {
        let request = try self.requestService.makeAuthRequest(
            pathComponents: ["organization", "reject-invitation"],
            method: "POST",
            body: InvitationIDRequest(invitationID: invitationID)
        )

        try await self.requestService.send(request)
    }

    // MARK: Private

    private static func decodeSlugAvailability(from data: Data) throws -> Bool {
        if let value = try? JSONDecoder().decode(Bool.self, from: data) {
            return value
        }

        let response = try JSONDecoder().decode(CheckOrganizationSlugResponse.self, from: data)
        if let available = response.available {
            return available
        }
        if let status = response.status {
            return status
        }
        if let taken = response.taken {
            return !taken
        }

        throw RequestServiceError.decodingFailed(DecodingError.dataCorrupted(.init(
            codingPath: [],
            debugDescription: "Slug availability response did not include an availability field."
        )))
    }

    private static func isDuplicateSlugErrorMessage(_ message: String?) -> Bool {
        guard let message else { return false }

        let normalizedMessage = message.lowercased()
        return normalizedMessage.contains("duplicate")
            && normalizedMessage.contains("slug")
    }

    private static func decodeOrganization(from data: Data) throws -> ProjectsAPIOrganization {
        if let organization = try? JSONDecoder().decode(ProjectsAPIOrganization.self, from: data) {
            return organization
        }

        return try JSONDecoder().decode(OrganizationResponse.self, from: data).organization
    }

    private static func decodeMembers(from data: Data) throws -> [OrganizationsAPIMember] {
        if let members = try? JSONDecoder().decode([OrganizationsAPIMember].self, from: data) {
            return members
        }

        return try JSONDecoder().decode(OrganizationsAPIMembersResponse.self, from: data).members
    }

    private static func decodeInvitations(from data: Data) throws -> [OrganizationsAPIInvitation] {
        if let invitations = try? JSONDecoder().decode([OrganizationsAPIInvitation].self, from: data) {
            return invitations
        }

        return try JSONDecoder().decode(OrganizationsAPIInvitationsResponse.self, from: data).invitations
    }
}
