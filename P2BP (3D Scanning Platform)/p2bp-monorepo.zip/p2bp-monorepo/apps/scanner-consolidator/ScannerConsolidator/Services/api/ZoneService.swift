import Foundation
import ZIPFoundation

// MARK: - ZonesService

nonisolated struct ZonesService {
    // MARK: Lifecycle

    init(
        requestService: RequestService? = nil,
        authService: AuthService = .shared,
        urlSession: URLSession = .shared,
        apiBaseURL: URL = RequestService.defaultAPIBaseURL,
        authBaseURL: URL = RequestService.defaultAuthBaseURL,
        organizationID: String,
        projectID: String
    ) {
        self.requestService = requestService ?? RequestService(
            authService: authService,
            urlSession: urlSession,
            apiBaseURL: apiBaseURL,
            authBaseURL: authBaseURL
        )
        self.organizationID = organizationID
        self.projectID = projectID
    }

    // MARK: Internal

    let requestService: RequestService
    let organizationID: String
    let projectID: String

    static func scanArchiveID(from objectKey: String?) -> UUID? {
        guard let objectKey else { return nil }
        let filename = URL(fileURLWithPath: objectKey).lastPathComponent
        let rawID = filename.hasSuffix(".zip") ? String(filename.dropLast(4)) : filename
        return UUID(uuidString: rawID)
    }

    func listZones() async throws -> [ZonesAPIZone] {
        try self.validateServiceScope()

        let request = try self.makeZonesRequest(pathComponents: [], method: "GET")

        return try await self.requestService.decode([ZonesAPIZone].self, from: request)
    }

    func fetchZone(zoneID: String) async throws -> ZonesAPIZone {
        try Self.validateRequiredID(zoneID, name: "zoneID")

        let request = try self.makeZonesRequest(pathComponents: [zoneID], method: "GET")

        return try await self.requestService.decode(ZonesAPIZone.self, from: request)
    }

    func updateZone(zoneID: String, request updateRequest: UpdateZonesAPIZoneRequest) async throws -> ZonesAPIZone {
        try Self.validateRequiredID(zoneID, name: "zoneID")

        let request = try self.makeZonesRequest(
            pathComponents: [zoneID],
            method: "PATCH",
            body: updateRequest
        )

        return try await self.requestService.decode(ZonesAPIZone.self, from: request)
    }

    func createScanArchiveUploadURL(zoneID: String) async throws -> ZonesAPIScanArchiveUploadURLResponse {
        try Self.validateRequiredID(zoneID, name: "zoneID")

        let request = try self.makeZonesRequest(
            pathComponents: [zoneID, "scan-archive", "upload-url"],
            method: "POST"
        )

        let response = try await self.requestService.decode(ZonesAPIScanArchiveUploadURLResponse.self, from: request)
        try Self.validateURL(response.uploadURL, field: "uploadUrl")
        return response
    }

    /// Zips the contents of a `.scanproject` bundle and uploads the archive to the zone's
    /// pre-signed scan-archive upload URL via `PUT`.
    @discardableResult
    func uploadZone(
        zoneID: String,
        scanProjectDirectory: URL
    ) async throws -> ZonesAPIScanArchiveUploadURLResponse {
        let uploadURLResponse = try await self.createScanArchiveUploadURL(zoneID: zoneID)

        let archiveURL = try Self.makeScanArchive(from: scanProjectDirectory)
        defer { try? FileManager.default.removeItem(at: archiveURL) }

        try await self.putPresignedFile(
            at: archiveURL,
            to: uploadURLResponse.uploadURL,
            contentType: uploadURLResponse.requiredHeaders.contentType
        )

        let previewURL = scanProjectDirectory.appendingPathComponent("preview.bin")
        guard FileManager.default.fileExists(atPath: previewURL.path),
              let previewUploadURL = uploadURLResponse.previewUploadURL,
              let previewRequiredHeaders = uploadURLResponse.previewRequiredHeaders
        else {
            return uploadURLResponse
        }

        try await self.putPresignedFile(
            at: previewURL,
            to: previewUploadURL,
            contentType: previewRequiredHeaders.contentType
        )

        return uploadURLResponse
    }

    func listScanArchives(
        zoneID: String,
        limit: Int? = nil,
        reconcileLimit: Int? = nil
    ) async throws -> [ZonesAPIScanArchive] {
        try Self.validateRequiredID(zoneID, name: "zoneID")
        try Self.validateLimit(limit)
        try Self.validateReconcileLimit(reconcileLimit)

        var queryItems = [URLQueryItem]()

        if let limit {
            queryItems.append(URLQueryItem(name: "limit", value: "\(limit)"))
        }
        if let reconcileLimit {
            queryItems.append(URLQueryItem(name: "reconcileLimit", value: "\(reconcileLimit)"))
        }

        let request = try self.makeZonesRequest(
            pathComponents: [zoneID, "scan-archives"],
            queryItems: queryItems,
            method: "GET"
        )

        return try await self.requestService.decode([ZonesAPIScanArchive].self, from: request)
    }

    func fetchScanArchiveDownloadURL(
        zoneID: String,
        archiveID: String
    ) async throws -> ZonesAPIScanDownloadURLResponse {
        try Self.validateRequiredID(zoneID, name: "zoneID")
        try Self.validateRequiredID(archiveID, name: "archiveID")

        let request = try self.makeZonesRequest(
            pathComponents: [zoneID, "scan-archives", archiveID, "scan", "download-url"],
            method: "GET"
        )

        let response = try await self.requestService.decode(ZonesAPIScanDownloadURLResponse.self, from: request)
        try Self.validateOptionalURL(response.downloadURL, field: "downloadUrl")
        return response
    }

    func fetchPreviewFile(zoneID: String, archiveID: String) async throws -> ZonesAPIPreviewFile {
        let response = try await self.fetchPreviewDownloadURL(zoneID: zoneID, archiveID: archiveID)
        guard let downloadURL = response.downloadURL else {
            throw ZonesServiceError.downloadUnavailable
        }

        let data = try await self.requestService.downloadPresignedFile(from: downloadURL)
        return ZonesAPIPreviewFile(
            archiveID: archiveID,
            previewObjectKey: response.previewObjectKey,
            data: data
        )
    }

    func fetchPreviewDownloadURL(
        zoneID: String,
        archiveID: String
    ) async throws -> ZonesAPIPreviewDownloadURLResponse {
        try Self.validateRequiredID(zoneID, name: "zoneID")
        try Self.validateRequiredID(archiveID, name: "archiveID")

        let request = try self.makeZonesRequest(
            pathComponents: [zoneID, "scan-archives", archiveID, "preview", "download-url"],
            method: "GET"
        )

        let response = try await self.requestService.decode(ZonesAPIPreviewDownloadURLResponse.self, from: request)
        try Self.validateOptionalURL(response.downloadURL, field: "downloadUrl")
        return response
    }

    func selectScanArchive(zoneID: String, archiveID: String) async throws -> ZonesAPIZone {
        try Self.validateRequiredID(zoneID, name: "zoneID")
        try Self.validateRequiredID(archiveID, name: "archiveID")

        let request = try self.makeZonesRequest(
            pathComponents: [zoneID, "scan-archives", archiveID, "select"],
            method: "POST"
        )

        return try await self.requestService.decode(ZonesAPIZone.self, from: request)
    }

    func putPresignedFile(
        at fileURL: URL,
        to uploadURLString: String,
        contentType: String
    ) async throws {
        guard let uploadURL = URL(string: uploadURLString) else {
            throw ZonesServiceError.invalidURL(field: "uploadUrl", value: uploadURLString)
        }

        var request = URLRequest(url: uploadURL)
        request.httpMethod = "PUT"
        request.setValue(contentType, forHTTPHeaderField: "Content-Type")

        let response: URLResponse
        do {
            (_, response) = try await self.requestService.urlSession.upload(for: request, fromFile: fileURL)
        } catch {
            throw ZonesServiceError.uploadFailed(statusCode: nil, underlying: error)
        }

        guard let httpResponse = response as? HTTPURLResponse else {
            throw ZonesServiceError.uploadFailed(statusCode: nil, underlying: nil)
        }

        guard (200 ... 299).contains(httpResponse.statusCode) else {
            throw ZonesServiceError.uploadFailed(statusCode: httpResponse.statusCode, underlying: nil)
        }
    }

    // MARK: Private

    private var basePathComponents: [String] {
        ["organizations", self.organizationID, "projects", self.projectID, "zones"]
    }

    private static func validateRequiredID(_ value: String, name: String) throws {
        if value.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            throw ZonesServiceError.missingRequiredIdentifier(name)
        }
    }

    private static func validateLimit(_ limit: Int?) throws {
        guard let limit else { return }

        if !(1 ... 100).contains(limit) {
            throw ZonesServiceError.invalidLimit(limit)
        }
    }

    private static func validateReconcileLimit(_ reconcileLimit: Int?) throws {
        guard let reconcileLimit else { return }

        if !(0 ... 10).contains(reconcileLimit) {
            throw ZonesServiceError.invalidReconcileLimit(reconcileLimit)
        }
    }

    /// Zips the *contents* of the supplied `.scanproject` directory (without the wrapping folder)
    /// into a temporary `.zip` file and returns its URL. The caller is responsible for cleanup.
    private static func makeScanArchive(from scanProjectDirectory: URL) throws -> URL {
        let fileManager = FileManager.default

        var isDirectory: ObjCBool = false
        guard
            fileManager.fileExists(atPath: scanProjectDirectory.path, isDirectory: &isDirectory),
            isDirectory.boolValue
        else {
            throw ZonesServiceError.scanProjectUnavailable(scanProjectDirectory)
        }

        let archiveURL = fileManager.temporaryDirectory
            .appendingPathComponent(UUID().uuidString)
            .appendingPathExtension("zip")

        do {
            // `shouldKeepParent: false` stores the directory's contents at the archive root
            // rather than nesting them inside a `<id>.scanproject/` folder.
            try fileManager.zipItem(
                at: scanProjectDirectory,
                to: archiveURL,
                shouldKeepParent: false,
                compressionMethod: .deflate
            )
        } catch {
            throw ZonesServiceError.archiveCreationFailed(error)
        }

        return archiveURL
    }

    private static func validateURL(_ value: String, field: String) throws {
        guard let url = URL(string: value), url.scheme != nil, url.host != nil else {
            throw ZonesServiceError.invalidURL(field: field, value: value)
        }
    }

    private static func validateOptionalURL(_ value: String?, field: String) throws {
        guard let value else { return }

        try Self.validateURL(value, field: field)
    }

    private func validateServiceScope() throws {
        try Self.validateRequiredID(self.organizationID, name: "organizationID")
        try Self.validateRequiredID(self.projectID, name: "projectID")
    }

    private func makeZonesRequest(
        pathComponents: [String],
        queryItems: [URLQueryItem] = [],
        method: String
    ) throws -> URLRequest {
        try self.validateServiceScope()

        return try self.requestService.makeRequest(
            baseURL: self.requestService.apiBaseURL,
            pathComponents: self.basePathComponents + pathComponents,
            queryItems: queryItems,
            method: method
        )
    }

    private func makeZonesRequest(
        pathComponents: [String],
        method: String,
        body: some Encodable
    ) throws -> URLRequest {
        try self.validateServiceScope()

        return try self.requestService.makeAPIRequest(
            pathComponents: self.basePathComponents + pathComponents,
            method: method,
            body: body
        )
    }
}

// MARK: - ZoneService

typealias ZoneService = ZonesService
