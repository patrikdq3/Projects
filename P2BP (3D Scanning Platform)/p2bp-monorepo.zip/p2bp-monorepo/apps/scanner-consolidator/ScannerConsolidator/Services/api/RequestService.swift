import Foundation

// MARK: - RequestService

nonisolated struct RequestService {
    // MARK: Lifecycle

    init(
        authService: AuthService = .shared,
        urlSession: URLSession = .shared,
        apiBaseURL: URL = Self.defaultAPIBaseURL,
        authBaseURL: URL = Self.defaultAuthBaseURL
    ) {
        self.authService = authService
        self.urlSession = urlSession
        self.apiBaseURL = apiBaseURL
        self.authBaseURL = authBaseURL
    }

    // MARK: Internal

    static let defaultAPIBaseURL = Self.baseURL(path: "/api")
    static let defaultAuthBaseURL = Self.baseURL(path: "/api/auth")

    let authService: AuthService
    let urlSession: URLSession
    let apiBaseURL: URL
    let authBaseURL: URL

    func makeAPIRequest(
        pathComponents: [String],
        method: String
    ) throws -> URLRequest {
        try self.makeRequest(
            baseURL: self.apiBaseURL,
            pathComponents: pathComponents,
            method: method
        )
    }

    func makeAPIRequest(
        pathComponents: [String],
        queryItems: [URLQueryItem],
        method: String
    ) throws -> URLRequest {
        try self.makeRequest(
            baseURL: self.apiBaseURL,
            pathComponents: pathComponents,
            queryItems: queryItems,
            method: method
        )
    }

    func makeAPIRequest(
        pathComponents: [String],
        method: String,
        body: some Encodable
    ) throws -> URLRequest {
        try self.makeRequest(
            baseURL: self.apiBaseURL,
            pathComponents: pathComponents,
            method: method,
            body: body
        )
    }

    func makeAuthRequest(
        pathComponents: [String],
        method: String
    ) throws -> URLRequest {
        try self.makeRequest(
            baseURL: self.authBaseURL,
            pathComponents: pathComponents,
            method: method
        )
    }

    func makeAuthRequest(
        pathComponents: [String],
        queryItems: [URLQueryItem],
        method: String
    ) throws -> URLRequest {
        try self.makeRequest(
            baseURL: self.authBaseURL,
            pathComponents: pathComponents,
            queryItems: queryItems,
            method: method
        )
    }

    func makeAuthRequest(
        pathComponents: [String],
        method: String,
        body: some Encodable
    ) throws -> URLRequest {
        try self.makeRequest(
            baseURL: self.authBaseURL,
            pathComponents: pathComponents,
            method: method,
            body: body
        )
    }

    func makeRequest(
        baseURL: URL,
        pathComponents: [String],
        method: String
    ) throws -> URLRequest {
        try self.makeRequest(
            baseURL: baseURL,
            pathComponents: pathComponents,
            queryItems: [],
            method: method,
            bodyData: nil
        )
    }

    func makeRequest(
        baseURL: URL,
        pathComponents: [String],
        queryItems: [URLQueryItem],
        method: String
    ) throws -> URLRequest {
        try self.makeRequest(
            baseURL: baseURL,
            pathComponents: pathComponents,
            queryItems: queryItems,
            method: method,
            bodyData: nil
        )
    }

    func makeRequest(
        baseURL: URL,
        pathComponents: [String],
        method: String,
        body: some Encodable
    ) throws -> URLRequest {
        let bodyData = try JSONEncoder().encode(body)

        return try self.makeRequest(
            baseURL: baseURL,
            pathComponents: pathComponents,
            queryItems: [],
            method: method,
            bodyData: bodyData
        )
    }

    func downloadPresignedFile(from downloadURLString: String) async throws -> Data {
        guard let downloadURL = URL(string: downloadURLString) else {
            throw RequestServiceError.invalidPresignedURL(field: "downloadUrl", value: downloadURLString)
        }

        let response: URLResponse
        let data: Data
        do {
            (data, response) = try await self.urlSession.data(from: downloadURL)
        } catch {
            throw RequestServiceError.presignedDownloadFailed(statusCode: nil, underlying: error)
        }

        guard let httpResponse = response as? HTTPURLResponse else {
            throw RequestServiceError.presignedDownloadFailed(statusCode: nil, underlying: nil)
        }

        guard (200 ... 299).contains(httpResponse.statusCode) else {
            throw RequestServiceError.presignedDownloadFailed(statusCode: httpResponse.statusCode, underlying: nil)
        }

        return data
    }

    func downloadPresignedFile(from downloadURLString: String, to destinationURL: URL) async throws {
        guard let downloadURL = URL(string: downloadURLString) else {
            throw RequestServiceError.invalidPresignedURL(field: "downloadUrl", value: downloadURLString)
        }

        let temporaryURL: URL
        let response: URLResponse
        do {
            (temporaryURL, response) = try await self.urlSession.download(from: downloadURL)
        } catch {
            throw RequestServiceError.presignedDownloadFailed(statusCode: nil, underlying: error)
        }

        guard let httpResponse = response as? HTTPURLResponse else {
            throw RequestServiceError.presignedDownloadFailed(statusCode: nil, underlying: nil)
        }

        guard (200 ... 299).contains(httpResponse.statusCode) else {
            throw RequestServiceError.presignedDownloadFailed(statusCode: httpResponse.statusCode, underlying: nil)
        }

        do {
            try Task.checkCancellation()
            try FileManager.default.createDirectory(
                at: destinationURL.deletingLastPathComponent(),
                withIntermediateDirectories: true
            )
            if FileManager.default.fileExists(atPath: destinationURL.path) {
                try FileManager.default.removeItem(at: destinationURL)
            }
            try FileManager.default.moveItem(at: temporaryURL, to: destinationURL)
        } catch is CancellationError {
            throw CancellationError()
        } catch {
            throw RequestServiceError.presignedDownloadFailed(statusCode: nil, underlying: error)
        }
    }

    func data(from request: URLRequest) async throws -> Data {
        let data: Data
        let response: URLResponse

        do {
            (data, response) = try await self.urlSession.data(for: request)
        } catch {
            throw RequestServiceError.network(error)
        }

        guard let httpResponse = response as? HTTPURLResponse else {
            throw RequestServiceError.invalidResponse
        }

        guard (200 ... 299).contains(httpResponse.statusCode) else {
            throw self.error(for: httpResponse.statusCode, data: data)
        }

        return data
    }

    func send(_ request: URLRequest) async throws {
        _ = try await self.data(from: request)
    }

    func decode<Response: Decodable>(
        _ responseType: Response.Type,
        from request: URLRequest
    ) async throws -> Response {
        let data = try await self.data(from: request)

        do {
            return try JSONDecoder().decode(responseType, from: data)
        } catch {
            throw RequestServiceError.decodingFailed(error)
        }
    }

    // MARK: Private

    private static let originHeaderValue = "https://\(AppEnvironment.apiHost)/"

    private static func baseURL(path: String) -> URL {
        var components = URLComponents()
        components.scheme = "https"
        components.host = AppEnvironment.apiHost
        components.path = path

        guard let url = components.url else {
            preconditionFailure("Invalid API base URL.")
        }

        return url
    }

    private func makeRequest(
        baseURL: URL,
        pathComponents: [String],
        queryItems: [URLQueryItem],
        method: String,
        bodyData: Data?
    ) throws -> URLRequest {
        let token: String
        do {
            token = try self.authService.getToken()
        } catch {
            throw RequestServiceError.missingAuthToken
        }

        var url = baseURL
        for pathComponent in pathComponents {
            url.append(path: pathComponent)
        }

        if !queryItems.isEmpty {
            guard var components = URLComponents(url: url, resolvingAgainstBaseURL: false) else {
                throw RequestServiceError.invalidURL
            }
            components.queryItems = queryItems

            guard let queryURL = components.url else {
                throw RequestServiceError.invalidURL
            }
            url = queryURL
        }

        var request = URLRequest(url: url)
        request.httpMethod = method
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue(Self.originHeaderValue, forHTTPHeaderField: "Origin")
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        request.httpBody = bodyData

        return request
    }

    private func error(for statusCode: Int, data: Data) -> RequestServiceError {
        let apiError = try? JSONDecoder().decode(RequestServiceErrorResponse.self, from: data)
        let responseText = String(data: data, encoding: .utf8)
        let message = apiError?.message ?? apiError?.error ?? responseText?.nilIfBlank

        switch statusCode {
        case 400:
            return .invalidInput(message)
        case 401:
            return .unauthorized
        case 403:
            return .forbidden
        case 404:
            return .notFound
        case 409:
            return .conflict(message)
        default:
            return .requestFailed(statusCode: statusCode, message: message)
        }
    }
}

// MARK: - RequestServiceError

nonisolated enum RequestServiceError: LocalizedError {
    case invalidURL
    case invalidPresignedURL(field: String, value: String)
    case missingAuthToken
    case invalidResponse
    case invalidInput(String?)
    case unauthorized
    case forbidden
    case notFound
    case conflict(String?)
    case requestFailed(statusCode: Int, message: String?)
    case presignedDownloadFailed(statusCode: Int?, underlying: Error?)
    case decodingFailed(Error)
    case network(Error)

    // MARK: Internal

    var errorDescription: String? {
        switch self {
        case .invalidURL:
            "Request URL could not be built."
        case let .invalidPresignedURL(field, value):
            "Presigned URL for \(field) is invalid: \(value)."
        case .missingAuthToken:
            "You are not signed in."
        case .invalidResponse:
            "The server returned an invalid response."
        case let .invalidInput(message):
            Self.message("The server rejected the upload request.", detail: message)
        case .unauthorized:
            "Your session expired. Sign in again."
        case .forbidden:
            "You do not have permission to upload this zone."
        case .notFound:
            "The project or zone was not found on the server."
        case let .conflict(message):
            Self.message("The request conflicts with the current server state.", detail: message)
        case let .requestFailed(statusCode, message):
            Self.message("Request failed with status code \(statusCode).", detail: message)
        case let .presignedDownloadFailed(statusCode, underlying):
            if let statusCode {
                "Presigned file download failed with status code \(statusCode)."
            } else if let underlying {
                "Presigned file download failed: \(underlying.localizedDescription)."
            } else {
                "Presigned file download failed with an unexpected response."
            }
        case let .decodingFailed(error):
            "The server response could not be read: \(error.localizedDescription)"
        case let .network(error):
            "Network request failed: \(error.localizedDescription)"
        }
    }

    // MARK: Private

    private nonisolated static func message(_ summary: String, detail: String?) -> String {
        guard let detail = detail?.nilIfBlank else { return summary }
        return "\(summary) \(detail)"
    }
}

// MARK: - RequestServiceErrorResponse

private nonisolated struct RequestServiceErrorResponse: Decodable {
    let error: String?
    let message: String?
}

private extension String {
    nonisolated var nilIfBlank: String? {
        let trimmed = self.trimmingCharacters(in: .whitespacesAndNewlines)
        return trimmed.isEmpty ? nil : trimmed
    }
}
