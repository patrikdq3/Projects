import Foundation

// MARK: - ProjectsService

nonisolated struct ProjectsService {
    // MARK: Lifecycle

    init(
        requestService: RequestService? = nil,
        authService: AuthService = .shared,
        urlSession: URLSession = .shared,
        apiBaseURL: URL = RequestService.defaultAPIBaseURL,
        authBaseURL: URL = RequestService.defaultAuthBaseURL
    ) {
        self.requestService = requestService ?? RequestService(
            authService: authService,
            urlSession: urlSession,
            apiBaseURL: apiBaseURL,
            authBaseURL: authBaseURL
        )
    }

    // MARK: Internal

    let requestService: RequestService

    func listProjects(organizationID: String) async throws -> [ProjectsAPIProject] {
        let request = try self.makeProjectRequest(
            organizationID: organizationID,
            pathComponents: [],
            method: "GET"
        )

        return try await self.requestService.decode([ProjectsAPIProject].self, from: request)
    }

    func fetchProject(organizationID: String, projectID: String) async throws -> ProjectsAPIProject {
        let request = try self.makeProjectRequest(
            organizationID: organizationID,
            pathComponents: [projectID],
            method: "GET"
        )

        return try await self.requestService.decode(ProjectsAPIProject.self, from: request)
    }

    func createProject(
        organizationID: String,
        request createRequest: CreateProjectsAPIProjectRequest
    ) async throws -> ProjectsAPIProject {
        let request = try self.makeProjectRequest(
            organizationID: organizationID,
            pathComponents: [],
            method: "POST",
            body: createRequest
        )

        return try await self.requestService.decode(ProjectsAPIProject.self, from: request)
    }

    func updateProject(
        organizationID: String,
        projectID: String,
        request updateRequest: UpdateProjectsAPIProjectRequest
    ) async throws -> ProjectsAPIProject {
        let request = try self.makeProjectRequest(
            organizationID: organizationID,
            pathComponents: [projectID],
            method: "PATCH",
            body: updateRequest
        )

        return try await self.requestService.decode(ProjectsAPIProject.self, from: request)
    }

    func deleteProject(organizationID: String, projectID: String) async throws -> Bool {
        let request = try self.makeProjectRequest(
            organizationID: organizationID,
            pathComponents: [projectID],
            method: "DELETE"
        )

        let response = try await self.requestService.decode(DefaultSuccessResponse.self, from: request)
        return response.success
    }

    func fetchMergeLAZFile(
        organizationID: String,
        projectID: String,
        jobID: String? = nil,
        destinationURL: URL
    ) async throws -> URL {
        try await self.fetchMergedArtifactFile(
            organizationID: organizationID,
            projectID: projectID,
            jobID: jobID,
            artifact: .fullLAZ,
            destinationURL: destinationURL
        ).fileURL
    }

    /// In-memory counterpart to the `destinationURL` overload, for merged artifacts that are
    /// parsed straight from `Data` rather than handed to a file-backed viewer. Artifact-kind
    /// driven, so a future merged output format can use it without new plumbing.
    func fetchMergedArtifactFile(
        organizationID: String,
        projectID: String,
        jobID: String? = nil,
        artifact: MeshArtifactKind
    ) async throws -> MeshFile {
        let request = try self.makeProjectRequest(
            organizationID: organizationID,
            pathComponents: self.mergedArtifactPathComponents(
                projectID: projectID,
                jobID: jobID,
                artifact: artifact
            ),
            method: "GET"
        )

        let response = try await self.decodeMergeDownloadResponse(GetMeshJobResponse.self, from: request)
        let data = try await self.downloadMergeFile(from: response.downloadURL)

        return MeshFile(objectKey: response.objectKey, data: data)
    }

    func fetchMergedArtifactFile(
        organizationID: String,
        projectID: String,
        jobID: String? = nil,
        artifact: MeshArtifactKind,
        destinationURL: URL
    ) async throws -> DownloadedMeshArtifact {
        let request = try self.makeProjectRequest(
            organizationID: organizationID,
            pathComponents: self.mergedArtifactPathComponents(
                projectID: projectID,
                jobID: jobID,
                artifact: artifact
            ),
            method: "GET"
        )
        let response = try await self.decodeMergeDownloadResponse(GetMeshJobResponse.self, from: request)

        try await self.downloadMergeFile(from: response.downloadURL, to: destinationURL)
        return DownloadedMeshArtifact(objectKey: response.objectKey, fileURL: destinationURL)
    }

    func listMeshJobs(
        organizationID: String,
        projectID: String,
        limit: Int = 100
    ) async throws -> [MeshJob] {
        guard (1 ... 100).contains(limit) else {
            throw ProjectsServiceError.invalidMeshJobLimit(limit)
        }

        let request = try self.makeProjectRequest(
            organizationID: organizationID,
            pathComponents: [projectID, "mesh-jobs"],
            queryItems: [URLQueryItem(name: "limit", value: "\(limit)")],
            method: "GET"
        )

        return try await self.requestService.decode(MeshJobsResponse.self, from: request).jobs
    }

    func fetchMeshJob(
        organizationID: String,
        projectID: String,
        jobID: String
    ) async throws -> MeshJob {
        let request = try self.makeProjectRequest(
            organizationID: organizationID,
            pathComponents: [projectID, "mesh-jobs", jobID],
            method: "GET"
        )

        return try await self.requestService.decode(MeshJobResponse.self, from: request).job
    }

    func launchMeshJob(
        organizationID: String,
        projectID: String,
        force: Bool = false
    ) async throws -> LaunchMeshJobResponse {
        let queryItems = force ? [URLQueryItem(name: "force", value: "true")] : []
        let request = try self.makeProjectRequest(
            organizationID: organizationID,
            pathComponents: [projectID, "mesh-jobs"],
            queryItems: queryItems,
            method: "POST"
        )

        do {
            return try await self.requestService.decode(LaunchMeshJobResponse.self, from: request)
        } catch {
            if Self.isNoUploadedScansAvailableError(error) {
                throw ProjectsServiceError.noUploadedScansAvailable
            }

            throw error
        }
    }

    // MARK: Private

    private static func isNoUploadedScansAvailableError(_ error: Error) -> Bool {
        guard case let RequestServiceError.invalidInput(message) = error else {
            return false
        }

        return Self.isNoUploadedScansAvailableErrorMessage(message)
    }

    private static func isNoUploadedScansAvailableErrorMessage(_ message: String?) -> Bool {
        message == "No uploaded zone scans available for this project"
    }

    private func decodeMergeDownloadResponse<Response: Decodable>(
        _ responseType: Response.Type,
        from request: URLRequest
    ) async throws -> Response {
        do {
            return try await self.requestService.decode(responseType, from: request)
        } catch RequestServiceError.notFound {
            throw ProjectsServiceError.noMergeJobForProject
        }
    }

    private func downloadMergeFile(from downloadURLString: String) async throws -> Data {
        do {
            return try await self.requestService.downloadPresignedFile(from: downloadURLString)
        } catch RequestServiceError.presignedDownloadFailed(statusCode: 404, underlying: _) {
            throw ProjectsServiceError.noMergeJobAvailableForProject
        }
    }

    private func downloadMergeFile(from downloadURLString: String, to destinationURL: URL) async throws {
        do {
            try await self.requestService.downloadPresignedFile(from: downloadURLString, to: destinationURL)
        } catch RequestServiceError.presignedDownloadFailed(statusCode: 404, underlying: _) {
            throw ProjectsServiceError.noMergeJobAvailableForProject
        }
    }

    private func mergedArtifactPathComponents(
        projectID: String,
        jobID: String?,
        artifact: MeshArtifactKind
    ) -> [String] {
        var pathComponents = [projectID]
        if let jobID {
            pathComponents.append(contentsOf: ["mesh-jobs", jobID])
        }
        pathComponents.append(contentsOf: artifact.pathComponents)
        return pathComponents
    }

    private func makeProjectRequest(
        organizationID: String,
        pathComponents: [String],
        method: String
    ) throws -> URLRequest {
        try self.requestService.makeAPIRequest(
            pathComponents: ["organizations", organizationID, "projects"] + pathComponents,
            method: method
        )
    }

    private func makeProjectRequest(
        organizationID: String,
        pathComponents: [String],
        queryItems: [URLQueryItem],
        method: String
    ) throws -> URLRequest {
        try self.requestService.makeAPIRequest(
            pathComponents: ["organizations", organizationID, "projects"] + pathComponents,
            queryItems: queryItems,
            method: method
        )
    }

    private func makeProjectRequest(
        organizationID: String,
        pathComponents: [String],
        method: String,
        body: some Encodable
    ) throws -> URLRequest {
        try self.requestService.makeAPIRequest(
            pathComponents: ["organizations", organizationID, "projects"] + pathComponents,
            method: method,
            body: body
        )
    }
}

// MARK: - ProjectsServiceError

nonisolated enum ProjectsServiceError: LocalizedError, Equatable {
    case invalidMeshJobLimit(Int)
    case noMergeJobAvailableForProject
    case noMergeJobForProject
    case noUploadedScansAvailable

    // MARK: Internal

    var errorDescription: String? {
        switch self {
        case let .invalidMeshJobLimit(limit):
            "Invalid mesh-job limit \(limit). Expected a value from 1 through 100."
        case .noMergeJobAvailableForProject:
            "No merge job available for this project."
        case .noMergeJobForProject:
            "No merge job for this project."
        case .noUploadedScansAvailable:
            "No uploaded scans are available for this project."
        }
    }
}
