import Foundation
import Security

final nonisolated class AuthService: Sendable {
    // MARK: Lifecycle

    private init() {} // don't allow instantiation

    // MARK: Internal

    /// let access of this service through AuthService.shared.*
    static let shared = AuthService()

    let baseURL = "https://\(AppEnvironment.apiHost)/api/auth"

    func emailLogin(email: String, password: String) async throws -> LoginResponse {
        guard let url = URL(string: "\(self.baseURL)/sign-in/email") else {
            throw AuthError.invalidURL
        }

        let body = EmailLoginRequest(email: email, password: password)

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        self.setHeaders(&request)
        request.httpBody = try JSONEncoder().encode(body)

        let (data, response) = try await URLSession.shared.data(for: request)

        guard let httpResponse = response as? HTTPURLResponse else {
            throw AuthError.invalidResponse
        }

        // anything other than a 200 response throws an exception
        guard (200 ... 299).contains(httpResponse.statusCode) else {
            let apiError = Self.apiError(from: data)
            if apiError?.code == "EMAIL_NOT_VERIFIED" {
                throw AuthError.emailNotVerified
            }
            switch httpResponse.statusCode {
            case 401: // failed login
                throw AuthError.unauthorized
            case _:
                throw AuthError.loginFailed(apiError?.message ?? "Login failed")
            }
        }

        do {
            let decodedResponse = try JSONDecoder().decode(LoginResponse.self, from: data)
            try self.saveToken(decodedResponse.token)

            return decodedResponse
        } catch is DecodingError {
            throw AuthError.invalidResponse
        } catch is TokenStoreError { // log this better in the future
            throw AuthError.storeAuthTokenError
        }
    }

    func emailSignUp(email: String, name: String, password: String) async throws -> EmailSignUpResponse {
        guard let url = URL(string: "\(self.baseURL)/sign-up/email") else {
            throw AuthError.invalidURL
        }

        let body = EmailSignUpRequest(email: email, name: name, password: password)

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        self.setHeaders(&request)
        request.httpBody = try JSONEncoder().encode(body)

        let (data, response) = try await URLSession.shared.data(for: request)

        guard let httpResponse = response as? HTTPURLResponse else {
            throw AuthError.invalidResponse
        }

        guard (200 ... 299).contains(httpResponse.statusCode) else {
            let apiError = Self.apiError(from: data)
            if apiError?.code == "PASSWORD_TOO_SHORT" {
                throw AuthError.passwordTooShort
            }
            throw AuthError.signUpFailed(apiError?.message ?? "Sign up failed")
        }

        do {
            let decodedResponse = try JSONDecoder().decode(EmailSignUpResponse.self, from: data)
            if let token = decodedResponse.token {
                try self.saveToken(token)
            }

            return decodedResponse
        } catch is DecodingError {
            throw AuthError.invalidResponse
        } catch is TokenStoreError {
            throw AuthError.storeAuthTokenError
        }
    }

    func signInWithApple(credential: AppleSignInCredential) async throws -> LoginResponse {
        guard let url = URL(string: "\(self.baseURL)/sign-in/social") else {
            throw AuthError.invalidURL
        }

        let body = AppleSocialSignInRequest(credential: credential)

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        self.setHeaders(&request)
        request.httpBody = try JSONEncoder().encode(body)

        let (data, response) = try await URLSession.shared.data(for: request)

        guard let httpResponse = response as? HTTPURLResponse else {
            throw AuthError.invalidResponse
        }

        guard (200 ... 299).contains(httpResponse.statusCode) else {
            let message = Self.apiError(from: data)?.message ?? "Sign in with Apple failed"
            if httpResponse.statusCode == 401 {
                throw AuthError.appleSignInFailed(message)
            }
            throw AuthError.appleSignInFailed(message)
        }

        do {
            let decodedResponse = try JSONDecoder().decode(LoginResponse.self, from: data)
            try self.saveToken(decodedResponse.token)

            return decodedResponse
        } catch is DecodingError {
            throw AuthError.invalidResponse
        } catch is TokenStoreError {
            throw AuthError.storeAuthTokenError
        }
    }

    // MARK: OTP verification

    func verifyEmailOTP(email: String, code otp: String) async throws -> VerifyEmailOtpResponse {
        guard let url = URL(string: "\(self.baseURL)/email-otp/verify-email") else {
            throw AuthError.invalidURL
        }

        let body = VerifyEmailOtpRequest(email: email, otp: otp)

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        self.setHeaders(&request)
        request.httpBody = try JSONEncoder().encode(body)

        let (data, response) = try await URLSession.shared.data(for: request)

        guard let httpResponse = response as? HTTPURLResponse else {
            throw AuthError.invalidResponse
        }

        guard (200 ... 299).contains(httpResponse.statusCode) else {
            throw Self.verifyEmailOTPError(statusCode: httpResponse.statusCode, data: data)
        }

        do {
            let decodedResponse = try JSONDecoder().decode(VerifyEmailOtpResponse.self, from: data)
            guard decodedResponse.status else {
                throw AuthError.otpVerificationFailed("Verification failed. Please try again.")
            }
            guard let token = decodedResponse.token else {
                throw AuthError.missingAuthToken
            }
            try self.saveToken(token)

            return decodedResponse
        } catch is DecodingError {
            throw AuthError.invalidResponse
        } catch is TokenStoreError { // log this better in the future
            throw AuthError.storeAuthTokenError
        }
    }

    /// Request a fresh one-time code for the given email.
    func resendEmailOTP(email: String) async throws -> ResendEmailOtpResponse {
        guard let url = URL(string: "\(self.baseURL)/email-otp/send-verification-otp") else {
            throw AuthError.invalidURL
        }

        let body = ResendEmailOtpRequest(email: email, type: .emailVerification)

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        self.setHeaders(&request)
        request.httpBody = try JSONEncoder().encode(body)

        let (data, response) = try await URLSession.shared.data(for: request)

        guard let httpResponse = response as? HTTPURLResponse else {
            throw AuthError.invalidResponse
        }

        guard (200 ... 299).contains(httpResponse.statusCode) else {
            let message = Self.apiError(from: data)?.message ?? "Could not resend code"
            throw AuthError.resendOtpFailed(message)
        }

        guard !data.isEmpty else {
            return ResendEmailOtpResponse(success: true)
        }

        do {
            return try JSONDecoder().decode(ResendEmailOtpResponse.self, from: data)
        } catch is DecodingError {
            throw AuthError.invalidResponse
        }
    }

    // MARK: session token utils

    func saveToken(_ token: String) throws {
        let data = Data(token.utf8)

        // Delete old token first
        try? self.clearToken()

        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: self.service,
            kSecAttrAccount as String: self.tokenID,
            kSecValueData as String: data,
        ]

        let status = SecItemAdd(query as CFDictionary, nil)

        if status != errSecSuccess {
            throw TokenStoreError.unhandledError(status)
        }
    }

    func getToken() throws -> String {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: self.service,
            kSecAttrAccount as String: self.tokenID,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne,
        ]

        var item: CFTypeRef?
        let status = SecItemCopyMatching(query as CFDictionary, &item)

        if status == errSecItemNotFound {
            throw TokenStoreError.tokenNotFound
        }

        if status != errSecSuccess {
            throw TokenStoreError.unhandledError(status)
        }

        guard let data = item as? Data else {
            throw TokenStoreError.invalidStoredData
        }

        guard let token = String(data: data, encoding: .utf8) else {
            throw TokenStoreError.invalidStoredData
        }

        return token
    }

    func clearToken() throws {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: self.service,
            kSecAttrAccount as String: self.tokenID,
        ]

        let status = SecItemDelete(query as CFDictionary)

        if status != errSecSuccess, status != errSecItemNotFound {
            throw TokenStoreError.unhandledError(status)
        }
    }

    func getSession() async -> GetSessionResponse? {
        guard let token = try? getToken() else {
            return nil
        }

        guard let url = URL(string: "\(self.baseURL)/get-session") else {
            return nil
        }

        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        self.setHeaders(&request)
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")

        do {
            let (data, response) = try await URLSession.shared.data(for: request)

            guard let httpResponse = response as? HTTPURLResponse,
                  200 ..< 300 ~= httpResponse.statusCode
            else {
                return nil
            }

            let decodedResponse = try JSONDecoder().decode(GetSessionResponse.self, from: data)

            let formatter = ISO8601DateFormatter()
            formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
            // if stored token expired, user needs to re-auth
            guard let expiresAt = formatter.date(from: decodedResponse.session.expiresAt),
                  expiresAt > Date()
            else {
                return nil
            }

            return decodedResponse
        } catch {
            return nil
        }
    }

    func logout() async -> Bool {
        guard let token = try? self.getToken() else {
            return true
        }
        guard let url = URL(string: "\(self.baseURL)/sign-out") else {
            return false
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        self.setHeaders(&request)
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")

        do {
            // setting body as empty {} json field, as we get a 500 response if we just send a nil/empty body
            request.httpBody = try JSONSerialization.data(
                withJSONObject: [:],
                options: []
            )

            let (_, response) = try await URLSession.shared.data(for: request)

            guard let httpResponse = response as? HTTPURLResponse else {
                return false
            }

            guard 200 ..< 300 ~= httpResponse.statusCode else {
                return false
            }

            try self.clearToken()
            return true
        } catch {
            return false
        }
    }

    // MARK: Private

    private let service = "com.ScannerConsolidator"
    private let tokenID = "sessionToken"

    private static func apiError(from data: Data) -> AuthAPIErrorResponse? {
        try? JSONDecoder().decode(AuthAPIErrorResponse.self, from: data)
    }

    private static func verifyEmailOTPError(statusCode: Int, data: Data) -> AuthError {
        let apiError = Self.apiError(from: data)
        switch (statusCode, apiError?.code) {
        case (401, _):
            return AuthError.unauthorized
        case (400, "INVALID_OTP"), (400, "OTP_EXPIRED"):
            return AuthError.incorrectOtp(apiError?.message ?? "That code didn’t match. Try again.")
        case (403, "TOO_MANY_ATTEMPTS"):
            let message = apiError?.message ?? "Too many incorrect attempts. Please request a new code."
            return AuthError.tooManyOtpAttempts(message)
        default:
            return AuthError.otpVerificationFailed(apiError?.message ?? "Could not verify code")
        }
    }

    private func setHeaders(_ request: inout URLRequest) {
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("https://\(AppEnvironment.apiHost)/", forHTTPHeaderField: "Origin")
    }
}
