import Foundation

enum ProjectCreationValidator {
    static let minimumVertexCount = 3
    static let maximumVertexCount = 16
    static let maximumAreaSquareMeters: Double = 10000 // ~100 m × 100 m

    static func canCreateProject(named name: String, boundary: ProjectBoundary?) -> Bool {
        let trimmedName = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmedName.isEmpty, let boundary else {
            return false
        }

        let vertexCount = boundary.vertices.count
        guard vertexCount >= Self.minimumVertexCount, vertexCount <= Self.maximumVertexCount else {
            return false
        }

        let area = boundary.areaSquareMeters
        return area > 0 && area <= Self.maximumAreaSquareMeters
    }
}
