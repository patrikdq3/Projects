import Foundation
import simd

// MARK: - CapturedPoint

/// One captured point sample stored in point-cloud chunk files.
nonisolated struct CapturedPoint: Codable, Hashable {
    // MARK: Lifecycle

    /// Creates a point record from a world-space position, color, confidence, and relative timestamp.
    init(
        position: SIMD3<Float>,
        red: UInt8,
        green: UInt8,
        blue: UInt8,
        confidence: UInt8,
        timestamp: TimeInterval
    ) {
        self.x = position.x
        self.y = position.y
        self.z = position.z
        self.red = red
        self.green = green
        self.blue = blue
        self.confidence = confidence
        self.timestamp = timestamp
    }

    // MARK: Internal

    /// Number of bytes used by the custom binary point layout written to disk.
    static let binaryRecordSize = 24

    var x: Float
    var y: Float
    var z: Float
    var red: UInt8
    var green: UInt8
    var blue: UInt8
    var confidence: UInt8
    var timestamp: TimeInterval

    /// Convenience access to the point position as a SIMD vector.
    var position: SIMD3<Float> {
        SIMD3(self.x, self.y, self.z)
    }
}

extension [CapturedPoint] {
    /// Serializes points into the compact binary format used by chunk and preview files.
    func binaryData() -> Data {
        var data = Data(capacity: count * CapturedPoint.binaryRecordSize)

        for point in self {
            var x = point.x
            var y = point.y
            var z = point.z
            var timestamp = point.timestamp

            Swift.withUnsafeBytes(of: &x) { data.append(contentsOf: $0) }
            Swift.withUnsafeBytes(of: &y) { data.append(contentsOf: $0) }
            Swift.withUnsafeBytes(of: &z) { data.append(contentsOf: $0) }
            data.append(point.red)
            data.append(point.green)
            data.append(point.blue)
            data.append(point.confidence)
            Swift.withUnsafeBytes(of: &timestamp) { data.append(contentsOf: $0) }
        }

        return data
    }

    /// Reconstructs points from the compact binary format used on disk.
    init(binaryData data: Data) {
        guard data.count.isMultiple(of: CapturedPoint.binaryRecordSize) else {
            self = []
            return
        }

        self = stride(from: 0, to: data.count, by: CapturedPoint.binaryRecordSize).compactMap { offset in
            let range = offset ..< (offset + CapturedPoint.binaryRecordSize)
            let chunk = data.subdata(in: range)

            let x = chunk.withUnsafeBytes { $0.load(fromByteOffset: 0, as: Float.self) }
            let y = chunk.withUnsafeBytes { $0.load(fromByteOffset: 4, as: Float.self) }
            let z = chunk.withUnsafeBytes { $0.load(fromByteOffset: 8, as: Float.self) }
            let red = chunk[12]
            let green = chunk[13]
            let blue = chunk[14]
            let confidence = chunk[15]
            let timestamp = chunk.withUnsafeBytes { $0.load(fromByteOffset: 16, as: Double.self) }

            return CapturedPoint(
                position: SIMD3(x, y, z),
                red: red,
                green: green,
                blue: blue,
                confidence: confidence,
                timestamp: timestamp
            )
        }
    }
}

// MARK: - VoxelKey

/// Quantized voxel coordinate used to estimate scan coverage.
nonisolated struct VoxelKey: Hashable {
    // MARK: Lifecycle

    /// Converts a world-space position into integer voxel coordinates.
    init(position: SIMD3<Float>, voxelSize: Float) {
        self.x = Int32(floor(position.x / voxelSize))
        self.y = Int32(floor(position.y / voxelSize))
        self.z = Int32(floor(position.z / voxelSize))
    }

    // MARK: Internal

    let x: Int32
    let y: Int32
    let z: Int32
}

// MARK: - ScanBounds

/// Axis-aligned bounds for the captured point cloud.
nonisolated struct ScanBounds: Codable {
    // MARK: Lifecycle

    /// Creates bounds initialized to a single point.
    init(point: SIMD3<Float>) {
        let x = Double(point.x)
        let y = Double(point.y)
        let z = Double(point.z)
        self.minX = x
        self.minY = y
        self.minZ = z
        self.maxX = x
        self.maxY = y
        self.maxZ = z
    }

    // MARK: Internal

    var minX: Double
    var minY: Double
    var minZ: Double
    var maxX: Double
    var maxY: Double
    var maxZ: Double

    /// Center of the bounds, useful when centering the preview scene.
    var center: SIMD3<Float> {
        SIMD3(
            Float((self.minX + self.maxX) * 0.5),
            Float((self.minY + self.maxY) * 0.5),
            Float((self.minZ + self.maxZ) * 0.5)
        )
    }

    /// Largest dimension of the bounds in meters.
    var maxExtent: Float {
        Float(max(self.maxX - self.minX, max(self.maxY - self.minY, self.maxZ - self.minZ)))
    }

    /// Expands the bounds to include another point.
    mutating func include(_ point: SIMD3<Float>) {
        self.minX = Swift.min(self.minX, Double(point.x))
        self.minY = Swift.min(self.minY, Double(point.y))
        self.minZ = Swift.min(self.minZ, Double(point.z))
        self.maxX = Swift.max(self.maxX, Double(point.x))
        self.maxY = Swift.max(self.maxY, Double(point.y))
        self.maxZ = Swift.max(self.maxZ, Double(point.z))
    }

    /// Merges another bounds object into this one.
    mutating func merge(_ other: ScanBounds) {
        self.minX = Swift.min(self.minX, other.minX)
        self.minY = Swift.min(self.minY, other.minY)
        self.minZ = Swift.min(self.minZ, other.minZ)
        self.maxX = Swift.max(self.maxX, other.maxX)
        self.maxY = Swift.max(self.maxY, other.maxY)
        self.maxZ = Swift.max(self.maxZ, other.maxZ)
    }
}

// MARK: - ScanProjectManifest

/// Top-level summary of a persisted `.scanproject` package.
struct ScanProjectManifest: Codable, Identifiable {
    /// High-level lifecycle state for the scan package.
    enum CaptureState: String, Codable {
        case capturing
        case completed
        case failed
    }

    var id: UUID
    var createdAt: Date
    var updatedAt: Date
    var state: CaptureState
    var pointCount: Int
    var chunkCount: Int
    var voxelSizeMeters: Float
    var approximateGeoreferencing: Bool
    var geoReference: GeoReference?
    var bounds: ScanBounds?
    var keyframeCount: Int?
    var meshAnchorCount: Int?
}

// MARK: - ScanMeshAnchorCatalog

/// Versioned catalog of mesh anchors persisted alongside the scan.
struct ScanMeshAnchorCatalog: Codable, Hashable {
    // MARK: Lifecycle

    /// Creates a mesh-anchor catalog with a format version for future compatibility.
    init(formatVersion: Int = 2, anchors: [ScanMeshAnchorRecord] = []) {
        self.formatVersion = formatVersion
        self.anchors = anchors
    }

    // MARK: Internal

    var formatVersion: Int
    var anchors: [ScanMeshAnchorRecord]
}

// MARK: - ScanMeshAnchorRecord

/// Metadata describing the binary payloads for one persisted AR mesh anchor.
struct ScanMeshAnchorRecord: Codable, Identifiable, Hashable {
    // MARK: Lifecycle

    /// Creates a metadata record for one mesh anchor artifact set.
    init(
        anchorIdentifier: String,
        transform: simd_float4x4,
        vertexCount: Int,
        verticesFilename: String,
        vertexFormat: String = "float32x3LittleEndian",
        faceCount: Int,
        faceIndexCountPerPrimitive: Int,
        faceVertexIndexCount: Int,
        faceVertexIndicesFilename: String,
        faceVertexIndexFormat: String = "uint32LittleEndian",
        vertexNormalsFilename: String? = nil,
        vertexNormalsFormat: String? = nil,
        faceClassificationFilename: String? = nil,
        faceClassificationFormat: String? = nil
    ) {
        self.anchorIdentifier = anchorIdentifier
        self.transform = transform.arrayRepresentation
        self.vertexCount = vertexCount
        self.verticesFilename = verticesFilename
        self.vertexFormat = vertexFormat
        self.faceCount = faceCount
        self.faceIndexCountPerPrimitive = faceIndexCountPerPrimitive
        self.faceVertexIndexCount = faceVertexIndexCount
        self.faceVertexIndicesFilename = faceVertexIndicesFilename
        self.faceVertexIndexFormat = faceVertexIndexFormat
        self.vertexNormalsFilename = vertexNormalsFilename
        self.vertexNormalsFormat = vertexNormalsFormat
        self.faceClassificationFilename = faceClassificationFilename
        self.faceClassificationFormat = faceClassificationFormat
    }

    // MARK: Internal

    var anchorIdentifier: String
    var transform: [Float]
    var vertexCount: Int
    var verticesFilename: String
    var vertexFormat: String
    var faceCount: Int
    var faceIndexCountPerPrimitive: Int
    var faceVertexIndexCount: Int
    var faceVertexIndicesFilename: String
    var faceVertexIndexFormat: String
    var vertexNormalsFilename: String?
    var vertexNormalsFormat: String?
    var faceClassificationFilename: String?
    var faceClassificationFormat: String?

    var id: String {
        self.anchorIdentifier
    }

    /// Reconstructs the flattened transform payload into a 4×4 matrix when valid.
    var transformMatrix: simd_float4x4? {
        simd_float4x4(arrayRepresentation: self.transform)
    }
}

// MARK: - ScanTrajectory

/// Versioned container for GPS and heading samples captured over time.
struct ScanTrajectory: Codable, Hashable {
    // MARK: Lifecycle

    /// Creates an empty or pre-populated trajectory payload.
    init(
        formatVersion: Int = 1,
        locationSamples: [ScanLocationTrajectorySample] = [],
        headingSamples: [ScanHeadingTrajectorySample] = []
    ) {
        self.formatVersion = formatVersion
        self.locationSamples = locationSamples
        self.headingSamples = headingSamples
    }

    // MARK: Internal

    var formatVersion: Int
    var locationSamples: [ScanLocationTrajectorySample]
    var headingSamples: [ScanHeadingTrajectorySample]
}

// MARK: - ScanLocationTrajectorySample

/// One GPS sample captured during the scan.
struct ScanLocationTrajectorySample: Codable, Hashable {
    var timestamp: TimeInterval
    var latitude: Double
    var longitude: Double
    var altitude: Double
    var horizontalAccuracy: Double
    var verticalAccuracy: Double
    var speed: Double
    var speedAccuracy: Double
    var course: Double
    var courseAccuracy: Double
}

// MARK: - ScanHeadingReference

/// Describes which north reference produced a heading sample.
nonisolated enum ScanHeadingReference: String, Codable, Hashable {
    case trueNorth
    case magneticNorth
    case unavailable
}

// MARK: - ScanGeoreferenceSource

/// Describes the source used to derive scan georeferencing.
nonisolated enum ScanGeoreferenceSource: String, Codable, Hashable {
    case deviceLocationOnly
    case deviceLocationAndHeading
    case externalRefinement
}

// MARK: - ScanGeoreferenceStatus

/// Indicates whether a georeference is the initial device estimate or a refined solution.
nonisolated enum ScanGeoreferenceStatus: String, Codable, Hashable {
    case initial
    case refined
}

// MARK: - ScanGeoreferenceQuality

/// High-level quality label for georeferencing metadata.
nonisolated enum ScanGeoreferenceQuality: String, Codable, Hashable {
    case approximate
    case phoneGrade
    case refined
}

// MARK: - ScanGeoreferenceMetadata

/// Provenance and quality details for a scan's georeference.
nonisolated struct ScanGeoreferenceMetadata: Codable, Hashable {
    var source: ScanGeoreferenceSource
    var status: ScanGeoreferenceStatus
    var quality: ScanGeoreferenceQuality
    var horizontalAccuracyMeters: Double?
    var verticalAccuracyMeters: Double?
    var headingAccuracyDegrees: Double?
    var headingProvenance: ScanHeadingReference
}

// MARK: - ScanHeadingTrajectorySample

/// One heading or compass sample captured during the scan.
struct ScanHeadingTrajectorySample: Codable, Hashable {
    var timestamp: TimeInterval
    var trueHeading: Double
    var magneticHeading: Double
    var headingAccuracy: Double
    var headingReference: ScanHeadingReference
    var resolvedHeadingDegrees: Double?
    var magneticFieldX: Double
    var magneticFieldY: Double
    var magneticFieldZ: Double
}

// MARK: - CapturedMeshAnchor

/// In-memory bundle of mesh-anchor metadata and the binary payloads to persist.
struct CapturedMeshAnchor {
    let metadata: ScanMeshAnchorRecord
    let verticesData: Data
    let faceVertexIndexData: Data
    let vertexNormalsData: Data?
    let faceClassificationData: Data?
}

// MARK: - SceneDepthSource

/// Identifies which ARKit depth product produced a keyframe depth payload.
enum SceneDepthSource: String, Codable, Hashable {
    case smoothedSceneDepth
    case sceneDepth
}

// MARK: - ScanSceneDepthPayload

/// Metadata describing the depth-map sidecar files stored for a keyframe.
struct ScanSceneDepthPayload: Codable, Hashable {
    var source: SceneDepthSource
    var width: Int
    var height: Int
    var storageLayout: String
    var depthMapFilename: String
    var depthDataFormat: String
    var depthUnit: String
    var confidenceMapFilename: String?
    var confidenceDataFormat: String?
}

// MARK: - ScanRGBKeyframeImageQuality

/// Image quality measurements attached to a persisted RGB keyframe.
struct ScanRGBKeyframeImageQuality: Codable, Hashable {
    var sharpnessScore: Double
    var sharpnessMethod: String
}

// MARK: - ScanRGBKeyframePhotometricMetadata

/// Exposure and ambient-light measurements recorded when a keyframe was captured.
struct ScanRGBKeyframePhotometricMetadata: Codable, Hashable {
    var exposureDurationSeconds: Double
    var exposureOffsetEV: Double
    var ambientIntensity: Double?
    var ambientColorTemperatureKelvin: Double?
}

// MARK: - ScanRGBKeyframe

/// Metadata describing a persisted RGB keyframe and its optional sidecar payloads.
struct ScanRGBKeyframe: Codable, Identifiable, Hashable {
    // MARK: Lifecycle

    /// Creates keyframe metadata from camera matrices, image info, and optional enrichment payloads.
    init(
        frameIdentifier: String,
        timestamp: TimeInterval,
        cameraTransform: simd_float4x4,
        cameraIntrinsics: simd_float3x3,
        imageWidth: Int,
        imageHeight: Int,
        imageFilename: String,
        imageQuality: ScanRGBKeyframeImageQuality? = nil,
        photometricMetadata: ScanRGBKeyframePhotometricMetadata? = nil,
        sceneDepthPayload: ScanSceneDepthPayload? = nil
    ) {
        self.frameIdentifier = frameIdentifier
        self.timestamp = timestamp
        self.cameraTransform = cameraTransform.arrayRepresentation
        self.cameraIntrinsics = cameraIntrinsics.arrayRepresentation
        self.imageWidth = imageWidth
        self.imageHeight = imageHeight
        self.imageFilename = imageFilename
        self.imageQuality = imageQuality
        self.photometricMetadata = photometricMetadata
        self.sceneDepthPayload = sceneDepthPayload
    }

    // MARK: Internal

    var frameIdentifier: String
    var timestamp: TimeInterval
    var cameraTransform: [Float]
    var cameraIntrinsics: [Float]
    var imageWidth: Int
    var imageHeight: Int
    var imageFilename: String
    var imageQuality: ScanRGBKeyframeImageQuality?
    var photometricMetadata: ScanRGBKeyframePhotometricMetadata?
    var sceneDepthPayload: ScanSceneDepthPayload?

    var id: String {
        self.frameIdentifier
    }

    /// Reconstructs the flattened camera transform array into a matrix when valid.
    var cameraTransformMatrix: simd_float4x4? {
        simd_float4x4(arrayRepresentation: self.cameraTransform)
    }

    /// Reconstructs the flattened camera intrinsics array into a matrix when valid.
    var cameraIntrinsicsMatrix: simd_float3x3? {
        simd_float3x3(arrayRepresentation: self.cameraIntrinsics)
    }
}

// MARK: - CapturedSceneDepthPayload

/// Raw depth and confidence payloads that accompany a persisted keyframe.
struct CapturedSceneDepthPayload {
    let depthMapData: Data
    let confidenceMapData: Data?
}

// MARK: - CapturedRGBKeyframe

/// In-memory bundle of keyframe metadata and the files that should be written to disk.
struct CapturedRGBKeyframe {
    // MARK: Lifecycle

    /// Creates a persisted keyframe package from metadata, JPEG bytes, and optional depth sidecars.
    init(
        metadata: ScanRGBKeyframe,
        imageData: Data,
        sceneDepthData: CapturedSceneDepthPayload? = nil
    ) {
        self.metadata = metadata
        self.imageData = imageData
        self.sceneDepthData = sceneDepthData
    }

    // MARK: Internal

    let metadata: ScanRGBKeyframe
    let imageData: Data
    let sceneDepthData: CapturedSceneDepthPayload?
}

// MARK: - CapturedImageColorRange

/// Quantization range used by the captured camera image planes.
enum CapturedImageColorRange {
    case fullRange
    case videoRange
}

// MARK: - CapturedImageYCbCrMatrix

/// YCbCr matrix declared by the captured camera image.
enum CapturedImageYCbCrMatrix {
    case ituR601
    case ituR709
    case ituR2020
}

// MARK: - FramePointCloudData

/// Fully extracted frame data consumed by the capture engine after reading ARKit buffers.
struct FramePointCloudData {
    // MARK: Lifecycle

    /// Creates a frame payload from decoded depth, color, camera, and timing data.
    init(
        depthWidth: Int,
        depthHeight: Int,
        depthValues: [Float],
        confidenceValues: [UInt8],
        imageWidth: Int,
        imageHeight: Int,
        lumaValues: [UInt8],
        chromaWidth: Int,
        chromaHeight: Int,
        chromaValues: [UInt8],
        imageColorRange: CapturedImageColorRange,
        imageYCbCrMatrix: CapturedImageYCbCrMatrix,
        intrinsics: simd_float3x3,
        cameraTransform: simd_float4x4,
        timestamp: TimeInterval,
        sceneDepthSource: SceneDepthSource = .sceneDepth
    ) {
        self.depthWidth = depthWidth
        self.depthHeight = depthHeight
        self.depthValues = depthValues
        self.confidenceValues = confidenceValues
        self.imageWidth = imageWidth
        self.imageHeight = imageHeight
        self.lumaValues = lumaValues
        self.chromaWidth = chromaWidth
        self.chromaHeight = chromaHeight
        self.chromaValues = chromaValues
        self.imageColorRange = imageColorRange
        self.imageYCbCrMatrix = imageYCbCrMatrix
        self.imageColorConversion = YCbCrToRGBConversion(
            colorRange: imageColorRange,
            matrix: imageYCbCrMatrix
        )
        self.intrinsics = intrinsics
        self.cameraTransform = cameraTransform
        self.timestamp = timestamp
        self.sceneDepthSource = sceneDepthSource
    }

    // MARK: Internal

    let depthWidth: Int
    let depthHeight: Int
    let depthValues: [Float]
    let confidenceValues: [UInt8]
    let imageWidth: Int
    let imageHeight: Int
    let lumaValues: [UInt8]
    let chromaWidth: Int
    let chromaHeight: Int
    let chromaValues: [UInt8]
    let imageColorRange: CapturedImageColorRange
    let imageYCbCrMatrix: CapturedImageYCbCrMatrix
    let imageColorConversion: YCbCrToRGBConversion
    let intrinsics: simd_float3x3
    let cameraTransform: simd_float4x4
    let timestamp: TimeInterval
    let sceneDepthSource: SceneDepthSource
}

extension [Float] {
    /// Serializes `Float` values as little-endian 32-bit binary data.
    func float32LittleEndianData() -> Data {
        var data = Data(capacity: count * MemoryLayout<UInt32>.size)

        for value in self {
            var bitPattern = value.bitPattern.littleEndian
            Swift.withUnsafeBytes(of: &bitPattern) { data.append(contentsOf: $0) }
        }

        return data
    }
}

extension [UInt32] {
    /// Serializes `UInt32` values as little-endian binary data.
    func uint32LittleEndianData() -> Data {
        var data = Data(capacity: count * MemoryLayout<UInt32>.size)

        for value in self {
            var littleEndianValue = value.littleEndian
            Swift.withUnsafeBytes(of: &littleEndianValue) { data.append(contentsOf: $0) }
        }

        return data
    }
}

private extension simd_float3x3 {
    var arrayRepresentation: [Float] {
        [
            self.columns.0.x, self.columns.0.y, self.columns.0.z,
            self.columns.1.x, self.columns.1.y, self.columns.1.z,
            self.columns.2.x, self.columns.2.y, self.columns.2.z,
        ]
    }

    init?(arrayRepresentation values: [Float]) {
        guard values.count == 9 else {
            return nil
        }

        self.init(columns: (
            SIMD3(values[0], values[1], values[2]),
            SIMD3(values[3], values[4], values[5]),
            SIMD3(values[6], values[7], values[8])
        ))
    }
}

private extension simd_float4x4 {
    var arrayRepresentation: [Float] {
        [
            self.columns.0.x, self.columns.0.y, self.columns.0.z, self.columns.0.w,
            self.columns.1.x, self.columns.1.y, self.columns.1.z, self.columns.1.w,
            self.columns.2.x, self.columns.2.y, self.columns.2.z, self.columns.2.w,
            self.columns.3.x, self.columns.3.y, self.columns.3.z, self.columns.3.w,
        ]
    }

    init?(arrayRepresentation values: [Float]) {
        guard values.count == 16 else {
            return nil
        }

        self.init(columns: (
            SIMD4(values[0], values[1], values[2], values[3]),
            SIMD4(values[4], values[5], values[6], values[7]),
            SIMD4(values[8], values[9], values[10], values[11]),
            SIMD4(values[12], values[13], values[14], values[15])
        ))
    }
}
