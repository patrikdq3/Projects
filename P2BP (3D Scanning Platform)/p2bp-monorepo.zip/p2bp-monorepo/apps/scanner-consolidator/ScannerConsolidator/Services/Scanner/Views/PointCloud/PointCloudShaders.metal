#include <metal_stdlib>

using namespace metal;

// Layouts must stay in sync with the Swift mirrors in PointCloudRenderTypes.swift and the
// C++ writer in LAZDecoder.mm.

struct PointVertexIn {
    packed_float3 position;
    uchar4 colorAndClass; // xyz: RGB, w: ASPRS classification code
    ushort intensity;
    ushort displayFlags; // bit 0: inferred blocker; bits 1-15: height above local ground, cm
};

struct PointCloudUniforms {
    float4x4 viewProjection;
    float pointSize;
    float intensityScale;
    float perspectiveReference;
    float projectionBlend;
    uint vertexStride;
    uint colorMode;
    float groundHeight;
    float elevationScale;
    float cutHeight; // roof/canopy cut above local ground, in meters; <= 0 disables
    uint hasViewerAttributes;
    uint padding2;
    uint padding3;
};

struct PointVertexOut {
    float4 position [[position]];
    float pointSize [[point_size]];
    half4 color;
};

constant uint kColorModeIntensity = 1;
constant uint kColorModeFlat = 2;
constant uint kColorModeHeatWarm = 3;
constant uint kColorModeHeatCool = 4;
constant uint kColorModeBlueprint = 5;

// ASPRS classes blanked out by the blueprint plan view: 4/5 medium+high vegetation,
// 6 building, plus best-effort inferred blockers in unclassified files.
bool isStructurePoint(uint classification, uint displayFlags) {
    return classification == 4 || classification == 5 || classification == 6 || (displayFlags & 1) != 0;
}

// Elevation-driven gradient for the top-down modes: near-neutral at ground level,
// ramping through the palette as structures rise above the estimated floor.
half3 elevationGradientColor(float positionZ, constant PointCloudUniforms &uniforms, bool coolGray) {
    const float heightAboveFloor = max(positionZ - uniforms.groundHeight, 0.0);
    const float elevation = saturate((heightAboveFloor - 0.08) * uniforms.elevationScale);
    const half3 floorColor = coolGray ? half3(0.85h, 0.86h, 0.88h) : half3(0.78h, 0.82h, 0.87h);
    const half3 lowColor = coolGray ? half3(0.62h, 0.67h, 0.74h) : half3(0.18h, 0.66h, 0.9h);
    const half3 middleColor = coolGray ? half3(0.44h, 0.5h, 0.59h) : half3(0.98h, 0.76h, 0.2h);
    const half3 highColor = coolGray ? half3(0.24h, 0.28h, 0.37h) : half3(0.9h, 0.24h, 0.22h);
    const half3 gradient = elevation < 0.5
        ? mix(lowColor, middleColor, half(elevation * 2.0))
        : mix(middleColor, highColor, half((elevation - 0.5) * 2.0));
    const half raisedAmount = half(smoothstep(0.08, 0.18, heightAboveFloor));
    return mix(floorColor, gradient, raisedAmount);
}

half3 pointDisplayColor(
    const device PointVertexIn &point,
    constant PointCloudUniforms &uniforms
) {
    if (uniforms.colorMode == kColorModeBlueprint) {
        // Paper-like ground shading: intensity texture when the file has it, otherwise a
        // subtle darkening of slightly raised features so the plan still reads as relief.
        float shade;
        if (uniforms.hasViewerAttributes == 0 && uniforms.intensityScale > 0.0) {
            const float normalized = sqrt(saturate(float(point.intensity) * uniforms.intensityScale));
            shade = 0.45 + 0.5 * normalized;
        } else {
            const float heightAboveGround = float(point.displayFlags >> 1) * 0.01;
            shade = 0.88 - 0.3 * saturate(heightAboveGround * 0.8);
        }
        return half3(half(shade));
    }
    if (uniforms.colorMode == kColorModeHeatWarm || uniforms.colorMode == kColorModeHeatCool) {
        return elevationGradientColor(
            float(point.position.z),
            uniforms,
            uniforms.colorMode == kColorModeHeatCool
        );
    }
    if (uniforms.colorMode == kColorModeIntensity) {
        const float normalized = sqrt(saturate(float(point.intensity) * uniforms.intensityScale));
        return half3(half(0.18 + 0.82 * normalized));
    }
    if (uniforms.colorMode == kColorModeFlat) {
        return half3(0.82h, 0.86h, 0.9h);
    }
    return half3(point.colorAndClass.xyz) / 255.0h;
}

vertex PointVertexOut pointCloudVertex(
    uint vertexID [[vertex_id]],
    device const PointVertexIn *points [[buffer(0)]],
    constant PointCloudUniforms &uniforms [[buffer(1)]]
) {
    const device PointVertexIn &point = points[vertexID * uniforms.vertexStride];

    PointVertexOut out;
    bool culled = false;
    if (uniforms.cutHeight > 0.0) {
        const float heightAboveGround = float(point.displayFlags >> 1) * 0.01;
        const uint surfaceFlags = uniforms.hasViewerAttributes != 0
            ? uint(point.intensity >> 8)
            : 0;
        const bool hasServerAttributes = (surfaceFlags & 128) != 0;
        const bool normalValid = (surfaceFlags & 2) != 0;
        const bool ceiling = (surfaceFlags & 4) != 0;
        const char quantizedNormalZ = char(point.intensity & 255);
        const bool downward = float(quantizedNormalZ) / 127.0 <= -0.5;
        const bool orientationMatches = !normalValid || downward || ceiling;
        culled = heightAboveGround > uniforms.cutHeight
            && (!hasServerAttributes || orientationMatches);
    }
    if (uniforms.colorMode == kColorModeBlueprint
        && isStructurePoint(point.colorAndClass.w, point.displayFlags)) {
        culled = true;
    }
    if (culled) {
        // NaN positions cull the point during clipping, so toggling never rebuilds buffers.
        out.position = float4(NAN);
        out.pointSize = 0.0;
        out.color = half4(0.0);
        return out;
    }
    const float4 clipPosition = uniforms.viewProjection * float4(float3(point.position), 1.0);
    out.position = clipPosition;

    const float attenuated = uniforms.pointSize
        * clamp(uniforms.perspectiveReference / max(clipPosition.w, 0.0001), 0.35, 4.0);
    out.pointSize = mix(attenuated, uniforms.pointSize, uniforms.projectionBlend);

    out.color = half4(pointDisplayColor(point, uniforms), 1.0h);
    return out;
}

fragment half4 pointCloudFragment(
    PointVertexOut in [[stage_in]],
    float2 pointCoord [[point_coord]]
) {
    const float2 offset = pointCoord - 0.5;
    if (dot(offset, offset) > 0.25) {
        discard_fragment();
    }
    return in.color;
}

struct OutlineVertexIn {
    packed_float3 position;
    uchar4 color;
    float arcLength; // cumulative distance along the outline loop, meters
};

struct OutlineUniforms {
    float4x4 viewProjection;
    float4 params; // x: opacity, y: blueprint style (dark dashed lines)
};

struct OutlineVertexOut {
    float4 position [[position]];
    half4 color;
    float arcLength; // negative disables dashing in the fragment stage
};

vertex OutlineVertexOut outlineVertex(
    uint vertexID [[vertex_id]],
    device const OutlineVertexIn *vertices [[buffer(0)]],
    constant OutlineUniforms &uniforms [[buffer(1)]]
) {
    const device OutlineVertexIn &vertexIn = vertices[vertexID];
    const bool blueprintStyle = uniforms.params.y > 0.5;
    OutlineVertexOut out;
    out.position = uniforms.viewProjection * float4(float3(vertexIn.position), 1.0);
    out.color = blueprintStyle
        ? half4(half3(0.16h), half(uniforms.params.x))
        : half4(half3(vertexIn.color.xyz) / 255.0h, half(uniforms.params.x));
    out.arcLength = blueprintStyle ? vertexIn.arcLength : -1.0;
    return out;
}

fragment half4 outlineFragment(OutlineVertexOut in [[stage_in]]) {
    if (in.arcLength >= 0.0) {
        const float dashPeriod = 0.9;
        if (fract(in.arcLength / dashPeriod) > 0.62) {
            discard_fragment();
        }
    }
    return in.color;
}
