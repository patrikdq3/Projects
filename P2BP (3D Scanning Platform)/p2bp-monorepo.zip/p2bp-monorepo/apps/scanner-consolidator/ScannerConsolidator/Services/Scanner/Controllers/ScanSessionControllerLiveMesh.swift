import ARKit
import SceneKit

// MARK: - ScanLiveMeshOverlayStyle

/// Shared styling values for the lightweight live mesh wireframe overlay.
private nonisolated enum ScanLiveMeshOverlayStyle {
    static let tint = CGColor(red: 0.45, green: 0.95, blue: 0.80, alpha: 1.0)
}

// MARK: - ScanSessionController Live Mesh

extension ScanSessionController {
    /// Builds the lightweight wireframe geometry shown on top of live scene-reconstruction anchors.
    private nonisolated func updateLiveMeshNode(_ node: SCNNode, from meshAnchor: ARMeshAnchor) {
        node.geometry = Self.makeLiveMeshGeometry(from: meshAnchor.geometry)
    }

    /// Converts ARKit mesh buffers into a low-cost SceneKit wireframe overlay.
    private nonisolated static func makeLiveMeshGeometry(from geometry: ARMeshGeometry) -> SCNGeometry {
        let vertexSource = SCNGeometrySource(
            buffer: geometry.vertices.buffer,
            vertexFormat: geometry.vertices.format,
            semantic: .vertex,
            vertexCount: geometry.vertices.count,
            dataOffset: geometry.vertices.offset,
            dataStride: geometry.vertices.stride
        )
        let element = SCNGeometryElement(
            buffer: geometry.faces.buffer,
            primitiveType: .triangles,
            primitiveCount: geometry.faces.count,
            bytesPerIndex: geometry.faces.bytesPerIndex
        )

        let meshGeometry = SCNGeometry(sources: [vertexSource], elements: [element])
        let material = SCNMaterial()
        material.lightingModel = .constant
        material.diffuse.contents = ScanLiveMeshOverlayStyle.tint
        material.emission.contents = ScanLiveMeshOverlayStyle.tint
        material.fillMode = .lines
        material.isDoubleSided = true
        material.readsFromDepthBuffer = true
        material.writesToDepthBuffer = false
        material.transparency = 0.72
        meshGeometry.materials = [material]
        return meshGeometry
    }
}

// MARK: - ScanSessionController + ARSCNViewDelegate

/// Adds and refreshes lightweight mesh-overlay geometry for ARKit scene-reconstruction anchors.
extension ScanSessionController: ARSCNViewDelegate {
    nonisolated func renderer(_: SCNSceneRenderer, didAdd node: SCNNode, for anchor: ARAnchor) {
        guard let meshAnchor = anchor as? ARMeshAnchor else {
            return
        }

        self.updateLiveMeshNode(node, from: meshAnchor)
    }

    nonisolated func renderer(_: SCNSceneRenderer, didUpdate node: SCNNode, for anchor: ARAnchor) {
        guard let meshAnchor = anchor as? ARMeshAnchor else {
            return
        }

        self.updateLiveMeshNode(node, from: meshAnchor)
    }

    nonisolated func renderer(_: SCNSceneRenderer, didRemove node: SCNNode, for anchor: ARAnchor) {
        guard anchor is ARMeshAnchor else {
            return
        }

        node.geometry = nil
    }
}
