import MetalKit
import SwiftUI

// MARK: - LAZMetalPointCloudView

/// Decodes a local LAZ file with the bundled laz-perf C++ library and renders it as a Metal
/// point cloud with orbit/pan/zoom controls. A top-down mode animates into an orthographic
/// plan view. Color styling is independent of the camera: colorful elevation, muted
/// cool-gray, and white blueprint looks remain available in both 3D and top-down modes.
/// Roof/canopy removal is also camera-independent, while structure outlines are top-down only.
struct LAZMetalPointCloudView: View {
    // MARK: Internal

    let fileURL: URL
    let metadataURL: URL?

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            switch self.model.phase {
            case .idle, .loading:
                self.loadingOverlay
            case let .failed(message):
                ContentUnavailableView(
                    "Point Cloud Unavailable",
                    systemImage: "cube.transparent",
                    description: Text(message)
                )
            case let .loaded(cloud):
                PointCloudMetalContainerView(
                    cloud: cloud,
                    outlineVertices: self.model.outlineVertices,
                    isTopDown: self.isTopDown,
                    topDownPalette: self.topDownPalette,
                    isCanopyRemoved: self.isCanopyRemoved
                )
                .overlay(alignment: .bottomTrailing) {
                    HStack(spacing: 12) {
                        self.canopyToggleButton
                        self.paletteToggleButton
                        self.topDownToggleButton
                    }
                    .padding(.trailing, 16)
                    .padding(.bottom, 24)
                }
                .overlay(alignment: .topLeading) {
                    if self.topDownPalette.showsElevationLegend {
                        self.elevationLegend
                            .padding(.leading, 16)
                            .padding(.top, 16)
                            .transition(.move(edge: .leading).combined(with: .opacity))
                    }
                }
            }
        }
        .task(id: self.fileURL) {
            self.isTopDown = false
            self.topDownPalette = .original
            self.isCanopyRemoved = false
            await self.model.load(fileURL: self.fileURL, metadataURL: self.metadataURL)
        }
    }

    // MARK: Private

    @State private var model = LAZMetalPointCloudModel()
    @State private var isTopDown = false
    @State private var topDownPalette = PointCloudTopDownPalette.original
    @State private var isCanopyRemoved = false

    private var legendColors: [Color] {
        switch self.topDownPalette {
        case .original:
            []
        case .heat, .blueprint:
            [
                Color(red: 0.78, green: 0.82, blue: 0.87),
                Color(red: 0.18, green: 0.66, blue: 0.9),
                Color(red: 0.98, green: 0.76, blue: 0.2),
                Color(red: 0.9, green: 0.24, blue: 0.22),
            ]
        case .coolGray:
            [
                Color(red: 0.85, green: 0.86, blue: 0.88),
                Color(red: 0.62, green: 0.67, blue: 0.74),
                Color(red: 0.44, green: 0.5, blue: 0.59),
                Color(red: 0.24, green: 0.28, blue: 0.37),
            ]
        }
    }

    private var paletteIconName: String {
        switch self.topDownPalette {
        case .original: "photo"
        case .heat: "circle.lefthalf.filled"
        case .coolGray: "pencil.and.outline"
        case .blueprint: "paintpalette.fill"
        }
    }

    private var paletteAccessibilityLabel: String {
        switch self.topDownPalette {
        case .original: "Switch to colorful heat map"
        case .heat: "Switch to gray gradient"
        case .coolGray: "Switch to blueprint plan view"
        case .blueprint: "Switch to original point colors"
        }
    }

    private var paletteAccessibilityValue: String {
        switch self.topDownPalette {
        case .original: "Original point colors"
        case .heat: "Colorful heat map"
        case .coolGray: "Gray gradient"
        case .blueprint: "Blueprint plan view"
        }
    }

    private var elevationLegend: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text("HEIGHT")
                .font(.caption2.weight(.bold))
                .tracking(0.8)
                .foregroundStyle(.secondary)
            LinearGradient(
                colors: self.legendColors,
                startPoint: .leading,
                endPoint: .trailing
            )
            .frame(width: 132, height: 8)
            .clipShape(Capsule())
            HStack {
                Text("Ground")
                Spacer()
                Text("Raised")
            }
            .font(.caption2.weight(.medium))
            .foregroundStyle(.secondary)
            .frame(width: 132)
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 10)
        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 12, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 12, style: .continuous)
                .stroke(Color.white.opacity(0.24), lineWidth: 0.75)
        )
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(
            self.topDownPalette == .heat
                ? "Height colors, neutral ground through blue, amber, and red raised structures"
                : "Height colors, light gray ground through dark slate raised structures"
        )
        .accessibilityIdentifier("preview.pointCloud.heightLegend")
    }

    private var loadingOverlay: some View {
        VStack(spacing: 14) {
            ProgressView(value: self.model.progress)
                .progressViewStyle(.linear)
                .frame(maxWidth: 220)
                .tint(.white)
            Text("Decoding LAZ… \(Int(self.model.progress * 100))%")
                .font(.footnote)
                .foregroundStyle(.secondary)
        }
        .padding(.horizontal, 24)
        .accessibilityIdentifier("preview.pointCloud.loading")
    }

    private var canopyToggleButton: some View {
        Button {
            withAnimation(.easeInOut(duration: 0.2)) {
                self.isCanopyRemoved.toggle()
            }
        } label: {
            Image(systemName: "scissors")
                .font(.system(size: PointCloudViewerControlStyle.iconSize, weight: .semibold))
                .foregroundStyle(Color("TextPrimary"))
                .frame(width: PointCloudViewerControlStyle.size, height: PointCloudViewerControlStyle.size)
                .background(.regularMaterial, in: Circle())
                .overlay(
                    Circle().stroke(
                        Color.white.opacity(self.isCanopyRemoved ? 0.62 : 0.28),
                        lineWidth: self.isCanopyRemoved ? 1.5 : 0.75
                    )
                )
                .shadow(color: .black.opacity(0.22), radius: 14, x: 0, y: 6)
        }
        .buttonStyle(.plain)
        .accessibilityLabel(
            self.isCanopyRemoved ? "Restore roofs and tree canopies" : "Remove roofs and tree canopies"
        )
        .accessibilityValue(self.isCanopyRemoved ? "Roofs and canopies hidden" : "Full height shown")
        .accessibilityIdentifier("preview.pointCloud.canopyToggle")
    }

    private var paletteToggleButton: some View {
        Button {
            withAnimation(.easeInOut(duration: 0.2)) {
                self.topDownPalette = self.topDownPalette.next
            }
        } label: {
            Image(systemName: self.paletteIconName)
                .font(.system(size: PointCloudViewerControlStyle.iconSize, weight: .semibold))
                .foregroundStyle(Color("TextPrimary"))
                .frame(width: PointCloudViewerControlStyle.size, height: PointCloudViewerControlStyle.size)
                .background(.regularMaterial, in: Circle())
                .overlay(
                    Circle().stroke(
                        Color.white.opacity(self.topDownPalette == .original ? 0.28 : 0.62),
                        lineWidth: self.topDownPalette == .original ? 0.75 : 1.5
                    )
                )
                .shadow(color: .black.opacity(0.22), radius: 14, x: 0, y: 6)
        }
        .buttonStyle(.plain)
        .accessibilityLabel(self.paletteAccessibilityLabel)
        .accessibilityValue(self.paletteAccessibilityValue)
        .accessibilityIdentifier("preview.pointCloud.paletteToggle")
    }

    private var topDownToggleButton: some View {
        Button {
            withAnimation(.spring(response: 0.32, dampingFraction: 0.86)) {
                self.isTopDown.toggle()
            }
        } label: {
            Image(systemName: self.isTopDown ? "view.3d" : "map.fill")
                .font(.system(size: PointCloudViewerControlStyle.iconSize, weight: .semibold))
                .foregroundStyle(Color("TextPrimary"))
                .frame(width: PointCloudViewerControlStyle.size, height: PointCloudViewerControlStyle.size)
                .background(.regularMaterial, in: Circle())
                .overlay(Circle().stroke(Color.white.opacity(0.28), lineWidth: 0.75))
                .shadow(color: .black.opacity(0.22), radius: 14, x: 0, y: 6)
        }
        .buttonStyle(.plain)
        .accessibilityLabel(self.isTopDown ? "Switch to 3D view" : "Switch to top-down view")
        .accessibilityValue(self.isTopDown ? "Top-down camera" : "3D camera")
        .accessibilityIdentifier("preview.pointCloud.topDownToggle")
    }
}

// MARK: - LAZMetalPointCloudModel

/// Owns background decoding and structure-outline generation for one LAZ file.
@Observable @MainActor
final class LAZMetalPointCloudModel {
    // MARK: Internal

    enum LoadPhase {
        case idle
        case loading
        case loaded(LoadedPointCloud)
        case failed(String)
    }

    private(set) var phase: LoadPhase = .idle
    private(set) var progress: Double = 0
    private(set) var outlineVertices: [PointCloudOutlineVertex]?

    func load(fileURL: URL, metadataURL: URL?) async {
        self.phase = .loading
        self.progress = 0
        self.outlineVertices = nil

        guard let device = MTLCreateSystemDefaultDevice() else {
            self.phase = .failed("Metal is not available on this device.")
            return
        }

        do {
            let cloud = try await Self.decodeCloud(
                fileURL: fileURL,
                deviceBox: MetalDeviceBox(device: device),
                onProgress: { [weak self] fraction in
                    Task { @MainActor [weak self] in
                        self?.progress = fraction
                    }
                }
            )
            try Task.checkCancellation()
            self.phase = .loaded(cloud)
            await self.loadOutlines(for: cloud, metadataURL: metadataURL)
        } catch is CancellationError {
            return
        } catch {
            self.phase = .failed(error.localizedDescription)
        }
    }

    // MARK: Private

    private nonisolated struct MetalDeviceBox: @unchecked Sendable {
        let device: any MTLDevice
    }

    /// Points are decoded straight into one shared-storage Metal buffer so peak memory stays
    /// at a single copy of the interleaved vertex data.
    private nonisolated static func decodeCloud(
        fileURL: URL,
        deviceBox: MetalDeviceBox,
        onProgress: @escaping @Sendable (Double) -> Void
    ) async throws -> LoadedPointCloud {
        let task = Task.detached(priority: .userInitiated) { () throws -> LoadedPointCloud in
            let vertexStride = MemoryLayout<PackedPointVertex>.stride
            precondition(vertexStride == 20, "Vertex layout must match LAZDecoder.mm")

            let info = try LAZDecoder.cloudInfo(forFileAt: fileURL)
            guard info.pointCount > 0 else {
                throw LAZMetalPointCloudError.noPoints
            }
            let budget = Self.pointBudget()
            let unsignedBudget = UInt64(budget)
            let sampleStride = max(
                1,
                info.pointCount / unsignedBudget
                    + UInt64(info.pointCount % unsignedBudget != 0 ? 1 : 0)
            )
            let sampledCountValue = info.pointCount / sampleStride
                + UInt64(info.pointCount % sampleStride != 0 ? 1 : 0)
            guard sampledCountValue <= UInt64(Int.max / vertexStride) else {
                throw LAZMetalPointCloudError.outOfMemory
            }
            let sampledCount = Int(sampledCountValue)
            guard let buffer = deviceBox.device.makeBuffer(
                length: sampledCount * vertexStride,
                options: .storageModeShared
            ) else {
                throw LAZMetalPointCloudError.outOfMemory
            }

            let result = try LAZDecoder.decodePoints(
                at: fileURL,
                intoBuffer: buffer.contents(),
                bufferCapacity: UInt(buffer.length),
                maximumPointCount: UInt(budget),
                progress: onProgress,
                shouldCancel: { Task.isCancelled }
            )
            try Task.checkCancellation()
            let boundsMin = SIMD3(result.boundsMinX, result.boundsMinY, result.boundsMinZ)
            let boundsMax = SIMD3(result.boundsMaxX, result.boundsMaxY, result.boundsMaxZ)
            let inferredBlockerPointCount = result.hasViewerAttributes || result
                .hasClassification ? 0 : PointCloudBlockerClassifier.inferBlockers(
                    in: buffer,
                    pointCount: Int(result.decodedPointCount),
                    boundsMin: boundsMin,
                    boundsMax: boundsMax,
                    shouldCancel: { Task.isCancelled }
                )
            try Task.checkCancellation()
            let floorHeight = PointCloudBlockerClassifier.estimateFloorHeight(
                in: buffer,
                pointCount: Int(result.decodedPointCount),
                fallback: boundsMin.z,
                shouldCancel: { Task.isCancelled }
            )
            try Task.checkCancellation()
            let cloud = LoadedPointCloud(
                vertexBuffer: buffer,
                pointCount: Int(result.decodedPointCount),
                boundsMin: boundsMin,
                boundsMax: boundsMax,
                coordinateOrigin: SIMD3(result.originX, result.originY, result.originZ),
                hasColor: info.hasColor,
                hasClassification: result.hasClassification,
                maxIntensity: result.maxIntensity,
                buildingPointCount: result.buildingPointCount,
                vegetationPointCount: result.vegetationPointCount,
                hasViewerAttributes: result.hasViewerAttributes,
                inferredBlockerPointCount: inferredBlockerPointCount,
                floorHeight: floorHeight,
                sourceURL: fileURL
            )
            if !result.hasViewerAttributes {
                PointCloudBlockerClassifier.encodeHeightsAboveGround(
                    cloud: cloud,
                    shouldCancel: { Task.isCancelled }
                )
            }
            try Task.checkCancellation()
            return cloud
        }
        return try await withTaskCancellationHandler {
            try await task.value
        } onCancel: {
            task.cancel()
        }
    }

    private nonisolated static func pointBudget() -> Int {
        2_000_000
    }

    private func loadOutlines(for cloud: LoadedPointCloud, metadataURL: URL?) async {
        guard cloud.hasRemovableObjects else { return }
        let cacheKey = PointCloudOutlineCache.key(
            for: cloud,
            hasViewerMetadata: metadataURL != nil
        )
        if let cached = PointCloudOutlineCache.value(for: cacheKey) {
            self.outlineVertices = cached
            return
        }

        let vertices = await Task.detached(priority: .utility) {
            if let metadataURL {
                let metadata = try? JSONDecoder().decode(
                    PointCloudViewerMetadata.self,
                    from: Data(contentsOf: metadataURL)
                )
                if let metadata {
                    return metadata.outlineVertices(relativeTo: cloud.coordinateOrigin)
                }
            }
            return PointCloudOutlineBuilder.buildOutlineVertices(cloud: cloud)
        }.value
        PointCloudOutlineCache.store(vertices, for: cacheKey)
        guard case let .loaded(current) = self.phase, current.sourceURL == cloud.sourceURL else { return }
        self.outlineVertices = vertices
    }
}

// MARK: - PointCloudViewerMetadata

private nonisolated struct PointCloudViewerMetadata: Decodable {
    struct Outline: Decodable {
        let category: String
        let coordinates: [[Double]]
    }

    let outlines: [Outline]

    func outlineVertices(relativeTo origin: SIMD3<Double>) -> [PointCloudOutlineVertex] {
        var result: [PointCloudOutlineVertex] = []
        for outline in self.outlines where outline.coordinates.count > 1 {
            let color: SIMD3<UInt8> = switch outline.category {
            case "building": SIMD3(255, 150, 60)
            case "vegetation": SIMD3(96, 210, 110)
            default: SIMD3(255, 196, 74)
            }
            var arcLength: Float = 0
            for index in 1 ..< outline.coordinates.count {
                let previous = outline.coordinates[index - 1]
                let current = outline.coordinates[index]
                guard previous.count == 3, current.count == 3 else { continue }
                let a = SIMD3<Float>(
                    Float(previous[0] - origin.x),
                    Float(previous[1] - origin.y),
                    Float(previous[2] - origin.z)
                )
                let b = SIMD3<Float>(
                    Float(current[0] - origin.x),
                    Float(current[1] - origin.y),
                    Float(current[2] - origin.z)
                )
                let nextArc = arcLength + simd_distance(a, b)
                result.append(PointCloudOutlineVertex(
                    x: a.x, y: a.y, z: a.z,
                    red: color.x, green: color.y, blue: color.z, alpha: 255,
                    arcLength: arcLength
                ))
                result.append(PointCloudOutlineVertex(
                    x: b.x, y: b.y, z: b.z,
                    red: color.x, green: color.y, blue: color.z, alpha: 255,
                    arcLength: nextArc
                ))
                arcLength = nextArc
            }
        }
        return result
    }
}

// MARK: - LAZMetalPointCloudError

private nonisolated enum LAZMetalPointCloudError: LocalizedError {
    case noPoints
    case outOfMemory

    // MARK: Internal

    var errorDescription: String? {
        switch self {
        case .noPoints:
            "The LAZ file does not contain any displayable points."
        case .outOfMemory:
            "There is not enough memory to display this point cloud."
        }
    }
}

// MARK: - PointCloudOutlineCache

/// Keeps computed outlines per file so re-opening a cloud shows them without recomputation.
@MainActor
enum PointCloudOutlineCache {
    // MARK: Internal

    static func key(for cloud: LoadedPointCloud, hasViewerMetadata: Bool) -> String {
        let attributes = try? FileManager.default.attributesOfItem(atPath: cloud.sourceURL.path)
        let modified = (attributes?[.modificationDate] as? Date)?.timeIntervalSince1970 ?? 0
        let provenance = hasViewerMetadata ? "server" : "fallback"
        return "\(cloud.sourceURL.path)|\(modified)|\(cloud.pointCount)|\(provenance)"
    }

    static func value(for key: String) -> [PointCloudOutlineVertex]? {
        self.storage[key]
    }

    static func store(_ vertices: [PointCloudOutlineVertex], for key: String) {
        if self.storage[key] == nil {
            self.insertionOrder.append(key)
        }
        self.storage[key] = vertices
        while self.insertionOrder.count > self.capacity {
            self.storage.removeValue(forKey: self.insertionOrder.removeFirst())
        }
    }

    // MARK: Private

    private static let capacity = 4
    private static var storage: [String: [PointCloudOutlineVertex]] = [:]
    private static var insertionOrder: [String] = []
}

// MARK: - PointCloudMetalContainerView

private struct PointCloudMetalContainerView: UIViewRepresentable {
    struct Configuration {
        let cloud: LoadedPointCloud
        let outlineVertices: [PointCloudOutlineVertex]?
        let isTopDown: Bool
        let topDownPalette: PointCloudTopDownPalette
        let isCanopyRemoved: Bool
    }

    final class Coordinator: NSObject {
        // MARK: Internal

        private(set) var renderer: PointCloudMetalRenderer?

        func attachGestures(to view: MTKView) {
            let orbit = UIPanGestureRecognizer(target: self, action: #selector(self.handleOrbit(_:)))
            orbit.maximumNumberOfTouches = 1
            view.addGestureRecognizer(orbit)

            let pan = UIPanGestureRecognizer(target: self, action: #selector(self.handlePan(_:)))
            pan.minimumNumberOfTouches = 2
            pan.maximumNumberOfTouches = 2
            view.addGestureRecognizer(pan)

            let pinch = UIPinchGestureRecognizer(target: self, action: #selector(self.handlePinch(_:)))
            view.addGestureRecognizer(pinch)

            let doubleTap = UITapGestureRecognizer(target: self, action: #selector(self.handleDoubleTap))
            doubleTap.numberOfTapsRequired = 2
            view.addGestureRecognizer(doubleTap)
        }

        func apply(_ configuration: Configuration, in view: MTKView) {
            if self.renderer == nil || self.cloudURL != configuration.cloud.sourceURL {
                self.renderer = PointCloudMetalRenderer(view: view, cloud: configuration.cloud)
                self.cloudURL = configuration.cloud.sourceURL
            }
            if let outlineVertices = configuration.outlineVertices {
                self.renderer?.setOutlineVertices(outlineVertices)
            }
            self.renderer?.setTopDown(configuration.isTopDown)
            self.renderer?.setTopDownPalette(configuration.topDownPalette)
            self.renderer?.setCanopyRemoval(configuration.isCanopyRemoved)
        }

        // MARK: Private

        private var cloudURL: URL?
        private var lastOrbitTranslation = CGPoint.zero
        private var lastPanTranslation = CGPoint.zero
        private var lastPinchScale: CGFloat = 1

        @objc private func handleOrbit(_ recognizer: UIPanGestureRecognizer) {
            let translation = recognizer.translation(in: recognizer.view)
            if recognizer.state == .began {
                self.lastOrbitTranslation = .zero
            }
            self.renderer?.orbit(
                deltaX: Float(translation.x - self.lastOrbitTranslation.x),
                deltaY: Float(translation.y - self.lastOrbitTranslation.y)
            )
            self.lastOrbitTranslation = translation
        }

        @objc private func handlePan(_ recognizer: UIPanGestureRecognizer) {
            let translation = recognizer.translation(in: recognizer.view)
            if recognizer.state == .began {
                self.lastPanTranslation = .zero
            }
            self.renderer?.pan(
                deltaX: Float(translation.x - self.lastPanTranslation.x),
                deltaY: Float(translation.y - self.lastPanTranslation.y)
            )
            self.lastPanTranslation = translation
        }

        @objc private func handlePinch(_ recognizer: UIPinchGestureRecognizer) {
            if recognizer.state == .began {
                self.lastPinchScale = 1
            }
            let scale = recognizer.scale
            if self.lastPinchScale > 0 {
                self.renderer?.zoom(byFactor: Float(scale / self.lastPinchScale))
            }
            self.lastPinchScale = scale
        }

        @objc private func handleDoubleTap() {
            self.renderer?.resetCamera()
        }
    }

    let cloud: LoadedPointCloud
    let outlineVertices: [PointCloudOutlineVertex]?
    let isTopDown: Bool
    let topDownPalette: PointCloudTopDownPalette
    let isCanopyRemoved: Bool

    static func dismantleUIView(_ uiView: MTKView, coordinator _: Coordinator) {
        uiView.isPaused = true
    }

    func makeCoordinator() -> Coordinator {
        Coordinator()
    }

    func makeUIView(context: Context) -> MTKView {
        let view = MTKView(frame: .zero, device: self.cloud.vertexBuffer.device)
        view.accessibilityIdentifier = "preview.pointCloud"
        context.coordinator.attachGestures(to: view)
        return view
    }

    func updateUIView(_ uiView: MTKView, context: Context) {
        context.coordinator.apply(
            Configuration(
                cloud: self.cloud,
                outlineVertices: self.outlineVertices,
                isTopDown: self.isTopDown,
                topDownPalette: self.topDownPalette,
                isCanopyRemoved: self.isCanopyRemoved
            ),
            in: uiView
        )
    }
}
