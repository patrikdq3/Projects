import simd
import SwiftUI

// MARK: - ScannerMiniMapOverlay

/// Compact top-down map for the live scanner surface.
struct ScannerMiniMapOverlay: View {
    // MARK: Internal

    let points: [CapturedPoint]
    let geoReference: GeoReference?
    let cameraTransform: simd_float4x4?
    let scanStartPosition: SIMD3<Float>?
    let zoneFootprint: ZoneFootprint?
    let projectBoundary: ProjectBoundary?

    var body: some View {
        Canvas { context, size in
            var context = context
            guard let snapshot = ScannerMiniMapProjection.snapshot(
                input: ScannerMiniMapInput(
                    points: self.points,
                    geoReference: self.geoReference,
                    cameraTransform: self.cameraTransform,
                    scanStartPosition: self.scanStartPosition,
                    zoneFootprint: self.zoneFootprint,
                    projectBoundary: self.projectBoundary
                )
            ) else {
                return
            }

            let viewport = ScannerMiniMapViewport(snapshot: snapshot, size: size)

            self.drawZone(snapshot.zoneOutline, viewport: viewport, context: &context)
            self.drawPoints(snapshot.points, viewport: viewport, context: &context)
            if let user = snapshot.user {
                self.drawUser(user, viewport: viewport, context: &context)
            }
        }
        .background(
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .fill(Color.black.opacity(0.68))
        )
        .overlay(
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .strokeBorder(Color.white.opacity(0.14), lineWidth: 1)
        )
        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
        .accessibilityIdentifier("scanner.miniMap")
    }

    // MARK: Private

    private func drawZone(
        _ outline: [ScannerMiniMapCoordinate],
        viewport: ScannerMiniMapViewport,
        context: inout GraphicsContext
    ) {
        guard outline.count >= 2 else {
            return
        }

        var path = Path()
        path.move(to: viewport.screenPoint(for: outline[0]))
        for coordinate in outline.dropFirst() {
            path.addLine(to: viewport.screenPoint(for: coordinate))
        }
        path.closeSubpath()

        context.stroke(path, with: .color(.white.opacity(0.78)), lineWidth: 1.6)
    }

    private func drawPoints(
        _ points: [ScannerMiniMapPoint],
        viewport: ScannerMiniMapViewport,
        context: inout GraphicsContext
    ) {
        for point in points {
            let screenPoint = viewport.screenPoint(for: point.coordinate)
            let rect = CGRect(x: screenPoint.x - 1, y: screenPoint.y - 1, width: 2, height: 2)
            context.fill(
                Path(ellipseIn: rect),
                with: .color(Color(
                    red: Double(point.red) / 255,
                    green: Double(point.green) / 255,
                    blue: Double(point.blue) / 255
                ))
            )
        }
    }

    private func drawUser(
        _ user: ScannerMiniMapUser,
        viewport: ScannerMiniMapViewport,
        context: inout GraphicsContext
    ) {
        let center = viewport.screenPoint(for: user.coordinate)
        let direction = viewport.screenVector(for: user.heading)
        let length = max(0.001, hypot(direction.dx, direction.dy))
        let unit = CGVector(dx: direction.dx / length, dy: direction.dy / length)
        let side = CGVector(dx: -unit.dy, dy: unit.dx)
        let tipLength = 10.0
        let halfBase = 5.5
        let back = CGPoint(x: center.x - unit.dx * 6, y: center.y - unit.dy * 6)

        var path = Path()
        path.move(to: CGPoint(x: center.x + unit.dx * tipLength, y: center.y + unit.dy * tipLength))
        path.addLine(to: CGPoint(x: back.x + side.dx * halfBase, y: back.y + side.dy * halfBase))
        path.addLine(to: CGPoint(x: back.x - side.dx * halfBase, y: back.y - side.dy * halfBase))
        path.closeSubpath()

        context.fill(path, with: .color(Color(red: 0.98, green: 0.78, blue: 0.33)))
        context.stroke(path, with: .color(.black.opacity(0.55)), lineWidth: 1)
    }
}

// MARK: - ScannerMiniMapInput

nonisolated struct ScannerMiniMapInput {
    let points: [CapturedPoint]
    let geoReference: GeoReference?
    let cameraTransform: simd_float4x4?
    let scanStartPosition: SIMD3<Float>?
    let zoneFootprint: ZoneFootprint?
    let projectBoundary: ProjectBoundary?
}

// MARK: - ScannerMiniMapProjection

nonisolated enum ScannerMiniMapProjection {
    // MARK: Internal

    static let maximumPointCount = 2000

    static func snapshot(input: ScannerMiniMapInput) -> ScannerMiniMapSnapshot? {
        let mapPoints = self.sample(input.points).map { point in
            ScannerMiniMapPoint(
                coordinate: self.mapCoordinate(
                    for: point.position,
                    geoReference: input.geoReference,
                    scanStartPosition: input.scanStartPosition,
                    cameraTransform: input.cameraTransform
                ),
                red: point.red,
                green: point.green,
                blue: point.blue
            )
        }
        let zoneOutline = self.zoneOutline(
            geoReference: input.geoReference,
            zoneFootprint: input.zoneFootprint,
            projectBoundary: input.projectBoundary
        )
        let user = input.cameraTransform.map {
            self.userIndicator(
                cameraTransform: $0,
                geoReference: input.geoReference,
                scanStartPosition: input.scanStartPosition
            )
        }

        guard !mapPoints.isEmpty || !zoneOutline.isEmpty || user != nil else {
            return nil
        }

        return ScannerMiniMapSnapshot(points: mapPoints, zoneOutline: zoneOutline, user: user)
    }

    // MARK: Private

    private static func sample(_ points: [CapturedPoint]) -> [CapturedPoint] {
        guard points.count > self.maximumPointCount else {
            return points
        }

        return (0 ..< self.maximumPointCount).map { index in
            let sourceIndex = index * points.count / self.maximumPointCount
            return points[sourceIndex]
        }
    }

    private static func mapCoordinate(
        for position: SIMD3<Float>,
        geoReference: GeoReference?,
        scanStartPosition: SIMD3<Float>?,
        cameraTransform: simd_float4x4?
    ) -> ScannerMiniMapCoordinate {
        if let geoReference {
            let projected = geoReference.projectedCoordinate(for: position)
            return ScannerMiniMapCoordinate(x: projected.x, y: projected.y)
        }

        let origin = scanStartPosition ?? cameraTransform.map(self.cameraPosition(from:)) ?? .zero
        return ScannerMiniMapCoordinate(
            x: Double(position.x - origin.x),
            y: Double(-(position.z - origin.z))
        )
    }

    private static func userIndicator(
        cameraTransform: simd_float4x4,
        geoReference: GeoReference?,
        scanStartPosition: SIMD3<Float>?
    ) -> ScannerMiniMapUser {
        let position = self.cameraPosition(from: cameraTransform)
        let forward = self.cameraForward(from: cameraTransform)
        let coordinate: ScannerMiniMapCoordinate
        let heading: CGVector

        if let geoReference {
            let projectedPosition = geoReference.projectedCoordinate(for: position)
            let projectedHeading = geoReference.projectedCoordinate(for: position + forward)
            coordinate = ScannerMiniMapCoordinate(x: projectedPosition.x, y: projectedPosition.y)
            heading = CGVector(
                dx: projectedHeading.x - projectedPosition.x,
                dy: projectedHeading.y - projectedPosition.y
            )
        } else {
            let origin = scanStartPosition ?? position
            coordinate = ScannerMiniMapCoordinate(
                x: Double(position.x - origin.x),
                y: Double(-(position.z - origin.z))
            )
            heading = CGVector(dx: Double(forward.x), dy: Double(-forward.z))
        }

        return ScannerMiniMapUser(coordinate: coordinate, heading: heading)
    }

    private static func zoneOutline(
        geoReference: GeoReference?,
        zoneFootprint: ZoneFootprint?,
        projectBoundary: ProjectBoundary?
    ) -> [ScannerMiniMapCoordinate] {
        guard geoReference != nil, let projectBoundary else {
            return []
        }

        let coordinates = self.zoneCoordinates(zoneFootprint: zoneFootprint, projectBoundary: projectBoundary)
        return coordinates.map { coordinate in
            let projected = UTMConverter.convert(
                latitude: coordinate.latitude,
                longitude: coordinate.longitude
            )
            return ScannerMiniMapCoordinate(x: projected.easting, y: projected.northing)
        }
    }

    private static func zoneCoordinates(
        zoneFootprint: ZoneFootprint?,
        projectBoundary: ProjectBoundary
    ) -> [GeoCoordinate] {
        guard let points = zoneFootprint?.points, !points.isEmpty else {
            return projectBoundary.vertices
        }

        let boundaryLocalPoints = projectBoundary.vertices.map {
            BoundaryGeometry.localPoint(of: $0, in: projectBoundary)
        }
        let clippedPoints = BoundaryGeometry.clip(polygon: points, to: boundaryLocalPoints)
        guard clippedPoints.count >= 3 else {
            return []
        }

        return clippedPoints.map {
            BoundaryGeometry.coordinate(from: projectBoundary, atLocal: $0)
        }
    }

    private static func cameraPosition(from transform: simd_float4x4) -> SIMD3<Float> {
        SIMD3(transform.columns.3.x, transform.columns.3.y, transform.columns.3.z)
    }

    private static func cameraForward(from transform: simd_float4x4) -> SIMD3<Float> {
        let forward = SIMD3<Float>(-transform.columns.2.x, -transform.columns.2.y, -transform.columns.2.z)
        let horizontal = SIMD3<Float>(forward.x, 0, forward.z)
        let length = simd_length(horizontal)

        guard length > .ulpOfOne else {
            return SIMD3<Float>(0, 0, -1)
        }

        return horizontal / length
    }
}

// MARK: - ScannerMiniMapViewport

nonisolated struct ScannerMiniMapViewport {
    // MARK: Lifecycle

    init(snapshot: ScannerMiniMapSnapshot, size: CGSize) {
        self.size = size

        var bounds = ScannerMiniMapBounds()
        for point in snapshot.points {
            bounds.include(point.coordinate)
        }
        for coordinate in snapshot.zoneOutline {
            bounds.include(coordinate)
        }
        if let user = snapshot.user {
            bounds.include(user.coordinate)
        }

        self.bounds = bounds.resolved()
    }

    // MARK: Internal

    let size: CGSize
    let bounds: ScannerMiniMapBounds

    func screenPoint(for coordinate: ScannerMiniMapCoordinate) -> CGPoint {
        let padding = 12.0
        let availableWidth = max(1, self.size.width - padding * 2)
        let availableHeight = max(1, self.size.height - padding * 2)
        let scale = min(availableWidth / self.bounds.width, availableHeight / self.bounds.height)
        let drawnWidth = self.bounds.width * scale
        let drawnHeight = self.bounds.height * scale
        let offsetX = (self.size.width - drawnWidth) * 0.5
        let offsetY = (self.size.height - drawnHeight) * 0.5

        return CGPoint(
            x: offsetX + (coordinate.x - self.bounds.minX) * scale,
            y: offsetY + (self.bounds.maxY - coordinate.y) * scale
        )
    }

    func screenVector(for vector: CGVector) -> CGVector {
        CGVector(dx: vector.dx, dy: -vector.dy)
    }
}

// MARK: - ScannerMiniMapSnapshot

nonisolated struct ScannerMiniMapSnapshot {
    let points: [ScannerMiniMapPoint]
    let zoneOutline: [ScannerMiniMapCoordinate]
    let user: ScannerMiniMapUser?
}

// MARK: - ScannerMiniMapPoint

nonisolated struct ScannerMiniMapPoint {
    let coordinate: ScannerMiniMapCoordinate
    let red: UInt8
    let green: UInt8
    let blue: UInt8
}

// MARK: - ScannerMiniMapUser

nonisolated struct ScannerMiniMapUser {
    let coordinate: ScannerMiniMapCoordinate
    let heading: CGVector
}

// MARK: - ScannerMiniMapCoordinate

nonisolated struct ScannerMiniMapCoordinate {
    let x: Double
    let y: Double
}

// MARK: - ScannerMiniMapBounds

nonisolated struct ScannerMiniMapBounds {
    var minX = Double.infinity
    var minY = Double.infinity
    var maxX = -Double.infinity
    var maxY = -Double.infinity

    var width: Double {
        self.maxX - self.minX
    }

    var height: Double {
        self.maxY - self.minY
    }

    mutating func include(_ coordinate: ScannerMiniMapCoordinate) {
        self.minX = min(self.minX, coordinate.x)
        self.minY = min(self.minY, coordinate.y)
        self.maxX = max(self.maxX, coordinate.x)
        self.maxY = max(self.maxY, coordinate.y)
    }

    func resolved() -> ScannerMiniMapBounds {
        guard self.minX.isFinite, self.minY.isFinite, self.maxX.isFinite, self.maxY.isFinite else {
            return ScannerMiniMapBounds(minX: -1, minY: -1, maxX: 1, maxY: 1)
        }

        var resolved = self
        let minimumExtent = 2.0
        if resolved.width < minimumExtent {
            let center = (resolved.minX + resolved.maxX) * 0.5
            resolved.minX = center - minimumExtent * 0.5
            resolved.maxX = center + minimumExtent * 0.5
        }
        if resolved.height < minimumExtent {
            let center = (resolved.minY + resolved.maxY) * 0.5
            resolved.minY = center - minimumExtent * 0.5
            resolved.maxY = center + minimumExtent * 0.5
        }

        return resolved
    }
}
