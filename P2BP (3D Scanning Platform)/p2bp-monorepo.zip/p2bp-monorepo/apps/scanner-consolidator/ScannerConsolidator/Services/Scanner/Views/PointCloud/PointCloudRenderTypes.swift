import Foundation
import Metal
import simd

// MARK: - PackedPointVertex

/// CPU mirror of `PointVertexIn` in PointCloudShaders.metal, written by LAZDecoder.mm.
nonisolated struct PackedPointVertex {
    var x: Float
    var y: Float
    var z: Float
    var red: UInt8
    var green: UInt8
    var blue: UInt8
    var classification: UInt8
    var intensity: UInt16
    /// Transient display metadata: bit zero marks an inferred blocker; bits 1–15 hold the
    /// point's height above the local ground envelope in centimeters.
    var padding: UInt16

    var position: SIMD3<Float> {
        SIMD3(self.x, self.y, self.z)
    }
}

// MARK: - PointCloudUniforms

/// Mirror of `PointCloudUniforms` in PointCloudShaders.metal.
nonisolated struct PointCloudUniforms {
    var viewProjection: simd_float4x4
    var pointSize: Float
    var intensityScale: Float
    var perspectiveReference: Float
    var projectionBlend: Float
    var vertexStride: UInt32
    var colorMode: UInt32
    var groundHeight: Float
    var elevationScale: Float
    /// Roof/canopy cut above the local ground envelope, in meters; zero or below disables.
    var cutHeight: Float
    /// Whether intensity contains server-provided normal and surface flags.
    var hasViewerAttributes: UInt32
    var padding2: UInt32 = 0
    var padding3: UInt32 = 0
}

// MARK: - PointCloudOutlineUniforms

/// Mirror of `OutlineUniforms` in PointCloudShaders.metal.
nonisolated struct PointCloudOutlineUniforms {
    var viewProjection: simd_float4x4
    var params: SIMD4<Float>
}

// MARK: - PointCloudOutlineVertex

/// Mirror of `OutlineVertexIn` in PointCloudShaders.metal; one line-list vertex.
/// `arcLength` is the cumulative distance along the outline loop, in meters, used for
/// dashed rendering in the blueprint style.
nonisolated struct PointCloudOutlineVertex {
    var x: Float
    var y: Float
    var z: Float
    var red: UInt8
    var green: UInt8
    var blue: UInt8
    var alpha: UInt8
    var arcLength: Float
}

// MARK: - PointCloudColorMode

nonisolated enum PointCloudColorMode: UInt32 {
    case rgb = 0
    case intensity = 1
    case flat = 2
    /// Elevation heat map: neutral ground through blue, amber, and red raised structures.
    case heatWarm = 3
    /// Elevation gradient in muted cool grays for a plan-style top-down read.
    case heatCool = 4
    /// Plan-drawing look: light gray ground shading on white with structures culled.
    case blueprint = 5
}

// MARK: - PointCloudTopDownPalette

/// Point-cloud looks available independently of the current camera projection.
nonisolated enum PointCloudTopDownPalette: Equatable {
    case original
    case heat
    case coolGray
    case blueprint

    // MARK: Internal

    var colorMode: PointCloudColorMode? {
        switch self {
        case .original: nil
        case .heat: .heatWarm
        case .coolGray: .heatCool
        case .blueprint: .blueprint
        }
    }

    var next: PointCloudTopDownPalette {
        switch self {
        case .original: .heat
        case .heat: .coolGray
        case .coolGray: .blueprint
        case .blueprint: .original
        }
    }

    var showsElevationLegend: Bool {
        self == .heat || self == .coolGray
    }
}

// MARK: - LoadedPointCloud

/// Immutable decoded cloud shared between the loader, renderer, and outline builder.
/// The vertex buffer is written once during decode and only read afterwards, so it is
/// safe to hand across concurrency domains.
nonisolated struct LoadedPointCloud: @unchecked Sendable {
    let vertexBuffer: any MTLBuffer
    let pointCount: Int
    let boundsMin: SIMD3<Float>
    let boundsMax: SIMD3<Float>
    /// Absolute LAS coordinate subtracted before Float conversion.
    let coordinateOrigin: SIMD3<Double>
    let hasColor: Bool
    let hasClassification: Bool
    let maxIntensity: UInt16
    let buildingPointCount: UInt64
    let vegetationPointCount: UInt64
    let hasViewerAttributes: Bool
    let inferredBlockerPointCount: Int
    let floorHeight: Float
    let sourceURL: URL

    var colorMode: PointCloudColorMode {
        if self.hasColor {
            .rgb
        } else if self.maxIntensity > 0 {
            .intensity
        } else {
            .flat
        }
    }

    var hasRemovableObjects: Bool {
        self.hasViewerAttributes || self.buildingPointCount + self.vegetationPointCount > 0
            || self.inferredBlockerPointCount > 0
    }
}
