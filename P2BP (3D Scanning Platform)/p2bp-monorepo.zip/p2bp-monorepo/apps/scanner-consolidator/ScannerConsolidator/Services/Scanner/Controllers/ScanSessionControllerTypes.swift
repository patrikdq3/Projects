import Foundation

extension ScanSessionController {
    /// Chooses how the scanner should be presented inside the host app.
    enum EntryMode: Equatable {
        case standalone
        case newZone
        case resumeZone(UUID)
        case reviewZone(UUID)

        // MARK: Internal

        var existingProjectID: UUID? {
            switch self {
            case let .resumeZone(projectID), let .reviewZone(projectID):
                return projectID
            case .standalone, .newZone:
                return nil
            }
        }

        var allowsCapture: Bool {
            switch self {
            case .reviewZone:
                return false
            case .standalone, .newZone, .resumeZone:
                return true
            }
        }

        var allowsResetForNewScan: Bool {
            self == .standalone
        }
    }

    /// High-level phase of the scanner workflow shown by the UI.
    enum ScanPhase: String {
        case unsupported
        case idle
        case calibratingLocation
        case capturing
        case processing
        case preview
        case failed

        // MARK: Internal

        /// User-facing label for the current phase.
        var title: String {
            switch self {
            case .unsupported:
                return "Unsupported"
            case .idle:
                return "Ready"
            case .calibratingLocation:
                return "Calibrating"
            case .capturing:
                return "Capturing"
            case .processing:
                return "Processing"
            case .preview:
                return "Preview"
            case .failed:
                return "Blocked"
            }
        }
    }

    /// Coarse quality label for the current location signal.
    enum LocationGrade {
        case good
        case fair
        case poor
        case unavailable
    }

    /// Visual tone used by the live capture-health overlay.
    enum CaptureHealthTone: Equatable {
        case neutral
        case progress
        case caution
        case critical
    }

    /// Compact operator guidance derived from scan phase, tracking, and recent growth.
    struct CaptureHealth: Equatable {
        let title: String
        let message: String
        let systemImage: String
        let tone: CaptureHealthTone
        let detail: String?
    }

    /// Returns `true` when a new capture can be started immediately.
    var canStartCapture: Bool {
        self.phase == .idle && self.entryMode.allowsCapture
    }

    /// Returns `true` when the preview should expose the generic reset button.
    var canResetForNewScan: Bool {
        self.entryMode.allowsResetForNewScan
    }

    /// Indicates whether the live AR camera surface should remain visible for the current phase.
    var shouldShowCameraView: Bool {
        switch self.phase {
        case .idle, .calibratingLocation, .capturing, .processing:
            return true
        case .unsupported, .preview, .failed:
            return false
        }
    }

    /// Warning text that explains limited or missing georeferencing quality.
    var locationWarningText: String? {
        if self.currentLocation == nil {
            return "Location unavailable. The scan will stay in a local frame until the device gets a fix."
        }

        if self.approximateGeoreferencing {
            return "Consumer-grade GPS/heading only. Georeferencing is approximate."
        }

        return nil
    }
}
