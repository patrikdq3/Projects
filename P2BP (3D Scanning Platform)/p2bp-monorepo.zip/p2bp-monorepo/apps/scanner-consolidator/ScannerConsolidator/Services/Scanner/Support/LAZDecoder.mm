#import "LAZDecoder.h"

#include "../../../ThirdParty/LAZPerf/lazperf/readers.hpp"

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <exception>
#include <limits>
#include <vector>

namespace {

// Must stay in sync with PointVertexIn in PointCloudShaders.metal and
// PackedPointVertex in PointCloudRenderTypes.swift.
struct PackedDisplayVertex {
    float x;
    float y;
    float z;
    uint8_t red;
    uint8_t green;
    uint8_t blue;
    uint8_t classification;
    uint16_t intensity;
    uint16_t padding;
};

static_assert(sizeof(PackedDisplayVertex) == 20, "Display vertex layout must match the Metal shaders");

constexpr size_t intensityFieldOffset = 12;
constexpr size_t pointFormat7BaseLength = 36;
constexpr size_t viewerHAGOffset = pointFormat7BaseLength + 1 + 2 + 8;
constexpr size_t viewerNormalZOffset = viewerHAGOffset + 2;
constexpr size_t viewerSurfaceFlagsOffset = viewerNormalZOffset + 1;
constexpr size_t viewerPointRecordLength = viewerSurfaceFlagsOffset + 1;
constexpr uint8_t serverAttributesFlag = 1 << 7;

struct ViewerExtraDimension {
    const char *name;
    uint8_t dataType;
};

constexpr std::array<ViewerExtraDimension, 6> viewerExtraDimensions = {{
    {"confidence", 1},
    {"source_id", 3},
    {"scan_time", 10},
    {"p2bp_hag_cm", 3},
    {"p2bp_normal_z", 2},
    {"p2bp_surface_flags", 1},
}};

struct ColorOffset {
    bool available;
    size_t value;
};

ColorOffset colorOffsetForPointFormat(int format) {
    switch (format) {
        case 2:
            return {true, 20};
        case 3:
        case 5:
            return {true, 28};
        case 7:
        case 8:
        case 10:
            return {true, 30};
        default:
            return {false, 0};
    }
}

size_t classificationOffsetForPointFormat(int format) {
    // Formats 0-5 pack the class into the low 5 bits at byte 15; formats 6-10 store a
    // full classification byte at offset 16.
    return format >= 6 ? 16 : 15;
}

uint8_t classificationMaskForPointFormat(int format) {
    return format >= 6 ? 0xFF : 0x1F;
}

template <typename Value>
Value readLittleEndian(const char *bytes) {
    Value value;
    std::memcpy(&value, bytes, sizeof(Value));
    return value;
}

uint8_t displayColor(uint16_t value) {
    return static_cast<uint8_t>(value > 255 ? value >> 8 : value);
}

bool hasViewerAttributeLayout(
    lazperf::reader::named_file &reader,
    const lazperf::header14 &header
) {
    if (header.pointFormat() != 7 || header.point_record_length != viewerPointRecordLength) {
        return false;
    }
    const std::vector<char> data = reader.vlrData("LASF_Spec", 4);
    if (data.size() != viewerExtraDimensions.size() * 192) {
        return false;
    }
    lazperf::eb_vlr extraBytes;
    extraBytes.fill(data.data(), data.size());
    if (extraBytes.items.size() != viewerExtraDimensions.size()) {
        return false;
    }
    for (size_t index = 0; index < viewerExtraDimensions.size(); ++index) {
        const ViewerExtraDimension &expected = viewerExtraDimensions[index];
        const lazperf::eb_vlr::ebfield &actual = extraBytes.items[index];
        if (actual.name != expected.name || actual.data_type != expected.dataType) {
            return false;
        }
    }
    return true;
}

NSError *decoderError(NSString *message) {
    return [NSError errorWithDomain:@"LAZDecoderErrorDomain"
                               code:1
                           userInfo:@{NSLocalizedDescriptionKey: message}];
}

NSError *cancelledError() {
    return [NSError errorWithDomain:NSCocoaErrorDomain code:NSUserCancelledError userInfo:nil];
}

} // namespace

// MARK: - LAZCloudInfo

@interface LAZCloudInfo ()

@property (nonatomic, readwrite) uint64_t pointCount;
@property (nonatomic, readwrite) BOOL hasColor;
@property (nonatomic, readwrite) double minX;
@property (nonatomic, readwrite) double minY;
@property (nonatomic, readwrite) double minZ;
@property (nonatomic, readwrite) double maxX;
@property (nonatomic, readwrite) double maxY;
@property (nonatomic, readwrite) double maxZ;

@end

@implementation LAZCloudInfo
@end

// MARK: - LAZCloudDecodeResult

@interface LAZCloudDecodeResult ()

@property (nonatomic, readwrite) NSUInteger decodedPointCount;
@property (nonatomic, readwrite) BOOL hasClassification;
@property (nonatomic, readwrite) uint16_t maxIntensity;
@property (nonatomic, readwrite) uint64_t buildingPointCount;
@property (nonatomic, readwrite) uint64_t vegetationPointCount;
@property (nonatomic, readwrite) BOOL hasViewerAttributes;
@property (nonatomic, readwrite) double originX;
@property (nonatomic, readwrite) double originY;
@property (nonatomic, readwrite) double originZ;
@property (nonatomic, readwrite) float boundsMinX;
@property (nonatomic, readwrite) float boundsMinY;
@property (nonatomic, readwrite) float boundsMinZ;
@property (nonatomic, readwrite) float boundsMaxX;
@property (nonatomic, readwrite) float boundsMaxY;
@property (nonatomic, readwrite) float boundsMaxZ;

@end

@implementation LAZCloudDecodeResult
@end

// MARK: - LAZDecoder

@implementation LAZDecoder

+ (LAZCloudInfo *)cloudInfoForFileAtURL:(NSURL *)fileURL error:(NSError **)error {
    if (!fileURL.isFileURL) {
        if (error) {
            *error = decoderError(@"The LAZ file URL is invalid.");
        }
        return nil;
    }

    try {
        lazperf::reader::named_file reader(fileURL.fileSystemRepresentation);
        const lazperf::header14 &header = reader.header();

        LAZCloudInfo *info = [[LAZCloudInfo alloc] init];
        info.pointCount = reader.pointCount();
        info.hasColor = colorOffsetForPointFormat(header.pointFormat()).available;
        info.minX = header.minx;
        info.minY = header.miny;
        info.minZ = header.minz;
        info.maxX = header.maxx;
        info.maxY = header.maxy;
        info.maxZ = header.maxz;
        return info;
    } catch (const std::exception &exception) {
        if (error) {
            NSString *message = [NSString stringWithUTF8String:exception.what()];
            *error = decoderError(message ?: @"The LAZ file could not be opened.");
        }
        return nil;
    } catch (...) {
        if (error) {
            *error = decoderError(@"The LAZ file could not be opened.");
        }
        return nil;
    }
}

+ (LAZCloudDecodeResult *)decodePointsAtURL:(NSURL *)fileURL
                                 intoBuffer:(void *)buffer
                             bufferCapacity:(NSUInteger)bufferCapacity
                          maximumPointCount:(NSUInteger)maximumPointCount
                                   progress:(void (^)(double))progress
                               shouldCancel:(BOOL (^)(void))shouldCancel
                                      error:(NSError **)error {
    if (!fileURL.isFileURL || buffer == NULL || maximumPointCount == 0) {
        if (error) {
            *error = decoderError(@"The LAZ decode request is invalid.");
        }
        return nil;
    }

    try {
        lazperf::reader::named_file reader(fileURL.fileSystemRepresentation);
        const lazperf::header14 &header = reader.header();
        const uint64_t sourcePointCount = reader.pointCount();
        if (sourcePointCount == 0) {
            if (error) {
                *error = decoderError(@"The LAZ file does not contain any points.");
            }
            return nil;
        }

        const uint64_t maximumPoints = static_cast<uint64_t>(maximumPointCount);
        const uint64_t stride = std::max<uint64_t>(
            1,
            sourcePointCount / maximumPoints
                + static_cast<uint64_t>(sourcePointCount % maximumPoints != 0)
        );
        const uint64_t sampledCount = sourcePointCount / stride
            + static_cast<uint64_t>(sourcePointCount % stride != 0);
        const NSUInteger capacityInVertices =
            bufferCapacity / sizeof(PackedDisplayVertex);
        if (sampledCount > capacityInVertices) {
            if (error) {
                *error = decoderError(@"The destination buffer is too small for the LAZ file.");
            }
            return nil;
        }

        const int pointFormat = header.pointFormat();
        const int baseRecordLength = lazperf::baseCount(pointFormat);
        if (baseRecordLength == 0) {
            if (error) {
                *error = decoderError(@"This LAZ point format is not supported.");
            }
            return nil;
        }
        if (header.point_record_length < baseRecordLength) {
            if (error) {
                *error = decoderError(@"The LAZ point record format is invalid.");
            }
            return nil;
        }
        const bool coordinateTransformValid =
            std::isfinite(header.scale.x) && std::isfinite(header.scale.y)
            && std::isfinite(header.scale.z) && std::isfinite(header.offset.x)
            && std::isfinite(header.offset.y) && std::isfinite(header.offset.z);
        if (!coordinateTransformValid) {
            if (error) {
                *error = decoderError(@"The LAZ coordinate transform is invalid.");
            }
            return nil;
        }

        const ColorOffset colorOffset = colorOffsetForPointFormat(pointFormat);
        if (colorOffset.available && header.point_record_length < colorOffset.value + 6) {
            if (error) {
                *error = decoderError(@"The LAZ point record format is invalid.");
            }
            return nil;
        }
        const size_t classificationOffset = classificationOffsetForPointFormat(pointFormat);
        const uint8_t classificationMask = classificationMaskForPointFormat(pointFormat);
        const bool hasViewerAttributes = hasViewerAttributeLayout(reader, header);

        // Subtract the header minimum in double precision before narrowing to Float so
        // UTM-scale coordinates do not jitter. Fall back to the first point when the
        // header bounds are missing or inconsistent.
        const bool headerBoundsValid = std::isfinite(header.minx) && std::isfinite(header.miny)
            && std::isfinite(header.minz) && header.minx <= header.maxx
            && header.miny <= header.maxy && header.minz <= header.maxz;
        double originX = headerBoundsValid ? header.minx : 0;
        double originY = headerBoundsValid ? header.miny : 0;
        double originZ = headerBoundsValid ? header.minz : 0;
        bool hasOrigin = headerBoundsValid;

        PackedDisplayVertex *vertices = static_cast<PackedDisplayVertex *>(buffer);
        NSUInteger written = 0;
        uint64_t buildingCount = 0;
        uint64_t vegetationCount = 0;
        bool sawClassified = false;
        uint16_t maxIntensity = 0;
        float minBounds[3] = {
            std::numeric_limits<float>::max(),
            std::numeric_limits<float>::max(),
            std::numeric_limits<float>::max(),
        };
        float maxBounds[3] = {
            std::numeric_limits<float>::lowest(),
            std::numeric_limits<float>::lowest(),
            std::numeric_limits<float>::lowest(),
        };

        std::vector<char> pointBuffer(header.point_record_length);
        const uint64_t progressStep = std::max<uint64_t>(1, sourcePointCount / 128);

        for (uint64_t index = 0; index < sourcePointCount; ++index) {
            if ((index & 0x3FF) == 0 && shouldCancel()) {
                if (error) {
                    *error = cancelledError();
                }
                return nil;
            }
            reader.readPoint(pointBuffer.data());
            if (progress && index % progressStep == 0) {
                progress(static_cast<double>(index) / static_cast<double>(sourcePointCount));
            }
            if (index % stride != 0) {
                continue;
            }
            if (written >= capacityInVertices) {
                if (error) {
                    *error = decoderError(@"The destination buffer is too small for the LAZ file.");
                }
                return nil;
            }

            const double x = readLittleEndian<int32_t>(pointBuffer.data()) * header.scale.x + header.offset.x;
            const double y = readLittleEndian<int32_t>(pointBuffer.data() + 4) * header.scale.y + header.offset.y;
            const double z = readLittleEndian<int32_t>(pointBuffer.data() + 8) * header.scale.z + header.offset.z;
            if (!std::isfinite(x) || !std::isfinite(y) || !std::isfinite(z)) {
                continue;
            }
            if (!hasOrigin) {
                originX = x;
                originY = y;
                originZ = z;
                hasOrigin = true;
            }

            const double localX = x - originX;
            const double localY = y - originY;
            const double localZ = z - originZ;
            if (!std::isfinite(static_cast<float>(localX))
                || !std::isfinite(static_cast<float>(localY))
                || !std::isfinite(static_cast<float>(localZ))) {
                continue;
            }
            PackedDisplayVertex &vertex = vertices[written];
            vertex.x = static_cast<float>(localX);
            vertex.y = static_cast<float>(localY);
            vertex.z = static_cast<float>(localZ);

            std::array<uint8_t, 3> color = {210, 220, 230};
            if (colorOffset.available) {
                color[0] = displayColor(readLittleEndian<uint16_t>(pointBuffer.data() + colorOffset.value));
                color[1] = displayColor(readLittleEndian<uint16_t>(pointBuffer.data() + colorOffset.value + 2));
                color[2] = displayColor(readLittleEndian<uint16_t>(pointBuffer.data() + colorOffset.value + 4));
            }
            vertex.red = color[0];
            vertex.green = color[1];
            vertex.blue = color[2];

            const uint8_t classification =
                static_cast<uint8_t>(pointBuffer[classificationOffset]) & classificationMask;
            vertex.classification = classification;
            const uint16_t sourceIntensity =
                readLittleEndian<uint16_t>(pointBuffer.data() + intensityFieldOffset);
            if (hasViewerAttributes) {
                const uint16_t hag =
                    readLittleEndian<uint16_t>(pointBuffer.data() + viewerHAGOffset);
                const uint8_t normalZ = static_cast<uint8_t>(pointBuffer[viewerNormalZOffset]);
                const uint8_t flags =
                    static_cast<uint8_t>(pointBuffer[viewerSurfaceFlagsOffset]) | serverAttributesFlag;
                // Keep the existing 20-byte GPU layout: HAG remains in padding's upper
                // 15 bits, while intensity carries quantized normal Z + surface flags.
                vertex.padding = static_cast<uint16_t>(std::min<uint16_t>(hag, 32767) << 1)
                    | (flags & 1);
                vertex.intensity = static_cast<uint16_t>(normalZ)
                    | (static_cast<uint16_t>(flags) << 8);
            } else {
                vertex.intensity = sourceIntensity;
                vertex.padding = 0;
            }

            if (classification > 1) {
                sawClassified = true;
            }
            if (classification == 6) {
                ++buildingCount;
            } else if (classification == 4 || classification == 5) {
                ++vegetationCount;
            }
            maxIntensity = std::max(maxIntensity, sourceIntensity);
            minBounds[0] = std::min(minBounds[0], vertex.x);
            minBounds[1] = std::min(minBounds[1], vertex.y);
            minBounds[2] = std::min(minBounds[2], vertex.z);
            maxBounds[0] = std::max(maxBounds[0], vertex.x);
            maxBounds[1] = std::max(maxBounds[1], vertex.y);
            maxBounds[2] = std::max(maxBounds[2], vertex.z);
            ++written;
        }

        if (written == 0) {
            if (error) {
                *error = decoderError(@"The LAZ file does not contain any displayable points.");
            }
            return nil;
        }
        if (progress) {
            progress(1.0);
        }

        LAZCloudDecodeResult *result = [[LAZCloudDecodeResult alloc] init];
        result.decodedPointCount = written;
        result.hasClassification = sawClassified;
        result.maxIntensity = maxIntensity;
        result.buildingPointCount = buildingCount;
        result.vegetationPointCount = vegetationCount;
        result.hasViewerAttributes = hasViewerAttributes;
        result.originX = originX;
        result.originY = originY;
        result.originZ = originZ;
        result.boundsMinX = minBounds[0];
        result.boundsMinY = minBounds[1];
        result.boundsMinZ = minBounds[2];
        result.boundsMaxX = maxBounds[0];
        result.boundsMaxY = maxBounds[1];
        result.boundsMaxZ = maxBounds[2];
        return result;
    } catch (const std::exception &exception) {
        if (error) {
            NSString *message = [NSString stringWithUTF8String:exception.what()];
            *error = decoderError(message ?: @"The LAZ file could not be decoded.");
        }
        return nil;
    } catch (...) {
        if (error) {
            *error = decoderError(@"The LAZ file could not be decoded.");
        }
        return nil;
    }
}

@end
