import SceneKit
import SwiftUI

// MARK: - PointCloudPreviewOrientation

/// Coordinate orientation for point data before it is displayed in SceneKit.
nonisolated enum PointCloudPreviewOrientation: Equatable {
    case yUp
    case zUp
}

// MARK: - PreparedPointCloudGeometry

nonisolated struct PreparedPointCloudGeometry {
    let positionData: Data
    let colorData: Data
    let pointCount: Int
    let extent: Float
    let orientation: PointCloudPreviewOrientation
}

// MARK: - PointCloudPreviewView

/// SwiftUI wrapper that displays captured points in a SceneKit preview.
struct PointCloudPreviewView: UIViewRepresentable {
    final class Coordinator: NSObject {
        // MARK: Internal

        func configure(_ sceneView: SCNView, orientation: PointCloudPreviewOrientation) {
            self.sceneView = sceneView
            self.defaultCameraTransform = sceneView.scene?
                .rootNode
                .childNode(withName: PointCloudSceneRenderer.previewCameraNodeName, recursively: true)?
                .transform
            if orientation == .zUp {
                PointCloudSceneRenderer.configureCameraControls(for: sceneView)
            }

            guard !self.didInstallDoubleTapRecognizer else { return }

            let recognizer = UITapGestureRecognizer(target: self, action: #selector(self.handleDoubleTap(_:)))
            recognizer.numberOfTapsRequired = 2
            recognizer.cancelsTouchesInView = false
            sceneView.addGestureRecognizer(recognizer)
            self.didInstallDoubleTapRecognizer = true
        }

        // MARK: Private

        private weak var sceneView: SCNView?
        private var didInstallDoubleTapRecognizer = false
        private var defaultCameraTransform: SCNMatrix4?

        @objc private func handleDoubleTap(_: UITapGestureRecognizer) {
            guard let sceneView,
                  let cameraNode = sceneView.scene?.rootNode.childNode(
                      withName: PointCloudSceneRenderer.previewCameraNodeName,
                      recursively: true
                  ),
                  let defaultCameraTransform
            else {
                return
            }

            SCNTransaction.begin()
            SCNTransaction.animationDuration = 0.22
            cameraNode.transform = defaultCameraTransform
            sceneView.pointOfView = cameraNode
            SCNTransaction.commit()
        }
    }

    /// Point samples to visualize in the preview scene.
    let points: [CapturedPoint]
    var orientation = PointCloudPreviewOrientation.yUp

    /// Creates the coordinator that owns UIKit gesture callbacks.
    func makeCoordinator() -> Coordinator {
        Coordinator()
    }

    /// Creates the SceneKit view used for the preview.
    func makeUIView(context: Context) -> SCNView {
        let sceneView = SCNView(frame: .zero)
        sceneView.backgroundColor = .black
        sceneView.allowsCameraControl = true
        sceneView.antialiasingMode = .multisampling4X
        sceneView.accessibilityIdentifier = "preview.pointCloud"
        sceneView.scene = PointCloudSceneRenderer.makeScene(points: self.points, orientation: self.orientation)
        context.coordinator.configure(sceneView, orientation: self.orientation)
        return sceneView
    }

    /// Rebuilds the scene whenever the preview point set changes.
    func updateUIView(_ uiView: SCNView, context: Context) {
        uiView.scene = PointCloudSceneRenderer.makeScene(points: self.points, orientation: self.orientation)
        context.coordinator.configure(uiView, orientation: self.orientation)
    }
}

// MARK: - PointCloudSceneRenderer

/// Builds simple SceneKit scenes for previewing captured point clouds.
enum PointCloudSceneRenderer {
    // MARK: Internal

    static let previewCameraNodeName = "PreviewCamera"

    /// Creates a preview scene with point geometry, a camera, and basic lighting.
    static func makeScene(
        points: [CapturedPoint],
        orientation: PointCloudPreviewOrientation = .yUp
    ) -> SCNScene {
        guard let preparedGeometry = self.prepareGeometry(points: points, orientation: orientation) else {
            return SCNScene()
        }
        return self.makeScene(preparedGeometry: preparedGeometry)
    }

    nonisolated static func prepareGeometry(
        points: [CapturedPoint],
        orientation: PointCloudPreviewOrientation
    ) -> PreparedPointCloudGeometry? {
        guard !points.isEmpty else { return nil }
        let initialPosition = self.scenePosition(for: points[0], orientation: orientation)
        let bounds = points.reduce(into: ScanBounds(point: initialPosition)) { partialResult, point in
            partialResult.include(self.scenePosition(for: point, orientation: orientation))
        }
        let center = bounds.center
        let rawExtent = max(0.6, bounds.maxExtent)
        let extent = orientation == .zUp ? min(rawExtent, self.maximumInteractiveExtent) : rawExtent
        let displayScale = extent / rawExtent
        let positionData = NSMutableData(length: points.count * MemoryLayout<Float>.size * 3) ?? NSMutableData()
        let colorData = NSMutableData(length: points.count * MemoryLayout<Float>.size * 4) ?? NSMutableData()
        let positionPointer = positionData.mutableBytes.assumingMemoryBound(to: Float.self)
        let colorPointer = colorData.mutableBytes.assumingMemoryBound(to: Float.self)

        for (index, point) in points.enumerated() {
            let offset = index * 3
            let centeredPoint = (self.scenePosition(for: point, orientation: orientation) - center) * displayScale
            positionPointer[offset] = centeredPoint.x
            positionPointer[offset + 1] = centeredPoint.y
            positionPointer[offset + 2] = centeredPoint.z

            let colorOffset = index * 4
            colorPointer[colorOffset] = self.sRGBToLinear(point.red)
            colorPointer[colorOffset + 1] = self.sRGBToLinear(point.green)
            colorPointer[colorOffset + 2] = self.sRGBToLinear(point.blue)
            colorPointer[colorOffset + 3] = 1.0
        }

        return PreparedPointCloudGeometry(
            positionData: positionData as Data,
            colorData: colorData as Data,
            pointCount: points.count,
            extent: extent,
            orientation: orientation
        )
    }

    static func makeScene(preparedGeometry: PreparedPointCloudGeometry) -> SCNScene {
        let scene = SCNScene()
        let extent = preparedGeometry.extent
        let geometry = self.pointGeometry(preparedGeometry)
        let node = SCNNode(geometry: geometry)
        scene.rootNode.addChildNode(node)

        let camera = SCNCamera()
        camera.zNear = 0.001
        camera.zFar = Double(max(10, extent * 20))
        let cameraNode = SCNNode()
        cameraNode.name = self.previewCameraNodeName
        cameraNode.camera = camera
        cameraNode.position = SCNVector3(0, extent * 0.55, extent * 2.4)
        if preparedGeometry.orientation == .zUp {
            cameraNode.look(at: self.previewTarget)
        }
        scene.rootNode.addChildNode(cameraNode)

        let light = SCNLight()
        light.type = .omni
        light.intensity = 1400
        let lightNode = SCNNode()
        lightNode.light = light
        lightNode.position = SCNVector3(extent, extent * 1.5, extent * 1.8)
        scene.rootNode.addChildNode(lightNode)

        let ambient = SCNLight()
        ambient.type = .ambient
        ambient.intensity = 220
        let ambientNode = SCNNode()
        ambientNode.light = ambient
        scene.rootNode.addChildNode(ambientNode)

        return scene
    }

    static func configureCameraControls(for sceneView: SCNView) {
        sceneView.defaultCameraController.automaticTarget = false
        sceneView.defaultCameraController.target = self.previewTarget
        sceneView.defaultCameraController.interactionMode = .orbitTurntable
        sceneView.defaultCameraController.inertiaEnabled = true
    }

    // MARK: Private

    private static let previewTarget = SCNVector3(0, 0, 0)
    /// Keeps large merged clouds close to zone-preview interaction scale.
    private nonisolated static let maximumInteractiveExtent: Float = 8

    private nonisolated static func scenePosition(
        for point: CapturedPoint,
        orientation: PointCloudPreviewOrientation
    ) -> SIMD3<Float> {
        switch orientation {
        case .yUp:
            point.position
        case .zUp:
            SIMD3(point.x, point.z, -point.y)
        }
    }

    private nonisolated static func sRGBToLinear(_ value: UInt8) -> Float {
        let normalized = Float(value) / 255.0
        if normalized <= 0.04045 {
            return normalized / 12.92
        } else {
            return pow((normalized + 0.055) / 1.055, 2.4)
        }
    }

    /// Converts sampled points into SceneKit geometry centered around the cloud bounds.
    private static func pointGeometry(_ preparedGeometry: PreparedPointCloudGeometry) -> SCNGeometry {
        let positionSource = SCNGeometrySource(
            data: preparedGeometry.positionData,
            semantic: .vertex,
            vectorCount: preparedGeometry.pointCount,
            usesFloatComponents: true,
            componentsPerVector: 3,
            bytesPerComponent: MemoryLayout<Float>.size,
            dataOffset: 0,
            dataStride: MemoryLayout<Float>.size * 3
        )
        let colorSource = SCNGeometrySource(
            data: preparedGeometry.colorData,
            semantic: .color,
            vectorCount: preparedGeometry.pointCount,
            usesFloatComponents: true,
            componentsPerVector: 4,
            bytesPerComponent: MemoryLayout<Float>.size,
            dataOffset: 0,
            dataStride: MemoryLayout<Float>.size * 4
        )

        let element = SCNGeometryElement(
            data: nil,
            primitiveType: .point,
            primitiveCount: preparedGeometry.pointCount,
            bytesPerIndex: 0
        )
        element.pointSize = 7
        element.minimumPointScreenSpaceRadius = 3
        element.maximumPointScreenSpaceRadius = 12

        let geometry = SCNGeometry(sources: [positionSource, colorSource], elements: [element])
        let material = SCNMaterial()
        material.lightingModel = .constant
        material.readsFromDepthBuffer = true
        material.writesToDepthBuffer = true
        geometry.materials = [material]
        return geometry
    }
}
