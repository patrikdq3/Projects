#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/// Header-level metadata for a LAS/LAZ file, read without decoding any points.
@interface LAZCloudInfo : NSObject

@property (nonatomic, readonly) uint64_t pointCount;
@property (nonatomic, readonly) BOOL hasColor;
@property (nonatomic, readonly) double minX;
@property (nonatomic, readonly) double minY;
@property (nonatomic, readonly) double minZ;
@property (nonatomic, readonly) double maxX;
@property (nonatomic, readonly) double maxY;
@property (nonatomic, readonly) double maxZ;

@end

/// Statistics gathered while decoding points into the display vertex buffer.
@interface LAZCloudDecodeResult : NSObject

@property (nonatomic, readonly) NSUInteger decodedPointCount;
/// YES when any point carries an ASPRS classification other than 0 (never classified)
/// or 1 (unclassified).
@property (nonatomic, readonly) BOOL hasClassification;
@property (nonatomic, readonly) uint16_t maxIntensity;
@property (nonatomic, readonly) uint64_t buildingPointCount;
@property (nonatomic, readonly) uint64_t vegetationPointCount;
/// YES when p2bp_hag_cm, p2bp_normal_z, and p2bp_surface_flags are present.
@property (nonatomic, readonly) BOOL hasViewerAttributes;
/// Absolute LAS coordinate subtracted from decoded positions.
@property (nonatomic, readonly) double originX;
@property (nonatomic, readonly) double originY;
@property (nonatomic, readonly) double originZ;
/// Observed bounds of the decoded (origin-relative) float positions.
@property (nonatomic, readonly) float boundsMinX;
@property (nonatomic, readonly) float boundsMinY;
@property (nonatomic, readonly) float boundsMinZ;
@property (nonatomic, readonly) float boundsMaxX;
@property (nonatomic, readonly) float boundsMaxY;
@property (nonatomic, readonly) float boundsMaxZ;

@end

/// Native bridge for decoding LAS/LAZ point clouds with laz-perf.
@interface LAZDecoder : NSObject

/// Reads only the file header so callers can size buffers before decoding.
+ (nullable LAZCloudInfo *)cloudInfoForFileAtURL:(NSURL *)fileURL
                                           error:(NSError * _Nullable * _Nullable)error
    NS_SWIFT_NAME(cloudInfo(forFileAt:));

/// Decodes evenly sampled points into `buffer` using the 20-byte interleaved layout shared
/// with PointCloudShaders.metal: XYZ Float32 (relative to the chosen decode origin to keep
/// Float precision on UTM-sized coordinates), RGB UInt8, ASPRS classification UInt8,
/// intensity UInt16, padding UInt16.
+ (nullable LAZCloudDecodeResult *)decodePointsAtURL:(NSURL *)fileURL
                                          intoBuffer:(void *)buffer
                                      bufferCapacity:(NSUInteger)bufferCapacity
                                   maximumPointCount:(NSUInteger)maximumPointCount
                                            progress:(void (^ _Nullable)(double fraction))progress
                                        shouldCancel:(BOOL (^)(void))shouldCancel
                                               error:(NSError * _Nullable * _Nullable)error
    NS_SWIFT_NAME(decodePoints(at:intoBuffer:bufferCapacity:maximumPointCount:progress:shouldCancel:));

@end

NS_ASSUME_NONNULL_END
