import ARKit
import CoreLocation
import Foundation

// MARK: - ScanSessionController Helpers

extension ScanSessionController {
    /// Converts a `CLLocation` update into the persisted trajectory sample schema.
    static func makeLocationTrajectorySample(from location: CLLocation) -> ScanLocationTrajectorySample? {
        guard CLLocationCoordinate2DIsValid(location.coordinate) else {
            return nil
        }

        return ScanLocationTrajectorySample(
            timestamp: location.timestamp.timeIntervalSince1970,
            latitude: location.coordinate.latitude,
            longitude: location.coordinate.longitude,
            altitude: location.altitude,
            horizontalAccuracy: location.horizontalAccuracy,
            verticalAccuracy: location.verticalAccuracy,
            speed: location.speed,
            speedAccuracy: location.speedAccuracy,
            course: location.course,
            courseAccuracy: location.courseAccuracy
        )
    }

    /// Converts a `CLHeading` update into the persisted heading trajectory schema.
    static func makeHeadingTrajectorySample(from heading: CLHeading) -> ScanHeadingTrajectorySample {
        let resolvedHeading: Double?
        let headingReference: ScanHeadingReference

        if heading.trueHeading >= 0 {
            resolvedHeading = heading.trueHeading
            headingReference = .trueNorth
        } else if heading.magneticHeading >= 0 {
            resolvedHeading = heading.magneticHeading
            headingReference = .magneticNorth
        } else {
            resolvedHeading = nil
            headingReference = .unavailable
        }

        return ScanHeadingTrajectorySample(
            timestamp: heading.timestamp.timeIntervalSince1970,
            trueHeading: heading.trueHeading,
            magneticHeading: heading.magneticHeading,
            headingAccuracy: heading.headingAccuracy,
            headingReference: headingReference,
            resolvedHeadingDegrees: resolvedHeading,
            magneticFieldX: heading.x,
            magneticFieldY: heading.y,
            magneticFieldZ: heading.z
        )
    }

    /// Converts ARKit tracking states into plain-English UI guidance.
    func describe(_ trackingState: ARCamera.TrackingState) -> String {
        switch trackingState {
        case .notAvailable:
            return "Tracking unavailable"
        case .normal:
            return "Tracking locked"
        case let .limited(reason):
            switch reason {
            case .excessiveMotion:
                return "Move more slowly for denser points"
            case .initializing:
                return "Initializing tracking"
            case .insufficientFeatures:
                return "Point the camera at richer surfaces"
            case .relocalizing:
                return "Relocalizing"
            @unknown default:
                return "Tracking limited"
            }
        }
    }
}
