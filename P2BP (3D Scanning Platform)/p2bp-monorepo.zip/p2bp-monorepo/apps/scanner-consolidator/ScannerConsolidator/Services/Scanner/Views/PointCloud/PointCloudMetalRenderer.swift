import MetalKit
import QuartzCore
import simd

// MARK: - PointCloudMetalRenderer

/// Draws a decoded LAZ cloud as point sprites with orbit/pan/zoom, an animated orthographic
/// top-down mode, camera-independent elevation color styles, and a line overlay that
/// outlines detected structures in top-down mode.
final class PointCloudMetalRenderer: NSObject {
    // MARK: Lifecycle

    init?(view: MTKView, cloud: LoadedPointCloud) {
        let device = cloud.vertexBuffer.device
        guard let commandQueue = device.makeCommandQueue(),
              let library = device.makeDefaultLibrary()
        else {
            return nil
        }

        view.device = device
        view.colorPixelFormat = .bgra8Unorm
        view.depthStencilPixelFormat = .depth32Float
        view.clearColor = MTLClearColor(red: 0, green: 0, blue: 0, alpha: 1)
        view.preferredFramesPerSecond = 60

        guard let pointPipeline = Self.makePointPipeline(device: device, library: library, view: view),
              let outlinePipeline = Self.makeOutlinePipeline(device: device, library: library, view: view),
              let pointDepthState = Self.makeDepthState(device: device, writesDepth: true),
              let overlayDepthState = Self.makeDepthState(device: device, writesDepth: false)
        else {
            return nil
        }

        self.cloud = cloud
        self.commandQueue = commandQueue
        self.pointPipeline = pointPipeline
        self.outlinePipeline = outlinePipeline
        self.pointDepthState = pointDepthState
        self.overlayDepthState = overlayDepthState
        self.basePointSize = Float(max(view.contentScaleFactor, 1)) * 3
        self.sceneRadius = max(simd_length(cloud.boundsMax - cloud.boundsMin) * 0.5, 1)
        self.camera = Self.makeInitialCamera(cloud: cloud, sceneRadius: self.sceneRadius)
        super.init()
        view.delegate = self
    }

    // MARK: Internal

    private(set) var isTopDown = false

    func setTopDown(_ enabled: Bool) {
        guard enabled != self.isTopDown else { return }
        self.isTopDown = enabled
        if enabled {
            self.savedElevation = self.camera.elevationRadians
            self.elevationAnimationTarget = PointCloudOrbitCamera.topDownElevation
            self.projectionBlendTarget = 1
        } else {
            self.elevationAnimationTarget = self.savedElevation
            self.projectionBlendTarget = 0
        }
    }

    func setTopDownPalette(_ palette: PointCloudTopDownPalette) {
        self.topDownPalette = palette
    }

    func setCanopyRemoval(_ enabled: Bool) {
        self.isCanopyRemoved = enabled
    }

    func setOutlineVertices(_ vertices: [PointCloudOutlineVertex]) {
        guard !vertices.isEmpty, self.outlineBuffer == nil else { return }
        let length = vertices.count * MemoryLayout<PointCloudOutlineVertex>.stride
        self.outlineBuffer = vertices.withUnsafeBytes { bytes in
            guard let baseAddress = bytes.baseAddress else { return nil }
            return self.cloud.vertexBuffer.device.makeBuffer(
                bytes: baseAddress,
                length: length,
                options: .storageModeShared
            )
        }
        self.outlineVertexCount = vertices.count
    }

    func orbit(deltaX: Float, deltaY: Float) {
        guard !self.isTopDown else {
            self.pan(deltaX: deltaX, deltaY: deltaY)
            return
        }
        self.elevationAnimationTarget = nil
        self.camera.orbit(deltaAzimuth: deltaX * 0.007, deltaElevation: deltaY * 0.007)
    }

    func pan(deltaX: Float, deltaY: Float) {
        self.camera.pan(screenRight: deltaX, screenDown: deltaY)
    }

    func zoom(byFactor factor: Float) {
        self.camera.zoom(byFactor: factor)
    }

    func resetCamera() {
        let initial = Self.makeInitialCamera(cloud: self.cloud, sceneRadius: self.sceneRadius)
        self.camera.target = initial.target
        self.camera.distance = initial.distance
        self.camera.azimuthRadians = initial.azimuthRadians
        if self.isTopDown {
            self.savedElevation = initial.elevationRadians
        } else {
            self.elevationAnimationTarget = initial.elevationRadians
        }
    }

    // MARK: Private

    /// Points higher than this above the local ground envelope are culled when the
    /// roof/canopy cut is active. Sits below typical eave and canopy heights while keeping
    /// enough wall and trunk to read a structure's footprint.
    private static let canopyCutHeight: Float = 2.2

    private let cloud: LoadedPointCloud
    private let commandQueue: any MTLCommandQueue
    private let pointPipeline: any MTLRenderPipelineState
    private let outlinePipeline: any MTLRenderPipelineState
    private let pointDepthState: any MTLDepthStencilState
    private let overlayDepthState: any MTLDepthStencilState
    private let basePointSize: Float
    private let sceneRadius: Float

    private var camera: PointCloudOrbitCamera
    private var topDownPalette = PointCloudTopDownPalette.original
    private var isCanopyRemoved = false
    private var savedElevation: Float = 0.62
    private var elevationAnimationTarget: Float?
    private var projectionBlend: Float = 0
    private var projectionBlendTarget: Float = 0

    private var outlineBuffer: (any MTLBuffer)?
    private var outlineVertexCount = 0

    private var lastFrameTime: CFTimeInterval = 0
    private var frameTimeAverage: CFTimeInterval = 1 / 60
    private var framesSinceStrideChange = 0
    private var lodStride = 1

    private static func makeInitialCamera(cloud: LoadedPointCloud, sceneRadius: Float) -> PointCloudOrbitCamera {
        let center = (cloud.boundsMin + cloud.boundsMax) * 0.5
        return PointCloudOrbitCamera(
            target: center,
            azimuthRadians: -.pi / 2,
            elevationRadians: 0.62,
            distance: sceneRadius * 2.1,
            minimumDistance: max(sceneRadius * 0.02, 0.2),
            maximumDistance: sceneRadius * 8
        )
    }

    private static func makePointPipeline(
        device: any MTLDevice,
        library: any MTLLibrary,
        view: MTKView
    ) -> (any MTLRenderPipelineState)? {
        let descriptor = MTLRenderPipelineDescriptor()
        descriptor.label = "PointCloudPoints"
        descriptor.vertexFunction = library.makeFunction(name: "pointCloudVertex")
        descriptor.fragmentFunction = library.makeFunction(name: "pointCloudFragment")
        descriptor.colorAttachments[0].pixelFormat = view.colorPixelFormat
        descriptor.depthAttachmentPixelFormat = view.depthStencilPixelFormat
        return try? device.makeRenderPipelineState(descriptor: descriptor)
    }

    private static func makeOutlinePipeline(
        device: any MTLDevice,
        library: any MTLLibrary,
        view: MTKView
    ) -> (any MTLRenderPipelineState)? {
        let descriptor = MTLRenderPipelineDescriptor()
        descriptor.label = "PointCloudOutlines"
        descriptor.vertexFunction = library.makeFunction(name: "outlineVertex")
        descriptor.fragmentFunction = library.makeFunction(name: "outlineFragment")
        descriptor.depthAttachmentPixelFormat = view.depthStencilPixelFormat
        let colorAttachment = descriptor.colorAttachments[0]
        colorAttachment?.pixelFormat = view.colorPixelFormat
        colorAttachment?.isBlendingEnabled = true
        colorAttachment?.sourceRGBBlendFactor = .sourceAlpha
        colorAttachment?.destinationRGBBlendFactor = .oneMinusSourceAlpha
        colorAttachment?.sourceAlphaBlendFactor = .sourceAlpha
        colorAttachment?.destinationAlphaBlendFactor = .oneMinusSourceAlpha
        return try? device.makeRenderPipelineState(descriptor: descriptor)
    }

    private static func makeDepthState(device: any MTLDevice, writesDepth: Bool) -> (any MTLDepthStencilState)? {
        let descriptor = MTLDepthStencilDescriptor()
        descriptor.depthCompareFunction = writesDepth ? .less : .always
        descriptor.isDepthWriteEnabled = writesDepth
        return device.makeDepthStencilState(descriptor: descriptor)
    }

    private func advanceAnimation(deltaTime: CFTimeInterval) {
        let ease = Float(1 - exp(-deltaTime * 10))
        self.projectionBlend += (self.projectionBlendTarget - self.projectionBlend) * ease
        if abs(self.projectionBlendTarget - self.projectionBlend) < 0.002 {
            self.projectionBlend = self.projectionBlendTarget
        }
        if let target = self.elevationAnimationTarget {
            self.camera.elevationRadians += (target - self.camera.elevationRadians) * ease
            if abs(target - self.camera.elevationRadians) < 0.001 {
                self.camera.elevationRadians = target
                self.elevationAnimationTarget = nil
            }
        }
    }

    /// Ratchets the shader-side decimation stride up when the frame rate stays below ~30fps.
    private func updateAdaptiveDecimation(deltaTime: CFTimeInterval) {
        self.frameTimeAverage = self.frameTimeAverage * 0.9 + deltaTime * 0.1
        self.framesSinceStrideChange += 1
        guard self.framesSinceStrideChange > 30,
              self.frameTimeAverage > 1.0 / 29.0,
              self.lodStride < 8
        else {
            return
        }
        self.lodStride *= 2
        self.framesSinceStrideChange = 0
        self.frameTimeAverage = 1 / 60
    }

    private func makeViewProjection(aspect: Float) -> simd_float4x4 {
        let fov: Float = .pi / 3
        let distance = self.camera.distance
        let nearZ = max(0.02, distance * 0.002)
        let farZ = distance + self.sceneRadius * 6
        let perspective = PointCloudProjection.perspective(
            fovYRadians: fov,
            aspect: aspect,
            nearZ: nearZ,
            farZ: farZ
        )
        let halfHeight = distance * tan(fov * 0.5)
        let orthographic = PointCloudProjection.orthographic(
            halfWidth: halfHeight * aspect,
            halfHeight: halfHeight,
            nearZ: -self.sceneRadius * 4,
            farZ: farZ
        )
        let projection = PointCloudProjection.blend(perspective, orthographic, amount: self.projectionBlend)
        return projection * self.camera.viewMatrix
    }

    private func encodePoints(encoder: any MTLRenderCommandEncoder, viewProjection: simd_float4x4) {
        var uniforms = self.makeUniforms(viewProjection: viewProjection, vertexStride: UInt32(self.lodStride))
        let drawCount = (self.cloud.pointCount + self.lodStride - 1) / self.lodStride
        encoder.setRenderPipelineState(self.pointPipeline)
        encoder.setDepthStencilState(self.pointDepthState)
        encoder.setVertexBuffer(self.cloud.vertexBuffer, offset: 0, index: 0)
        encoder.setVertexBytes(&uniforms, length: MemoryLayout<PointCloudUniforms>.stride, index: 1)
        encoder.drawPrimitives(type: .point, vertexStart: 0, vertexCount: drawCount)
    }

    private func makeUniforms(
        viewProjection: simd_float4x4,
        vertexStride: UInt32
    ) -> PointCloudUniforms {
        let visibleHeight = max(min(self.cloud.boundsMax.z - self.cloud.floorHeight, 2.4), 0.75)
        let colorMode = self.topDownPalette.colorMode ?? self.cloud.colorMode
        return PointCloudUniforms(
            viewProjection: viewProjection,
            pointSize: self.basePointSize,
            intensityScale: self.cloud.maxIntensity > 0 ? 1 / Float(self.cloud.maxIntensity) : 0,
            perspectiveReference: self.camera.distance,
            projectionBlend: self.projectionBlend,
            vertexStride: vertexStride,
            colorMode: colorMode.rawValue,
            groundHeight: self.cloud.floorHeight,
            elevationScale: 1 / visibleHeight,
            cutHeight: self.isCanopyRemoved ? Self.canopyCutHeight : 0,
            hasViewerAttributes: self.cloud.hasViewerAttributes ? 1 : 0
        )
    }

    private func encodeOutlines(encoder: any MTLRenderCommandEncoder, viewProjection: simd_float4x4) {
        guard self.isTopDown,
              self.projectionBlend > 0.02,
              let outlineBuffer = self.outlineBuffer,
              self.outlineVertexCount > 1
        else {
            return
        }
        var uniforms = PointCloudOutlineUniforms(
            viewProjection: viewProjection,
            params: SIMD4(self.projectionBlend, self.topDownPalette == .blueprint ? 1 : 0, 0, 0)
        )
        encoder.setRenderPipelineState(self.outlinePipeline)
        encoder.setDepthStencilState(self.overlayDepthState)
        encoder.setVertexBuffer(outlineBuffer, offset: 0, index: 0)
        encoder.setVertexBytes(&uniforms, length: MemoryLayout<PointCloudOutlineUniforms>.stride, index: 1)
        encoder.drawPrimitives(type: .line, vertexStart: 0, vertexCount: self.outlineVertexCount)
    }
}

// MARK: MTKViewDelegate

extension PointCloudMetalRenderer: MTKViewDelegate {
    func mtkView(_: MTKView, drawableSizeWillChange _: CGSize) {}

    func draw(in view: MTKView) {
        let now = CACurrentMediaTime()
        let deltaTime = self.lastFrameTime > 0 ? min(now - self.lastFrameTime, 0.25) : 1 / 60
        self.lastFrameTime = now
        self.advanceAnimation(deltaTime: deltaTime)
        self.updateAdaptiveDecimation(deltaTime: deltaTime)

        // The blueprint plan view draws on paper white; every other mode keeps the black stage.
        view.clearColor = self.topDownPalette == .blueprint
            ? MTLClearColor(red: 1, green: 1, blue: 1, alpha: 1)
            : MTLClearColor(red: 0, green: 0, blue: 0, alpha: 1)

        guard let descriptor = view.currentRenderPassDescriptor,
              let drawable = view.currentDrawable,
              let commandBuffer = self.commandQueue.makeCommandBuffer(),
              let encoder = commandBuffer.makeRenderCommandEncoder(descriptor: descriptor)
        else {
            return
        }

        let drawableSize = view.drawableSize
        let aspect = Float(drawableSize.width / max(drawableSize.height, 1))
        let viewProjection = self.makeViewProjection(aspect: aspect)
        self.encodePoints(encoder: encoder, viewProjection: viewProjection)
        self.encodeOutlines(encoder: encoder, viewProjection: viewProjection)
        encoder.endEncoding()
        commandBuffer.present(drawable)
        commandBuffer.commit()
    }
}
