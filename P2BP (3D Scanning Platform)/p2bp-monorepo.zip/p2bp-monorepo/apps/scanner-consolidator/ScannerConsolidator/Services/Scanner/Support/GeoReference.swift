import CoreLocation
import Foundation
import simd

// MARK: - UTMCoordinate

/// Projected coordinate metadata derived from a latitude and longitude in WGS84.
nonisolated struct UTMCoordinate: Codable {
    /// UTM zone number computed from longitude.
    var zone: Int

    /// Indicates whether the coordinate belongs to the northern UTM hemisphere.
    var isNorthernHemisphere: Bool

    /// Easting in meters within the projected UTM zone.
    var easting: Double

    /// Northing in meters within the projected UTM zone.
    var northing: Double

    /// EPSG identifier for the projected coordinate reference system.
    var epsgCode: Int
}

// MARK: - UTMConverter

/// Converts geographic coordinates into UTM coordinates and projection metadata.
nonisolated enum UTMConverter {
    // MARK: Internal

    /// Converts latitude and longitude into a rounded UTM coordinate.
    static func convert(latitude: Double, longitude: Double) -> UTMCoordinate {
        let normalizedLongitude = ((longitude + 180).truncatingRemainder(dividingBy: 360) + 360)
            .truncatingRemainder(dividingBy: 360) - 180
        let latitudeRadians = latitude * .pi / 180
        let longitudeRadians = normalizedLongitude * .pi / 180
        let zone = Int((normalizedLongitude + 180) / 6) + 1
        let centralMeridian = Double(zone * 6 - 183) * .pi / 180
        let isNorthernHemisphere = latitude >= 0

        let eccentricityPrimeSquared = self.eccentricitySquared / (1 - self.eccentricitySquared)
        let n = self.equatorialRadius / sqrt(1 - self.eccentricitySquared * pow(sin(latitudeRadians), 2))
        let t = pow(tan(latitudeRadians), 2)
        let c = eccentricityPrimeSquared * pow(cos(latitudeRadians), 2)
        let a = cos(latitudeRadians) * (longitudeRadians - centralMeridian)

        let m = self.equatorialRadius * (
            (1 - self.eccentricitySquared / 4 - 3 * pow(self.eccentricitySquared, 2) / 64 - 5 * pow(
                self.eccentricitySquared,
                3
            ) / 256) * latitudeRadians
                - (3 * self.eccentricitySquared / 8 + 3 * pow(self.eccentricitySquared, 2) / 32 + 45 * pow(
                    self.eccentricitySquared,
                    3
                ) / 1024) * sin(2 * latitudeRadians)
                + (15 * pow(self.eccentricitySquared, 2) / 256 + 45 * pow(self.eccentricitySquared, 3) / 1024) *
                sin(4 * latitudeRadians)
                - (35 * pow(self.eccentricitySquared, 3) / 3072) * sin(6 * latitudeRadians)
        )

        var easting = self.scaleFactor * n * (
            a
                + (1 - t + c) * pow(a, 3) / 6
                + (5 - 18 * t + pow(t, 2) + 72 * c - 58 * eccentricityPrimeSquared) * pow(a, 5) / 120
        ) + 500_000.0

        var northing = self.scaleFactor * (
            m
                + n * tan(latitudeRadians) * (
                    pow(a, 2) / 2
                        + (5 - t + 9 * c + 4 * pow(c, 2)) * pow(a, 4) / 24
                        + (61 - 58 * t + pow(t, 2) + 600 * c - 330 * eccentricityPrimeSquared) * pow(a, 6) / 720
                )
        )

        if !isNorthernHemisphere {
            northing += 10_000_000.0
        }

        easting = easting.rounded(toPlaces: 3)
        northing = northing.rounded(toPlaces: 3)

        return UTMCoordinate(
            zone: zone,
            isNorthernHemisphere: isNorthernHemisphere,
            easting: easting,
            northing: northing,
            epsgCode: self.epsgCode(zone: zone, isNorthernHemisphere: isNorthernHemisphere)
        )
    }

    /// Returns the EPSG code for a UTM zone and hemisphere pair.
    static func epsgCode(zone: Int, isNorthernHemisphere: Bool) -> Int {
        (isNorthernHemisphere ? 32600 : 32700) + zone
    }

    /// Builds a projected coordinate system WKT string for downstream georeference consumers.
    static func projectedWKT(for coordinate: UTMCoordinate) -> String {
        let hemisphere = coordinate.isNorthernHemisphere ? "N" : "S"
        let falseNorthing = coordinate.isNorthernHemisphere ? 0 : 10_000_000
        let centralMeridian = coordinate.zone * 6 - 183
        let wktComponents = [
            "PROJCS[\"WGS 84 / UTM zone \(coordinate.zone)\(hemisphere)\",",
            "GEOGCS[\"WGS 84\",DATUM[\"WGS_1984\",",
            "SPHEROID[\"WGS 84\",6378137,298.257223563]],",
            "PRIMEM[\"Greenwich\",0],UNIT[\"degree\",0.0174532925199433]],",
            "PROJECTION[\"Transverse_Mercator\"],",
            "PARAMETER[\"latitude_of_origin\",0],",
            "PARAMETER[\"central_meridian\",\(centralMeridian)],",
            "PARAMETER[\"scale_factor\",0.9996],",
            "PARAMETER[\"false_easting\",500000],",
            "PARAMETER[\"false_northing\",\(falseNorthing)],",
            "UNIT[\"metre\",1],",
            "AUTHORITY[\"EPSG\",\"\(coordinate.epsgCode)\"]]",
        ]

        return wktComponents.joined()
    }

    // MARK: Private

    private static let equatorialRadius = 6_378_137.0
    private static let eccentricitySquared = 0.00669437999014
    private static let scaleFactor = 0.9996
}

// MARK: - GeoReference

/// Maps the local ARKit scan frame into a projected real-world coordinate system.
nonisolated struct GeoReference: Codable {
    // MARK: Lifecycle

    /// Creates georeference metadata from device location, heading, and the initial camera pose.
    init?(location: CLLocation, heading: CLHeading?, initialCameraTransform: simd_float4x4, createdAt: Date = .now) {
        guard CLLocationCoordinate2DIsValid(location.coordinate) else {
            return nil
        }

        let utm = UTMConverter.convert(
            latitude: location.coordinate.latitude,
            longitude: location.coordinate.longitude
        )

        let resolvedHeading = Self.resolvedHeading(from: heading)
        let worldForward = Self.worldForwardVector(from: initialCameraTransform)
        let desiredNorthVector = SIMD2<Double>(
            sin(resolvedHeading.degrees * .pi / 180),
            cos(resolvedHeading.degrees * .pi / 180)
        )
        let worldAngle = atan2(Double(worldForward.y), Double(worldForward.x))
        let desiredAngle = atan2(desiredNorthVector.y, desiredNorthVector.x)

        self.originLatitude = location.coordinate.latitude
        self.originLongitude = location.coordinate.longitude
        self.originAltitude = location.altitude
        self.originHorizontalAccuracy = location.horizontalAccuracy
        self.originVerticalAccuracy = location.verticalAccuracy
        self.headingDegrees = resolvedHeading.degrees
        self.headingAccuracy = resolvedHeading.accuracyDegrees ?? -1
        self.utmZone = utm.zone
        self.isNorthernHemisphere = utm.isNorthernHemisphere
        self.epsgCode = utm.epsgCode
        self.originEasting = utm.easting
        self.originNorthing = utm.northing
        self.worldToENURotationRadians = desiredAngle - worldAngle
        self.createdAt = createdAt
        self.wkt = UTMConverter.projectedWKT(for: utm)
        self.alignmentMetadata = Self.makeAlignmentMetadata(
            horizontalAccuracy: location.horizontalAccuracy,
            verticalAccuracy: location.verticalAccuracy,
            resolvedHeading: resolvedHeading
        )
    }

    // MARK: Internal

    /// Latitude of the scan origin.
    var originLatitude: Double

    /// Longitude of the scan origin.
    var originLongitude: Double

    /// Altitude of the scan origin in meters.
    var originAltitude: Double

    /// Horizontal accuracy reported by Core Location for the origin fix.
    var originHorizontalAccuracy: Double

    /// Vertical accuracy reported by Core Location for the origin fix.
    var originVerticalAccuracy: Double

    /// Heading used to align the local scan frame with projected east/north axes.
    var headingDegrees: Double

    /// Reported heading accuracy in degrees, or `-1` when unavailable.
    var headingAccuracy: Double

    /// UTM zone used by the projected coordinate system.
    var utmZone: Int

    /// Indicates whether the selected UTM zone is in the northern hemisphere.
    var isNorthernHemisphere: Bool

    /// EPSG code for the projected coordinate reference system.
    var epsgCode: Int

    /// Projected easting of the scan origin.
    var originEasting: Double

    /// Projected northing of the scan origin.
    var originNorthing: Double

    /// Rotation applied when converting local horizontal coordinates into projected coordinates.
    var worldToENURotationRadians: Double

    /// Timestamp describing when the georeference was created.
    var createdAt: Date

    /// Well-known text description of the projected coordinate system.
    var wkt: String

    /// Provenance and quality metadata for downstream georeference consumers.
    var alignmentMetadata: ScanGeoreferenceMetadata?

    /// Indicates whether the current alignment should be treated as approximate.
    var isApproximate: Bool {
        if let alignmentMetadata {
            return alignmentMetadata.quality == .approximate
        }

        return self.originHorizontalAccuracy < 0 || self.originHorizontalAccuracy > 10 || self.headingAccuracy < 0 ||
            self.headingAccuracy > 20
    }

    // swiftlint:disable large_tuple
    /// Projects a local ARKit point into the persisted coordinate reference system.
    func projectedCoordinate(for localPoint: SIMD3<Float>) -> (x: Double, y: Double, z: Double) {
        let projected = self.makeProjectedCoordinate(for: localPoint)

        return (x: projected.x, y: projected.y, z: projected.z)
    }

    // swiftlint:enable large_tuple

    // MARK: Private

    private struct ProjectedCoordinate {
        let x: Double
        let y: Double
        let z: Double
    }

    private struct ResolvedHeading {
        let degrees: Double
        let accuracyDegrees: Double?
        let provenance: ScanHeadingReference
        let usedHeadingInput: Bool
    }

    private static func resolvedHeading(from heading: CLHeading?) -> ResolvedHeading {
        guard let heading else {
            return ResolvedHeading(
                degrees: 0,
                accuracyDegrees: nil,
                provenance: .unavailable,
                usedHeadingInput: false
            )
        }

        let accuracyDegrees = heading.headingAccuracy >= 0 ? heading.headingAccuracy : nil

        if heading.trueHeading >= 0 {
            return ResolvedHeading(
                degrees: heading.trueHeading,
                accuracyDegrees: accuracyDegrees,
                provenance: .trueNorth,
                usedHeadingInput: true
            )
        }

        if heading.magneticHeading >= 0 {
            return ResolvedHeading(
                degrees: heading.magneticHeading,
                accuracyDegrees: accuracyDegrees,
                provenance: .magneticNorth,
                usedHeadingInput: true
            )
        }

        return ResolvedHeading(
            degrees: 0,
            accuracyDegrees: accuracyDegrees,
            provenance: .unavailable,
            usedHeadingInput: false
        )
    }

    private static func makeAlignmentMetadata(
        horizontalAccuracy: Double,
        verticalAccuracy: Double,
        resolvedHeading: ResolvedHeading
    ) -> ScanGeoreferenceMetadata {
        let horizontalAccuracyMeters = horizontalAccuracy >= 0 ? horizontalAccuracy : nil
        let verticalAccuracyMeters = verticalAccuracy >= 0 ? verticalAccuracy : nil
        let hasStrongHorizontalAccuracy = horizontalAccuracyMeters.map { $0 <= 10 } ?? false
        let hasStrongHeadingAccuracy = resolvedHeading.provenance != .unavailable
            && (resolvedHeading.accuracyDegrees.map { $0 <= 20 } ?? false)

        return ScanGeoreferenceMetadata(
            source: resolvedHeading.usedHeadingInput ? .deviceLocationAndHeading : .deviceLocationOnly,
            status: .initial,
            quality: hasStrongHorizontalAccuracy && hasStrongHeadingAccuracy ? .phoneGrade : .approximate,
            horizontalAccuracyMeters: horizontalAccuracyMeters,
            verticalAccuracyMeters: verticalAccuracyMeters,
            headingAccuracyDegrees: resolvedHeading.accuracyDegrees,
            headingProvenance: resolvedHeading.provenance
        )
    }

    private static func worldForwardVector(from transform: simd_float4x4) -> SIMD2<Float> {
        let forward = SIMD3<Float>(-transform.columns.2.x, -transform.columns.2.y, -transform.columns.2.z)
        let flattened = SIMD2<Float>(forward.x, -forward.z)
        let length = simd_length(flattened)

        guard length > .ulpOfOne else {
            return SIMD2<Float>(0, 1)
        }

        return flattened / length
    }

    private func makeProjectedCoordinate(for localPoint: SIMD3<Float>) -> ProjectedCoordinate {
        let horizontal = SIMD2<Double>(Double(localPoint.x), Double(-localPoint.z))
        let rotated = self.rotate(horizontal, by: self.worldToENURotationRadians)

        return ProjectedCoordinate(
            x: self.originEasting + rotated.x,
            y: self.originNorthing + rotated.y,
            z: self.originAltitude + Double(localPoint.y)
        )
    }

    private func rotate(_ vector: SIMD2<Double>, by angle: Double) -> SIMD2<Double> {
        let cosine = cos(angle)
        let sine = sin(angle)
        return SIMD2<Double>(
            vector.x * cosine - vector.y * sine,
            vector.x * sine + vector.y * cosine
        )
    }
}

private extension Double {
    nonisolated func rounded(toPlaces places: Int) -> Double {
        let divisor = pow(10.0, Double(places))
        return (self * divisor).rounded() / divisor
    }
}
