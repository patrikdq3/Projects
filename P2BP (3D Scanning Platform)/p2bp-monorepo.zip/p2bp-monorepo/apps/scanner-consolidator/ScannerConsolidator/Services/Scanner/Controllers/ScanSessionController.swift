import ARKit
import AVFoundation
import Combine
import CoreLocation
import Foundation
import SwiftUI

// MARK: - ScanSessionController

/// Coordinates permissions, live capture, persisted artifacts, and preview generation.
@MainActor
final class ScanSessionController: NSObject, ObservableObject {
    // MARK: Lifecycle

    init(
        entryMode: EntryMode = .standalone,
        projectStore: ScanProjectStore? = nil
    ) {
        self.entryMode = entryMode
        self.projectStore = projectStore ?? ScanProjectStore()
        self.linkedProjectID = entryMode.existingProjectID
        super.init()
    }

    // MARK: Internal

    /// Current workflow phase.
    @Published private(set) var phase: ScanPhase = .idle
    /// Total accepted point count for the active or most recently completed scan.
    @Published private(set) var pointCount = 0
    /// Number of occupied coverage cells observed during capture.
    @Published private(set) var coverageCellCount = 0
    /// Number of mesh anchors currently observed or persisted.
    @Published private(set) var meshAnchorCount = 0
    /// Elapsed capture duration in seconds.
    @Published private(set) var elapsedTime: TimeInterval = 0
    /// Indicates whether live frame ingest is temporarily paused.
    @Published var isCapturePaused = false
    /// Human-readable GPS and heading status shown in the UI.
    @Published private(set) var locationStatusText = "Waiting for location"
    /// Color-coded location quality grade derived from Core Location accuracy.
    @Published private(set) var locationGrade: LocationGrade = .unavailable
    /// Primary status line shown to the user.
    @Published private(set) var statusMessage = "Move into a LiDAR scene and start a scan."
    /// Human-readable AR tracking state.
    @Published private(set) var trackingStatusText = "Waiting for AR session"
    /// Compact live guidance shown in the scanner HUD during setup and capture.
    @Published var captureHealth = CaptureHealth(
        title: "Ready to scan",
        message: "Start a pass, then sweep slowly across nearby surfaces.",
        systemImage: "viewfinder",
        tone: .neutral,
        detail: nil
    )
    /// Live or finalized preview subset used by the preview renderer.
    @Published private(set) var previewPoints: [CapturedPoint] = []
    /// Latest AR camera transform, used by live scanner overlays.
    @Published private(set) var currentCameraTransform: simd_float4x4?
    /// Camera position captured at scan start for local, non-georeferenced mini maps.
    @Published private(set) var scanStartCameraPosition: SIMD3<Float>?
    /// Manifest for the active or most recently completed scan package.
    @Published private(set) var currentManifest: ScanProjectManifest?
    /// Error text currently shown in an alert, if any.
    @Published var errorMessage: String?
    /// Indicates whether the active georeference should be treated as approximate.
    @Published private(set) var approximateGeoreferencing = true

    /// Live AR scene view provided by `ScannerARView`.
    weak var sceneView: ARSCNView?
    /// Most recent GPS fix received from Core Location.
    var currentLocation: CLLocation?
    /// Most recent AR camera tracking state seen by the session delegate.
    var latestTrackingState: ARCamera.TrackingState?
    /// Baseline used to estimate short-term capture growth without adding extra ingest work.
    var captureHealthBaseline: ScanCaptureHealthBaseline?
    /// Most recent window of accepted point, coverage, and mesh growth.
    var recentCaptureProgress: ScanCaptureHealthProgress?
    /// Timestamp of the latest frame that produced meaningful scan growth.
    var lastMeaningfulCaptureProgressTimestamp: TimeInterval?

    let entryMode: EntryMode

    /// Performs one-time capability checks and requests camera and location permissions.
    func prepareIfNeeded() {
        guard !self.hasPrepared else {
            return
        }

        self.hasPrepared = true

        if case let .reviewZone(projectID) = self.entryMode {
            self.loadExistingProjectState(projectID: projectID, presentingPhase: .preview)
            return
        }

        guard Self.supportsLiDARScanning else {
            self.phase = .unsupported
            self.statusMessage = "This app needs a LiDAR-equipped rear camera with scene depth."
            self.trackingStatusText = "LiDAR scene depth is unavailable on this device."
            self.refreshCaptureHealth()
            return
        }

        self.locationManager.delegate = self
        self.locationManager.desiredAccuracy = kCLLocationAccuracyBest
        self.locationManager.distanceFilter = kCLDistanceFilterNone
        self.locationManager.headingFilter = 2
        self.locationManager.activityType = .otherNavigation
        self.requestPermissions()
        self.refreshCaptureHealth()
    }

    /// Starts a new scan after confirming that AR tracking is ready.
    func startCapture() {
        guard self.canStartCapture else {
            return
        }

        guard let frame = sceneView?.session.currentFrame else {
            self.phase = .failed
            self.statusMessage = "The AR session is not ready yet."
            self.trackingStatusText = "Open the scanner and wait for tracking before starting."
            return
        }

        self.primaryCameraController.setLocked(true)
        self.phase = .calibratingLocation
        self.statusMessage = "Calibrating location and heading."
        self.trackingStatusText = self.describe(frame.camera.trackingState)
        self.pointCount = 0
        self.coverageCellCount = 0
        self.meshAnchorCount = 0
        self.previewPoints = []
        self.currentManifest = nil
        self.currentCameraTransform = frame.camera.transform
        self.scanStartCameraPosition = nil
        self.lastMiniMapTransformPublishTimestamp = frame.timestamp
        self.approximateGeoreferencing = true
        self.isCapturePaused = false
        self.resetCaptureHealthProgressTracking()
        self.calibrationAttempt = UUID()
        self.calibrationStartedAt = .now
        self.latestTrackingState = frame.camera.trackingState
        self.refreshCaptureHealth()

        let activeAttempt = self.calibrationAttempt
        self.scheduleCalibrationRetry(attemptID: activeAttempt, delay: 0.1)
        self.scheduleCalibrationRetry(attemptID: activeAttempt, delay: 1.8)
    }

    /// Temporarily pauses or resumes frame ingest while keeping the AR session running.
    func togglePauseCapture() {
        guard self.phase == .capturing else {
            return
        }

        self.isCapturePaused.toggle()
        self.resetCaptureHealthProgressTracking(at: self.sceneView?.session.currentFrame?.timestamp)
        self.statusMessage = self.isCapturePaused
            ? "Capture paused. Resume when you are ready to keep scanning."
            : "Capturing LiDAR depth and camera color."
        self.refreshCaptureHealth(frameTimestamp: self.sceneView?.session.currentFrame?.timestamp)
    }

    /// Finalizes the active capture, persists remaining artifacts, and enters preview mode.
    func stopCapture() {
        guard self.phase == .capturing || self.phase == .processing else {
            return
        }

        self.primaryCameraController.setLocked(false)
        self.phase = .processing
        self.elapsedTimer?.invalidate()
        self.elapsedTimerOrigin = nil
        self.statusMessage = "Finalizing the point cloud."
        self.refreshCaptureHealth()

        do {
            if let anchors = self.sceneView?.session.currentFrame?.anchors {
                try self.persistMeshAnchorSnapshot(from: anchors)
            }
            let previewPoints = try captureEngine.finalize()
            self.previewPoints = previewPoints
            let manifest = try projectStore.finalize(
                previewPoints: previewPoints,
                state: ScanProjectManifest.CaptureState.completed
            )
            self.currentManifest = manifest
            self.pointCount = manifest.pointCount
            self.phase = .preview
            self.statusMessage = "Scan ready. Review the preview or start a new pass."
            self.refreshCaptureHealth()
        } catch {
            self.handle(error: error, fallbackPhase: .failed)
        }
    }

    /// Resets controller state so the user can start another scan.
    func resetForNewScan() {
        guard self.canResetForNewScan else {
            return
        }

        self.primaryCameraController.setLocked(false)
        self.elapsedTimer?.invalidate()
        self.elapsedTimerOrigin = nil
        self.previewPoints = []
        self.currentManifest = nil
        self.linkedProjectID = nil
        self.currentCameraTransform = nil
        self.scanStartCameraPosition = nil
        self.lastMiniMapTransformPublishTimestamp = nil
        self.pointCount = 0
        self.coverageCellCount = 0
        self.meshAnchorCount = 0
        self.elapsedTime = 0
        self.existingCoverageVoxels = []
        self.approximateGeoreferencing = self.currentLocation?.horizontalAccuracy ?? 99 > 10
        self.phase = Self.supportsLiDARScanning ? .idle : .unsupported
        self.statusMessage = "Move into a LiDAR scene and start a scan."
        self.resetCaptureHealthProgressTracking()
        self.bootScannerIfPossible(resetTracking: true)
        self.refreshCaptureHealth()
    }

    // MARK: Private

    /// Returns `true` when the current device can run the LiDAR capture pipeline.
    private static var supportsLiDARScanning: Bool {
        ARWorldTrackingConfiguration.isSupported
            && ARWorldTrackingConfiguration.supportsFrameSemantics(.sceneDepth)
    }

    /// Converts ARKit frames into point samples, keyframes, and preview data.
    private let captureEngine = PointCloudCaptureEngine()
    /// Supplies GPS and heading updates used for approximate georeferencing.
    private let locationManager = CLLocationManager()
    /// Writes and reloads `.scanproject` artifacts on disk.
    private let projectStore: ScanProjectStore
    /// Manages live camera behavior so scan RGB output remains stable while recording.
    private let primaryCameraController = ScannerPrimaryCameraController()
    private var hasPrepared = false
    private var cameraAuthorized = false
    private var linkedProjectID: UUID?
    private var existingCoverageVoxels: Set<VoxelKey> = []
    /// Most recent heading sample received from Core Location.
    private var currentHeading: CLHeading?
    private var elapsedTimer: Timer?
    private var elapsedTimerOrigin: Date?
    private var calibrationAttempt = UUID()
    private var calibrationStartedAt: Date?
    /// Tracks whether mesh face classifications should be persisted with mesh anchors.
    private var persistFaceClassifications = false
    /// Timestamp of the most recent camera transform published for the mini map overlay.
    private var lastMiniMapTransformPublishTimestamp: TimeInterval?

    /// Extracts world-space camera translation from an ARKit transform.
    private static func cameraPosition(from transform: simd_float4x4) -> SIMD3<Float> {
        SIMD3(transform.columns.3.x, transform.columns.3.y, transform.columns.3.z)
    }

    /// Requests camera and location access required by the scanner.
    private func requestPermissions() {
        self.requestCameraPermission()

        switch self.locationManager.authorizationStatus {
        case .authorizedAlways, .authorizedWhenInUse:
            self.startUpdatingLocation()
        case .notDetermined:
            self.locationManager.requestWhenInUseAuthorization()
        case .denied, .restricted:
            self.locationStatusText = "Location denied"
            self.locationGrade = .unavailable
        @unknown default:
            self.locationStatusText = "Location unavailable"
            self.locationGrade = .unavailable
        }
    }

    /// Requests permission for the camera used by the AR session.
    private func requestCameraPermission() {
        switch AVCaptureDevice.authorizationStatus(for: .video) {
        case .authorized:
            self.cameraAuthorized = true
            self.bootScannerIfPossible(resetTracking: true)
        case .notDetermined:
            AVCaptureDevice.requestAccess(for: .video) { [weak self] granted in
                DispatchQueue.main.async {
                    guard let self else {
                        return
                    }

                    self.cameraAuthorized = granted
                    if granted {
                        self.bootScannerIfPossible(resetTracking: true)
                    } else {
                        self.phase = .failed
                        self.statusMessage = "Camera access is required to scan with LiDAR."
                        self.refreshCaptureHealth()
                    }
                }
            }
        case .denied, .restricted:
            self.cameraAuthorized = false
            self.phase = .failed
            self.statusMessage = "Camera access is required to scan with LiDAR."
            self.refreshCaptureHealth()
        @unknown default:
            self.cameraAuthorized = false
            self.phase = .failed
            self.refreshCaptureHealth()
        }
    }

    /// Starts GPS and heading updates once location permission is available.
    private func startUpdatingLocation() {
        self.locationManager.startUpdatingLocation()

        if CLLocationManager.headingAvailable() {
            self.locationManager.startUpdatingHeading()
        }
    }

    /// Starts or restarts the AR session when permissions and hardware support are available.
    private func bootScannerIfPossible(resetTracking: Bool) {
        guard self.cameraAuthorized, let sceneView, Self.supportsLiDARScanning else {
            return
        }

        let configuration = ARWorldTrackingConfiguration()
        configuration.worldAlignment = .gravity
        configuration.planeDetection = [.horizontal, .vertical]
        configuration.frameSemantics = [.sceneDepth]
        configuration.videoHDRAllowed = false

        if ARWorldTrackingConfiguration.supportsSceneReconstruction(.meshWithClassification) {
            configuration.sceneReconstruction = .meshWithClassification
            self.persistFaceClassifications = true
        } else if ARWorldTrackingConfiguration.supportsSceneReconstruction(.mesh) {
            configuration.sceneReconstruction = .mesh
            self.persistFaceClassifications = false
        } else {
            self.persistFaceClassifications = false
        }

        let options: ARSession.RunOptions = resetTracking ? [.resetTracking, .removeExistingAnchors] : []
        sceneView.session.run(configuration, options: options)
        self.primaryCameraController.reapplyLockedConfigurationIfNeeded()

        if self.phase == .failed {
            self.phase = .idle
        }
    }

    /// Waits briefly for location calibration, then starts the on-disk project and capture engine.
    private func beginCaptureIfReady(attemptID: UUID) {
        guard attemptID == self.calibrationAttempt,
              self.phase == .calibratingLocation,
              let frame = sceneView?.session.currentFrame
        else {
            return
        }

        let hasLocationSignal = self.currentLocation != nil
        let hasWaitedLongEnough = Date().timeIntervalSince(self.calibrationStartedAt ?? .now) >= 1.5

        if !hasLocationSignal, !hasWaitedLongEnough {
            self.scheduleCalibrationRetry(attemptID: attemptID, delay: 1.4)
            return
        }

        do {
            let manifest: ScanProjectManifest
            let approximate: Bool
            let existingPreviewPoints: [CapturedPoint]
            let existingCoverageVoxels: Set<VoxelKey>

            if let linkedProjectID = self.linkedProjectID {
                manifest = try self.projectStore.openProject(id: linkedProjectID)
                approximate = manifest.approximateGeoreferencing
                existingPreviewPoints = try self.projectStore.loadPreviewPoints(
                    limit: self.captureEngine.configuration.previewLimit,
                    manifest: manifest
                )
                existingCoverageVoxels = try self.coverageVoxels(for: manifest)
            } else {
                let geoReference = self.currentLocation.flatMap {
                    GeoReference(
                        location: $0,
                        heading: self.currentHeading,
                        initialCameraTransform: frame.camera.transform
                    )
                }
                approximate = geoReference?.isApproximate ?? true
                manifest = try self.projectStore.startProject(
                    voxelSizeMeters: self.captureEngine.configuration.voxelSizeMeters,
                    geoReference: geoReference,
                    approximateGeoreferencing: approximate
                )
                self.linkedProjectID = manifest.id
                existingPreviewPoints = []
                existingCoverageVoxels = []
            }

            try self.persistCurrentTrajectorySnapshot()

            self.currentManifest = manifest
            self.approximateGeoreferencing = approximate
            self.previewPoints = existingPreviewPoints
            self.existingCoverageVoxels = existingCoverageVoxels
            self.currentCameraTransform = frame.camera.transform
            self.lastMiniMapTransformPublishTimestamp = frame.timestamp
            self.scanStartCameraPosition = Self.cameraPosition(from: frame.camera.transform)
            self.captureEngine.start(
                projectStore: self.projectStore,
                existingPointCount: manifest.pointCount,
                existingCoverageVoxels: existingCoverageVoxels,
                existingPreviewPoints: existingPreviewPoints
            )
            self.phase = .capturing
            self.pointCount = manifest.pointCount
            self.coverageCellCount = existingCoverageVoxels.count
            self.meshAnchorCount = frame.anchors.compactMap { $0 as? ARMeshAnchor }.count
            self.resetCaptureHealthProgressTracking(at: frame.timestamp)
            try self.persistMeshAnchorSnapshot(from: frame.anchors)
            self.statusMessage = approximate
                ? "Capturing with approximate georeferencing."
                : "Capturing LiDAR depth and camera color."
            self.elapsedTime = 0
            self.startElapsedTimer()
            self.latestTrackingState = frame.camera.trackingState
            self.refreshCaptureHealth(frameTimestamp: frame.timestamp)
        } catch {
            self.handle(error: error, fallbackPhase: .failed)
        }
    }

    /// Schedules another attempt to begin capture while location calibration is in progress.
    private func scheduleCalibrationRetry(attemptID: UUID, delay: TimeInterval) {
        Task { @MainActor in
            try? await Task.sleep(for: .seconds(delay))
            guard self.phase == .calibratingLocation else {
                return
            }
            self.beginCaptureIfReady(attemptID: attemptID)
        }
    }

    /// Starts a timer used to update the live elapsed-time display.
    private func startElapsedTimer() {
        self.elapsedTimer?.invalidate()
        guard let createdAt = currentManifest?.createdAt else {
            return
        }

        self.elapsedTimerOrigin = createdAt
        self.elapsedTimer = Timer.scheduledTimer(
            timeInterval: 0.25,
            target: self,
            selector: #selector(self.updateElapsedTime),
            userInfo: nil,
            repeats: true
        )
    }

    /// Updates the published elapsed capture duration.
    @objc
    private func updateElapsedTime() {
        guard let elapsedTimerOrigin else {
            return
        }

        self.elapsedTime = max(0, Date().timeIntervalSince(elapsedTimerOrigin))
    }

    /// Restores persisted scan metadata so a zone can resume capture or review previews.
    private func loadExistingProjectState(projectID: UUID, presentingPhase: ScanPhase) {
        do {
            let manifest = try self.projectStore.openProject(id: projectID)
            let previewPoints = try self.projectStore.loadPreviewPoints(
                limit: self.captureEngine.configuration.previewLimit,
                manifest: manifest
            )
            let coverageVoxels = try self.coverageVoxels(for: manifest)

            self.linkedProjectID = manifest.id
            self.currentManifest = manifest
            self.previewPoints = previewPoints
            self.pointCount = manifest.pointCount
            self.coverageCellCount = coverageVoxels.count
            self.existingCoverageVoxels = coverageVoxels
            self.meshAnchorCount = manifest.meshAnchorCount ?? 0
            self.elapsedTime = 0
            self.approximateGeoreferencing = manifest.approximateGeoreferencing
            self.locationStatusText = manifest.geoReference == nil ? "Local scan frame" : "Georeferenced"
            self.locationGrade = manifest.geoReference == nil ? .unavailable : .good
            self.phase = presentingPhase
            self.statusMessage = presentingPhase == .preview
                ? "Scan ready. Review the preview."
                : "Resume this zone's scan when you are ready."
            self.refreshCaptureHealth()
        } catch {
            self.handle(error: error, fallbackPhase: .failed)
        }
    }

    /// Rebuilds the persisted voxel set so resumed captures continue coverage accounting.
    private func coverageVoxels(for manifest: ScanProjectManifest) throws -> Set<VoxelKey> {
        var voxels: Set<VoxelKey> = []
        try self.projectStore.enumeratePoints(from: manifest) { points in
            for point in points {
                voxels.insert(VoxelKey(
                    position: point.position,
                    voxelSize: self.captureEngine.configuration.voxelSizeMeters
                ))
            }
        }
        return voxels
    }

    /// Publishes an error and moves the UI back into a recoverable phase.
    private func handle(error: Error, fallbackPhase: ScanPhase) {
        self.primaryCameraController.setLocked(false)
        self.errorMessage = error.localizedDescription
        self.phase = fallbackPhase
        self.statusMessage = error.localizedDescription
        self.refreshCaptureHealth()
    }

    /// Writes the most recent location and heading samples into the current project.
    private func persistCurrentTrajectorySnapshot() throws {
        if let currentLocation, let locationSample = Self.makeLocationTrajectorySample(from: currentLocation) {
            try self.projectStore.append(locationSample: locationSample)
        }

        if let currentHeading {
            try self.projectStore.append(headingSample: Self.makeHeadingTrajectorySample(from: currentHeading))
        }
    }

    /// Persists the latest mesh anchors whenever capture is active and not paused.
    private func persistUpdatedMeshAnchorsIfNeeded(from anchors: [ARAnchor]) {
        guard self.phase == .capturing, !self.isCapturePaused else {
            return
        }

        do {
            try self.persistMeshAnchorSnapshot(from: anchors)
        } catch {
            self.handle(error: error, fallbackPhase: .failed)
        }
    }

    /// Converts the current ARKit mesh anchors into persisted binary artifacts.
    private func persistMeshAnchorSnapshot(from anchors: [ARAnchor]) throws {
        let meshAnchors = anchors.compactMap { $0 as? ARMeshAnchor }
        guard !meshAnchors.isEmpty else {
            return
        }

        let capturedMeshAnchors = try meshAnchors.map {
            try CapturedMeshAnchor(meshAnchor: $0, persistFaceClassifications: self.persistFaceClassifications)
        }
        try self.projectStore.upsert(meshAnchors: capturedMeshAnchors)
    }

    /// Derives user-facing location status text and quality labels from the latest sensor values.
    private func refreshLocationStatus() {
        guard let currentLocation else {
            self.locationStatusText = "Location unavailable"
            self.locationGrade = .unavailable
            self.approximateGeoreferencing = true
            self.refreshCaptureHealth()
            return
        }

        let horizontalAccuracy = currentLocation.horizontalAccuracy
        let headingText = if let currentHeading, currentHeading.trueHeading >= 0 {
            " • \(Int(currentHeading.trueHeading.rounded()))°"
        } else if let currentHeading, currentHeading.magneticHeading >= 0 {
            " • \(Int(currentHeading.magneticHeading.rounded()))°"
        } else {
            ""
        }

        self.locationStatusText = "GPS ±\(Int(horizontalAccuracy.rounded())) m\(headingText)"

        if horizontalAccuracy <= 5 {
            self.locationGrade = .good
        } else if horizontalAccuracy <= 15 {
            self.locationGrade = .fair
        } else {
            self.locationGrade = .poor
        }

        if self.phase != .preview {
            self.approximateGeoreferencing = horizontalAccuracy > 10 || (currentHeading?.headingAccuracy ?? 99) > 20
        }

        self.refreshCaptureHealth()
    }
}

extension ScanSessionController {
    /// Connects the controller to the `ARSCNView` created by SwiftUI.
    func attach(sceneView: ARSCNView) {
        self.sceneView = sceneView
        sceneView.session.delegateQueue = .main
        sceneView.session.delegate = self
        sceneView.delegate = self
        self.bootScannerIfPossible(resetTracking: true)
        self.refreshCaptureHealth()
    }

    /// Pauses or resumes the AR session as the app moves between foreground and background.
    func handleScenePhase(_ scenePhase: ScenePhase) {
        switch scenePhase {
        case .background, .inactive:
            if self.phase == .capturing {
                self.isCapturePaused = true
                self.statusMessage = "Capture paused while the app is inactive."
                self.refreshCaptureHealth()
            }
            self.sceneView?.session.pause()
        case .active:
            self.bootScannerIfPossible(resetTracking: false)
            self.refreshCaptureHealth()
        @unknown default:
            break
        }
    }

    /// Stops timers and pauses the AR session when the feature disappears.
    func stopSession() {
        self.primaryCameraController.setLocked(false)
        self.elapsedTimer?.invalidate()
        self.elapsedTimerOrigin = nil
        self.sceneView?.session.pause()
    }

    /// Clears the currently displayed error alert.
    func dismissError() {
        self.errorMessage = nil
    }
}

// MARK: @preconcurrency CLLocationManagerDelegate

/// Receives GPS and compass updates used for georeferencing and trajectory persistence.
extension ScanSessionController: @preconcurrency CLLocationManagerDelegate {
    /// Reacts to location authorization changes.
    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        switch manager.authorizationStatus {
        case .authorizedAlways, .authorizedWhenInUse:
            self.startUpdatingLocation()
        case .denied, .restricted:
            self.currentLocation = nil
            self.refreshLocationStatus()
        case .notDetermined:
            break
        @unknown default:
            break
        }
    }

    /// Stores incoming GPS samples while capture is active and refreshes the status badge.
    func locationManager(_: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        self.currentLocation = locations.last

        if self.phase == .capturing {
            do {
                for location in locations {
                    if let sample = Self.makeLocationTrajectorySample(from: location) {
                        try self.projectStore.append(locationSample: sample)
                    }
                }
            } catch {
                self.handle(error: error, fallbackPhase: .failed)
                return
            }
        }

        self.refreshLocationStatus()
    }

    /// Stores incoming heading samples while capture is active and refreshes the status badge.
    func locationManager(_: CLLocationManager, didUpdateHeading newHeading: CLHeading) {
        self.currentHeading = newHeading

        if self.phase == .capturing {
            do {
                try self.projectStore.append(headingSample: Self.makeHeadingTrajectorySample(from: newHeading))
            } catch {
                self.handle(error: error, fallbackPhase: .failed)
                return
            }
        }

        self.refreshLocationStatus()
    }
}

// MARK: @preconcurrency ARSessionDelegate

/// Receives live ARKit frames and mesh anchor updates from the camera session.
extension ScanSessionController: @preconcurrency ARSessionDelegate {
    /// Persists newly added mesh anchors during capture.
    func session(_: ARSession, didAdd anchors: [ARAnchor]) {
        self.persistUpdatedMeshAnchorsIfNeeded(from: anchors)
    }

    /// Main per-frame callback that feeds ARKit data into the capture engine.
    func session(_: ARSession, didUpdate frame: ARFrame) {
        let miniMapTransformElapsed = frame.timestamp - (self.lastMiniMapTransformPublishTimestamp ?? -.infinity)
        if miniMapTransformElapsed >= self.captureEngine.configuration.minimumFrameInterval {
            self.currentCameraTransform = frame.camera.transform
            self.lastMiniMapTransformPublishTimestamp = frame.timestamp
        }

        self.latestTrackingState = frame.camera.trackingState
        self.trackingStatusText = self.describe(frame.camera.trackingState)
        self.meshAnchorCount = frame.anchors.compactMap { $0 as? ARMeshAnchor }.count

        guard self.phase == .capturing, !self.isCapturePaused else {
            self.refreshCaptureHealth(frameTimestamp: frame.timestamp)
            return
        }

        do {
            if let result = try captureEngine.ingest(frame: frame) {
                self.pointCount = result.totalPointCount
                self.coverageCellCount = result.coverageCellCount
                self.previewPoints = result.previewPoints
            }

            self.refreshCaptureHealth(frameTimestamp: frame.timestamp)
        } catch {
            self.handle(error: error, fallbackPhase: .failed)
        }
    }

    /// Persists updated mesh anchors during capture.
    func session(_: ARSession, didUpdate anchors: [ARAnchor]) {
        self.persistUpdatedMeshAnchorsIfNeeded(from: anchors)
    }

    func session(_: ARSession, didFailWithError error: Error) {
        self.handle(error: error, fallbackPhase: .failed)
    }

    func sessionWasInterrupted(_: ARSession) {
        self.statusMessage = "AR session interrupted."
        self.refreshCaptureHealth()
    }

    func sessionInterruptionEnded(_: ARSession) {
        self.statusMessage = "AR session restored."
        self.bootScannerIfPossible(resetTracking: false)
        self.resetCaptureHealthProgressTracking(at: self.sceneView?.session.currentFrame?.timestamp)
        self.refreshCaptureHealth(frameTimestamp: self.sceneView?.session.currentFrame?.timestamp)
    }
}
