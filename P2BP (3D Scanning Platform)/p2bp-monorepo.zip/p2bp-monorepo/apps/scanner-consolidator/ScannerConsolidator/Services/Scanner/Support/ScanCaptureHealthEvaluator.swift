import ARKit
import Foundation

// MARK: - ScanCaptureHealthBaseline

/// Snapshot of live scan counters used to estimate recent growth without extra capture work.
struct ScanCaptureHealthBaseline {
    let timestamp: TimeInterval
    let pointCount: Int
    let coverageCellCount: Int
    let meshAnchorCount: Int
}

// MARK: - ScanCaptureHealthProgress

/// Recent delta of accepted points, coverage cells, and observed mesh anchors.
struct ScanCaptureHealthProgress {
    let pointDelta: Int
    let coverageCellDelta: Int
    let meshAnchorDelta: Int
}

// MARK: - ScanCaptureHealthSnapshot

/// Flattened scanner state used to derive a compact live guidance banner.
struct ScanCaptureHealthSnapshot {
    let phase: ScanSessionController.ScanPhase
    let isCapturePaused: Bool
    let currentLocationAvailable: Bool
    let locationStatusText: String
    let pointCount: Int
    let meshAnchorCount: Int
    let elapsedTime: TimeInterval
    let statusMessage: String
    let trackingStatusText: String
    let latestTrackingState: ARCamera.TrackingState?
    let currentManifestPointCount: Int?
    let recentProgress: ScanCaptureHealthProgress?
    let timeSinceMeaningfulProgress: TimeInterval?
}

// MARK: - ScanCaptureHealthThresholds

/// Timing thresholds that keep live scan guidance lightweight and stable.
enum ScanCaptureHealthThresholds {
    static let evaluationInterval: TimeInterval = 1.25
    static let stalledCapture: TimeInterval = 2.6
}

// MARK: - ScanCaptureHealthEvaluator

/// Resolves the operator-facing health banner from lightweight live scanner signals.
enum ScanCaptureHealthEvaluator {
    // MARK: Internal

    static func captureHealth(
        from snapshot: ScanCaptureHealthSnapshot
    ) -> ScanSessionController.CaptureHealth {
        switch snapshot.phase {
        case .unsupported:
            return ScanSessionController.CaptureHealth(
                title: "LiDAR required",
                message: "This device cannot provide the scene-depth input needed for live scanning.",
                systemImage: "exclamationmark.triangle.fill",
                tone: .critical,
                detail: nil
            )
        case .idle:
            return ScanSessionController.CaptureHealth(
                title: "Ready to scan",
                message: "Start a pass, then sweep slowly across nearby surfaces.",
                systemImage: "viewfinder",
                tone: .neutral,
                detail: nil
            )
        case .calibratingLocation:
            return self.calibrationHealth(from: snapshot)
        case .capturing:
            return self.activeHealth(from: snapshot)
        case .processing:
            return ScanSessionController.CaptureHealth(
                title: "Finalizing scan",
                message: "Hold briefly while the point chunks, mesh anchors, and preview are written out.",
                systemImage: "hourglass.circle.fill",
                tone: .neutral,
                detail: "\(snapshot.pointCount) accepted points"
            )
        case .preview:
            return ScanSessionController.CaptureHealth(
                title: "Scan ready",
                message: "Review the preview or begin another pass.",
                systemImage: "checkmark.circle.fill",
                tone: .progress,
                detail: snapshot.currentManifestPointCount.map { "\($0) persisted points" }
            )
        case .failed:
            return ScanSessionController.CaptureHealth(
                title: "Scan blocked",
                message: snapshot.statusMessage,
                systemImage: "exclamationmark.triangle.fill",
                tone: .critical,
                detail: nil
            )
        }
    }

    // MARK: Private

    private static func calibrationHealth(
        from snapshot: ScanCaptureHealthSnapshot
    ) -> ScanSessionController.CaptureHealth {
        let detail = snapshot.currentLocationAvailable ? snapshot.locationStatusText : nil
        let message = snapshot.currentLocationAvailable
            ? "Keep the device steady while the initial location and heading alignment settles."
            : "Hold briefly while the scanner waits for GPS and heading before capture starts automatically."

        return ScanSessionController.CaptureHealth(
            title: "Calibrating sensors",
            message: message,
            systemImage: "location.north.line.fill",
            tone: .neutral,
            detail: detail
        )
    }

    private static func activeHealth(
        from snapshot: ScanCaptureHealthSnapshot
    ) -> ScanSessionController.CaptureHealth {
        if snapshot.isCapturePaused {
            return ScanSessionController.CaptureHealth(
                title: "Capture paused",
                message: "Resume when you are ready to keep scanning this area.",
                systemImage: "pause.circle.fill",
                tone: .neutral,
                detail: "\(snapshot.pointCount) accepted points retained"
            )
        }

        guard let latestTrackingState = snapshot.latestTrackingState else {
            return ScanSessionController.CaptureHealth(
                title: "Finding tracking",
                message: "Hold on a nearby surface until AR tracking locks in.",
                systemImage: "camera.aperture",
                tone: .caution,
                detail: nil
            )
        }

        switch latestTrackingState {
        case .notAvailable:
            return ScanSessionController.CaptureHealth(
                title: "Tracking unavailable",
                message: "Hold still and keep the camera pointed at nearby geometry until tracking recovers.",
                systemImage: "exclamationmark.triangle.fill",
                tone: .critical,
                detail: snapshot.trackingStatusText
            )
        case let .limited(reason):
            return self.limitedTrackingHealth(
                reason: reason,
                trackingStatusText: snapshot.trackingStatusText
            )
        case .normal:
            return self.stableTrackingHealth(from: snapshot)
        }
    }

    private static func limitedTrackingHealth(
        reason: ARCamera.TrackingState.Reason,
        trackingStatusText: String
    ) -> ScanSessionController.CaptureHealth {
        let message: String
        let systemImage: String

        switch reason {
        case .excessiveMotion:
            message = "Slow down and keep overlap between passes so LiDAR can accumulate denser geometry."
            systemImage = "tortoise.fill"
        case .initializing:
            message = "Hold steady for a moment while AR tracking finishes initializing."
            systemImage = "camera.aperture"
        case .insufficientFeatures:
            message = "Aim at textured edges or objects with depth variation so tracking can stay locked."
            systemImage = "square.grid.3x3.fill"
        case .relocalizing:
            message = "Return to recently scanned surfaces until tracking relocalizes."
            systemImage = "arrow.triangle.2.circlepath.circle.fill"
        @unknown default:
            message = "Tracking is limited. Slow down and revisit surfaces with clearer structure."
            systemImage = "exclamationmark.triangle.fill"
        }

        return ScanSessionController.CaptureHealth(
            title: "Tracking limited",
            message: message,
            systemImage: systemImage,
            tone: .caution,
            detail: trackingStatusText
        )
    }

    private static func stableTrackingHealth(
        from snapshot: ScanCaptureHealthSnapshot
    ) -> ScanSessionController.CaptureHealth {
        let recentDetail = self.recentProgressDetail(from: snapshot.recentProgress)

        if snapshot.pointCount < 1500 || snapshot.elapsedTime < 2.5 {
            let message = snapshot.meshAnchorCount == 0
                ? "Sweep across nearby walls, floors, or furniture so the live mesh can lock in."
                : "Keep a steady side-to-side sweep while the first surfaces fill in."
            return ScanSessionController.CaptureHealth(
                title: "Building initial coverage",
                message: message,
                systemImage: "viewfinder.circle.fill",
                tone: .progress,
                detail: recentDetail
            )
        }

        if let timeSinceMeaningfulProgress = snapshot.timeSinceMeaningfulProgress {
            if timeSinceMeaningfulProgress >= ScanCaptureHealthThresholds.stalledCapture {
                let message = snapshot.meshAnchorCount == 0
                    ? "Move closer to a nearby surface with structure to restart mesh growth."
                    : "Change angle or revisit uncovered surfaces to keep adding new detail."
                return ScanSessionController.CaptureHealth(
                    title: "Coverage has slowed",
                    message: message,
                    systemImage: "exclamationmark.triangle.fill",
                    tone: .caution,
                    detail: recentDetail
                )
            }
        }

        let coverageIsGrowing = snapshot.recentProgress?.coverageCellDelta ?? 0 >= 8
        let meshIsGrowing = snapshot.recentProgress?.meshAnchorDelta ?? 0 > 0
        if coverageIsGrowing || meshIsGrowing {
            return ScanSessionController.CaptureHealth(
                title: "Capture healthy",
                message: "Keep moving slowly and overlap passes to extend coverage.",
                systemImage: "checkmark.circle.fill",
                tone: .progress,
                detail: recentDetail
            )
        }

        if snapshot.recentProgress?.pointDelta ?? 0 >= 600 {
            return ScanSessionController.CaptureHealth(
                title: "Capture steady",
                message: "Sweep a bit wider so each pass expands coverage, not just density.",
                systemImage: "arrow.left.and.right.circle.fill",
                tone: .neutral,
                detail: recentDetail
            )
        }

        return ScanSessionController.CaptureHealth(
            title: "Refine this area",
            message: "Tilt slightly or rescan from a new angle to add more surface detail.",
            systemImage: "scope",
            tone: .neutral,
            detail: recentDetail
        )
    }

    private static func recentProgressDetail(from progress: ScanCaptureHealthProgress?) -> String? {
        guard let progress else {
            return nil
        }

        var detailParts = [
            "Recent growth: +\(progress.pointDelta) pts",
            "+\(progress.coverageCellDelta) cells",
        ]

        if progress.meshAnchorDelta > 0 {
            detailParts.append("+\(progress.meshAnchorDelta) mesh")
        }

        return detailParts.joined(separator: " • ")
    }
}
