import ARKit
import Foundation

// MARK: - MeshAnchorEncodingError

/// Errors raised while translating ARKit mesh geometry into on-disk binary payloads.
private enum MeshAnchorEncodingError: LocalizedError {
    case unsupportedFaceIndexWidth(Int)

    // MARK: Internal

    var errorDescription: String? {
        switch self {
        case let .unsupportedFaceIndexWidth(bytesPerIndex):
            return "Unsupported AR mesh face index width: \(bytesPerIndex) bytes."
        }
    }
}

extension CapturedMeshAnchor {
    /// Converts an `ARMeshAnchor` into persisted metadata plus binary payloads.
    init(meshAnchor: ARMeshAnchor, persistFaceClassifications: Bool) throws {
        let geometry = meshAnchor.geometry
        let anchorIdentifier = meshAnchor.identifier.uuidString.lowercased()
        let verticesFilename = "\(anchorIdentifier).vertices-f32x3.bin"
        let faceVertexIndicesFilename = "\(anchorIdentifier).faces-u32.bin"
        let vertexNormalsFilename = "\(anchorIdentifier).normals-f32x3.bin"
        let faceClassificationFilename = persistFaceClassifications
            ? "\(anchorIdentifier).face-classification-u8.bin"
            : nil
        let verticesData = Self.makeVerticesData(from: geometry.vertices)
        let faceVertexIndexData = try Self.makeFaceVertexIndexData(from: geometry.faces)
        let vertexNormalsData = Self.makeVerticesData(from: geometry.normals)
        let faceClassificationData = persistFaceClassifications
            ? Self.makeFaceClassificationData(from: geometry.classification)
            : nil

        self.init(
            metadata: ScanMeshAnchorRecord(
                anchorIdentifier: anchorIdentifier,
                transform: meshAnchor.transform,
                vertexCount: geometry.vertices.count,
                verticesFilename: verticesFilename,
                faceCount: geometry.faces.count,
                faceIndexCountPerPrimitive: geometry.faces.indexCountPerPrimitive,
                faceVertexIndexCount: geometry.faces.count * geometry.faces.indexCountPerPrimitive,
                faceVertexIndicesFilename: faceVertexIndicesFilename,
                vertexNormalsFilename: vertexNormalsFilename,
                vertexNormalsFormat: "float32x3LittleEndian",
                faceClassificationFilename: faceClassificationData == nil ? nil : faceClassificationFilename,
                faceClassificationFormat: faceClassificationData == nil ? nil : "uint8ARMeshClassificationRawValue"
            ),
            verticesData: verticesData,
            faceVertexIndexData: faceVertexIndexData,
            vertexNormalsData: vertexNormalsData,
            faceClassificationData: faceClassificationData
        )
    }

    /// Extracts mesh vertex positions as tightly packed little-endian float triples.
    private static func makeVerticesData(from source: ARGeometrySource) -> Data {
        let rawPointer = source.buffer.contents()
        var vertices = [Float]()
        vertices.reserveCapacity(source.count * 3)

        for index in 0 ..< source.count {
            let vertexPointer = rawPointer
                .advanced(by: source.offset + (index * source.stride))
                .assumingMemoryBound(to: Float.self)
            vertices.append(vertexPointer[0])
            vertices.append(vertexPointer[1])
            vertices.append(vertexPointer[2])
        }

        return vertices.float32LittleEndianData()
    }

    /// Extracts face indices and normalizes them to 32-bit little-endian integers.
    private static func makeFaceVertexIndexData(from element: ARGeometryElement) throws -> Data {
        let rawPointer = element.buffer.contents()
        let totalIndexCount = element.count * element.indexCountPerPrimitive
        var indices = [UInt32]()
        indices.reserveCapacity(totalIndexCount)

        for index in 0 ..< totalIndexCount {
            let byteOffset = index * element.bytesPerIndex
            let value: UInt32

            switch element.bytesPerIndex {
            case 1:
                value = UInt32(
                    rawPointer
                        .advanced(by: byteOffset)
                        .assumingMemoryBound(to: UInt8.self)
                        .pointee
                )
            case 2:
                value = UInt32(
                    rawPointer
                        .advanced(by: byteOffset)
                        .assumingMemoryBound(to: UInt16.self)
                        .pointee
                )
            case 4:
                value = rawPointer
                    .advanced(by: byteOffset)
                    .assumingMemoryBound(to: UInt32.self)
                    .pointee
            default:
                throw MeshAnchorEncodingError.unsupportedFaceIndexWidth(element.bytesPerIndex)
            }

            indices.append(value)
        }

        return indices.uint32LittleEndianData()
    }

    /// Serializes optional per-face classifications when the AR session provides them.
    private static func makeFaceClassificationData(from source: ARGeometrySource?) -> Data? {
        guard let source else {
            return nil
        }

        let rawPointer = source.buffer.contents()
        return Data((0 ..< source.count).map { index in
            rawPointer
                .advanced(by: source.offset + (index * source.stride))
                .assumingMemoryBound(to: UInt8.self)
                .pointee
        })
    }
}
