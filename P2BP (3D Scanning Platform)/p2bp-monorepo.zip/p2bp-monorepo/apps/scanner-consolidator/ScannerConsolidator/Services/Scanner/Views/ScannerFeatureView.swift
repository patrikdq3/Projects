import SwiftUI

// MARK: - ScannerFeatureView

/// Presents the primary scanner workflow and its surrounding overlays.
struct ScannerFeatureView: View {
    // MARK: Lifecycle

    init(
        title: String = "Scanner Consolidated",
        subtitle: String? = nil,
        entryMode: ScanSessionController.EntryMode = .standalone,
        zoneFootprint: ZoneFootprint? = nil,
        projectBoundary: ProjectBoundary? = nil,
        onStateChange: ((_ phase: ScanSessionController.ScanPhase, _ manifest: ScanProjectManifest?) -> Void)? = nil
    ) {
        self.title = title
        self.subtitle = subtitle
        self.zoneFootprint = zoneFootprint
        self.projectBoundary = projectBoundary
        self.onStateChange = onStateChange
        self._controller = StateObject(wrappedValue: ScanSessionController(entryMode: entryMode))
    }

    // MARK: Internal

    /// Chooses the correct high-level surface for the current scan phase.
    var body: some View {
        ZStack {
            switch self.controller.phase {
            case .preview:
                self.previewSurface
            case .unsupported, .failed:
                self.blockedSurface
            default:
                self.liveScannerSurface
            }
        }
        .background(Color.black)
        .task {
            self.controller.prepareIfNeeded()
            self.notifyStateChange()
        }
        .onChange(of: self.scenePhase) { _, newValue in
            self.controller.handleScenePhase(newValue)
        }
        .onChange(of: self.controller.phase) { _, _ in
            self.notifyStateChange()
        }
        .onChange(of: self.controller.currentManifest?.id) { _, _ in
            self.notifyStateChange()
        }
        .onChange(of: self.controller.currentManifest?.state.rawValue) { _, _ in
            self.notifyStateChange()
        }
        .onDisappear {
            self.controller.stopSession()
        }
        .alert(
            "Scanner Error",
            isPresented: Binding(
                get: { self.controller.errorMessage != nil },
                set: {
                    if !$0 {
                        self.controller.dismissError()
                    }
                }
            ),
            actions: {
                Button("OK", role: .cancel) {
                    self.controller.dismissError()
                }
            },
            message: {
                Text(self.controller.errorMessage ?? "")
            }
        )
    }

    // MARK: Private

    /// Monitors whether the app is foregrounded so capture can pause safely.
    @Environment(\.scenePhase) private var scenePhase
    /// Owns scanner state, permissions, capture, and preview actions.
    @StateObject private var controller: ScanSessionController

    private let title: String
    private let subtitle: String?
    private let zoneFootprint: ZoneFootprint?
    private let projectBoundary: ProjectBoundary?
    private let onStateChange: ((_ phase: ScanSessionController.ScanPhase, _ manifest: ScanProjectManifest?) -> Void)?

    /// Full-screen live capture layout shown while the AR session is active.
    private var liveScannerSurface: some View {
        ZStack {
            ScannerARView(controller: self.controller)
                .ignoresSafeArea()

            LinearGradient(
                colors: [
                    Color.black.opacity(0.84),
                    Color.black.opacity(0.28),
                    Color.clear,
                ],
                startPoint: .top,
                endPoint: .center
            )
            .ignoresSafeArea()

            LinearGradient(
                colors: [
                    Color.clear,
                    Color.black.opacity(0.24),
                    Color.black.opacity(0.88),
                ],
                startPoint: .center,
                endPoint: .bottom
            )
            .ignoresSafeArea()

            VStack(alignment: .leading, spacing: 18) {
                self.topOverlay
                Spacer()
                if let warningText = controller.locationWarningText {
                    self.warningBanner(warningText)
                }
                self.bottomPanel
            }
            .padding(.horizontal, 18)
            .padding(.top, 18)
            .padding(.bottom, 22)

            ScannerMiniMapOverlay(
                points: self.controller.previewPoints,
                geoReference: self.controller.currentManifest?.geoReference,
                cameraTransform: self.controller.currentCameraTransform,
                scanStartPosition: self.controller.scanStartCameraPosition,
                zoneFootprint: self.zoneFootprint,
                projectBoundary: self.projectBoundary
            )
            .frame(width: 160, height: 160)
            .padding(.top, 86)
            .padding(.trailing, 18)
            .allowsHitTesting(false)
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topTrailing)
        }
    }

    /// Preview layout shown after a scan has been finalized.
    private var previewSurface: some View {
        ZStack {
            RadialGradient(
                colors: [Color(red: 0.12, green: 0.14, blue: 0.18), .black],
                center: .topLeading,
                startRadius: 60,
                endRadius: 900
            )
            .ignoresSafeArea()

            VStack(spacing: 18) {
                HStack(alignment: .firstTextBaseline) {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("Scan Preview")
                            .font(.system(size: 30, weight: .bold, design: .rounded))
                            .foregroundStyle(.white)
                        Text("Point cloud sample and georeferencing status.")
                            .font(.system(size: 14, weight: .medium, design: .rounded))
                            .foregroundStyle(.white.opacity(0.7))
                    }
                    Spacer()
                    self.phaseBadge(self.controller.phase.title)
                }

                Group {
                    if self.controller.previewPoints.isEmpty {
                        RoundedRectangle(cornerRadius: 28, style: .continuous)
                            .fill(Color.white.opacity(0.06))
                            .overlay {
                                Text("No preview points were captured.")
                                    .font(.system(size: 17, weight: .semibold, design: .rounded))
                                    .foregroundStyle(.white.opacity(0.78))
                            }
                    } else {
                        PointCloudPreviewView(points: self.controller.previewPoints)
                            .clipShape(RoundedRectangle(cornerRadius: 28, style: .continuous))
                    }
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .overlay(alignment: .topTrailing) {
                    self.statPill(title: "Sample", value: "\(self.controller.previewPoints.count) pts")
                        .padding(18)
                }

                VStack(spacing: 14) {
                    HStack(spacing: 12) {
                        self.statCard("Accepted Points", value: "\(self.controller.pointCount)")
                        self.statCard("Coverage Cells", value: "\(self.controller.coverageCellCount)")
                        self.statCard("Location", value: self.controller.locationStatusText)
                    }

                    if self.controller.canResetForNewScan {
                        HStack(spacing: 12) {
                            self.actionButton(
                                title: "New Scan",
                                subtitle: "Reset capture and reopen camera",
                                style: ActionButtonStyle(
                                    fill: Color.white.opacity(0.08),
                                    foreground: .white,
                                    identifier: "action.newScan"
                                ),
                                action: self.controller.resetForNewScan
                            )
                        }
                    }
                }
            }
            .padding(20)
        }
    }

    /// Explanation shown when the device cannot supply the required hardware or permissions.
    private var blockedSurface: some View {
        ZStack {
            LinearGradient(
                colors: [
                    Color(red: 0.08, green: 0.10, blue: 0.14),
                    Color.black,
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()

            VStack(alignment: .leading, spacing: 18) {
                Text(self.controller.phase == .unsupported ? "LiDAR Required" : "Camera Access Required")
                    .font(.system(size: 34, weight: .bold, design: .rounded))
                    .foregroundStyle(.white)
                    .accessibilityIdentifier("unsupported.title")

                Text(self.controller.statusMessage)
                    .font(.system(size: 17, weight: .medium, design: .rounded))
                    .foregroundStyle(.white.opacity(0.75))

                VStack(alignment: .leading, spacing: 12) {
                    self.featureCallout(
                        title: "Rear-camera scene depth",
                        body: "The scan pipeline depends on ARKit scene depth from a LiDAR rear camera."
                    )
                    self.featureCallout(
                        title: "Colorized scan capture",
                        body: "Captured RGB keyframes and point data are retained with project metadata."
                    )
                    self.featureCallout(
                        title: "Approximate georeferencing",
                        body: "Phone GPS and heading are embedded when available, with quality warnings."
                    )
                }
            }
            .padding(28)
            .background(
                RoundedRectangle(cornerRadius: 32, style: .continuous)
                    .fill(Color.white.opacity(0.06))
            )
            .padding(20)
        }
    }

    /// Status overlay displayed above the live camera feed.
    private var topOverlay: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack(alignment: .firstTextBaseline) {
                VStack(alignment: .leading, spacing: 4) {
                    Text(self.title)
                        .font(.system(size: 28, weight: .bold, design: .rounded))
                        .foregroundStyle(.white)
                    if let subtitle {
                        Text(subtitle)
                            .font(.system(size: 13, weight: .semibold, design: .rounded))
                            .foregroundStyle(.white.opacity(0.62))
                    }
                    Text(self.controller.statusMessage)
                        .font(.system(size: 14, weight: .medium, design: .rounded))
                        .foregroundStyle(.white.opacity(0.7))
                }
                Spacer()
                self.phaseBadge(self.controller.phase.title)
            }

            self.captureHealthBanner

            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 10) {
                    self.statPill(title: "Points", value: "\(self.controller.pointCount)")
                    self.statPill(title: "Coverage", value: "\(self.controller.coverageCellCount)")
                    self.statPill(title: "Mesh", value: "\(self.controller.meshAnchorCount)")
                    self.statPill(title: "Elapsed", value: self.durationString(self.controller.elapsedTime))
                    self.statPill(title: "Tracking", value: self.controller.trackingStatusText)
                    self.locationPill
                }
            }
        }
    }

    /// Compact live guidance card that surfaces tracking and capture-health feedback.
    private var captureHealthBanner: some View {
        let health = self.controller.captureHealth
        let style = self.captureHealthBannerStyle(for: health.tone)

        return HStack(alignment: .top, spacing: 12) {
            Image(systemName: health.systemImage)
                .font(.system(size: 15, weight: .bold))
                .foregroundStyle(style.accent)
                .frame(width: 30, height: 30)
                .background(
                    Circle()
                        .fill(style.accent.opacity(0.18))
                )

            VStack(alignment: .leading, spacing: 4) {
                Text(health.title)
                    .font(.system(size: 15, weight: .bold, design: .rounded))
                    .foregroundStyle(.white)
                Text(health.message)
                    .font(.system(size: 13, weight: .medium, design: .rounded))
                    .foregroundStyle(.white.opacity(0.84))
                if let detail = health.detail {
                    Text(detail)
                        .font(.system(size: 12, weight: .semibold, design: .rounded))
                        .foregroundStyle(.white.opacity(0.6))
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(
            RoundedRectangle(cornerRadius: 22, style: .continuous)
                .fill(style.fill)
                .overlay(
                    RoundedRectangle(cornerRadius: 22, style: .continuous)
                        .strokeBorder(style.stroke, lineWidth: 1)
                )
        )
    }

    /// Bottom control area with capture actions and operator guidance.
    private var bottomPanel: some View {
        VStack(alignment: .leading, spacing: 18) {
            HStack(spacing: 12) {
                self.controlButton(
                    label: "Start",
                    systemImage: "record.circle.fill",
                    fill: self.controller.canStartCapture ? Color(red: 0.94, green: 0.33, blue: 0.28) : Color.white
                        .opacity(0.08),
                    action: self.controller.startCapture
                )
                .accessibilityIdentifier("action.start")
                .disabled(!self.controller.canStartCapture)

                self.controlButton(
                    label: self.controller.isCapturePaused ? "Resume" : "Pause",
                    systemImage: self.controller.isCapturePaused ? "play.fill" : "pause.fill",
                    fill: self.controller.phase == .capturing ? Color(red: 0.90, green: 0.60, blue: 0.18) : Color.white
                        .opacity(0.08),
                    action: self.controller.togglePauseCapture
                )
                .accessibilityIdentifier("action.pause")
                .disabled(self.controller.phase != .capturing)

                self.controlButton(
                    label: "Stop",
                    systemImage: "stop.fill",
                    fill: self.controller.phase == .capturing || self.controller.phase == .processing ? Color.white
                        .opacity(0.12) : Color.white.opacity(0.08),
                    action: self.controller.stopCapture
                )
                .accessibilityIdentifier("action.stop")
                .disabled(self.controller.phase != .capturing)
            }

            Text(
                "Walk steadily, keep textured surfaces in frame, "
                    + "and let the GPS badge settle before long outdoor passes."
            )
            .font(.system(size: 14, weight: .medium, design: .rounded))
            .foregroundStyle(.white.opacity(0.72))
            .padding(.horizontal, 2)
        }
        .padding(18)
        .background(
            RoundedRectangle(cornerRadius: 28, style: .continuous)
                .fill(Color.black.opacity(0.46))
                .overlay(
                    RoundedRectangle(cornerRadius: 28, style: .continuous)
                        .strokeBorder(Color.white.opacity(0.08), lineWidth: 1)
                )
        )
    }

    /// Color-coded location badge that summarizes current GPS and heading quality.
    private var locationPill: some View {
        let fill = switch self.controller.locationGrade {
        case .good:
            Color(red: 0.18, green: 0.55, blue: 0.34)
        case .fair:
            Color(red: 0.80, green: 0.58, blue: 0.16)
        case .poor, .unavailable:
            Color(red: 0.71, green: 0.29, blue: 0.23)
        }

        return HStack(spacing: 8) {
            Circle()
                .fill(fill)
                .frame(width: 8, height: 8)
            Text(self.controller.locationStatusText)
                .font(.system(size: 13, weight: .semibold, design: .rounded))
        }
        .foregroundStyle(.white)
        .padding(.horizontal, 12)
        .padding(.vertical, 9)
        .background(
            Capsule(style: .continuous)
                .fill(Color.black.opacity(0.42))
        )
    }
}

private extension ScannerFeatureView {
    struct ActionButtonStyle {
        let fill: Color
        let foreground: Color
        let identifier: String
    }

    struct HealthBannerStyle {
        let fill: Color
        let stroke: Color
        let accent: Color
    }

    func phaseBadge(_ title: String) -> some View {
        Text(title.uppercased())
            .font(.system(size: 11, weight: .black, design: .rounded))
            .tracking(1.2)
            .foregroundStyle(Color(red: 0.95, green: 0.77, blue: 0.34))
            .padding(.horizontal, 12)
            .padding(.vertical, 8)
            .background(
                Capsule(style: .continuous)
                    .fill(Color(red: 0.19, green: 0.15, blue: 0.08).opacity(0.9))
            )
    }

    func statPill(title: String, value: String) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(title.uppercased())
                .font(.system(size: 10, weight: .black, design: .rounded))
                .tracking(1.3)
                .foregroundStyle(.white.opacity(0.55))
            Text(value)
                .font(.system(size: 14, weight: .semibold, design: .rounded))
                .foregroundStyle(.white)
                .lineLimit(1)
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 10)
        .background(
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .fill(Color.black.opacity(0.44))
        )
    }

    func statCard(_ title: String, value: String) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title)
                .font(.system(size: 12, weight: .bold, design: .rounded))
                .foregroundStyle(.white.opacity(0.6))
            Text(value)
                .font(.system(size: 18, weight: .bold, design: .rounded))
                .foregroundStyle(.white)
                .lineLimit(2)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(16)
        .background(
            RoundedRectangle(cornerRadius: 22, style: .continuous)
                .fill(Color.white.opacity(0.06))
        )
    }

    func controlButton(
        label: String,
        systemImage: String,
        fill: Color,
        action: @escaping () -> Void
    ) -> some View {
        Button(action: action) {
            HStack(spacing: 9) {
                Image(systemName: systemImage)
                    .font(.system(size: 16, weight: .black))
                Text(label)
                    .font(.system(size: 16, weight: .bold, design: .rounded))
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 16)
            .background(
                RoundedRectangle(cornerRadius: 20, style: .continuous)
                    .fill(fill)
            )
        }
        .foregroundStyle(label == "Start" ? .black : .white)
    }

    func actionButton(
        title: String,
        subtitle: String,
        style: ActionButtonStyle,
        action: @escaping () -> Void
    ) -> some View {
        Button(action: action) {
            VStack(alignment: .leading, spacing: 6) {
                Text(title)
                    .font(.system(size: 18, weight: .bold, design: .rounded))
                Text(subtitle)
                    .font(.system(size: 13, weight: .medium, design: .rounded))
                    .opacity(0.75)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(18)
            .background(
                RoundedRectangle(cornerRadius: 24, style: .continuous)
                    .fill(style.fill)
            )
        }
        .foregroundStyle(style.foreground)
        .accessibilityIdentifier(style.identifier)
    }

    func warningBanner(_ text: String) -> some View {
        Text(text)
            .font(.system(size: 13, weight: .semibold, design: .rounded))
            .foregroundStyle(.white)
            .padding(.horizontal, 14)
            .padding(.vertical, 12)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(
                RoundedRectangle(cornerRadius: 18, style: .continuous)
                    .fill(Color(red: 0.33, green: 0.22, blue: 0.08).opacity(0.88))
            )
    }

    func featureCallout(title: String, body: String) -> some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(title)
                .font(.system(size: 16, weight: .bold, design: .rounded))
                .foregroundStyle(.white)
            Text(body)
                .font(.system(size: 14, weight: .medium, design: .rounded))
                .foregroundStyle(.white.opacity(0.72))
        }
    }

    func captureHealthBannerStyle(for tone: ScanSessionController.CaptureHealthTone) -> HealthBannerStyle {
        switch tone {
        case .neutral:
            return HealthBannerStyle(
                fill: Color.black.opacity(0.44),
                stroke: Color.white.opacity(0.08),
                accent: Color.white.opacity(0.9)
            )
        case .progress:
            return HealthBannerStyle(
                fill: Color(red: 0.08, green: 0.24, blue: 0.20).opacity(0.86),
                stroke: Color(red: 0.29, green: 0.72, blue: 0.58).opacity(0.45),
                accent: Color(red: 0.48, green: 0.93, blue: 0.77)
            )
        case .caution:
            return HealthBannerStyle(
                fill: Color(red: 0.28, green: 0.19, blue: 0.08).opacity(0.9),
                stroke: Color(red: 0.91, green: 0.66, blue: 0.25).opacity(0.45),
                accent: Color(red: 0.98, green: 0.78, blue: 0.33)
            )
        case .critical:
            return HealthBannerStyle(
                fill: Color(red: 0.30, green: 0.12, blue: 0.12).opacity(0.92),
                stroke: Color(red: 0.93, green: 0.40, blue: 0.36).opacity(0.52),
                accent: Color(red: 0.98, green: 0.51, blue: 0.47)
            )
        }
    }

    func durationString(_ duration: TimeInterval) -> String {
        let minutes = Int(duration) / 60
        let seconds = Int(duration) % 60
        return String(format: "%02d:%02d", minutes, seconds)
    }

    func notifyStateChange() {
        self.onStateChange?(self.controller.phase, self.controller.currentManifest)
    }
}
