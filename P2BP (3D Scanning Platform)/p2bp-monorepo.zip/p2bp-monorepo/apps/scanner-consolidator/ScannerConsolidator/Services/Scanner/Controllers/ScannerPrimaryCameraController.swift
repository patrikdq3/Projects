import ARKit
import AVFoundation

@MainActor
final class ScannerPrimaryCameraController {
    // MARK: Internal

    func setLocked(_ locked: Bool) {
        switch self.configurePrimaryCameraDevice(lockAdjustments: locked) {
        case .applied, .unavailable:
            self.shouldLockAdjustments = locked
        case .failed:
            break
        }
    }

    func reapplyLockedConfigurationIfNeeded() {
        guard self.shouldLockAdjustments else {
            return
        }

        _ = self.configurePrimaryCameraDevice(lockAdjustments: true)
    }

    // MARK: Private

    private enum ConfigurationResult {
        case applied
        case unavailable
        case failed
    }

    private var automaticLowLightBoostEnabled: Bool?
    private var automaticTorchMode: AVCaptureDevice.TorchMode?
    private var shouldLockAdjustments = false

    private func configurePrimaryCameraDevice(lockAdjustments: Bool) -> ConfigurationResult {
        guard let device = ARWorldTrackingConfiguration.configurableCaptureDeviceForPrimaryCamera else {
            return .unavailable
        }

        do {
            try device.lockForConfiguration()
            defer { device.unlockForConfiguration() }

            if lockAdjustments {
                self.applyLockedConfiguration(to: device)
            } else {
                self.applyAutomaticConfiguration(to: device)
            }

            return .applied
        } catch {
            let actionDescription = lockAdjustments ? "lock" : "unlock"
            NSLog(
                "ScannerPrimaryCameraController failed to %@ scan camera: %@",
                actionDescription,
                error.localizedDescription
            )
            return .failed
        }
    }

    private func applyLockedConfiguration(to device: AVCaptureDevice) {
        self.applyLockedTorchMode(to: device)

        device.automaticallyAdjustsVideoHDREnabled = false
        if device.activeFormat.isGlobalToneMappingSupported {
            device.isGlobalToneMappingEnabled = true
        }
        if device.isFocusModeSupported(.autoFocus) || device.isFocusModeSupported(.continuousAutoFocus) {
            device.automaticallyAdjustsFaceDrivenAutoFocusEnabled = false
        }
        if device.isExposureModeSupported(.autoExpose) || device.isExposureModeSupported(.continuousAutoExposure) {
            device.automaticallyAdjustsFaceDrivenAutoExposureEnabled = false
        }

        if device.isFocusModeSupported(.locked) {
            device.focusMode = .locked
        }

        if device.isExposureModeSupported(.locked) {
            device.exposureMode = .locked
        }

        if device.isWhiteBalanceModeSupported(.locked) {
            device.whiteBalanceMode = .locked
        }

        if device.isLowLightBoostSupported {
            if self.automaticLowLightBoostEnabled == nil {
                self.automaticLowLightBoostEnabled = device.automaticallyEnablesLowLightBoostWhenAvailable
            }

            device.automaticallyEnablesLowLightBoostWhenAvailable = false
        }

        if device.activeFormat.isVideoHDRSupported {
            device.isVideoHDREnabled = false
        }
    }

    private func applyAutomaticConfiguration(to device: AVCaptureDevice) {
        self.restoreAutomaticTorchMode(for: device)

        device.automaticallyAdjustsVideoHDREnabled = true
        if device.activeFormat.isGlobalToneMappingSupported {
            device.isGlobalToneMappingEnabled = false
        }
        if device.isFocusModeSupported(.autoFocus) || device.isFocusModeSupported(.continuousAutoFocus) {
            device.automaticallyAdjustsFaceDrivenAutoFocusEnabled = true
        }
        if device.isExposureModeSupported(.autoExpose) || device.isExposureModeSupported(.continuousAutoExposure) {
            device.automaticallyAdjustsFaceDrivenAutoExposureEnabled = true
        }
        self.restoreAutomaticLowLightBoostSetting(for: device)
        self.restoreFocusMode(for: device)
        self.restoreExposureMode(for: device)
        self.restoreWhiteBalanceMode(for: device)
        self.automaticLowLightBoostEnabled = nil
        self.automaticTorchMode = nil
    }

    private func restoreFocusMode(for device: AVCaptureDevice) {
        if device.isFocusModeSupported(.continuousAutoFocus) {
            device.focusMode = .continuousAutoFocus
        } else if device.isFocusModeSupported(.autoFocus) {
            device.focusMode = .autoFocus
        }
    }

    private func restoreExposureMode(for device: AVCaptureDevice) {
        if device.isExposureModeSupported(.continuousAutoExposure) {
            device.exposureMode = .continuousAutoExposure
        } else if device.isExposureModeSupported(.autoExpose) {
            device.exposureMode = .autoExpose
        }
    }

    private func restoreWhiteBalanceMode(for device: AVCaptureDevice) {
        if device.isWhiteBalanceModeSupported(.continuousAutoWhiteBalance) {
            device.whiteBalanceMode = .continuousAutoWhiteBalance
        } else if device.isWhiteBalanceModeSupported(.autoWhiteBalance) {
            device.whiteBalanceMode = .autoWhiteBalance
        }
    }

    private func applyLockedTorchMode(to device: AVCaptureDevice) {
        guard device.hasTorch else {
            return
        }

        if self.automaticTorchMode == nil {
            self.automaticTorchMode = device.torchMode
        }

        if device.isTorchModeSupported(.off), device.torchMode != .off {
            device.torchMode = .off
        }
    }

    private func restoreAutomaticTorchMode(for device: AVCaptureDevice) {
        guard let automaticTorchMode = self.automaticTorchMode else {
            return
        }

        let shouldRestoreAutomaticTorchMode =
            device.isTorchModeSupported(automaticTorchMode) &&
            device.torchMode != automaticTorchMode

        if shouldRestoreAutomaticTorchMode {
            device.torchMode = automaticTorchMode
        }
    }

    private func restoreAutomaticLowLightBoostSetting(for device: AVCaptureDevice) {
        guard device.isLowLightBoostSupported,
              let automaticLowLightBoostEnabled = self.automaticLowLightBoostEnabled
        else {
            return
        }

        let shouldRestoreAutomaticLowLightBoost =
            device.automaticallyEnablesLowLightBoostWhenAvailable != automaticLowLightBoostEnabled

        if shouldRestoreAutomaticLowLightBoost {
            device.automaticallyEnablesLowLightBoostWhenAvailable = automaticLowLightBoostEnabled
        }
    }
}
