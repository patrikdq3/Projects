import CoreVideo
import Foundation

extension CapturedImageColorRange {
    init(capturedImage: CVPixelBuffer) {
        let pixelFormat = CVPixelBufferGetPixelFormatType(capturedImage)

        if let knownColorRange = Self.knownColorRange(for: pixelFormat) {
            self = knownColorRange
            return
        }

        let formatDescription =
            CVPixelFormatDescriptionCreateWithPixelFormatType(nil, pixelFormat) as? [CFString: Any]

        guard let formatDescription,
              let componentRange = formatDescription[kCVPixelFormatComponentRange] as? NSString
        else {
            self = .videoRange
            return
        }

        let usesFullRangeCoefficients =
            componentRange.isEqual(kCVPixelFormatComponentRange_FullRange) ||
            componentRange.isEqual(kCVPixelFormatComponentRange_WideRange)

        if usesFullRangeCoefficients {
            self = .fullRange
        } else if componentRange.isEqual(kCVPixelFormatComponentRange_VideoRange) {
            self = .videoRange
        } else {
            self = .videoRange
        }
    }

    private static func knownColorRange(for pixelFormat: OSType) -> CapturedImageColorRange? {
        switch pixelFormat {
        case kCVPixelFormatType_420YpCbCr8PlanarFullRange,
             kCVPixelFormatType_420YpCbCr8BiPlanarFullRange,
             kCVPixelFormatType_422YpCbCr8BiPlanarFullRange,
             kCVPixelFormatType_444YpCbCr8BiPlanarFullRange,
             kCVPixelFormatType_422YpCbCr8FullRange,
             kCVPixelFormatType_420YpCbCr10BiPlanarFullRange,
             kCVPixelFormatType_422YpCbCr10BiPlanarFullRange,
             kCVPixelFormatType_444YpCbCr10BiPlanarFullRange,
             kCVPixelFormatType_Lossless_420YpCbCr8BiPlanarFullRange,
             kCVPixelFormatType_Lossless_420YpCbCr10PackedBiPlanarFullRange,
             kCVPixelFormatType_Lossy_420YpCbCr8BiPlanarFullRange:
            return .fullRange
        case kCVPixelFormatType_420YpCbCr8Planar,
             kCVPixelFormatType_420YpCbCr8BiPlanarVideoRange,
             kCVPixelFormatType_422YpCbCr8BiPlanarVideoRange,
             kCVPixelFormatType_444YpCbCr8BiPlanarVideoRange,
             kCVPixelFormatType_420YpCbCr10BiPlanarVideoRange,
             kCVPixelFormatType_422YpCbCr10BiPlanarVideoRange,
             kCVPixelFormatType_444YpCbCr10BiPlanarVideoRange,
             kCVPixelFormatType_420YpCbCr8VideoRange_8A_TriPlanar,
             kCVPixelFormatType_422YpCbCr16BiPlanarVideoRange,
             kCVPixelFormatType_444YpCbCr16BiPlanarVideoRange,
             kCVPixelFormatType_444YpCbCr16VideoRange_16A_TriPlanar,
             kCVPixelFormatType_Lossless_420YpCbCr8BiPlanarVideoRange,
             kCVPixelFormatType_Lossless_420YpCbCr10PackedBiPlanarVideoRange,
             kCVPixelFormatType_Lossless_422YpCbCr10PackedBiPlanarVideoRange,
             kCVPixelFormatType_Lossy_420YpCbCr8BiPlanarVideoRange,
             kCVPixelFormatType_Lossy_420YpCbCr10PackedBiPlanarVideoRange,
             kCVPixelFormatType_Lossy_422YpCbCr10PackedBiPlanarVideoRange:
            return .videoRange
        default:
            return nil
        }
    }
}

extension CapturedImageYCbCrMatrix {
    init(capturedImage: CVPixelBuffer) {
        guard
            let attachment = CVBufferCopyAttachment(capturedImage, kCVImageBufferYCbCrMatrixKey, nil),
            let matrix = attachment as? NSString
        else {
            self = .ituR709
            return
        }

        if matrix.isEqual(kCVImageBufferYCbCrMatrix_ITU_R_709_2) {
            self = .ituR709
        } else if matrix.isEqual(kCVImageBufferYCbCrMatrix_ITU_R_601_4) {
            self = .ituR601
        } else if matrix.isEqual(kCVImageBufferYCbCrMatrix_ITU_R_2020) {
            self = .ituR2020
        } else {
            self = .ituR709
        }
    }
}

// MARK: - YCbCrToRGBConversion

struct YCbCrToRGBConversion {
    // MARK: Lifecycle

    init(
        lumaScale: Double,
        lumaOffset: Double,
        redCrScale: Double,
        greenCbScale: Double,
        greenCrScale: Double,
        blueCbScale: Double
    ) {
        self.lumaScale = lumaScale
        self.lumaOffset = lumaOffset
        self.redCrScale = redCrScale
        self.greenCbScale = greenCbScale
        self.greenCrScale = greenCrScale
        self.blueCbScale = blueCbScale
    }

    init(colorRange: CapturedImageColorRange, matrix: CapturedImageYCbCrMatrix) {
        switch (colorRange, matrix) {
        case (.fullRange, .ituR601):
            self.init(
                lumaScale: 1,
                lumaOffset: 0,
                redCrScale: 1.402,
                greenCbScale: 0.344_136,
                greenCrScale: 0.714_136,
                blueCbScale: 1.772
            )
        case (.fullRange, .ituR709):
            self.init(
                lumaScale: 1,
                lumaOffset: 0,
                redCrScale: 1.574_8,
                greenCbScale: 0.187_324,
                greenCrScale: 0.468_124,
                blueCbScale: 1.855_6
            )
        case (.fullRange, .ituR2020):
            self.init(
                lumaScale: 1,
                lumaOffset: 0,
                redCrScale: 1.474_6,
                greenCbScale: 0.164_553,
                greenCrScale: 0.571_353,
                blueCbScale: 1.881_4
            )
        case (.videoRange, .ituR601):
            self.init(
                lumaScale: 1.164_384,
                lumaOffset: 16,
                redCrScale: 1.596_027,
                greenCbScale: 0.391_762,
                greenCrScale: 0.812_968,
                blueCbScale: 2.017_232
            )
        case (.videoRange, .ituR709):
            self.init(
                lumaScale: 1.164_384,
                lumaOffset: 16,
                redCrScale: 1.792_741,
                greenCbScale: 0.213_249,
                greenCrScale: 0.532_909,
                blueCbScale: 2.112_402
            )
        case (.videoRange, .ituR2020):
            self.init(
                lumaScale: 1.164_384,
                lumaOffset: 16,
                redCrScale: 1.678_674,
                greenCbScale: 0.187_326,
                greenCrScale: 0.650_424,
                blueCbScale: 2.141_772
            )
        }
    }

    // MARK: Internal

    let lumaScale: Double
    let lumaOffset: Double
    let redCrScale: Double
    let greenCbScale: Double
    let greenCrScale: Double
    let blueCbScale: Double
}
