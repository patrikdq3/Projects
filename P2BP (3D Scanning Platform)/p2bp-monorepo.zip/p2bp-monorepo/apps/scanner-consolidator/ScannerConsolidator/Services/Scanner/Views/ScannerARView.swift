import ARKit
import SceneKit
import SwiftUI

/// Hosts the live ARKit camera view used during capture.
struct ScannerARView: UIViewRepresentable {
    /// Controller that owns the AR session and capture pipeline.
    @ObservedObject var controller: ScanSessionController

    /// Pauses the AR session when SwiftUI tears down the view.
    static func dismantleUIView(_ uiView: ARSCNView, coordinator _: ()) {
        uiView.session.pause()
    }

    /// Builds and configures the AR scene view used for live scanning.
    func makeUIView(context _: Context) -> ARSCNView {
        let sceneView = ARSCNView(frame: .zero)
        sceneView.scene = SCNScene()
        sceneView.automaticallyUpdatesLighting = true
        sceneView.preferredFramesPerSecond = 60
        sceneView.rendersMotionBlur = false
        sceneView.antialiasingMode = .multisampling4X
        sceneView.accessibilityIdentifier = "scanner.cameraView"
        self.controller.attach(sceneView: sceneView)
        return sceneView
    }

    /// The controller pushes changes through delegates, so no view diffing is needed here.
    func updateUIView(_: ARSCNView, context _: Context) {}
}
