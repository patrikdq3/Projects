import Metal
import simd

// MARK: - PointCloudOutlineBuilder

/// Builds 2D footprint outlines for detected structures (buildings and vegetation) that are
/// drawn over the top-down elevation heat map.
///
/// Grid-based fallback: fine XY occupancy rasterization per category, 8-connected component
/// clustering, boundary tracing, and sub-cell corner smoothing. Server-provided outlines use
/// the richer support-aware segmentation; this remains deterministic and CPU-only.
nonisolated enum PointCloudOutlineBuilder {
    // MARK: Internal

    static func buildOutlineVertices(cloud: LoadedPointCloud) -> [PointCloudOutlineVertex] {
        guard cloud.pointCount > 0 else { return [] }
        let extent = cloud.boundsMax - cloud.boundsMin
        let planarExtent = max(extent.x, extent.y)
        guard cloud.boundsMin.x.isFinite, cloud.boundsMin.y.isFinite, cloud.boundsMin.z.isFinite,
              extent.x.isFinite, extent.y.isFinite, extent.z.isFinite,
              planarExtent.isFinite, planarExtent > 1
        else { return [] }

        let cellSize = max(planarExtent / Float(self.maximumGridDimension), 0.2)
        let width = min(Int(extent.x / cellSize) + 1, self.maximumGridDimension + 1)
        let height = min(Int(extent.y / cellSize) + 1, self.maximumGridDimension + 1)
        var buildingGrid = OccupancyGrid(width: width, height: height, cellSize: cellSize, origin: cloud.boundsMin)
        var vegetationGrid = OccupancyGrid(width: width, height: height, cellSize: cellSize, origin: cloud.boundsMin)
        var inferredGrid = OccupancyGrid(width: width, height: height, cellSize: cellSize, origin: cloud.boundsMin)

        let sampleStride = max(1, cloud.pointCount / 8_000_000)
        let points = cloud.vertexBuffer.contents().assumingMemoryBound(to: PackedPointVertex.self)
        var index = 0
        while index < cloud.pointCount {
            let point = points[index]
            index += sampleStride
            switch point.classification {
            case 6:
                buildingGrid.add(x: point.x, y: point.y, z: point.z)
            case 4, 5:
                vegetationGrid.add(x: point.x, y: point.y, z: point.z)
            default:
                if point.padding & PointCloudBlockerClassifier.inferredMarker != 0 {
                    inferredGrid.add(x: point.x, y: point.y, z: point.z)
                }
            }
        }

        let occupancyThreshold: UInt16 = sampleStride > 1 ? 1 : 3
        var vertices: [PointCloudOutlineVertex] = []
        self.appendOutlines(
            grid: buildingGrid,
            occupancyThreshold: occupancyThreshold,
            color: SIMD3(255, 150, 60),
            into: &vertices
        )
        self.appendOutlines(
            grid: vegetationGrid,
            occupancyThreshold: occupancyThreshold,
            color: SIMD3(96, 210, 110),
            into: &vertices
        )
        self.appendOutlines(
            grid: inferredGrid,
            occupancyThreshold: occupancyThreshold,
            color: SIMD3(255, 196, 74),
            into: &vertices
        )
        return vertices
    }

    // MARK: Private

    private struct OccupancyGrid {
        // MARK: Lifecycle

        init(width: Int, height: Int, cellSize: Float, origin: SIMD3<Float>) {
            self.width = width
            self.height = height
            self.cellSize = cellSize
            self.origin = origin
            self.counts = [UInt16](repeating: 0, count: width * height)
            self.minimumZ = [Float](repeating: .greatestFiniteMagnitude, count: width * height)
        }

        // MARK: Internal

        let width: Int
        let height: Int
        let cellSize: Float
        let origin: SIMD3<Float>
        var counts: [UInt16]
        var minimumZ: [Float]

        mutating func add(x: Float, y: Float, z: Float) {
            let gridX = (x - self.origin.x) / self.cellSize
            let gridY = (y - self.origin.y) / self.cellSize
            guard gridX.isFinite, gridY.isFinite, z.isFinite else { return }
            let cellX = Int(min(max(gridX, 0), Float(self.width - 1)))
            let cellY = Int(min(max(gridY, 0), Float(self.height - 1)))
            let index = cellY * self.width + cellX
            if self.counts[index] < .max {
                self.counts[index] += 1
            }
            self.minimumZ[index] = min(self.minimumZ[index], z)
        }
    }

    private static let maximumGridDimension = 1024
    private static let minimumClusterCells = 5
    private static let maximumOutlineVertices = 2_000_000

    /// Labels 8-connected clusters of occupied cells; returns one cell-index list per cluster.
    private static func clusters(grid: OccupancyGrid, occupancyThreshold: UInt16) -> [[Int]] {
        let cellCount = grid.width * grid.height
        var labels = [Int32](repeating: -1, count: cellCount)
        var result: [[Int]] = []

        for start in 0 ..< cellCount where labels[start] < 0 && grid.counts[start] >= occupancyThreshold {
            var component: [Int] = []
            var stack = [start]
            let label = Int32(result.count)
            labels[start] = label
            while let cell = stack.popLast() {
                component.append(cell)
                let cellX = cell % grid.width
                let cellY = cell / grid.width
                for (neighborX, neighborY) in [
                    (cellX - 1, cellY - 1), (cellX, cellY - 1), (cellX + 1, cellY - 1),
                    (cellX - 1, cellY), (cellX + 1, cellY),
                    (cellX - 1, cellY + 1), (cellX, cellY + 1), (cellX + 1, cellY + 1),
                ] {
                    guard neighborX >= 0, neighborX < grid.width, neighborY >= 0, neighborY < grid.height
                    else { continue }
                    let neighbor = neighborY * grid.width + neighborX
                    guard labels[neighbor] < 0, grid.counts[neighbor] >= occupancyThreshold else { continue }
                    labels[neighbor] = label
                    stack.append(neighbor)
                }
            }
            result.append(component)
        }
        return result
    }

    /// Collects the directed boundary edges of one cluster, oriented with the interior on
    /// the left. Corners are encoded as `cornerY * (width + 1) + cornerX`.
    private static func boundaryEdges(of component: [Int], grid: OccupancyGrid, occupied: Set<Int>) -> [Int: [Int]] {
        let cornerStride = grid.width + 1
        var edges: [Int: [Int]] = [:]
        func addEdge(from start: Int, to end: Int) {
            edges[start, default: []].append(end)
        }

        for cell in component {
            let cellX = cell % grid.width
            let cellY = cell / grid.width
            let bottomLeft = cellY * cornerStride + cellX
            if cellY == 0 || !occupied.contains(cell - grid.width) {
                addEdge(from: bottomLeft, to: bottomLeft + 1)
            }
            if cellX == grid.width - 1 || !occupied.contains(cell + 1) {
                addEdge(from: bottomLeft + 1, to: bottomLeft + 1 + cornerStride)
            }
            if cellY == grid.height - 1 || !occupied.contains(cell + grid.width) {
                addEdge(from: bottomLeft + 1 + cornerStride, to: bottomLeft + cornerStride)
            }
            if cellX == 0 || !occupied.contains(cell - 1) {
                addEdge(from: bottomLeft + cornerStride, to: bottomLeft)
            }
        }
        return edges
    }

    /// Chains directed edges into closed loops and drops collinear midpoints.
    private static func loops(from edges: [Int: [Int]], cornerStride: Int) -> [[SIMD2<Int>]] {
        var remaining = edges
        var result: [[SIMD2<Int>]] = []
        let edgeCount = edges.values.reduce(0) { $0 + $1.count }
        var consumed = 0

        while let start = remaining.keys.first, consumed < edgeCount {
            var loop: [Int] = [start]
            var current = start
            while consumed < edgeCount {
                guard var nextCandidates = remaining[current], let next = nextCandidates.popLast() else { break }
                if nextCandidates.isEmpty {
                    remaining.removeValue(forKey: current)
                } else {
                    remaining[current] = nextCandidates
                }
                consumed += 1
                if next == start {
                    break
                }
                loop.append(next)
                current = next
            }
            if loop.count >= 4 {
                result.append(self.simplified(loop: loop, cornerStride: cornerStride))
            }
        }
        return result
    }

    private static func simplified(loop: [Int], cornerStride: Int) -> [SIMD2<Int>] {
        let corners = loop.map { SIMD2($0 % cornerStride, $0 / cornerStride) }
        var result: [SIMD2<Int>] = []
        result.reserveCapacity(corners.count)
        for index in 0 ..< corners.count {
            let previous = corners[(index + corners.count - 1) % corners.count]
            let current = corners[index]
            let next = corners[(index + 1) % corners.count]
            if (current &- previous) != (next &- current) {
                result.append(current)
            }
        }
        return result
    }

    /// One Chaikin pass replaces hard raster corners with sub-cell points. At the 20 cm
    /// fallback resolution this removes visible stair steps without materially moving an
    /// object's boundary.
    private static func smoothed(loop: [SIMD2<Int>]) -> [SIMD2<Float>] {
        guard loop.count >= 4 else { return loop.map { SIMD2(Float($0.x), Float($0.y)) } }
        var result: [SIMD2<Float>] = []
        result.reserveCapacity(loop.count * 2)
        for index in loop.indices {
            let current = SIMD2(Float(loop[index].x), Float(loop[index].y))
            let nextIndex = loop.index(after: index) == loop.endIndex ? loop.startIndex : loop.index(after: index)
            let next = SIMD2(Float(loop[nextIndex].x), Float(loop[nextIndex].y))
            result.append(current * 0.75 + next * 0.25)
            result.append(current * 0.25 + next * 0.75)
        }
        return result
    }

    private static func appendOutlines(
        grid: OccupancyGrid,
        occupancyThreshold: UInt16,
        color: SIMD3<UInt8>,
        into vertices: inout [PointCloudOutlineVertex]
    ) {
        let cornerStride = grid.width + 1
        for component in self.clusters(grid: grid, occupancyThreshold: occupancyThreshold) {
            guard component.count >= self.minimumClusterCells,
                  vertices.count < self.maximumOutlineVertices else { continue }
            let occupied = Set(component)
            let baseZ = component.map { grid.minimumZ[$0] }.min() ?? grid.origin.z
            let edges = self.boundaryEdges(of: component, grid: grid, occupied: occupied)
            for rasterLoop in self.loops(from: edges, cornerStride: cornerStride) {
                let loop = self.smoothed(loop: rasterLoop)
                var arcLength: Float = 0
                for index in 0 ..< loop.count {
                    let start = loop[index]
                    let end = loop[(index + 1) % loop.count]
                    let delta = end - start
                    let scaledDelta = delta * grid.cellSize
                    let segmentLength = simd_length(scaledDelta)
                    for (corner, cornerArcLength) in [(start, arcLength), (end, arcLength + segmentLength)] {
                        vertices.append(PointCloudOutlineVertex(
                            x: grid.origin.x + corner.x * grid.cellSize,
                            y: grid.origin.y + corner.y * grid.cellSize,
                            z: baseZ,
                            red: color.x,
                            green: color.y,
                            blue: color.z,
                            alpha: 255,
                            arcLength: cornerArcLength
                        ))
                    }
                    arcLength += segmentLength
                }
            }
        }
    }
}
