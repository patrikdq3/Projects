import Metal

// MARK: - PointCloudBlockerClassifier

/// Marks likely above-ground occluders when a cloud has no useful ASPRS classes.
///
/// The fallback builds a low-resolution robust lower-height surface, relaxes it into a
/// slope-limited ground envelope, and tags points sufficiently far above that envelope.
/// This keeps sloped terrain while removing likely roofs, walls, and vegetation.
///
/// Robustness against stray low returns matters more than recall here: a ground estimate
/// pulled below the true floor makes genuine floor points disappear from the top-down
/// view. The estimate therefore ignores the few lowest returns per cell, distrusts
/// sparsely populated cells, and rejects cells that sit far below their neighborhood
/// before the envelope relaxation can spread them.
nonisolated enum PointCloudBlockerClassifier {
    // MARK: Internal

    static let inferredMarker: UInt16 = 1

    /// Estimates a stable global floor reference for height visualization. Classified
    /// ground returns win when present; otherwise a low percentile keeps a few stray
    /// returns below the scan from dragging the reference away from the visible floor.
    static func estimateFloorHeight(
        in buffer: any MTLBuffer,
        pointCount: Int,
        fallback: Float,
        shouldCancel: () -> Bool
    ) -> Float {
        guard pointCount > 0 else { return fallback }
        let points = buffer.contents().assumingMemoryBound(to: PackedPointVertex.self)
        let stride = max(1, pointCount / self.floorEstimateSampleBudget)
        var allHeights: [Float] = []
        var groundHeights: [Float] = []
        allHeights.reserveCapacity(min(pointCount, self.floorEstimateSampleBudget))
        groundHeights.reserveCapacity(allHeights.capacity / 4)
        for index in Swift.stride(from: 0, to: pointCount, by: stride) {
            if index & 0xFFFF == 0, shouldCancel() {
                return fallback
            }
            let point = points[index]
            guard point.z.isFinite else { continue }
            allHeights.append(point.z)
            if point.classification == 2 {
                groundHeights.append(point.z)
            }
        }
        if groundHeights.count >= self.minimumClassifiedGroundSamples {
            groundHeights.sort()
            return groundHeights[groundHeights.count / 2]
        }
        guard !allHeights.isEmpty else { return fallback }
        allHeights.sort()
        let floorIndex = min(Int(Float(allHeights.count) * self.unclassifiedFloorPercentile), allHeights.count - 1)
        return allHeights[floorIndex]
    }

    /// Writes each point's height above the local ground envelope into the upper 15 bits of
    /// `padding` (centimeters, clamped to zero and ~327 m), preserving the inferred-blocker
    /// bit. When the cloud is too small or sparse for a reliable envelope, heights fall back
    /// to the global floor estimate so the roof/canopy cut still behaves sensibly.
    static func encodeHeightsAboveGround(cloud: LoadedPointCloud, shouldCancel: () -> Bool) {
        let pointCount = cloud.pointCount
        guard pointCount > 0 else { return }
        let points = cloud.vertexBuffer.contents().assumingMemoryBound(to: PackedPointVertex.self)
        let extent = cloud.boundsMax - cloud.boundsMin
        let planarExtent = max(extent.x, extent.y)

        var envelope: (grid: Grid, ground: [Float])?
        if planarExtent > 1, let grid = Grid(
            boundsMin: cloud.boundsMin,
            extent: extent,
            planarExtent: planarExtent,
            pointCount: pointCount
        ) {
            if grid.width > 0, grid.height > 0, var ground = self.makeRobustGroundSurface(
                points: points,
                pointCount: pointCount,
                grid: grid,
                shouldCancel: shouldCancel
            ) {
                self.despikeGroundSurface(&ground, grid: grid)
                self.relaxGroundEnvelope(&ground, grid: grid)
                envelope = (grid, ground)
            }
        }

        for index in 0 ..< pointCount {
            if index & 0xFFFF == 0, shouldCancel() {
                return
            }
            let point = points[index]
            var reference = cloud.floorHeight
            if let envelope, let cell = envelope.grid.cellIndex(x: point.x, y: point.y) {
                let cellGround = envelope.ground[cell]
                if cellGround < .greatestFiniteMagnitude {
                    reference = cellGround
                }
            }
            let centimeters = (point.z - reference) * 100
            let quantized = centimeters.isFinite ? UInt16(min(max(centimeters, 0), 32767)) : 0
            points[index].padding = (point.padding & self.inferredMarker) | (quantized << 1)
        }
    }

    static func inferBlockers(
        in buffer: any MTLBuffer,
        pointCount: Int,
        boundsMin: SIMD3<Float>,
        boundsMax: SIMD3<Float>,
        shouldCancel: () -> Bool
    ) -> Int {
        guard pointCount > 0 else { return 0 }
        let extent = boundsMax - boundsMin
        let planarExtent = max(extent.x, extent.y)
        let verticalExtent = extent.z
        guard planarExtent > 1, verticalExtent > self.minimumBlockerHeight else { return 0 }

        guard let grid = Grid(
            boundsMin: boundsMin,
            extent: extent,
            planarExtent: planarExtent,
            pointCount: pointCount
        ) else { return 0 }
        guard grid.width > 0, grid.height > 0 else { return 0 }

        let points = buffer.contents().assumingMemoryBound(to: PackedPointVertex.self)
        guard var ground = self.makeRobustGroundSurface(
            points: points,
            pointCount: pointCount,
            grid: grid,
            shouldCancel: shouldCancel
        ) else { return 0 }

        self.despikeGroundSurface(&ground, grid: grid)
        self.relaxGroundEnvelope(&ground, grid: grid)

        // Large cells can hide real terrain slope inside a single cell; keep the height
        // threshold above that in-cell variation so hillside floors are not tagged.
        let blockerHeight = max(self.minimumBlockerHeight, grid.cellSize * self.cellSlopeAllowance)
        let context = InferenceContext(grid: grid, ground: ground, blockerHeight: blockerHeight)
        guard let candidateCounts = self.countCandidates(
            points: points,
            pointCount: pointCount,
            context: context,
            shouldCancel: shouldCancel
        ), let inferredCount = self.markCandidates(
            points: points,
            pointCount: pointCount,
            context: context,
            candidateCounts: candidateCounts,
            shouldCancel: shouldCancel
        ) else { return 0 }

        // A bad header or an unusual non-terrain cloud should not make the fallback erase
        // nearly everything. Undo inferred tags and leave the orthographic view unfiltered.
        if inferredCount > pointCount * self.maximumRemovalPercent / 100 {
            self.clearInferredMarkers(points: points, pointCount: pointCount)
            return 0
        }
        return inferredCount
    }

    // MARK: Private

    private struct Grid {
        // MARK: Lifecycle

        init?(
            boundsMin: SIMD3<Float>,
            extent: SIMD3<Float>,
            planarExtent: Float,
            pointCount: Int
        ) {
            guard boundsMin.x.isFinite, boundsMin.y.isFinite, boundsMin.z.isFinite,
                  extent.x.isFinite, extent.y.isFinite, extent.z.isFinite,
                  planarExtent.isFinite, planarExtent > 0, pointCount > 0
            else { return nil }
            self.origin = boundsMin
            // Sparse clouds need larger cells so enough returns land in each one to
            // support a trustworthy ground estimate.
            let planarArea = max(extent.x * extent.y, 1)
            let densityCellSize = min(
                (PointCloudBlockerClassifier.targetSamplesPerCell * planarArea / Float(pointCount)).squareRoot(),
                PointCloudBlockerClassifier.maximumCellSize
            )
            self.cellSize = max(
                planarExtent / Float(PointCloudBlockerClassifier.maximumGridDimension),
                PointCloudBlockerClassifier.minimumCellSize,
                densityCellSize
            )
            self.width = min(
                Int(extent.x / self.cellSize) + 1,
                PointCloudBlockerClassifier.maximumGridDimension + 1
            )
            self.height = min(
                Int(extent.y / self.cellSize) + 1,
                PointCloudBlockerClassifier.maximumGridDimension + 1
            )
        }

        // MARK: Internal

        let origin: SIMD3<Float>
        let cellSize: Float
        let width: Int
        let height: Int

        func cellIndex(x: Float, y: Float) -> Int? {
            let gridX = (x - self.origin.x) / self.cellSize
            let gridY = (y - self.origin.y) / self.cellSize
            guard gridX.isFinite, gridY.isFinite else { return nil }
            let cellX = Int(min(max(gridX, 0), Float(self.width - 1)))
            let cellY = Int(min(max(gridY, 0), Float(self.height - 1)))
            return cellY * self.width + cellX
        }
    }

    private struct InferenceContext {
        let grid: Grid
        let ground: [Float]
        let blockerHeight: Float
    }

    private static let maximumGridDimension = 768
    private static let floorEstimateSampleBudget = 65536
    private static let minimumClassifiedGroundSamples = 64
    private static let unclassifiedFloorPercentile: Float = 0.05
    private static let minimumCellSize: Float = 0.75
    private static let maximumCellSize: Float = 4
    private static let targetSamplesPerCell: Float = 12
    private static let groundSampleCount = 4
    private static let minimumCellSamples: Int32 = 4
    private static let despikeThreshold: Float = 2.5
    private static let minimumBlockerHeight: Float = 1.8
    private static let cellSlopeAllowance: Float = 0.6
    private static let maximumGroundSlope: Float = 1.0
    private static let minimumBlockerSupport: Int32 = 3
    private static let maximumRemovalPercent = 85
    private static let diagonalScale = Float(2).squareRoot()

    /// Only cells with several elevated returns count as occluders, so isolated noise
    /// above the floor does not punch holes into it.
    private static func countCandidates(
        points: UnsafeMutablePointer<PackedPointVertex>,
        pointCount: Int,
        context: InferenceContext,
        shouldCancel: () -> Bool
    ) -> [Int32]? {
        var counts = [Int32](repeating: 0, count: context.grid.width * context.grid.height)
        for index in 0 ..< pointCount {
            if index & 0xFFFF == 0, shouldCancel() {
                return nil
            }
            let point = points[index]
            guard point.z.isFinite,
                  let cell = context.grid.cellIndex(x: point.x, y: point.y)
            else { continue }
            let groundHeight = context.ground[cell]
            guard groundHeight.isFinite, point.z - groundHeight >= context.blockerHeight else { continue }
            counts[cell] += 1
        }
        return counts
    }

    private static func markCandidates(
        points: UnsafeMutablePointer<PackedPointVertex>,
        pointCount: Int,
        context: InferenceContext,
        candidateCounts: [Int32],
        shouldCancel: () -> Bool
    ) -> Int? {
        var inferredCount = 0
        for index in 0 ..< pointCount {
            if index & 0xFFFF == 0, shouldCancel() {
                return nil
            }
            let point = points[index]
            guard point.z.isFinite,
                  let cell = context.grid.cellIndex(x: point.x, y: point.y)
            else { continue }
            let groundHeight = context.ground[cell]
            guard groundHeight.isFinite,
                  point.z - groundHeight >= context.blockerHeight,
                  candidateCounts[cell] >= self.minimumBlockerSupport
            else { continue }
            points[index].padding = self.inferredMarker
            inferredCount += 1
        }
        return inferredCount
    }

    private static func clearInferredMarkers(
        points: UnsafeMutablePointer<PackedPointVertex>,
        pointCount: Int
    ) {
        for index in 0 ..< pointCount where points[index].padding & self.inferredMarker != 0 {
            points[index].padding &= ~self.inferredMarker
        }
    }

    /// Per-cell ground is the highest of the few lowest returns, so a handful of stray
    /// low returns (glass reflections, multipath) cannot pull the floor down. Cells with
    /// too few returns provide no estimate and are filled by the envelope relaxation.
    private static func makeRobustGroundSurface(
        points: UnsafeMutablePointer<PackedPointVertex>,
        pointCount: Int,
        grid: Grid,
        shouldCancel: () -> Bool
    ) -> [Float]? {
        let cellCount = grid.width * grid.height
        var lowest = [Float](repeating: .greatestFiniteMagnitude, count: cellCount * self.groundSampleCount)
        var counts = [Int32](repeating: 0, count: cellCount)
        for index in 0 ..< pointCount {
            if index & 0xFFFF == 0, shouldCancel() {
                return nil
            }
            let point = points[index]
            guard point.z.isFinite, let cell = grid.cellIndex(x: point.x, y: point.y)
            else { continue }
            counts[cell] += 1
            let base = cell * self.groundSampleCount
            var value = point.z
            for slot in base ..< base + self.groundSampleCount where value < lowest[slot] {
                swap(&value, &lowest[slot])
            }
        }
        var ground = [Float](repeating: .greatestFiniteMagnitude, count: cellCount)
        for cell in 0 ..< cellCount where counts[cell] >= self.minimumCellSamples {
            ground[cell] = lowest[cell * self.groundSampleCount + self.groundSampleCount - 1]
        }
        return ground
    }

    /// Rejects cells whose ground sits far below the surrounding surface before the
    /// envelope relaxation can spread them. Without this, one poisoned cell lowers the
    /// envelope across a wide radius and genuine floor points above it get removed.
    private static func despikeGroundSurface(_ ground: inout [Float], grid: Grid) {
        let source = ground
        var neighbors = [Float]()
        neighbors.reserveCapacity(8)
        for y in 0 ..< grid.height {
            for x in 0 ..< grid.width {
                let index = y * grid.width + x
                let value = source[index]
                guard value < .greatestFiniteMagnitude else { continue }
                neighbors.removeAll(keepingCapacity: true)
                for offsetY in -1 ... 1 {
                    for offsetX in -1 ... 1 where offsetY != 0 || offsetX != 0 {
                        let neighborX = x + offsetX
                        let neighborY = y + offsetY
                        guard neighborX >= 0, neighborX < grid.width,
                              neighborY >= 0, neighborY < grid.height else { continue }
                        let neighbor = source[neighborY * grid.width + neighborX]
                        if neighbor < .greatestFiniteMagnitude {
                            neighbors.append(neighbor)
                        }
                    }
                }
                guard neighbors.count >= 3 else { continue }
                neighbors.sort()
                let median = neighbors[neighbors.count / 2]
                if value < median - self.despikeThreshold {
                    ground[index] = median
                }
            }
        }
    }

    /// A pair of opposing chamfer sweeps computes a lower, slope-limited envelope.
    /// Nearby low cells can therefore identify a roof-only cell as elevated, while the
    /// allowed rise per meter prevents ordinary terrain slopes from being flattened.
    private static func relaxGroundEnvelope(
        _ ground: inout [Float],
        grid: Grid
    ) {
        let axialRise = grid.cellSize * self.maximumGroundSlope
        let diagonalRise = axialRise * self.diagonalScale
        for _ in 0 ..< 2 {
            self.forwardSweep(&ground, grid: grid, axialRise: axialRise, diagonalRise: diagonalRise)
            self.backwardSweep(&ground, grid: grid, axialRise: axialRise, diagonalRise: diagonalRise)
        }
    }

    private static func forwardSweep(
        _ ground: inout [Float],
        grid: Grid,
        axialRise: Float,
        diagonalRise: Float
    ) {
        for y in 0 ..< grid.height {
            for x in 0 ..< grid.width {
                let index = y * grid.width + x
                if x > 0 {
                    ground[index] = min(ground[index], ground[index - 1] + axialRise)
                }
                guard y > 0 else { continue }
                ground[index] = min(ground[index], ground[index - grid.width] + axialRise)
                if x > 0 {
                    ground[index] = min(ground[index], ground[index - grid.width - 1] + diagonalRise)
                }
                if x + 1 < grid.width {
                    ground[index] = min(ground[index], ground[index - grid.width + 1] + diagonalRise)
                }
            }
        }
    }

    private static func backwardSweep(
        _ ground: inout [Float],
        grid: Grid,
        axialRise: Float,
        diagonalRise: Float
    ) {
        for y in stride(from: grid.height - 1, through: 0, by: -1) {
            for x in stride(from: grid.width - 1, through: 0, by: -1) {
                let index = y * grid.width + x
                if x + 1 < grid.width {
                    ground[index] = min(ground[index], ground[index + 1] + axialRise)
                }
                guard y + 1 < grid.height else { continue }
                ground[index] = min(ground[index], ground[index + grid.width] + axialRise)
                if x > 0 {
                    ground[index] = min(ground[index], ground[index + grid.width - 1] + diagonalRise)
                }
                if x + 1 < grid.width {
                    ground[index] = min(ground[index], ground[index + grid.width + 1] + diagonalRise)
                }
            }
        }
    }
}
