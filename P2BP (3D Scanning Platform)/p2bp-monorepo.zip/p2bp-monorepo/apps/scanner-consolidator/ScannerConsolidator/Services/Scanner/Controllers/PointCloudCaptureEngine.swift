import ARKit
import CoreImage
import Foundation
import simd
import UIKit

// MARK: - CaptureEngineConfiguration

/// Tunable parameters that control point density, filtering, and persistence cadence.
struct CaptureEngineConfiguration {
    /// Pixel stride used when walking the depth map. Lower values keep more points.
    var samplingStride = 4
    /// Smallest accepted depth sample in meters.
    var minimumDepthMeters: Float = 0.2
    /// Largest accepted depth sample in meters.
    var maximumDepthMeters: Float = 5.0
    /// Minimum ARKit confidence level required for a point to be accepted.
    var minimumConfidence: UInt8 = 1
    /// Voxel size used when tracking approximate scan coverage.
    var voxelSizeMeters: Float = 0.025
    /// Number of buffered points to accumulate before writing a chunk to disk.
    var flushThreshold = 12000
    /// Maximum number of points retained in memory for live and final preview.
    var previewLimit = 100_000_000
    /// Minimum time between processed frames to limit work per second.
    var minimumFrameInterval: TimeInterval = 0.4
    /// Minimum time between persisted RGB keyframes.
    var minimumKeyframeInterval: TimeInterval = 1.0
}

// MARK: - CaptureIngestResult

/// Summary returned after one frame ingest pass.
struct CaptureIngestResult {
    /// Number of new points accepted from the processed frame.
    var acceptedPointCount: Int
    /// Total accepted point count since capture began.
    var totalPointCount: Int
    /// Number of occupied coverage voxels observed so far.
    var coverageCellCount: Int
    /// Preview subset used by the UI while capture is running.
    var previewPoints: [CapturedPoint]
}

// MARK: - KeyframeImageQualityEstimator

/// Lightweight sharpness estimator used to enrich persisted keyframes.
enum KeyframeImageQualityEstimator {
    // MARK: Internal

    /// Identifier stored with each sharpness score so downstream readers know how it was computed.
    static let sharpnessMethod = "meanAbsoluteNeighborGradientLuma_stride4"

    /// Estimates image sharpness from luma gradients so frames can be ranked later.
    static func sharpnessScore(lumaValues: [UInt8], width: Int, height: Int) -> Double {
        guard width > self.samplingStride,
              height > self.samplingStride,
              lumaValues.count >= width * height
        else {
            return 0
        }

        var accumulatedGradient = 0.0
        var sampleCount = 0

        for y in stride(from: 0, to: height - 1, by: self.samplingStride) {
            for x in stride(from: 0, to: width - 1, by: self.samplingStride) {
                let index = y * width + x
                let center = Double(lumaValues[index])
                let right = Double(lumaValues[index + 1])
                let bottom = Double(lumaValues[index + width])
                let horizontalGradient = abs(center - right)
                let verticalGradient = abs(center - bottom)

                accumulatedGradient += horizontalGradient + verticalGradient
                sampleCount += 1
            }
        }

        guard sampleCount > 0 else {
            return 0
        }

        return accumulatedGradient / Double(sampleCount)
    }

    // MARK: Private

    private static let samplingStride = 4
}

// MARK: - PointCloudCaptureEngine

/// Converts ARKit depth and camera frames into persisted scan artifacts.
final class PointCloudCaptureEngine {
    // MARK: Lifecycle

    /// Creates a capture engine with caller-supplied or default sampling settings.
    init(
        configuration: CaptureEngineConfiguration = CaptureEngineConfiguration(),
        previewRandomDraw: @escaping (_ upperBoundExclusive: Int) -> Int = { upperBoundExclusive in
            Int.random(in: 0 ..< upperBoundExclusive)
        }
    ) {
        self.configuration = configuration
        self.previewRandomDraw = previewRandomDraw
    }

    // MARK: Internal

    /// Active configuration used for sampling, throttling, and persistence decisions.
    let configuration: CaptureEngineConfiguration

    func start(
        projectStore: ScanProjectStore,
        existingPointCount: Int = 0,
        existingCoverageVoxels: Set<VoxelKey> = [],
        existingPreviewPoints: [CapturedPoint] = []
    ) {
        self.projectStore = projectStore
        self.seenVoxels = existingCoverageVoxels
        self.bufferedPoints.removeAll(keepingCapacity: true)
        self.previewPoints = Array(existingPreviewPoints.prefix(self.configuration.previewLimit))
        self.pendingBounds = nil
        self.totalPointCount = existingPointCount
        self.captureStartTimestamp = nil
        self.lastProcessedFrameTimestamp = 0
        self.lastKeyframeTimestamp = nil
        self.keyframeSequenceNumber = 0
    }

    /// Ingests one ARKit frame, returning `nil` when no usable depth data is available.
    func ingest(frame: ARFrame) throws -> CaptureIngestResult? {
        guard let frameData = FramePointCloudData(frame: frame) else {
            return nil
        }

        let result = try self.ingest(frameData: frameData)

        if let result {
            try self.persistKeyframeIfNeeded(
                for: frame,
                frameData: frameData,
                acceptedPointCount: result.acceptedPointCount
            )
        }

        return result
    }

    /// Ingests a prebuilt frame payload. This overload is primarily useful for deterministic tests.
    func ingest(frameData: FramePointCloudData) throws -> CaptureIngestResult? {
        guard frameData.timestamp - self.lastProcessedFrameTimestamp >= self.configuration.minimumFrameInterval else {
            return nil
        }

        self.lastProcessedFrameTimestamp = frameData.timestamp

        if self.captureStartTimestamp == nil {
            self.captureStartTimestamp = frameData.timestamp
        }

        let relativeTimestamp = frameData.timestamp - (self.captureStartTimestamp ?? frameData.timestamp)
        let intrinsics = self.scaledIntrinsics(for: frameData)

        var acceptedPoints: [CapturedPoint] = []
        var acceptedBounds: ScanBounds?

        for y in stride(from: 0, to: frameData.depthHeight, by: self.configuration.samplingStride) {
            for x in stride(from: 0, to: frameData.depthWidth, by: self.configuration.samplingStride) {
                guard let point = self.acceptedPoint(
                    depthX: x,
                    depthY: y,
                    frameData: frameData,
                    intrinsics: intrinsics,
                    relativeTimestamp: relativeTimestamp
                ) else {
                    continue
                }

                acceptedPoints.append(point)
                self.include(point.position, in: &acceptedBounds)
            }
        }

        guard !acceptedPoints.isEmpty else {
            return CaptureIngestResult(
                acceptedPointCount: 0,
                totalPointCount: self.totalPointCount,
                coverageCellCount: self.seenVoxels.count,
                previewPoints: self.previewPoints
            )
        }

        let previewStartIndex = self.totalPointCount
        self.bufferedPoints.append(contentsOf: acceptedPoints)
        self.totalPointCount += acceptedPoints.count
        self.appendToPreview(points: acceptedPoints, startingAt: previewStartIndex)

        self.mergePendingBounds(with: acceptedBounds)

        if self.bufferedPoints.count >= self.configuration.flushThreshold {
            try self.flush()
        }

        return CaptureIngestResult(
            acceptedPointCount: acceptedPoints.count,
            totalPointCount: self.totalPointCount,
            coverageCellCount: self.seenVoxels.count,
            previewPoints: self.previewPoints
        )
    }

    /// Flushes any buffered points to disk and returns the final preview subset.
    func finalize() throws -> [CapturedPoint] {
        try self.flush()
        return self.previewPoints
    }

    // MARK: Private

    private struct SampledColor {
        let red: UInt8
        let green: UInt8
        let blue: UInt8
    }

    private enum CaptureEngineError: LocalizedError {
        case keyframeImageEncodingFailed

        // MARK: Internal

        var errorDescription: String? {
            switch self {
            case .keyframeImageEncodingFailed:
                return "The scan keyframe image could not be encoded."
            }
        }
    }

    private static let keyframeCompressionQuality: CGFloat = 0.85
    private static let sceneDepthStorageLayout = "rowMajorContiguous"
    private static let sceneDepthDataFormat = "float32LittleEndian"
    private static let sceneDepthUnit = "meters"
    private static let confidenceDataFormat = "uint8ARConfidenceLevelRawValue"

    private var seenVoxels = Set<VoxelKey>()
    private var bufferedPoints: [CapturedPoint] = []
    private var previewPoints: [CapturedPoint] = []
    private var totalPointCount = 0
    private var pendingBounds: ScanBounds?
    private var captureStartTimestamp: TimeInterval?
    private var lastProcessedFrameTimestamp = 0.0
    private var lastKeyframeTimestamp: TimeInterval?
    private var keyframeSequenceNumber = 0
    private weak var projectStore: ScanProjectStore?
    private let keyframeImageContext = CIContext(options: nil)
    private let previewRandomDraw: (Int) -> Int

    /// Writes the current point buffer as the next chunk file.
    private func flush() throws {
        guard !self.bufferedPoints.isEmpty else {
            return
        }

        try self.projectStore?.append(points: self.bufferedPoints, bounds: self.pendingBounds)
        self.bufferedPoints.removeAll(keepingCapacity: true)
        self.pendingBounds = nil
    }

    /// Persists a new keyframe when enough time has passed and the frame produced accepted points.
    private func persistKeyframeIfNeeded(
        for frame: ARFrame,
        frameData: FramePointCloudData,
        acceptedPointCount: Int
    ) throws {
        guard self.shouldPersistKeyframe(frameData: frameData, acceptedPointCount: acceptedPointCount),
              let projectStore = self.projectStore
        else {
            return
        }

        let relativeTimestamp = frameData.timestamp - (self.captureStartTimestamp ?? frameData.timestamp)
        let keyframe = try self.makeKeyframe(
            from: frame,
            frameData: frameData,
            relativeTimestamp: relativeTimestamp
        )

        try projectStore.append(keyframe: keyframe)
        self.lastKeyframeTimestamp = frameData.timestamp
    }

    /// Decides whether the current frame should become a persisted RGB keyframe.
    private func shouldPersistKeyframe(frameData: FramePointCloudData, acceptedPointCount: Int) -> Bool {
        guard acceptedPointCount > 0 else {
            return false
        }

        guard let lastKeyframeTimestamp else {
            return true
        }

        return frameData.timestamp - lastKeyframeTimestamp >= self.configuration.minimumKeyframeInterval
    }

    /// Builds a persisted keyframe package containing JPEG metadata and optional depth sidecars.
    private func makeKeyframe(
        from frame: ARFrame,
        frameData: FramePointCloudData,
        relativeTimestamp: TimeInterval
    ) throws -> CapturedRGBKeyframe {
        self.keyframeSequenceNumber += 1

        let frameIdentifier = String(format: "frame-%05d", self.keyframeSequenceNumber)
        let imageFilename = "\(frameIdentifier).jpg"
        let imageData = try self.makeJPEGData(from: frame.capturedImage)
        let imageQuality = ScanRGBKeyframeImageQuality(
            sharpnessScore: KeyframeImageQualityEstimator.sharpnessScore(
                lumaValues: frameData.lumaValues,
                width: frameData.imageWidth,
                height: frameData.imageHeight
            ),
            sharpnessMethod: KeyframeImageQualityEstimator.sharpnessMethod
        )
        let photometricMetadata = self.makePhotometricMetadata(from: frame)
        let sceneDepthPayload = self.makeSceneDepthPayload(from: frameData, frameIdentifier: frameIdentifier)
        let metadata = ScanRGBKeyframe(
            frameIdentifier: frameIdentifier,
            timestamp: relativeTimestamp,
            cameraTransform: frameData.cameraTransform,
            cameraIntrinsics: frameData.intrinsics,
            imageWidth: CVPixelBufferGetWidth(frame.capturedImage),
            imageHeight: CVPixelBufferGetHeight(frame.capturedImage),
            imageFilename: imageFilename,
            imageQuality: imageQuality,
            photometricMetadata: photometricMetadata,
            sceneDepthPayload: sceneDepthPayload.metadata
        )

        return CapturedRGBKeyframe(
            metadata: metadata,
            imageData: imageData,
            sceneDepthData: sceneDepthPayload.payload
        )
    }

    /// Encodes the camera image as a JPEG for scan archiving or server-side reconstruction.
    private func makeJPEGData(from pixelBuffer: CVPixelBuffer) throws -> Data {
        let image = CIImage(cvPixelBuffer: pixelBuffer)
        let bounds = CGRect(
            x: 0,
            y: 0,
            width: CVPixelBufferGetWidth(pixelBuffer),
            height: CVPixelBufferGetHeight(pixelBuffer)
        )

        guard let cgImage = self.keyframeImageContext.createCGImage(image, from: bounds) else {
            throw CaptureEngineError.keyframeImageEncodingFailed
        }

        guard let imageData = UIImage(cgImage: cgImage).jpegData(compressionQuality: Self.keyframeCompressionQuality)
        else {
            throw CaptureEngineError.keyframeImageEncodingFailed
        }

        return imageData
    }

    /// Captures exposure and ambient-light measurements associated with a keyframe.
    private func makePhotometricMetadata(from frame: ARFrame) -> ScanRGBKeyframePhotometricMetadata {
        let lightEstimate = frame.lightEstimate

        return ScanRGBKeyframePhotometricMetadata(
            exposureDurationSeconds: frame.camera.exposureDuration,
            exposureOffsetEV: Double(frame.camera.exposureOffset),
            ambientIntensity: lightEstimate.map { Double($0.ambientIntensity) },
            ambientColorTemperatureKelvin: lightEstimate.map { Double($0.ambientColorTemperature) }
        )
    }

    /// Packages scene depth and optional confidence maps as metadata plus raw binary payloads.
    private func makeSceneDepthPayload(
        from frameData: FramePointCloudData,
        frameIdentifier: String
    ) -> (metadata: ScanSceneDepthPayload, payload: CapturedSceneDepthPayload) {
        let depthMapFilename = "\(frameIdentifier).depth-float32.bin"
        let confidenceMapFilename = frameData.confidenceValues.isEmpty
            ? nil
            : "\(frameIdentifier).confidence-u8.bin"

        let metadata = ScanSceneDepthPayload(
            source: frameData.sceneDepthSource,
            width: frameData.depthWidth,
            height: frameData.depthHeight,
            storageLayout: Self.sceneDepthStorageLayout,
            depthMapFilename: depthMapFilename,
            depthDataFormat: Self.sceneDepthDataFormat,
            depthUnit: Self.sceneDepthUnit,
            confidenceMapFilename: confidenceMapFilename,
            confidenceDataFormat: confidenceMapFilename == nil ? nil : Self.confidenceDataFormat
        )
        let payload = CapturedSceneDepthPayload(
            depthMapData: frameData.depthValues.float32LittleEndianData(),
            confidenceMapData: frameData.confidenceValues.isEmpty ? nil : Data(frameData.confidenceValues)
        )

        return (metadata, payload)
    }

    /// Maintains a bounded preview reservoir so the sample stays representative across the full scan.
    private func appendToPreview(points: [CapturedPoint], startingAt pointIndex: Int) {
        guard self.configuration.previewLimit > 0 else { return }
        var pointIndex = pointIndex

        for point in points {
            if self.previewPoints.count < self.configuration.previewLimit {
                self.previewPoints.append(point)
            } else {
                let replacementIndex = self.previewRandomDraw(pointIndex + 1)
                if replacementIndex < self.configuration.previewLimit {
                    self.previewPoints[replacementIndex] = point
                }
            }

            pointIndex += 1
        }
    }

    /// Converts one depth pixel into a colored world-space point when it passes all filters.
    private func acceptedPoint(
        depthX: Int,
        depthY: Int,
        frameData: FramePointCloudData,
        intrinsics: simd_float3x3,
        relativeTimestamp: TimeInterval
    ) -> CapturedPoint? {
        let index = depthY * frameData.depthWidth + depthX
        let depth = frameData.depthValues[index]

        guard depth.isFinite,
              depth >= self.configuration.minimumDepthMeters,
              depth <= self.configuration.maximumDepthMeters,
              let confidence = self.acceptedConfidence(at: index, frameData: frameData)
        else {
            return nil
        }

        let cameraPoint = self.unproject(
            pixelX: Float(depthX),
            pixelY: Float(depthY),
            depth: depth,
            intrinsics: intrinsics
        )
        let worldPoint = self.worldPosition(cameraPoint, transform: frameData.cameraTransform)
        let voxel = VoxelKey(position: worldPoint, voxelSize: self.configuration.voxelSizeMeters)
        self.seenVoxels.insert(voxel)

        let color = self.sampleColor(
            depthX: depthX,
            depthY: depthY,
            frameData: frameData
        )
        return CapturedPoint(
            position: worldPoint,
            red: color.red,
            green: color.green,
            blue: color.blue,
            confidence: confidence,
            timestamp: relativeTimestamp
        )
    }

    /// Returns the accepted confidence value for a depth sample, or `nil` when it should be dropped.
    private func acceptedConfidence(at index: Int, frameData: FramePointCloudData) -> UInt8? {
        guard !frameData.confidenceValues.isEmpty else {
            return self.configuration.minimumConfidence
        }

        let confidence = frameData.confidenceValues[index]
        guard confidence >= self.configuration.minimumConfidence else {
            return nil
        }

        return confidence
    }

    private func include(_ point: SIMD3<Float>, in bounds: inout ScanBounds?) {
        if var currentBounds = bounds {
            currentBounds.include(point)
            bounds = currentBounds
        } else {
            bounds = ScanBounds(point: point)
        }
    }

    private func mergePendingBounds(with acceptedBounds: ScanBounds?) {
        guard let acceptedBounds else {
            return
        }

        if var pendingBounds = self.pendingBounds {
            pendingBounds.merge(acceptedBounds)
            self.pendingBounds = pendingBounds
        } else {
            self.pendingBounds = acceptedBounds
        }
    }

    /// Scales camera intrinsics from RGB image resolution into depth-map resolution.
    private func scaledIntrinsics(for frameData: FramePointCloudData) -> simd_float3x3 {
        let scaleX = Float(frameData.depthWidth) / Float(frameData.imageWidth)
        let scaleY = Float(frameData.depthHeight) / Float(frameData.imageHeight)

        var intrinsics = frameData.intrinsics
        intrinsics[0, 0] *= scaleX
        intrinsics[1, 1] *= scaleY
        intrinsics[2, 0] *= scaleX
        intrinsics[2, 1] *= scaleY
        return intrinsics
    }

    /// Unprojects one depth sample from image space into camera-local 3D coordinates.
    private func unproject(pixelX: Float, pixelY: Float, depth: Float, intrinsics: simd_float3x3) -> SIMD3<Float> {
        let fx = intrinsics[0, 0]
        let fy = intrinsics[1, 1]
        let cx = intrinsics[2, 0]
        let cy = intrinsics[2, 1]

        let cameraX = (pixelX - cx) * depth / fx
        let cameraY = -((pixelY - cy) * depth / fy)
        let cameraZ = -depth

        return SIMD3(cameraX, cameraY, cameraZ)
    }

    /// Applies the camera transform to a camera-local point to obtain world coordinates.
    private func worldPosition(_ cameraPoint: SIMD3<Float>, transform: simd_float4x4) -> SIMD3<Float> {
        let homogeneous = SIMD4<Float>(cameraPoint.x, cameraPoint.y, cameraPoint.z, 1)
        let world = transform * homogeneous
        return SIMD3(world.x, world.y, world.z)
    }

    /// Samples RGB values from the camera image for the supplied depth pixel.
    private func sampleColor(
        depthX: Int,
        depthY: Int,
        frameData: FramePointCloudData
    ) -> SampledColor {
        let normalizedX = (Float(depthX) + 0.5) / Float(frameData.depthWidth)
        let normalizedY = (Float(depthY) + 0.5) / Float(frameData.depthHeight)
        let imageX = min(frameData.imageWidth - 1, max(0, Int(normalizedX * Float(frameData.imageWidth - 1))))
        let imageY = min(frameData.imageHeight - 1, max(0, Int(normalizedY * Float(frameData.imageHeight - 1))))
        let lumaIndex = imageY * frameData.imageWidth + imageX

        let chromaX = min(frameData.chromaWidth - 1, max(0, imageX / 2))
        let chromaY = min(frameData.chromaHeight - 1, max(0, imageY / 2))
        let chromaIndex = (chromaY * frameData.chromaWidth + chromaX) * 2

        let conversion = frameData.imageColorConversion
        let yComponent = Double(frameData.lumaValues[lumaIndex])
        let cb = Double(frameData.chromaValues[chromaIndex]) - 128.0
        let cr = Double(frameData.chromaValues[chromaIndex + 1]) - 128.0
        let adjustedLuma = conversion.lumaScale * (yComponent - conversion.lumaOffset)

        let red = adjustedLuma + conversion.redCrScale * cr
        let green = adjustedLuma - conversion.greenCbScale * cb - conversion.greenCrScale * cr
        let blue = adjustedLuma + conversion.blueCbScale * cb

        return SampledColor(
            red: self.clampColor(red),
            green: self.clampColor(green),
            blue: self.clampColor(blue)
        )
    }

    /// Clamps a floating-point color channel into an 8-bit integer.
    private func clampColor(_ value: Double) -> UInt8 {
        UInt8(max(0, min(255, Int(value.rounded()))))
    }
}

private extension FramePointCloudData {
    /// Extracts depth, confidence, color planes, camera intrinsics, and timing from an ARKit frame.
    init?(frame: ARFrame) {
        let depthSource: ARDepthData
        let sceneDepthSource: SceneDepthSource

        if let sceneDepth = frame.sceneDepth {
            depthSource = sceneDepth
            sceneDepthSource = .sceneDepth
        } else if let smoothedSceneDepth = frame.smoothedSceneDepth {
            depthSource = smoothedSceneDepth
            sceneDepthSource = .smoothedSceneDepth
        } else {
            return nil
        }

        let depthMap = depthSource.depthMap
        let confidenceMap = depthSource.confidenceMap
        let capturedImage = frame.capturedImage
        let imageColorRange = CapturedImageColorRange(capturedImage: capturedImage)
        let imageYCbCrMatrix = CapturedImageYCbCrMatrix(capturedImage: capturedImage)

        CVPixelBufferLockBaseAddress(depthMap, .readOnly)
        CVPixelBufferLockBaseAddress(capturedImage, .readOnly)

        if let confidenceMap {
            CVPixelBufferLockBaseAddress(confidenceMap, .readOnly)
        }

        defer {
            CVPixelBufferUnlockBaseAddress(capturedImage, .readOnly)
            if let confidenceMap {
                CVPixelBufferUnlockBaseAddress(confidenceMap, .readOnly)
            }
            CVPixelBufferUnlockBaseAddress(depthMap, .readOnly)
        }

        let depthWidth = CVPixelBufferGetWidth(depthMap)
        let depthHeight = CVPixelBufferGetHeight(depthMap)
        let depthBytesPerRow = CVPixelBufferGetBytesPerRow(depthMap) / MemoryLayout<Float32>.stride
        let imageWidth = CVPixelBufferGetWidthOfPlane(capturedImage, 0)
        let imageHeight = CVPixelBufferGetHeightOfPlane(capturedImage, 0)
        let chromaWidth = CVPixelBufferGetWidthOfPlane(capturedImage, 1)
        let chromaHeight = CVPixelBufferGetHeightOfPlane(capturedImage, 1)
        let lumaBytesPerRow = CVPixelBufferGetBytesPerRowOfPlane(capturedImage, 0)
        let chromaBytesPerRow = CVPixelBufferGetBytesPerRowOfPlane(capturedImage, 1)

        guard let depthBaseAddress = CVPixelBufferGetBaseAddress(depthMap),
              let lumaBaseAddress = CVPixelBufferGetBaseAddressOfPlane(capturedImage, 0),
              let chromaBaseAddress = CVPixelBufferGetBaseAddressOfPlane(capturedImage, 1)
        else {
            return nil
        }

        let depthPointer = depthBaseAddress.assumingMemoryBound(to: Float32.self)
        let lumaPointer = lumaBaseAddress.assumingMemoryBound(to: UInt8.self)
        let chromaPointer = chromaBaseAddress.assumingMemoryBound(to: UInt8.self)

        var depthValues = [Float]()
        depthValues.reserveCapacity(depthWidth * depthHeight)

        for row in 0 ..< depthHeight {
            let rowStart = depthPointer.advanced(by: row * depthBytesPerRow)
            depthValues.append(contentsOf: UnsafeBufferPointer(start: rowStart, count: depthWidth))
        }

        var confidenceValues = [UInt8]()
        if let confidenceMap, let confidenceBaseAddress = CVPixelBufferGetBaseAddress(confidenceMap) {
            let confidencePointer = confidenceBaseAddress.assumingMemoryBound(to: UInt8.self)
            let confidenceBytesPerRow = CVPixelBufferGetBytesPerRow(confidenceMap)
            confidenceValues.reserveCapacity(depthWidth * depthHeight)

            for row in 0 ..< depthHeight {
                let rowStart = confidencePointer.advanced(by: row * confidenceBytesPerRow)
                confidenceValues.append(contentsOf: UnsafeBufferPointer(start: rowStart, count: depthWidth))
            }
        }

        var lumaValues = [UInt8]()
        lumaValues.reserveCapacity(imageWidth * imageHeight)

        for row in 0 ..< imageHeight {
            let rowStart = lumaPointer.advanced(by: row * lumaBytesPerRow)
            lumaValues.append(contentsOf: UnsafeBufferPointer(start: rowStart, count: imageWidth))
        }

        var chromaValues = [UInt8]()
        chromaValues.reserveCapacity(chromaWidth * chromaHeight * 2)

        for row in 0 ..< chromaHeight {
            let rowStart = chromaPointer.advanced(by: row * chromaBytesPerRow)
            chromaValues.append(contentsOf: UnsafeBufferPointer(start: rowStart, count: chromaWidth * 2))
        }

        self.init(
            depthWidth: depthWidth,
            depthHeight: depthHeight,
            depthValues: depthValues,
            confidenceValues: confidenceValues,
            imageWidth: imageWidth,
            imageHeight: imageHeight,
            lumaValues: lumaValues,
            chromaWidth: chromaWidth,
            chromaHeight: chromaHeight,
            chromaValues: chromaValues,
            imageColorRange: imageColorRange,
            imageYCbCrMatrix: imageYCbCrMatrix,
            intrinsics: frame.camera.intrinsics,
            cameraTransform: frame.camera.transform,
            timestamp: frame.timestamp,
            sceneDepthSource: sceneDepthSource
        )
    }
}
