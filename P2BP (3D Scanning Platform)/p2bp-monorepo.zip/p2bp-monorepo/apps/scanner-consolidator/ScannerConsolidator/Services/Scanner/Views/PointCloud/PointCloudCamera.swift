import simd

// MARK: - PointCloudCameraBasis

nonisolated struct PointCloudCameraBasis {
    let right: SIMD3<Float>
    let up: SIMD3<Float>
    let forward: SIMD3<Float>
}

// MARK: - PointCloudOrbitCamera

/// Spherical orbit camera for a z-up point cloud. Pure math; safe off the main actor.
nonisolated struct PointCloudOrbitCamera {
    static let minimumElevation: Float = -1.5
    static let maximumElevation: Float = 1.53
    /// Just shy of straight down so the view basis never degenerates.
    static let topDownElevation: Float = .pi / 2 - 0.012

    var target: SIMD3<Float>
    var azimuthRadians: Float
    var elevationRadians: Float
    var distance: Float
    var minimumDistance: Float
    var maximumDistance: Float

    var eye: SIMD3<Float> {
        let cosElevation = cos(self.elevationRadians)
        let direction = SIMD3<Float>(
            cosElevation * cos(self.azimuthRadians),
            cosElevation * sin(self.azimuthRadians),
            sin(self.elevationRadians)
        )
        return self.target + direction * self.distance
    }

    /// Right/up/forward basis; the right vector stays well-defined at the poles.
    var basis: PointCloudCameraBasis {
        let forward = simd_normalize(self.target - self.eye)
        let right = SIMD3<Float>(-sin(self.azimuthRadians), cos(self.azimuthRadians), 0)
        let up = simd_normalize(simd_cross(right, forward))
        return PointCloudCameraBasis(right: right, up: up, forward: forward)
    }

    var viewMatrix: simd_float4x4 {
        let basis = self.basis
        let right = basis.right
        let up = basis.up
        let forward = basis.forward
        let eye = self.eye
        return simd_float4x4(columns: (
            SIMD4(right.x, up.x, -forward.x, 0),
            SIMD4(right.y, up.y, -forward.y, 0),
            SIMD4(right.z, up.z, -forward.z, 0),
            SIMD4(
                -simd_dot(right, eye),
                -simd_dot(up, eye),
                simd_dot(forward, eye),
                1
            )
        ))
    }

    mutating func orbit(deltaAzimuth: Float, deltaElevation: Float) {
        self.azimuthRadians -= deltaAzimuth
        self.elevationRadians = min(
            max(self.elevationRadians + deltaElevation, Self.minimumElevation),
            Self.maximumElevation
        )
    }

    mutating func pan(screenRight: Float, screenDown: Float) {
        let basis = self.basis
        let scale = self.distance * 0.0016
        self.target -= basis.right * screenRight * scale
        self.target += basis.up * screenDown * scale
    }

    mutating func zoom(byFactor factor: Float) {
        guard factor > 0 else { return }
        self.distance = min(max(self.distance / factor, self.minimumDistance), self.maximumDistance)
    }
}

// MARK: - PointCloudProjection

/// Projection helpers using Metal's [0, 1] clip-space depth convention.
nonisolated enum PointCloudProjection {
    static func perspective(fovYRadians: Float, aspect: Float, nearZ: Float, farZ: Float) -> simd_float4x4 {
        let yScale = 1 / tan(fovYRadians * 0.5)
        let xScale = yScale / max(aspect, 0.0001)
        let zScale = farZ / (nearZ - farZ)
        return simd_float4x4(columns: (
            SIMD4(xScale, 0, 0, 0),
            SIMD4(0, yScale, 0, 0),
            SIMD4(0, 0, zScale, -1),
            SIMD4(0, 0, farZ * nearZ / (nearZ - farZ), 0)
        ))
    }

    static func orthographic(halfWidth: Float, halfHeight: Float, nearZ: Float, farZ: Float) -> simd_float4x4 {
        let depthRange = nearZ - farZ
        return simd_float4x4(columns: (
            SIMD4(1 / max(halfWidth, 0.0001), 0, 0, 0),
            SIMD4(0, 1 / max(halfHeight, 0.0001), 0, 0),
            SIMD4(0, 0, 1 / depthRange, 0),
            SIMD4(0, 0, nearZ / depthRange, 1)
        ))
    }

    /// Element-wise blend used to animate between perspective and orthographic framing.
    static func blend(_ from: simd_float4x4, _ to: simd_float4x4, amount: Float) -> simd_float4x4 {
        let clamped = min(max(amount, 0), 1)
        return simd_float4x4(columns: (
            simd_mix(from.columns.0, to.columns.0, SIMD4(repeating: clamped)),
            simd_mix(from.columns.1, to.columns.1, SIMD4(repeating: clamped)),
            simd_mix(from.columns.2, to.columns.2, SIMD4(repeating: clamped)),
            simd_mix(from.columns.3, to.columns.3, SIMD4(repeating: clamped))
        ))
    }
}
