import ARKit
import Foundation

// MARK: - ScanSessionController Capture Health

extension ScanSessionController {
    /// Clears the short-term progress window so health guidance does not react to stale samples.
    func resetCaptureHealthProgressTracking(at timestamp: TimeInterval? = nil) {
        self.recentCaptureProgress = nil

        if let timestamp {
            self.captureHealthBaseline = ScanCaptureHealthBaseline(
                timestamp: timestamp,
                pointCount: self.pointCount,
                coverageCellCount: self.coverageCellCount,
                meshAnchorCount: self.meshAnchorCount
            )
            self.lastMeaningfulCaptureProgressTimestamp = timestamp
        } else {
            self.captureHealthBaseline = nil
            self.lastMeaningfulCaptureProgressTimestamp = nil
        }
    }

    /// Re-evaluates capture guidance from the current phase, tracking signal, and recent scan growth.
    func refreshCaptureHealth(frameTimestamp: TimeInterval? = nil) {
        let resolvedCaptureHealth = self.resolvedCaptureHealth(frameTimestamp: frameTimestamp)
        guard resolvedCaptureHealth != self.captureHealth else {
            return
        }

        self.captureHealth = resolvedCaptureHealth
    }

    /// Updates the lightweight progress window used for stable-tracking health guidance.
    private func evaluateCaptureProgress(at frameTimestamp: TimeInterval) {
        guard let baseline = self.captureHealthBaseline else {
            self.captureHealthBaseline = ScanCaptureHealthBaseline(
                timestamp: frameTimestamp,
                pointCount: self.pointCount,
                coverageCellCount: self.coverageCellCount,
                meshAnchorCount: self.meshAnchorCount
            )
            self.lastMeaningfulCaptureProgressTimestamp =
                self.lastMeaningfulCaptureProgressTimestamp ?? frameTimestamp
            return
        }

        guard frameTimestamp - baseline.timestamp >= ScanCaptureHealthThresholds.evaluationInterval else {
            return
        }

        let progress = ScanCaptureHealthProgress(
            pointDelta: self.pointCount - baseline.pointCount,
            coverageCellDelta: self.coverageCellCount - baseline.coverageCellCount,
            meshAnchorDelta: self.meshAnchorCount - baseline.meshAnchorCount
        )
        self.recentCaptureProgress = progress
        self.captureHealthBaseline = ScanCaptureHealthBaseline(
            timestamp: frameTimestamp,
            pointCount: self.pointCount,
            coverageCellCount: self.coverageCellCount,
            meshAnchorCount: self.meshAnchorCount
        )

        if progress.pointDelta >= 800 || progress.coverageCellDelta >= 6 || progress.meshAnchorDelta > 0 {
            self.lastMeaningfulCaptureProgressTimestamp = frameTimestamp
        }
    }

    /// Builds the compact operator-guidance state used by the live scanner HUD.
    private func resolvedCaptureHealth(frameTimestamp: TimeInterval?) -> CaptureHealth {
        ScanCaptureHealthEvaluator.captureHealth(
            from: self.captureHealthSnapshot(frameTimestamp: frameTimestamp)
        )
    }

    /// Collects the current capture signals into a lightweight health snapshot for HUD guidance.
    private func captureHealthSnapshot(frameTimestamp: TimeInterval?) -> ScanCaptureHealthSnapshot {
        let stableTrackingTimestamp = self.stableTrackingTimestamp(frameTimestamp: frameTimestamp)

        if self.phase == .capturing, !self.isCapturePaused, let stableTrackingTimestamp {
            if case .normal? = self.latestTrackingState {
                self.evaluateCaptureProgress(at: stableTrackingTimestamp)
            }
        }

        let timeSinceMeaningfulProgress = stableTrackingTimestamp.map {
            $0 - (self.lastMeaningfulCaptureProgressTimestamp ?? $0)
        }

        return ScanCaptureHealthSnapshot(
            phase: self.phase,
            isCapturePaused: self.isCapturePaused,
            currentLocationAvailable: self.currentLocation != nil,
            locationStatusText: self.locationStatusText,
            pointCount: self.pointCount,
            meshAnchorCount: self.meshAnchorCount,
            elapsedTime: self.elapsedTime,
            statusMessage: self.statusMessage,
            trackingStatusText: self.trackingStatusText,
            latestTrackingState: self.latestTrackingState,
            currentManifestPointCount: self.currentManifest?.pointCount,
            recentProgress: self.recentCaptureProgress,
            timeSinceMeaningfulProgress: timeSinceMeaningfulProgress
        )
    }

    /// Resolves the timestamp used when evaluating steady-state capture growth.
    private func stableTrackingTimestamp(frameTimestamp: TimeInterval?) -> TimeInterval? {
        frameTimestamp
            ?? self.sceneView?.session.currentFrame?.timestamp
            ?? self.lastMeaningfulCaptureProgressTimestamp
    }
}
