import Foundation

// MARK: - ScanProjectStoreError

/// Errors raised while opening or mutating persisted `.scanproject` bundles.
enum ScanProjectStoreError: LocalizedError {
    case invalidPreviewData
    case projectUnavailable

    // MARK: Internal

    var errorDescription: String? {
        switch self {
        case .invalidPreviewData:
            return "The point cloud preview data is invalid."
        case .projectUnavailable:
            return "The scan project could not be found on disk."
        }
    }
}

// MARK: - ScanProjectStore

/// Reads and writes the on-disk files that make up a captured scan project.
final class ScanProjectStore {
    // MARK: Lifecycle

    /// Creates a store rooted either in Application Support or a caller-supplied directory.
    init(fileManager: FileManager = .default, rootDirectory: URL? = nil) {
        self.fileManager = fileManager

        if let rootDirectory {
            self.rootDirectory = rootDirectory
        } else {
            let applicationSupport = fileManager.urls(for: .applicationSupportDirectory, in: .userDomainMask).first
                ?? fileManager.temporaryDirectory
            self.rootDirectory = applicationSupport
                .appendingPathComponent("Scans", isDirectory: true)
        }
    }

    // MARK: Internal

    /// Manifest for the currently open scan project, if one is active.
    private(set) var currentManifest: ScanProjectManifest?
    /// Directory for the currently open `.scanproject` bundle.
    private(set) var currentProjectDirectory: URL?

    /// Creates a fresh `.scanproject` directory and seeds its initial metadata files.
    func startProject(
        voxelSizeMeters: Float,
        geoReference: GeoReference?,
        approximateGeoreferencing: Bool
    ) throws -> ScanProjectManifest {
        try self.fileManager.createDirectory(at: self.rootDirectory, withIntermediateDirectories: true, attributes: nil)

        let identifier = UUID()
        let projectDirectory = self.rootDirectory.appendingPathComponent(
            "\(identifier.uuidString).scanproject",
            isDirectory: true
        )
        try self.fileManager.createDirectory(at: projectDirectory, withIntermediateDirectories: true, attributes: nil)

        let manifest = ScanProjectManifest(
            id: identifier,
            createdAt: .now,
            updatedAt: .now,
            state: .capturing,
            pointCount: 0,
            chunkCount: 0,
            voxelSizeMeters: voxelSizeMeters,
            approximateGeoreferencing: approximateGeoreferencing,
            geoReference: geoReference,
            bounds: nil,
            keyframeCount: 0,
            meshAnchorCount: 0
        )

        self.currentKeyframes = []
        self.currentTrajectory = ScanTrajectory()
        self.currentMeshAnchorCatalog = ScanMeshAnchorCatalog()
        self.currentManifest = manifest
        self.currentProjectDirectory = projectDirectory
        try self.persistManifest()
        try self.persistTrajectory(self.currentTrajectory, in: projectDirectory)
        try self.persistMeshAnchorCatalog(self.currentMeshAnchorCatalog, in: projectDirectory)
        return manifest
    }

    /// Opens an existing `.scanproject` directory and restores its in-memory metadata caches.
    func openProject(id: UUID) throws -> ScanProjectManifest {
        let projectDirectory = self.rootDirectory.appendingPathComponent(
            "\(id.uuidString).scanproject",
            isDirectory: true
        )
        let manifestURL = projectDirectory.appendingPathComponent("manifest.json")

        guard self.fileManager.fileExists(atPath: manifestURL.path) else {
            throw ScanProjectStoreError.projectUnavailable
        }

        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601

        let manifestData = try Data(contentsOf: manifestURL)
        let manifest = try decoder.decode(ScanProjectManifest.self, from: manifestData)

        self.currentManifest = manifest
        self.currentProjectDirectory = projectDirectory
        self.currentKeyframes = try self.readKeyframes(from: projectDirectory)
        self.currentTrajectory = try self.readTrajectory(from: projectDirectory)
        self.currentMeshAnchorCatalog = try self.readMeshAnchorCatalog(from: projectDirectory)
        return manifest
    }

    /// Removes a persisted `.scanproject` bundle and clears in-memory caches if it is active.
    func deleteProject(id: UUID) throws {
        let projectDirectory = self.projectDirectory(for: id)

        // clearing in mem-cache
        if self.currentManifest?.id == id {
            self.currentManifest = nil
            self.currentProjectDirectory = nil
            self.currentKeyframes = []
            self.currentTrajectory = ScanTrajectory()
            self.currentMeshAnchorCatalog = ScanMeshAnchorCatalog()
        }

        // if folder exists, delete, else return
        guard self.fileManager.fileExists(atPath: projectDirectory.path) else {
            return
        }

        try self.fileManager.removeItem(at: projectDirectory)
    }

    func projectDirectory(for id: UUID) -> URL {
        self.rootDirectory.appendingPathComponent(
            "\(id.uuidString).scanproject",
            isDirectory: true
        )
    }

    func hasPreview(id: UUID) -> Bool {
        self.fileManager.fileExists(atPath: self.projectDirectory(for: id).appendingPathComponent("preview.bin").path)
    }

    @discardableResult
    func storePreviewProject(id: UUID, previewData: Data) throws -> ScanProjectManifest {
        guard previewData.count.isMultiple(of: CapturedPoint.binaryRecordSize) else {
            throw ScanProjectStoreError.invalidPreviewData
        }

        try self.fileManager.createDirectory(at: self.rootDirectory, withIntermediateDirectories: true, attributes: nil)

        let projectDirectory = self.projectDirectory(for: id)
        let stagingDirectory = self.rootDirectory.appendingPathComponent(".\(UUID().uuidString).scanproject")
        defer { try? self.removeItemIfExists(at: stagingDirectory) }
        try self.fileManager.createDirectory(at: stagingDirectory, withIntermediateDirectories: true, attributes: nil)
        try previewData.write(to: stagingDirectory.appendingPathComponent("preview.bin"), options: .atomic)

        let previewPointCount = previewData.count / CapturedPoint.binaryRecordSize
        let manifest = ScanProjectManifest(
            id: id,
            createdAt: .now,
            updatedAt: .now,
            state: .completed,
            pointCount: previewPointCount,
            chunkCount: 0,
            voxelSizeMeters: 0.03,
            approximateGeoreferencing: true,
            geoReference: nil,
            bounds: nil,
            keyframeCount: 0,
            meshAnchorCount: 0
        )
        let encoder = JSONEncoder()
        encoder.dateEncodingStrategy = .iso8601
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        let manifestURL = stagingDirectory.appendingPathComponent("manifest.json")
        try encoder.encode(manifest).write(to: manifestURL, options: .atomic)
        if self.fileManager.fileExists(atPath: projectDirectory.path) {
            _ = try self.fileManager.replaceItemAt(projectDirectory, withItemAt: stagingDirectory)
        } else {
            try self.fileManager.moveItem(at: stagingDirectory, to: projectDirectory)
        }
        return manifest
    }

    @discardableResult
    func replaceProjectWithPreviewOnly(id: UUID, previewID: UUID) throws -> ScanProjectManifest {
        let sourceURL = self.projectDirectory(for: id)
        let previewURL = sourceURL.appendingPathComponent("preview.bin")
        guard self.fileManager.fileExists(atPath: previewURL.path) else {
            throw ScanProjectStoreError.projectUnavailable
        }

        let previewData = try Data(contentsOf: previewURL)
        let manifest = try self.storePreviewProject(id: previewID, previewData: previewData)
        if id != previewID {
            try self.removeItemIfExists(at: sourceURL)
        }
        if self.currentManifest?.id == id {
            self.currentManifest = manifest
            self.currentProjectDirectory = self.projectDirectory(for: previewID)
            self.currentKeyframes = []
            self.currentTrajectory = ScanTrajectory()
            self.currentMeshAnchorCatalog = ScanMeshAnchorCatalog()
        }
        return manifest
    }

    /// Appends one chunk of captured points and merges updated bounds into the manifest.
    func append(points: [CapturedPoint], bounds: ScanBounds?) throws {
        guard !points.isEmpty, var manifest = currentManifest, let projectDirectory = currentProjectDirectory else {
            return
        }

        let chunkURL = projectDirectory.appendingPathComponent(String(
            format: "chunk-%05d.bin",
            manifest.chunkCount + 1
        ))
        try points.binaryData().write(to: chunkURL, options: .atomic)

        manifest.pointCount += points.count
        manifest.chunkCount += 1
        manifest.updatedAt = .now

        if let bounds {
            if var existingBounds = manifest.bounds {
                existingBounds.merge(bounds)
                manifest.bounds = existingBounds
            } else {
                manifest.bounds = bounds
            }
        }

        self.currentManifest = manifest
        try self.persistManifest()
    }

    /// Persists a keyframe image, optional depth payloads, and its JSON metadata entry.
    func append(keyframe: CapturedRGBKeyframe) throws {
        guard var manifest = currentManifest, let projectDirectory = currentProjectDirectory else {
            return
        }

        let keyframeDirectory = self.keyframesDirectoryURL(in: projectDirectory)
        try self.fileManager.createDirectory(at: keyframeDirectory, withIntermediateDirectories: true, attributes: nil)

        let imageURL = keyframeDirectory.appendingPathComponent(keyframe.metadata.imageFilename)
        try keyframe.imageData.write(to: imageURL, options: .atomic)

        if let sceneDepthPayload = keyframe.metadata.sceneDepthPayload, let sceneDepthData = keyframe.sceneDepthData {
            let depthMapURL = keyframeDirectory.appendingPathComponent(sceneDepthPayload.depthMapFilename)
            try sceneDepthData.depthMapData.write(to: depthMapURL, options: .atomic)

            if let confidenceMapFilename = sceneDepthPayload.confidenceMapFilename {
                if let confidenceMapData = sceneDepthData.confidenceMapData {
                    let confidenceMapURL = keyframeDirectory.appendingPathComponent(confidenceMapFilename)
                    try confidenceMapData.write(to: confidenceMapURL, options: .atomic)
                }
            }
        }

        var updatedKeyframes = self.currentKeyframes
        updatedKeyframes.append(keyframe.metadata)

        manifest.keyframeCount = updatedKeyframes.count
        manifest.updatedAt = .now

        try self.persistKeyframes(updatedKeyframes, in: projectDirectory)

        self.currentKeyframes = updatedKeyframes
        self.currentManifest = manifest
        try self.persistManifest()
    }

    /// Adds one GPS trajectory sample to `trajectory.json`.
    func append(locationSample: ScanLocationTrajectorySample) throws {
        guard let projectDirectory = currentProjectDirectory else {
            return
        }

        var updatedTrajectory = self.currentTrajectory
        updatedTrajectory.locationSamples.append(locationSample)
        try self.persistTrajectory(updatedTrajectory, in: projectDirectory)
        self.currentTrajectory = updatedTrajectory
    }

    /// Adds one heading trajectory sample to `trajectory.json`.
    func append(headingSample: ScanHeadingTrajectorySample) throws {
        guard let projectDirectory = currentProjectDirectory else {
            return
        }

        var updatedTrajectory = self.currentTrajectory
        updatedTrajectory.headingSamples.append(headingSample)
        try self.persistTrajectory(updatedTrajectory, in: projectDirectory)
        self.currentTrajectory = updatedTrajectory
    }

    /// Inserts or replaces mesh anchor artifacts using stable per-anchor filenames.
    func upsert(meshAnchors: [CapturedMeshAnchor]) throws {
        guard !meshAnchors.isEmpty,
              var manifest = currentManifest,
              let projectDirectory = currentProjectDirectory
        else {
            return
        }

        let meshAnchorsDirectory = self.meshAnchorsDirectoryURL(in: projectDirectory)
        try self.fileManager.createDirectory(
            at: meshAnchorsDirectory,
            withIntermediateDirectories: true,
            attributes: nil
        )

        var updatedCatalog = self.currentMeshAnchorCatalog
        updatedCatalog.formatVersion = 2

        for meshAnchor in meshAnchors {
            try meshAnchor.verticesData.write(
                to: meshAnchorsDirectory.appendingPathComponent(meshAnchor.metadata.verticesFilename),
                options: .atomic
            )
            try meshAnchor.faceVertexIndexData.write(
                to: meshAnchorsDirectory.appendingPathComponent(meshAnchor.metadata.faceVertexIndicesFilename),
                options: .atomic
            )
            try self.persistVertexNormals(for: meshAnchor, in: meshAnchorsDirectory)

            if let faceClassificationFilename = meshAnchor.metadata.faceClassificationFilename {
                if let faceClassificationData = meshAnchor.faceClassificationData {
                    try faceClassificationData.write(
                        to: meshAnchorsDirectory.appendingPathComponent(faceClassificationFilename),
                        options: .atomic
                    )
                }
            }

            if let previousRecord = updatedCatalog.anchors.first(where: {
                $0.anchorIdentifier == meshAnchor.metadata.anchorIdentifier
            }) {
                let previousClassificationFilename = previousRecord.faceClassificationFilename
                try self.removeReplacedVertexNormals(
                    previousRecord: previousRecord,
                    currentRecord: meshAnchor.metadata,
                    from: meshAnchorsDirectory
                )
                if previousRecord.faceClassificationFilename != meshAnchor.metadata.faceClassificationFilename {
                    if let previousClassificationFilename {
                        try self.removeItemIfExists(
                            at: meshAnchorsDirectory.appendingPathComponent(previousClassificationFilename)
                        )
                    }
                }
            }

            if let index = updatedCatalog.anchors.firstIndex(where: {
                $0.anchorIdentifier == meshAnchor.metadata.anchorIdentifier
            }) {
                updatedCatalog.anchors[index] = meshAnchor.metadata
            } else {
                updatedCatalog.anchors.append(meshAnchor.metadata)
            }
        }

        updatedCatalog.anchors.sort { $0.anchorIdentifier < $1.anchorIdentifier }

        manifest.meshAnchorCount = updatedCatalog.anchors.count
        manifest.updatedAt = .now

        try self.persistMeshAnchorCatalog(updatedCatalog, in: projectDirectory)

        self.currentMeshAnchorCatalog = updatedCatalog
        self.currentManifest = manifest
        try self.persistManifest()
    }

    /// Writes the final preview subset and marks the project with its terminal capture state.
    func finalize(
        previewPoints: [CapturedPoint],
        state: ScanProjectManifest.CaptureState
    ) throws -> ScanProjectManifest {
        guard var manifest = currentManifest, let projectDirectory = currentProjectDirectory else {
            throw ScanProjectStoreError.projectUnavailable
        }

        let previewURL = projectDirectory.appendingPathComponent("preview.bin")
        try previewPoints.binaryData().write(to: previewURL, options: .atomic)

        manifest.state = state
        manifest.keyframeCount = self.currentKeyframes.count
        manifest.meshAnchorCount = self.currentMeshAnchorCatalog.anchors.count
        manifest.updatedAt = .now
        self.currentManifest = manifest
        try self.persistManifest()
        return manifest
    }

    /// Loads a limited preview set, preferring the persisted preview file when present.
    func loadPreviewPoints(limit: Int, manifest: ScanProjectManifest? = nil) throws -> [CapturedPoint] {
        let activeManifest = manifest ?? self.currentManifest
        let projectDirectory = try resolveProjectDirectory(for: activeManifest)
        let previewURL = projectDirectory.appendingPathComponent("preview.bin")

        if self.fileManager.fileExists(atPath: previewURL.path) {
            let previewData = try Data(contentsOf: previewURL)
            return Array([CapturedPoint](binaryData: previewData).prefix(limit))
        }

        var previewPoints: [CapturedPoint] = []
        try enumeratePoints(from: activeManifest) { points in
            let remaining = max(0, limit - previewPoints.count)
            guard remaining > 0 else {
                return
            }

            previewPoints.append(contentsOf: points.prefix(remaining))
        }

        return previewPoints
    }

    /// Iterates through all persisted point chunks for a project in chunk order.
    func enumeratePoints(
        from manifest: ScanProjectManifest? = nil,
        body: ([CapturedPoint]) throws -> Void
    ) throws {
        let activeManifest = manifest ?? self.currentManifest
        let projectDirectory = try resolveProjectDirectory(for: activeManifest)
        guard (activeManifest?.chunkCount ?? 0) > 0 else { return }

        for index in 1 ... (activeManifest?.chunkCount ?? 0) {
            let chunkURL = projectDirectory.appendingPathComponent(String(format: "chunk-%05d.bin", index))
            let data = try Data(contentsOf: chunkURL)
            try body([CapturedPoint](binaryData: data))
        }
    }

    // MARK: Private

    private let fileManager: FileManager
    private let rootDirectory: URL
    private var currentKeyframes: [ScanRGBKeyframe] = []
    private var currentTrajectory = ScanTrajectory()
    private var currentMeshAnchorCatalog = ScanMeshAnchorCatalog()

    private func persistVertexNormals(for meshAnchor: CapturedMeshAnchor, in directory: URL) throws {
        guard let filename = meshAnchor.metadata.vertexNormalsFilename,
              let data = meshAnchor.vertexNormalsData
        else {
            return
        }
        try data.write(to: directory.appendingPathComponent(filename), options: .atomic)
    }

    private func removeReplacedVertexNormals(
        previousRecord: ScanMeshAnchorRecord,
        currentRecord: ScanMeshAnchorRecord,
        from directory: URL
    ) throws {
        guard previousRecord.vertexNormalsFilename != currentRecord.vertexNormalsFilename,
              let filename = previousRecord.vertexNormalsFilename
        else {
            return
        }
        try self.removeItemIfExists(at: directory.appendingPathComponent(filename))
    }

    /// Resolves the directory for either the active project or a previously captured manifest.
    private func resolveProjectDirectory(for manifest: ScanProjectManifest?) throws -> URL {
        if let currentProjectDirectory, manifest?.id == currentManifest?.id {
            return currentProjectDirectory
        }

        guard let manifest else {
            throw ScanProjectStoreError.projectUnavailable
        }

        let projectDirectory = self.rootDirectory.appendingPathComponent(
            "\(manifest.id.uuidString).scanproject",
            isDirectory: true
        )

        guard self.fileManager.fileExists(atPath: projectDirectory.path) else {
            throw ScanProjectStoreError.projectUnavailable
        }

        return projectDirectory
    }

    /// Writes the current manifest JSON file to disk.
    private func persistManifest() throws {
        guard let currentManifest, let currentProjectDirectory else {
            return
        }

        let manifestURL = currentProjectDirectory.appendingPathComponent("manifest.json")
        let encoder = JSONEncoder()
        encoder.dateEncodingStrategy = .iso8601
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        let data = try encoder.encode(currentManifest)
        try data.write(to: manifestURL, options: .atomic)
    }

    /// Writes keyframe metadata JSON alongside the keyframe image directory.
    private func persistKeyframes(_ keyframes: [ScanRGBKeyframe], in projectDirectory: URL) throws {
        let metadataURL = self.keyframesMetadataURL(in: projectDirectory)
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        let data = try encoder.encode(keyframes)
        try data.write(to: metadataURL, options: .atomic)
    }

    /// Writes trajectory samples to `trajectory.json`.
    private func persistTrajectory(_ trajectory: ScanTrajectory, in projectDirectory: URL) throws {
        let trajectoryURL = self.trajectoryURL(in: projectDirectory)
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        let data = try encoder.encode(trajectory)
        try data.write(to: trajectoryURL, options: .atomic)
    }

    /// Writes mesh anchor metadata to `mesh-anchors.json`.
    private func persistMeshAnchorCatalog(_ catalog: ScanMeshAnchorCatalog, in projectDirectory: URL) throws {
        let catalogURL = self.meshAnchorCatalogURL(in: projectDirectory)
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        let data = try encoder.encode(catalog)
        try data.write(to: catalogURL, options: .atomic)
    }

    /// Reads keyframe metadata from disk for a previously captured project.
    private func readKeyframes(from projectDirectory: URL) throws -> [ScanRGBKeyframe] {
        let metadataURL = self.keyframesMetadataURL(in: projectDirectory)
        guard self.fileManager.fileExists(atPath: metadataURL.path) else {
            return []
        }

        let data = try Data(contentsOf: metadataURL)
        return try JSONDecoder().decode([ScanRGBKeyframe].self, from: data)
    }

    /// Reads trajectory metadata from disk for a previously captured project.
    private func readTrajectory(from projectDirectory: URL) throws -> ScanTrajectory {
        let trajectoryURL = self.trajectoryURL(in: projectDirectory)
        guard self.fileManager.fileExists(atPath: trajectoryURL.path) else {
            return ScanTrajectory()
        }

        let data = try Data(contentsOf: trajectoryURL)
        return try JSONDecoder().decode(ScanTrajectory.self, from: data)
    }

    /// Reads mesh-anchor metadata from disk for a previously captured project.
    private func readMeshAnchorCatalog(from projectDirectory: URL) throws -> ScanMeshAnchorCatalog {
        let catalogURL = self.meshAnchorCatalogURL(in: projectDirectory)
        guard self.fileManager.fileExists(atPath: catalogURL.path) else {
            return ScanMeshAnchorCatalog()
        }

        let data = try Data(contentsOf: catalogURL)
        return try JSONDecoder().decode(ScanMeshAnchorCatalog.self, from: data)
    }

    private func removeItemIfExists(at url: URL) throws {
        guard self.fileManager.fileExists(atPath: url.path) else {
            return
        }

        try self.fileManager.removeItem(at: url)
    }

    private func keyframesDirectoryURL(in projectDirectory: URL) -> URL {
        projectDirectory.appendingPathComponent("keyframes", isDirectory: true)
    }

    private func keyframesMetadataURL(in projectDirectory: URL) -> URL {
        projectDirectory.appendingPathComponent("keyframes.json")
    }

    private func meshAnchorsDirectoryURL(in projectDirectory: URL) -> URL {
        projectDirectory.appendingPathComponent("mesh-anchors", isDirectory: true)
    }

    private func meshAnchorCatalogURL(in projectDirectory: URL) -> URL {
        projectDirectory.appendingPathComponent("mesh-anchors.json")
    }

    private func trajectoryURL(in projectDirectory: URL) -> URL {
        projectDirectory.appendingPathComponent("trajectory.json")
    }
}
