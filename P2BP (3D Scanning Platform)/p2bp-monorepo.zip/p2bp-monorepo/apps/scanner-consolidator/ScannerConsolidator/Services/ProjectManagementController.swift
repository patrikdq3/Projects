import Foundation

// MARK: - ProjectManagementController

@MainActor
struct ProjectManagementController {
    let projectStore: ProjectStore
    let coordinator: RemoteProjectsDataCoordinator

    /// Renames local-first — cheap and revertible — then applies the remote edit, rolling the
    /// local copy back if the remote update fails so both sides stay consistent.
    func rename(
        localID: UUID?,
        remoteID: String?,
        organizationID: String?,
        currentName: String,
        to newName: String
    ) async throws {
        if let localID {
            try self.projectStore.renameProject(projectID: localID, name: newName)
        }

        guard let remoteID else { return }
        do {
            try await self.coordinator.editProject(
                organizationID: organizationID,
                projectID: remoteID,
                edit: UpdateProjectsAPIProjectRequest(name: newName)
            )
        } catch {
            if let localID {
                try? self.projectStore.renameProject(projectID: localID, name: currentName)
            }
            throw error
        }
    }

    /// Deletes remote-first so a failed API delete cannot discard local scan artifacts while
    /// leaving the server project behind.
    func delete(
        localID: UUID?,
        remoteID: String?,
        organizationID: String?
    ) async throws {
        if let remoteID {
            try await self.coordinator.deleteProject(
                organizationID: organizationID,
                projectID: remoteID
            )
        }
        if let localID {
            try self.projectStore.deleteProject(projectID: localID)
        }
    }
}
