nonisolated enum AppEnvironment {
    #if ENV_DEV
        static let apiHost = "p2bp-dev.chrismathew98.workers.dev"
    #elseif ENV_STAGING
        static let apiHost = "p2bp-staging.chrismathew98.workers.dev"
    #elseif ENV_PROD
        static let apiHost = "p2bp.chrismathew98.workers.dev"
    #endif
}
