import SwiftData
import SwiftUI

@MainActor
@main
struct ScannerConsolidatorApp: App {
    // MARK: Internal

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(self.dependencies.projectStore)
                .environmentObject(self.dependencies.zoneScanArchiveCacheService)
                .environmentObject(self.dependencies.remoteProjectsDataCoordinator)
                .environmentObject(self.dependencies.organizationDataCoordinator)
                .modelContainer(self.dependencies.modelContainer)
        }
    }

    // MARK: Private

    private let dependencies = AppDependencies.shared
}
