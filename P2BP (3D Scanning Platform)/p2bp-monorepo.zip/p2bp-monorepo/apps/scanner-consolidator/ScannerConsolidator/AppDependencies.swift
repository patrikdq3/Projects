import Foundation
import SwiftData

@MainActor
final class AppDependencies {
    // MARK: Lifecycle

    private init(inMemoryOnly: Bool = ProcessInfo.processInfo.arguments.contains("UI_TESTING")) {
        do {
            let schema = Schema([
                StoredProject.self,
                StoredZone.self,
            ])
            let configuration = ModelConfiguration(
                schema: schema,
                isStoredInMemoryOnly: inMemoryOnly
            )
            let container = try ModelContainer(for: schema, configurations: [configuration])
            self.modelContainer = container
            self.projectStore = ProjectStore(container: container)
            self.zoneScanArchiveCacheService = ZoneScanArchiveCacheService(projectStore: self.projectStore)
            self.remoteProjectsDataCoordinator = RemoteProjectsDataCoordinator()
            self.organizationDataCoordinator = OrganizationDataCoordinator()
        } catch {
            fatalError("Failed to create app dependencies: \(error.localizedDescription)")
        }
    }

    // MARK: Internal

    static let shared = AppDependencies()
    static let preview = AppDependencies(inMemoryOnly: true)

    let modelContainer: ModelContainer
    let projectStore: ProjectStore
    let zoneScanArchiveCacheService: ZoneScanArchiveCacheService
    let remoteProjectsDataCoordinator: RemoteProjectsDataCoordinator
    let organizationDataCoordinator: OrganizationDataCoordinator
}
