import SwiftUI

// MARK: - ContentView

/// entry point
struct ContentView: View {
    // MARK: Internal

    var body: some View {
        ZStack {
            if self.isCheckingSession {
                AppLoadingView()
            } else if self.isAuthenticated {
                ProjectsView(
                    currentUser: self.currentUser,
                    onLoggedOut: {
                        self.remoteProjectsDataCoordinator.resetInMemoryState(clearDiskCache: true)
                        self.organizationDataCoordinator.resetInMemoryState(clearDiskCache: true)
                        self.zoneScanArchiveCacheService.currentUserID = nil
                        self.currentUser = nil
                        self.isAuthenticated = false
                    }
                )
                .transition(.opacity)
            } else {
                AuthView(unverifiedEmail: self.unverifiedEmail) { user in
                    self.unverifiedEmail = nil
                    self.currentUser = user
                    self.zoneScanArchiveCacheService.currentUserID = user?.id
                    self.isAuthenticated = true
                    Task {
                        await self.remoteProjectsDataCoordinator.warmAllOrganizations(user: user)
                    }
                }
                .transition(.opacity)
            }
        }
        .animation(
            self.hasCompletedInitialSessionCheck ? .easeInOut(duration: 0.4) : nil,
            value: self.isAuthenticated
        )
        .task {
            await self.restoreSessionIfAvailable()
        }
    }

    // MARK: Private

    @EnvironmentObject private var remoteProjectsDataCoordinator: RemoteProjectsDataCoordinator
    @EnvironmentObject private var organizationDataCoordinator: OrganizationDataCoordinator
    @EnvironmentObject private var zoneScanArchiveCacheService: ZoneScanArchiveCacheService

    @State private var isCheckingSession = true
    @State private var isAuthenticated = false
    @State private var currentUser: User?
    @State private var unverifiedEmail: String?
    @State private var hasCompletedInitialSessionCheck = false

    private func restoreSessionIfAvailable() async {
        guard self.isCheckingSession else { return }

        let sessionResponse = await AuthService.shared.getSession()

        if let user = sessionResponse?.user, !user.emailVerified {
            // Valid session, but the email still needs verifying — gate on the OTP.
            self.unverifiedEmail = user.email
            self.currentUser = nil
            self.zoneScanArchiveCacheService.currentUserID = nil
            self.isAuthenticated = false
        } else {
            self.unverifiedEmail = nil
            self.currentUser = sessionResponse?.user
            self.zoneScanArchiveCacheService.currentUserID = sessionResponse?.user.id
            self.isAuthenticated = sessionResponse != nil
            if let user = sessionResponse?.user {
                Task {
                    await self.remoteProjectsDataCoordinator.warmAllOrganizations(user: user)
                }
            }
        }

        self.isCheckingSession = false
        Task { @MainActor in
            await Task.yield()
            self.hasCompletedInitialSessionCheck = true
        }
    }
}

// MARK: - AppLoadingView

private struct AppLoadingView: View {
    var body: some View {
        VStack(spacing: 14) {
            ProgressView()
                .controlSize(.regular)
                .tint(Color("Primary"))

            Text("Loading Workspace")
                .font(.system(size: 17, weight: .semibold))
                .foregroundStyle(Color("TextPrimary"))
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color("Background"))
    }
}
