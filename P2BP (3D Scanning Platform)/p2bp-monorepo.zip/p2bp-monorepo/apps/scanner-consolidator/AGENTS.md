# Agent Guide

iOS SwiftUI app for placemaking projects: draw map boundaries, split into scannable zones, capture LiDAR point clouds, export scan artifacts.

## Build & Test

```sh
bash ./scripts/run-swiftformat.sh .
bash ./scripts/run-swiftlint.sh --strict
bash ./scripts/run-xcodebuild.sh build
bash ./scripts/run-xcodebuild.sh test
```

Quick build (generic device):

```sh
xcodebuild -project ScannerConsolidator.xcodeproj -scheme "ScannerConsolidator Dev" -destination generic/platform=iOS build
```

## Formatting and Style

Let SwiftFormat own formatting. Use explicit `self.` where SwiftFormat inserts it. Keep lines under 120 chars (error at 130). Keep trailing commas in multiline collections. Avoid force unwraps and force casts. Preserve existing `// MARK:` sections.

## Concurrency and Isolation

Default actor isolation is `MainActor` (set in `project.pbxproj`).

- UI types, view models, SwiftData stores, and MapKit coordinator code stay `@MainActor`.
- Pure data/computation (`geometry`, `zone generation`, `scan math`) should be `nonisolated`.
- Do not add `nonisolated` to silence warnings on code that mutates UI state or `@Published` properties.

For default init args that create `@MainActor` types, prefer:

```swift
init(store: SomeStore? = nil) {
    self.store = store ?? SomeStore()
}
```

## Map Editing Gestures

- Long-press map: insert vertex near closest edge.
- Drag vertex annotation: move that vertex.
- Double-tap vertex annotation: delete that vertex.

## Persistence and Data Safety

- `ProjectStore` is the persistence boundary; enforce save-time invariants there.
- `ScanProjectStore` owns `.scanproject` artifacts — keep deletion aligned with zone state.
- Do not change `StoredProject` or `StoredZone` fields without considering migration. Preserve fallback decoding paths for legacy data.

## Scanner Feature

Keep frame-processing and geometry code deterministic and testable. Do not move heavy point-cloud processing onto the main actor unless UI state requires it. Do not weaken confidence/depth filtering or export metadata.

## Assets

Prefer unambiguous asset names (e.g. `BrandPrimary` over `Primary`, which conflicts with `Color.primary`). Update `Color("...")` call sites when renaming.

## Working Tree Rules

- Check `git status --short` before editing.
- Do not revert unrelated user changes.
- Keep edits scoped to the requested behavior.
- DONT write unit tests

## Review Checklist

- Does the app still build?
- Did SwiftFormat/SwiftLint pass?
- Were `ProjectStore` save-time invariants preserved?
- Is UI/SwiftData work on `@MainActor` and pure computation `nonisolated`?
- Were signing/team changes avoided?
- Were unrelated user edits left untouched?
