import XCTest

final class ScannerConsolidatedUITests: XCTestCase {
    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.

        // In UI tests it is usually best to stop immediately when a failure occurs.
        continueAfterFailure = false

        // In UI tests it’s important to set the initial state - such as interface orientation - required for your tests
        // before they run. The setUp method is a good place to do this.
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }

//    @MainActor
//    func testCreateProjectAndOpenFirstZone() {
//        let app = XCUIApplication()
//        app.launchArguments.append("UI_TESTING")
//        app.launch()
//
//        XCTAssertTrue(app.buttons["createProjectButton"].waitForExistence(timeout: 2))
//        app.buttons["createProjectButton"].tap()
//
//        let projectNameField = app.textFields["projectNameField"]
//        XCTAssertTrue(projectNameField.waitForExistence(timeout: 2))
//        projectNameField.tap()
//        projectNameField.typeText("Campus North")
//
//        app.buttons["locationChoiceArbitrary"].tap()
//
//        let confirmBoundaryButton = app.buttons["confirmBoundaryButton"]
//        XCTAssertTrue(confirmBoundaryButton.waitForExistence(timeout: 2))
//        confirmBoundaryButton.tap()
//
//        let createButton = app.buttons["createProjectSubmitButton"]
//        XCTAssertTrue(createButton.isEnabled)
//        createButton.tap()
//
//        XCTAssertTrue(app.staticTexts["Project Overview"].waitForExistence(timeout: 3))
//
//        let firstZone = app.buttons["zoneTile_A1"]
//        XCTAssertTrue(firstZone.waitForExistence(timeout: 2))
//        firstZone.tap()
//
//        let startButton = app.buttons["action.start"]
//        let unsupportedTitle = app.staticTexts["LiDAR Required"]
//        XCTAssertTrue(
//            startButton.waitForExistence(timeout: 2) || unsupportedTitle.waitForExistence(timeout: 2)
//        )
//    }

    @MainActor
    func testLaunchPerformance() {
        // This measures how long it takes to launch your application.
        measure(metrics: [XCTApplicationLaunchMetric()]) {
            XCUIApplication().launch()
        }
    }
}
