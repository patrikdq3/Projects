#!/usr/bin/env bash
set -euo pipefail

args=("$@")

has_argument() {
  local expected="$1"
  local argument

  for argument in "${args[@]}"; do
    case "$argument" in
      "$expected" | "$expected"=*)
        return 0
        ;;
    esac
  done

  return 1
}

if [[ "${GITHUB_ACTIONS:-}" == "true" ]] && ! has_argument "--reporter"; then
  args+=(--reporter github-actions-logging)
fi

mise exec -- swiftlint "${args[@]}"
