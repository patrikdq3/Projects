#!/usr/bin/env bash
set -euo pipefail

args=("$@")

has_argument() {
  local expected="$1"
  local argument

  for argument in "${args[@]}"; do
    case "$argument" in
      "$expected" | "$expected"=*)
        return 0
        ;;
    esac
  done

  return 1
}

if [[ "${CI:-}" == "true" || "${GITHUB_ACTIONS:-}" == "true" ]]; then
  if ! has_argument "--lint"; then
    args=(--lint "${args[@]}")
  fi

  if ! has_argument "--reporter"; then
    args+=(--reporter github-actions-log)
  fi
fi

mise exec -- swiftformat "${args[@]}"
