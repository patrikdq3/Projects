#!/usr/bin/env bash
set -euo pipefail

pbxproj="ScannerConsolidator.xcodeproj/project.pbxproj"
errors=0

# Manual signing must only ever come from Config/Signing.local.xcconfig,
# never from the project file (Xcode writes these when someone configures
# manual signing in Signing & Capabilities).
if grep -n 'PROVISIONING_PROFILE_SPECIFIER' "$pbxproj"; then
  echo "error: PROVISIONING_PROFILE_SPECIFIER must not appear in $pbxproj" >&2
  errors=1
fi

if grep -n 'CODE_SIGN_IDENTITY' "$pbxproj"; then
  echo "error: CODE_SIGN_IDENTITY must not appear in $pbxproj" >&2
  errors=1
fi

if grep -n 'CODE_SIGN_STYLE = Manual' "$pbxproj"; then
  echo "error: CODE_SIGN_STYLE = Manual must not appear in $pbxproj" >&2
  errors=1
fi

# The app target gets CODE_SIGN_STYLE from its per-environment xcconfig
# (Config/Dev.xcconfig, Config/Staging.xcconfig, Config/Prod.xcconfig).
# Changing signing in the UI writes the override back into the project file;
# catch that by pinning the count of remaining legitimate occurrences
# (test targets only).
expected=12
actual="$(grep -c 'CODE_SIGN_STYLE' "$pbxproj" || true)"
if [ "$actual" -ne "$expected" ]; then
  echo "error: expected $expected CODE_SIGN_STYLE entries in $pbxproj, found $actual" >&2
  echo "       (did Signing & Capabilities write a signing override back into the project?)" >&2
  errors=1
fi

exit "$errors"
