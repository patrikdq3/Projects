#!/usr/bin/env bash
set -euo pipefail

PROJECT_PATH="${PROJECT_PATH:-ScannerConsolidator.xcodeproj}"
SCHEME_NAME="${SCHEME_NAME:-ScannerConsolidator Dev}"
DERIVED_DATA_PATH="${DERIVED_DATA_PATH:-build/DerivedData}"
XCODEBUILD_LOG_DIR="${XCODEBUILD_LOG_DIR:-build/ci-artifacts/xcodebuild}"
XCODEBUILD_RESULT_BUNDLE_DIR="${XCODEBUILD_RESULT_BUNDLE_DIR:-build/result-bundles}"

if [[ $# -lt 1 ]]; then
  echo "usage: bash ./scripts/run-xcodebuild.sh <build|test|build-for-testing|test-without-building> [additional xcodebuild arguments...]" >&2
  exit 64
fi

action="$1"
shift

case "$action" in
  build | test | build-for-testing | test-without-building)
    ;;
  *)
    echo "error: Unsupported xcodebuild action '${action}'. Expected build, test, build-for-testing, or test-without-building." >&2
    exit 64
    ;;
esac

if [[ "$action" == "test-without-building" ]]; then
  if [[ "${XCODEBUILD_CLEAN:-0}" == "1" ]]; then
    echo "error: XCODEBUILD_CLEAN=1 cannot be combined with test-without-building." >&2
    exit 64
  fi

  shopt -s nullglob
  xctestrun_paths=("$DERIVED_DATA_PATH"/Build/Products/*.xctestrun)
  shopt -u nullglob

  if [[ ${#xctestrun_paths[@]} -eq 0 ]]; then
    echo "error: No .xctestrun file found under ${DERIVED_DATA_PATH}/Build/Products. Run build-for-testing first." >&2
    exit 1
  fi
fi

destination_name_from_line() {
  sed -nE 's/.*name:([^,}]+).*/\1/p' <<<"$1" | sed -E 's/^[[:space:]]+|[[:space:]]+$//g'
}

destination_id_from_line() {
  sed -nE 's/.*id:([^,}]+).*/\1/p' <<<"$1" | sed -E 's/^[[:space:]]+|[[:space:]]+$//g'
}

destination_os_from_line() {
  sed -nE 's/.*OS:([^,}]+).*/\1/p' <<<"$1" | sed -E 's/^[[:space:]]+|[[:space:]]+$//g'
}

simulator_sdk_version_from_output() {
  sed -nE 's/.*SDKROOT = iphonesimulator([0-9.]+).*/\1/p' <<<"$1" | head -n 1
}

major_minor_version() {
  local version="$1"

  if [[ "$version" =~ ^([0-9]+)\.([0-9]+) ]]; then
    printf '%s.%s\n' "${BASH_REMATCH[1]}" "${BASH_REMATCH[2]}"
    return
  fi

  printf '%s\n' "$version"
}

append_available_simulators_from_xcodebuild() {
  local destinations_output
  local line

  destinations_output="$(
    xcodebuild \
      -project "$PROJECT_PATH" \
      -scheme "$SCHEME_NAME" \
      -sdk iphonesimulator \
      -destination "generic/platform=iOS Simulator" \
      -showdestinations 2>&1 || true
  )"

  while IFS= read -r line; do
    [[ "$line" == *"platform:iOS Simulator"* ]] || continue
    [[ "$line" == *"placeholder"* ]] && continue
    [[ "$line" == *"name:Any iOS Simulator Device"* ]] && continue
    destination_lines+=("$line")
  done < <(printf '%s\n' "$destinations_output")

  SHOWDESTINATIONS_OUTPUT="$destinations_output"
}

append_available_simulators_from_simctl() {
  local requested_os_major_minor="${1:-}"
  local os_version=""
  local os_major_minor=""
  local simctl_output
  local line
  local simulator_name
  local simulator_id

  simctl_output="$(xcrun simctl list devices available 2>/dev/null || true)"

  while IFS= read -r line; do
    if [[ "$line" =~ ^--\ iOS\ ([^[:space:]]+)\ --$ ]]; then
      os_version="${BASH_REMATCH[1]}"
      os_major_minor="$(major_minor_version "$os_version")"
      continue
    fi

    if [[ "$line" =~ ^[[:space:]]+(.+)[[:space:]]+\(([0-9A-F-]+)\)[[:space:]]+\((Booted|Shutdown)\)[[:space:]]*$ ]]; then
      if [[ -n "$requested_os_major_minor" ]] && [[ "$os_major_minor" != "$requested_os_major_minor" ]]; then
        continue
      fi

      simulator_name="${BASH_REMATCH[1]}"
      simulator_id="${BASH_REMATCH[2]}"

      if [[ -n "$os_version" ]]; then
        destination_lines+=("{ platform:iOS Simulator, id:${simulator_id}, OS:${os_version}, name:${simulator_name} }")
      else
        destination_lines+=("{ platform:iOS Simulator, id:${simulator_id}, name:${simulator_name} }")
      fi
    fi
  done < <(printf '%s\n' "$simctl_output")
}

resolve_simulator_destination() {
  if [[ -n "${IOS_SIMULATOR_ID:-}" ]]; then
    RESOLVED_SIMULATOR_DESTINATION="id=${IOS_SIMULATOR_ID}"
    echo "info: Using explicit iOS Simulator id ${IOS_SIMULATOR_ID}" >&2
    return
  fi

  local -a destination_lines=()
  local line
  local SHOWDESTINATIONS_OUTPUT=""
  append_available_simulators_from_xcodebuild

  if [[ ${#destination_lines[@]} -eq 0 ]]; then
    local simulator_sdk_version
    simulator_sdk_version="$(simulator_sdk_version_from_output "$SHOWDESTINATIONS_OUTPUT")"
    local simulator_sdk_major_minor=""
    if [[ -n "$simulator_sdk_version" ]]; then
      simulator_sdk_major_minor="$(major_minor_version "$simulator_sdk_version")"
      echo "info: xcodebuild -showdestinations exposed only the generic simulator placeholder; falling back to simctl devices for iOS ${simulator_sdk_major_minor}" >&2
      append_available_simulators_from_simctl "$simulator_sdk_major_minor"
    fi

    if [[ ${#destination_lines[@]} -eq 0 ]]; then
      echo "info: No simctl devices matched the simulator SDK reported by xcodebuild; falling back to any available iOS Simulator device" >&2
      append_available_simulators_from_simctl
    fi

    if [[ ${#destination_lines[@]} -eq 0 ]]; then
      echo "error: No concrete iOS Simulator destinations found for scheme ${SCHEME_NAME}" >&2
      if [[ -n "$SHOWDESTINATIONS_OUTPUT" ]]; then
        printf '%s\n' "$SHOWDESTINATIONS_OUTPUT" >&2
      fi
      exit 1
    fi
  fi

  local selected_line=""
  local requested_name="${IOS_SIMULATOR_NAME:-}"
  local requested_os="${IOS_SIMULATOR_OS:-}"
  local candidate_name
  local candidate_os

  if [[ -n "$requested_name" ]]; then
    for line in "${destination_lines[@]}"; do
      candidate_name="$(destination_name_from_line "$line")"
      candidate_os="$(destination_os_from_line "$line")"

      if [[ "$candidate_name" == "$requested_name" ]] && [[ -z "$requested_os" || "$candidate_os" == "$requested_os" ]]; then
        selected_line="$line"
        break
      fi
    done
  fi

  if [[ -z "$selected_line" ]]; then
    local -a preferred_names=(
      "iPhone 17 Pro"
      "iPhone 17"
      "iPhone 16 Pro"
      "iPhone 16"
      "iPhone 15 Pro"
      "iPhone 15"
    )
    local preferred_name

    for preferred_name in "${preferred_names[@]}"; do
      for line in "${destination_lines[@]}"; do
        candidate_name="$(destination_name_from_line "$line")"
        if [[ "$candidate_name" == "$preferred_name" ]]; then
          selected_line="$line"
          break 2
        fi
      done
    done
  fi

  if [[ -z "$selected_line" ]]; then
    for line in "${destination_lines[@]}"; do
      candidate_name="$(destination_name_from_line "$line")"
      if [[ "$candidate_name" == iPhone* ]]; then
        selected_line="$line"
        break
      fi
    done
  fi

  if [[ -z "$selected_line" ]]; then
    selected_line="${destination_lines[0]}"
  fi

  local simulator_id
  simulator_id="$(destination_id_from_line "$selected_line")"
  if [[ -z "$simulator_id" ]]; then
    echo "error: Failed to parse simulator destination from: $selected_line" >&2
    exit 1
  fi

  local simulator_name
  simulator_name="$(destination_name_from_line "$selected_line")"
  local simulator_os
  simulator_os="$(destination_os_from_line "$selected_line")"

  RESOLVED_SIMULATOR_DESTINATION="id=${simulator_id}"

  if [[ -n "$simulator_os" ]]; then
    echo "info: Using iOS Simulator destination ${simulator_name} (OS ${simulator_os}, id ${simulator_id})" >&2
  else
    echo "info: Using iOS Simulator destination ${simulator_name} (id ${simulator_id})" >&2
  fi
}

ensure_simulator_ready() {
  local simulator_id="$1"

  echo "info: Booting iOS Simulator ${simulator_id} if needed" >&2
  xcrun simctl boot "$simulator_id" >/dev/null 2>&1 || true
  xcrun simctl bootstatus "$simulator_id" -b
}

artifact_basename="${XCODEBUILD_ARTIFACT_BASENAME:-$action}"
log_path="${XCODEBUILD_LOG_DIR}/${artifact_basename}.log"
result_bundle_path="${XCODEBUILD_RESULT_BUNDLE_DIR}/${artifact_basename}.xcresult"

mkdir -p "$DERIVED_DATA_PATH" "$XCODEBUILD_LOG_DIR" "$XCODEBUILD_RESULT_BUNDLE_DIR"
rm -rf "$result_bundle_path"

resolve_simulator_destination

if [[ "$action" == "test" || "$action" == "build-for-testing" || "$action" == "test-without-building" ]]; then
  ensure_simulator_ready "${RESOLVED_SIMULATOR_DESTINATION#id=}"
fi

actions=()
if [[ "${XCODEBUILD_CLEAN:-0}" == "1" ]]; then
  actions+=(clean)
fi
actions+=("$action")

additional_arguments=("$@")
disable_package_repository_cache=0

run_xcodebuild() {
  local -a command=(
    xcodebuild
    -project "$PROJECT_PATH"
    -scheme "$SCHEME_NAME"
    -derivedDataPath "$DERIVED_DATA_PATH"
    -sdk iphonesimulator
    -destination "$RESOLVED_SIMULATOR_DESTINATION"
    -resultBundlePath "$result_bundle_path"
  )

  if [[ "$disable_package_repository_cache" == "1" ]]; then
    command+=(-disablePackageRepositoryCache)
  fi

  command+=(
    "${actions[@]}"
    CODE_SIGNING_ALLOWED=NO
  )

  if [[ ${#additional_arguments[@]} -gt 0 ]]; then
    command+=("${additional_arguments[@]}")
  fi

  set +e
  "${command[@]}" 2>&1 | tee "$log_path"
  status=${PIPESTATUS[0]}
  set -e
}

echo "info: Writing xcodebuild log to ${log_path}" >&2
run_xcodebuild

if [[ $status -ne 0 ]] && grep -Eq "Couldn't check out revision|fatal: unable to read tree" "$log_path"; then
  echo "warning: Swift package checkout cache is corrupt; clearing generated package data and retrying once" >&2
  rm -rf "$DERIVED_DATA_PATH/SourcePackages" "$result_bundle_path"
  disable_package_repository_cache=1
  run_xcodebuild
fi

if [[ $status -ne 0 ]]; then
  echo "error: xcodebuild failed for action '${action}'. See ${log_path} and ${result_bundle_path} for details." >&2
fi

exit "$status"
