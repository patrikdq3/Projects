#!/usr/bin/env bash
set -euo pipefail

if ! command -v mise >/dev/null 2>&1; then
  echo "error: mise is required. Install it with: brew install mise"
  exit 1
fi

if [[ ! -f mise.toml ]]; then
  echo "error: mise.toml not found"
  exit 1
fi

# Unlike Mint, `mise exec` resolves to the pinned version by construction, so
# this is a bootstrap smoke test rather than a drift check: it confirms mise is
# on PATH, that mise.toml declares both tools, and that both actually run at the
# pinned versions. That is what the CI Swift steps need to be true before they
# start, and it prints the versions into the CI log.

if ! EXPECTED_SWIFTLINT="$(mise cfg get tools.swiftlint 2>/dev/null)"; then
  echo "error: swiftlint is not configured in mise.toml"
  exit 1
fi

if ! EXPECTED_SWIFTFORMAT="$(mise cfg get tools.swiftformat 2>/dev/null)"; then
  echo "error: swiftformat is not configured in mise.toml"
  exit 1
fi

ACTUAL_SWIFTLINT="$(mise exec -- swiftlint version | tr -d '\n\r')"
ACTUAL_SWIFTFORMAT="$(mise exec -- swiftformat --version | tr -d '\n\r')"

if [[ "$ACTUAL_SWIFTLINT" != "$EXPECTED_SWIFTLINT" ]]; then
  echo "error: SwiftLint version mismatch. Expected $EXPECTED_SWIFTLINT, got $ACTUAL_SWIFTLINT"
  exit 1
fi

if [[ "$ACTUAL_SWIFTFORMAT" != "$EXPECTED_SWIFTFORMAT" ]]; then
  echo "error: SwiftFormat version mismatch. Expected $EXPECTED_SWIFTFORMAT, got $ACTUAL_SWIFTFORMAT"
  exit 1
fi

echo "info: SwiftLint ${ACTUAL_SWIFTLINT}, SwiftFormat ${ACTUAL_SWIFTFORMAT}"
