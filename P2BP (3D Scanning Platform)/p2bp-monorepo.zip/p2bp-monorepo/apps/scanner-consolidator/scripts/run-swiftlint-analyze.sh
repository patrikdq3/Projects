#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
XCODEBUILD_LOG_DIR="${XCODEBUILD_LOG_DIR:-build/ci-artifacts/xcodebuild}"
XCODEBUILD_RESULT_BUNDLE_DIR="${XCODEBUILD_RESULT_BUNDLE_DIR:-build/result-bundles}"
SWIFTLINT_LOG_DIR="${SWIFTLINT_LOG_DIR:-build/ci-artifacts/swiftlint}"
BUILD_ARTIFACT_BASENAME="${SWIFTLINT_ANALYZE_BUILD_BASENAME:-swiftlint-analyze-build-for-testing}"
COMPILER_LOG_PATH="${XCODEBUILD_LOG_DIR}/${BUILD_ARTIFACT_BASENAME}.log"
ANALYZE_LOG_PATH="${SWIFTLINT_LOG_DIR}/swiftlint-analyze.log"

mkdir -p "$XCODEBUILD_LOG_DIR" "$XCODEBUILD_RESULT_BUNDLE_DIR" "$SWIFTLINT_LOG_DIR"

XCODEBUILD_CLEAN=1 \
XCODEBUILD_ARTIFACT_BASENAME="$BUILD_ARTIFACT_BASENAME" \
XCODEBUILD_LOG_DIR="$XCODEBUILD_LOG_DIR" \
XCODEBUILD_RESULT_BUNDLE_DIR="$XCODEBUILD_RESULT_BUNDLE_DIR" \
bash "$SCRIPT_DIR/run-xcodebuild.sh" build-for-testing

if [[ ! -f "$COMPILER_LOG_PATH" ]]; then
  echo "error: Expected SwiftLint compiler log at ${COMPILER_LOG_PATH}" >&2
  exit 1
fi

args=(analyze --compiler-log-path "$COMPILER_LOG_PATH" "$@")

has_argument() {
  local expected="$1"
  local argument

  for argument in "${args[@]}"; do
    case "$argument" in
      "$expected" | "$expected"=*)
        return 0
        ;;
    esac
  done

  return 1
}

if [[ "${GITHUB_ACTIONS:-}" == "true" ]] && ! has_argument "--reporter"; then
  args+=(--reporter github-actions-logging)
fi

echo "info: Writing SwiftLint analyze log to ${ANALYZE_LOG_PATH}" >&2
set +e
mise exec -- swiftlint "${args[@]}" 2>&1 | tee "$ANALYZE_LOG_PATH"
status=${PIPESTATUS[0]}
set -e

exit "$status"
