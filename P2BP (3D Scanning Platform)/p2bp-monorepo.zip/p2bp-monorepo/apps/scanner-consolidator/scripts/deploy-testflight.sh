#!/usr/bin/env bash

set -Eeuo pipefail

script_directory="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
repository_root="$(cd -- "$script_directory/../../.." && pwd)"

cd "$repository_root"

required_variables=(
  APPLE_DISTRIBUTION_CERTIFICATE
  APPLE_DISTRIBUTION_CERTIFICATE_PASSWORD
  APPLE_PROVISIONING_PROFILE_BASE64
  APP_STORE_CONNECT_API_PRIVATE_KEY
  APP_STORE_CONNECT_API_KEY_ID
  APP_STORE_CONNECT_API_ISSUER_ID
  APPLE_TEAM_ID
)

for variable_name in "${required_variables[@]}"; do
  if [[ -z "${!variable_name:-}" ]]; then
    printf 'ERROR: required environment variable %s is missing or empty\n' "$variable_name" >&2
    exit 1
  fi
done

app_bundle_id="${APP_BUNDLE_ID:-staging.p2bp.scanner}"
app_scheme="${APP_SCHEME:-ScannerConsolidator Staging}"
app_configuration="${APP_CONFIGURATION:-Release-Staging}"
app_build_number="${APP_BUILD_NUMBER:-$(date -u +%Y%m%d%H%M%S)}"

project_directory="$PWD/apps/scanner-consolidator"
project_path="$project_directory/ScannerConsolidator.xcodeproj"
ci_signing_config_path="$project_directory/Config/Signing.ci.xcconfig"
ci_signing_config_created=0

[[ -d "$project_path" ]] || {
  echo "ERROR: Xcode project not found: $project_path" >&2
  exit 1
}

temporary_directory="$(mktemp -d)"
keychain="$temporary_directory/testflight.keychain-db"
keychain_password="$(openssl rand -hex 24)"
archive_path="$temporary_directory/ScannerConsolidator.xcarchive"
export_path="$temporary_directory/export"
export_options="$temporary_directory/ExportOptions.plist"
p12_path="$temporary_directory/distribution.p12"
wwdr_certificate_path="$temporary_directory/AppleWWDRCAG3.cer"
app_store_connect_key_path="$temporary_directory/AuthKey_${APP_STORE_CONNECT_API_KEY_ID}.p8"
profile_source="$temporary_directory/staging.mobileprovision"
profile_plist="$temporary_directory/profile.plist"
profile_destination=""
profile_created=0

original_keychains=()
while IFS= read -r line; do
  line="${line#*\"}"
  line="${line%\"*}"
  [[ -n "$line" ]] && original_keychains+=("$line")
done < <(security list-keychains -d user)

cleanup() {
  set +e

  if ((${#original_keychains[@]})); then
    security list-keychains -d user -s "${original_keychains[@]}" >/dev/null
  fi

  security delete-keychain "$keychain" >/dev/null 2>&1

  if [[ "$profile_created" == 1 && -n "$profile_destination" ]]; then
    rm -f "$profile_destination"
  fi

  if [[ "$ci_signing_config_created" == 1 ]]; then
    rm -f "$ci_signing_config_path"
  fi

  rm -rf "$temporary_directory"
}
trap cleanup EXIT

printf '%s' "$APPLE_DISTRIBUTION_CERTIFICATE" | /usr/bin/base64 -D >"$p12_path"
printf '%s' "$APPLE_PROVISIONING_PROFILE_BASE64" | /usr/bin/base64 -D >"$profile_source"
printf '%s' "$APP_STORE_CONNECT_API_PRIVATE_KEY" | /usr/bin/base64 -D >"$app_store_connect_key_path"

chmod 600 "$p12_path" "$app_store_connect_key_path" "$profile_source"

openssl pkey -in "$app_store_connect_key_path" -noout >/dev/null || {
  echo "ERROR: APP_STORE_CONNECT_API_PRIVATE_KEY did not decode to a valid private key" >&2
  exit 1
}

security cms -D -i "$profile_source" >"$profile_plist" || {
  echo "ERROR: provisioning profile is invalid" >&2
  exit 1
}

profile_uuid="$(/usr/libexec/PlistBuddy -c 'Print :UUID' "$profile_plist")"
profile_name="$(/usr/libexec/PlistBuddy -c 'Print :Name' "$profile_plist")"
profile_app_identifier="$(
  /usr/libexec/PlistBuddy \
    -c 'Print :Entitlements:application-identifier' \
    "$profile_plist"
)"
expected_app_identifier="${APPLE_TEAM_ID}.${app_bundle_id}"

if [[ "$profile_app_identifier" != "$expected_app_identifier" ]]; then
  echo "ERROR: provisioning profile is for $profile_app_identifier" >&2
  echo "Expected: $expected_app_identifier" >&2
  exit 1
fi

if [[ -e "$ci_signing_config_path" ]]; then
  echo "ERROR: refusing to overwrite existing CI signing config: $ci_signing_config_path" >&2
  exit 1
fi

printf '%s\n' \
  'CODE_SIGN_STYLE = Manual' \
  'CODE_SIGN_IDENTITY = Apple Distribution' \
  "DEVELOPMENT_TEAM = $APPLE_TEAM_ID" \
  "PROVISIONING_PROFILE_SPECIFIER = $profile_uuid" \
  >"$ci_signing_config_path"
ci_signing_config_created=1

profile_directory="$HOME/Library/MobileDevice/Provisioning Profiles"
profile_destination="$profile_directory/$profile_uuid.mobileprovision"
mkdir -p "$profile_directory"

if [[ ! -f "$profile_destination" ]]; then
  cp "$profile_source" "$profile_destination"
  profile_created=1
fi

security create-keychain -p "$keychain_password" "$keychain"
security set-keychain-settings -lut 21600 "$keychain"
security unlock-keychain -p "$keychain_password" "$keychain"
security list-keychains -d user -s "$keychain"

curl \
  --fail \
  --silent \
  --show-error \
  --location \
  --proto '=https' \
  --tlsv1.2 \
  https://www.apple.com/certificateauthority/AppleWWDRCAG3.cer \
  --output "$wwdr_certificate_path"

wwdr_fingerprint="$(
  openssl x509 \
    -in "$wwdr_certificate_path" \
    -inform DER \
    -noout \
    -fingerprint \
    -sha256 |
    cut -d= -f2 |
    tr -d ':'
)"

expected_wwdr_fingerprint='DCF21878C77F4198E4B4614F03D696D89C66C66008D4244E1B99161AAC91601F'
if [[ "$wwdr_fingerprint" != "$expected_wwdr_fingerprint" ]]; then
  echo "ERROR: downloaded Apple WWDR G3 certificate has an unexpected fingerprint" >&2
  exit 1
fi

security import "$wwdr_certificate_path" \
  -k "$keychain" \
  -t cert \
  -f x509

security import "$p12_path" \
  -k "$keychain" \
  -P "$APPLE_DISTRIBUTION_CERTIFICATE_PASSWORD" \
  -f pkcs12 \
  -A

security set-key-partition-list \
  -S apple-tool:,apple: \
  -s \
  -k "$keychain_password" \
  "$keychain" >/dev/null

if ! security find-identity -v -p codesigning "$keychain" | grep -q 'Apple Distribution'; then
  echo "ERROR: the P12 does not contain a valid Apple Distribution identity" >&2
  exit 1
fi

echo "Archiving build $app_build_number with profile: $profile_name"

xcodebuild archive \
  -project "$project_path" \
  -scheme "$app_scheme" \
  -configuration "$app_configuration" \
  -destination 'generic/platform=iOS' \
  -archivePath "$archive_path" \
  -authenticationKeyPath "$app_store_connect_key_path" \
  -authenticationKeyID "$APP_STORE_CONNECT_API_KEY_ID" \
  -authenticationKeyIssuerID "$APP_STORE_CONNECT_API_ISSUER_ID" \
  -allowProvisioningUpdates \
  -hideShellScriptEnvironment \
  CURRENT_PROJECT_VERSION="$app_build_number"

plutil -create xml1 "$export_options"
/usr/libexec/PlistBuddy -c 'Add :method string app-store-connect' "$export_options"
/usr/libexec/PlistBuddy -c 'Add :destination string upload' "$export_options"
/usr/libexec/PlistBuddy -c 'Add :signingStyle string manual' "$export_options"
/usr/libexec/PlistBuddy -c 'Add :signingCertificate string Apple Distribution' "$export_options"
/usr/libexec/PlistBuddy -c "Add :teamID string $APPLE_TEAM_ID" "$export_options"
/usr/libexec/PlistBuddy -c 'Add :uploadSymbols bool true' "$export_options"
/usr/libexec/PlistBuddy -c 'Add :manageAppVersionAndBuildNumber bool false' "$export_options"
/usr/libexec/PlistBuddy -c 'Add :provisioningProfiles dict' "$export_options"
/usr/libexec/PlistBuddy \
  -c "Add :provisioningProfiles:$app_bundle_id string $profile_uuid" \
  "$export_options"

mkdir -p "$export_path"

echo "Uploading $app_bundle_id build $app_build_number to App Store Connect..."

xcodebuild -exportArchive \
  -archivePath "$archive_path" \
  -exportPath "$export_path" \
  -exportOptionsPlist "$export_options" \
  -authenticationKeyPath "$app_store_connect_key_path" \
  -authenticationKeyID "$APP_STORE_CONNECT_API_KEY_ID" \
  -authenticationKeyIssuerID "$APP_STORE_CONNECT_API_ISSUER_ID" \
  -allowProvisioningUpdates \
  -hideShellScriptEnvironment

echo "Upload accepted. Apple will process the build before it appears in TestFlight."
