# EC2 Queue Worker

## Overview

This repository contains the AWS EC2 instance responsible for consuming jobs from a Cloudflare Queue.

At the current stage of development, the instance can:

- Connect to a Cloudflare Queue
- Pull messages from the queue
- Validate `MESH_JOBS` messages
- Download zipped `.scanproject` archives from R2
- Merge zone scans into project LAZ and E57 outputs
- Acknowledge messages after successful processing

This repository serves as the foundation for point cloud postprocessing and meshing functionality.

---

# Repository Structure

```text
.
├── src/
│   ├── config.py
│   ├── mesh_jobs.py               # pydantic models for MESH_JOBS queue messages
│   ├── migrate_merged_point_cloud_e57.py  # one-off R2 migration: .bin -> .e57
│   ├── pull_queue.py
│   ├── r2.py
│   ├── viewer_analysis.py
│   └── scanproject_merger/        # point cloud registration & merging library
│       ├── __init__.py
│       ├── format.py
│       ├── registration.py
│       ├── visual.py
│       ├── export.py
│       └── merge.py
├── systemd/                   # environment-specific EC2 service definitions
├── tests/
├── pyproject.toml
├── uv.lock
└── README.md
```

## File Descriptions

### pull_queue.py

Queue worker entry point.

Responsibilities:

- Authenticate with Cloudflare
- Pull messages from the configured queue
- Validate and dispatch mesh job messages
- Stage zipped scanproject archives from R2
- Upload merged project point-cloud outputs
- Acknowledge messages only after successful processing

### r2.py

Utilities for uploading objects to and downloading objects from Cloudflare R2 (S3-compatible, via boto3).

Responsibilities:

- Build an R2 client from the environment
- Upload local files to R2 (with overwrite protection via a HEAD check)
- Download objects to a given path, directory, or a unique temp directory
- List keys under a prefix and delete objects
- Manage collision-free, private temp download directories

### migrate_merged_point_cloud_e57.py

One-off migration that retires the merged point cloud `.bin` outputs stored in
R2 before E57 existed. For every `merged-point-cloud.bin` and
`merged-point-cloud.preview.bin` it writes the matching `.e57` -- rebuilt from
the full-precision LAZ beside it, not converted from the `.bin` -- and deletes
the `.bin` only once that upload succeeds. Versioned per-job keys and the
legacy fixed keys are both covered; zone scan previews
(`.../scans/{uploadId}.preview.bin`) are a different, still-used artifact and
are never touched.

It reports without changing anything unless `--apply` is passed, and is safe to
re-run: a cloud that already has its E57 skips to deleting the `.bin`, and a
`.bin` whose LAZ is gone is reported and left in place. The exit code is
non-zero when anything was left unmigrated.

Backfilling also avoids needless merges: the Worker declines to reuse a
completed mesh job that is missing any current output, so an un-backfilled
project re-runs its whole merge on the next launch just to obtain the E57.
Merges old enough to also predate `merged-point-cloud.viewer.json` re-merge
once regardless -- this script only writes the E57.

```bash
uv run migrate-merged-point-cloud-e57                          # dry run
uv run migrate-merged-point-cloud-e57 --apply                  # migrate
uv run migrate-merged-point-cloud-e57 --prefix organizations/org_123/
```

### config.py

Shared configuration helpers (`require_env`, `ConfigError`) used by the other
modules to read required environment variables.

### mesh_jobs.py

Pydantic models for the messages the worker consumes from the `MESH_JOBS`
queue. Each message carries a `type` for dispatch and a `version` pinned per
variant, so a consumer validates only the exact schema it was built for and
rejects any other version. The discriminated union (`MeshGenerateJob`,
`MeshRefineJob`) mirrors the `MeshJobQueueMessage` type defined in
`p2bp-cf-worker`; field names are camelCase to match that JSON wire contract
exactly (do not rename them to snake_case). Use `parse_mesh_job_message()` to
validate an arbitrary payload into a typed variant.

`mesh.generate` messages are processed by the queue worker. `mesh.refine`
messages are validated but intentionally rejected until refinement is implemented,
so they are retried instead of being acknowledged as completed.

### scanproject_merger/

Library that registers overlapping ScannerConsolidator `.scanproject` zones into a
single georeferenced LAS/LAZ point cloud. It is a port of the standalone
[`scanproject-merger`](https://github.com/ChrisMGeo/ScannerConsolidator) CLI as an
importable library (no command-line interface). See
[Point Cloud Registration Library](#point-cloud-registration-library) for usage.

The queue worker calls this library for `mesh.generate` jobs after extracting the
zipped `.scanproject` archives from R2.

### pyproject.toml

Project metadata and Python package dependencies, managed by [uv](https://docs.astral.sh/uv/).

### uv.lock

Pinned, reproducible dependency versions resolved by uv. Commit this file.

### README.md

Setup and development documentation.

---

# Prerequisites

Before running the worker, ensure the following are installed:

- [uv](https://docs.astral.sh/uv/) (manages Python and dependencies)
- Git
- Access to the Cloudflare account containing the queue

Verify uv installation:

```bash
uv --version
```

uv will automatically download a compatible Python (3.12+) if one is not present.

---

# Setup

## Clone Repository

```bash
git clone <repository-url>
cd <repository-name>
```

## Install Dependencies

uv creates the virtual environment and installs all dependencies from `uv.lock`:

```bash
uv sync
```

---

# Cloudflare Configuration

Create a `.env` file in the repository root:

```env
CLOUDFLARE_ACCOUNT_ID=
CLOUDFLARE_QUEUE_ID=
CLOUDFLARE_POSTPROCESSING_API_TOKEN=

# R2 (object downloads)
R2_ACCESS_KEY_ID=
R2_SECRET_ACCESS_KEY=
R2_BUCKET=
```

## Environment Variables

### CLOUDFLARE_ACCOUNT_ID

Cloudflare Account ID that owns the queue. Also used to build the R2 endpoint
URL, so it must be the 32-character hex account id.

### CLOUDFLARE_QUEUE_ID

Unique Cloudflare Queue ID.

Note:

This is **not** the queue name.

Example:

```text
Correct:
8f3d2d8a7aab4d8bbcd123456789abcd

Incorrect:
mesh-jobs
```

### CLOUDFLARE_POSTPROCESSING_API_TOKEN

Cloudflare API token with Queue permissions.

Required permissions:

- Queues Read
- Queues Write

### R2_ACCESS_KEY_ID

Access key id of an R2 API token (used to upload and download objects to/from R2).

### R2_SECRET_ACCESS_KEY

Secret for the R2 API token above.

### R2_BUCKET

Default R2 bucket, so upload and download calls can omit the bucket argument.
Required unless every call passes an explicit bucket argument — when omitted, the
transfer helpers fall back to this variable and raise `ConfigError` if it is unset.

### P2BP_TMP_DIR

Optional. Base directory for temporary downloads. Must be an **absolute** path,
and its parent directory must already exist. Defaults to `<system temp>/p2bp-tmp`
(i.e. `/tmp/p2bp-tmp` on the EC2 Linux host).

For security, every ancestor directory of this path must be trusted — owned by
the worker user, or under a sticky directory such as `/tmp`. Do **not** point it
under a world- or group-writable, non-sticky directory: the download tree is
created with strict ownership/permission checks, but those checks cannot protect
against a hostile ancestor that could redirect the path.

### MERGED_POINT_CLOUD_DEDUPLICATE_VOXEL

Optional. Output voxel size, in meters, for the canonical
`merged-point-cloud.laz` / `merged-point-cloud.e57`. Defaults to `0.02`.

### PREVIEW_POINT_CLOUD_DEDUPLICATE_VOXEL

Optional. Output voxel size, in meters, for the downsampled
`merged-point-cloud.preview.laz` / `merged-point-cloud.preview.e57`. Defaults to
`0.10`.

### Registration tuning

All point-cloud registration heuristics can be overridden without rebuilding the
worker. Invalid values fail the job configuration rather than silently falling
back. Boolean values accept `true`/`false`, `1`/`0`, `yes`/`no`, or `on`/`off`.

Scan preparation and pair acceptance:

| Environment variable                              | Default | Purpose                                                   |
| ------------------------------------------------- | ------: | --------------------------------------------------------- |
| `P2BP_REGISTRATION_VOXEL_SIZE`                    | `0.075` | Registration sampling grid in metres.                     |
| `P2BP_REGISTRATION_MINIMUM_CONFIDENCE`            |     `1` | Minimum point confidence used by alignment.               |
| `P2BP_REGISTRATION_CANDIDATE_PADDING`             |  `10.0` | Horizontal bounds padding for candidate pairs, in metres. |
| `P2BP_REGISTRATION_MAXIMUM_DISTANCE`              |   `5.0` | Initial ICP correspondence gate, in metres.               |
| `P2BP_REGISTRATION_MINIMUM_OVERLAP`               |  `0.06` | Minimum accepted moving-cloud overlap ratio.              |
| `P2BP_REGISTRATION_MAXIMUM_RMSE`                  |  `0.40` | Maximum accepted pair RMSE, in metres.                    |
| `P2BP_REGISTRATION_MAXIMUM_LOOP_YAW_DEGREES`      |   `3.0` | Maximum loop-closure yaw error.                           |
| `P2BP_REGISTRATION_MAXIMUM_LOOP_HORIZONTAL_ERROR` |   `1.0` | Maximum horizontal loop error, in metres.                 |
| `P2BP_REGISTRATION_MAXIMUM_LOOP_VERTICAL_ERROR`   |   `1.0` | Maximum vertical loop error, in metres.                   |
| `P2BP_REGISTRATION_USE_VISUAL_REGISTRATION`       |  `true` | Enable RGB/depth initialization.                          |
| `P2BP_REGISTRATION_EDGE_QUALITY_RMSE_FLOOR`       | `0.001` | RMSE floor used to rank registration edges.               |

ICP and pose-graph optimization:

| Environment variable                             |   Default | Purpose                                                                  |
| ------------------------------------------------ | --------: | ------------------------------------------------------------------------ |
| `P2BP_REGISTRATION_ICP_ITERATIONS`               |      `40` | Number of coarse-to-fine ICP gates.                                      |
| `P2BP_REGISTRATION_ICP_FINAL_DISTANCE`           |    `0.50` | Final ICP correspondence gate, in metres.                                |
| `P2BP_REGISTRATION_ICP_MINIMUM_CORRESPONDENCES`  |      `12` | Minimum correspondences required for a stable pair.                      |
| `P2BP_REGISTRATION_ICP_TRIM_QUANTILE`            |    `0.80` | Fraction of nearest correspondences retained per iteration.              |
| `P2BP_REGISTRATION_POSE_GRAPH_YAW_SCALE`         |    `10.0` | Metre-equivalent residual weight for one radian of yaw.                  |
| `P2BP_REGISTRATION_POSE_GRAPH_ROBUST_LOSS`       | `soft_l1` | SciPy robust loss (`linear`, `soft_l1`, `huber`, `cauchy`, or `arctan`). |
| `P2BP_REGISTRATION_POSE_GRAPH_ROBUST_LOSS_SCALE` |    `0.25` | Robust-loss transition scale.                                            |

Visual initialization:

| Environment variable                                | Default | Purpose                                                  |
| --------------------------------------------------- | ------: | -------------------------------------------------------- |
| `P2BP_REGISTRATION_VISUAL_MAXIMUM_KEYFRAMES`        |   `120` | Maximum sampled RGB/depth keyframes per scan.            |
| `P2BP_REGISTRATION_VISUAL_SIFT_FEATURES`            |   `600` | Maximum SIFT features detected per keyframe.             |
| `P2BP_REGISTRATION_VISUAL_SIFT_CONTRAST_THRESHOLD`  | `0.025` | SIFT contrast threshold.                                 |
| `P2BP_REGISTRATION_VISUAL_MAXIMUM_IMAGE_WIDTH`      | `960.0` | Maximum feature-extraction image width in pixels.        |
| `P2BP_REGISTRATION_VISUAL_MINIMUM_KEYPOINTS`        |     `8` | Minimum keypoints required from a keyframe.              |
| `P2BP_REGISTRATION_VISUAL_MINIMUM_DEPTH`            |  `0.05` | Minimum usable feature depth, in metres.                 |
| `P2BP_REGISTRATION_VISUAL_MAXIMUM_DEPTH`            |   `8.0` | Maximum usable feature depth, in metres.                 |
| `P2BP_REGISTRATION_VISUAL_MINIMUM_DEPTH_CONFIDENCE` |     `1` | Minimum confidence for feature depth samples.            |
| `P2BP_REGISTRATION_VISUAL_FLANN_TREES`              |     `5` | FLANN KD-tree count.                                     |
| `P2BP_REGISTRATION_VISUAL_FLANN_CHECKS`             |    `64` | FLANN search checks.                                     |
| `P2BP_REGISTRATION_VISUAL_MATCH_RATIO`              |  `0.75` | Lowe nearest-neighbor match ratio.                       |
| `P2BP_REGISTRATION_VISUAL_MINIMUM_INLIERS`          |    `20` | Minimum depth-backed RANSAC inliers.                     |
| `P2BP_REGISTRATION_VISUAL_RANSAC_THRESHOLD`         |  `0.20` | RANSAC inlier distance, in metres.                       |
| `P2BP_REGISTRATION_VISUAL_RANSAC_ITERATIONS`        |  `2500` | Visual RANSAC iteration count.                           |
| `P2BP_REGISTRATION_VISUAL_RANSAC_SEED`              |     `0` | Deterministic RANSAC random seed.                        |
| `P2BP_REGISTRATION_VISUAL_ICP_MAXIMUM_DISTANCE`     |  `0.75` | Initial ICP gate after visual initialization, in metres. |

---

# Queue Requirements

The queue must have HTTP Pull enabled.

Example:

```bash
wrangler queues consumer http add mesh-jobs
```

Without HTTP Pull enabled, the worker will receive:

```text
messages cannot be pulled unless http_pull mode is enabled
```

---

# Running the instance

Run with uv (no manual activation needed):

```bash
uv run src/pull_queue.py
```

Or via the installed entry point:

```bash
uv run pull-queue
```

## EC2 systemd services

The queue worker runs as a systemd service on each of the dev, staging, and
production EC2 instances. All three services use the same user, working
directory, command, `PATH`, and temporary directory. The environment-specific
`EnvironmentFile` is the only difference.

| Environment | Service definition                                                                                 | Environment file on EC2                                                   |
| ----------- | -------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------- |
| Dev         | [`systemd/p2bp-postprocessing-dev.service`](systemd/p2bp-postprocessing-dev.service)               | `/home/ubuntu/app/p2bp-monorepo/apps/p2bp-postprocessing/.env.dev`        |
| Staging     | [`systemd/p2bp-postprocessing-staging.service`](systemd/p2bp-postprocessing-staging.service)       | `/home/ubuntu/app/p2bp-monorepo/apps/p2bp-postprocessing/.env.staging`    |
| Production  | [`systemd/p2bp-postprocessing-production.service`](systemd/p2bp-postprocessing-production.service) | `/home/ubuntu/app/p2bp-monorepo/apps/p2bp-postprocessing/.env.production` |

The `Restart` directives are currently commented out in all three deployed
definitions. The queue worker shuts down its EC2 instance after
`IDLE_LIMIT_SECONDS` of inactivity (60 seconds by default), as well as when its
maximum runtime or failure limit is reached, and it expects its supervisor not
to relaunch it while the instance is stopping.

### Known idle-shutdown race condition

The inactivity shutdown currently has a race condition that still needs to be
fixed. Once the idle limit is reached, the worker performs a final queue poll
and then asynchronously stops the EC2 instance if that poll is empty. A producer
can enqueue a job after the confirming poll but before the instance finishes
stopping. During that window the job launcher can observe the instance as still
running and decide that no start is necessary; the instance then stops, leaving
the newly queued job without an active consumer.

The final confirming poll narrows this timing window but cannot eliminate the
cross-system race between Cloudflare Queues and EC2 state changes. This section
documents the known issue only; the shutdown and launch coordination still
requires a separate fix.

---

# Expected Behavior

When a `mesh.generate` message exists:

```text
Processing message with body type: dict
Downloading r2://<bucket>/<zone-scan-object-key> -> <workspace>/archives/000-zone.zip
Merging 1 scanproject archive(s) for organization=org_test project=proj_test
Uploading merged cloud (...) and preview (...)

Acknowledging message...

Message acknowledged successfully.
```

The worker uploads under the versioned per-job prefix
`organizations/{orgId}/projects/{projectId}/mesh-jobs/{jobId}/`:

- `merged-point-cloud.laz`
- `merged-point-cloud.e57` -- the same full-resolution cloud in the format CAD
  tools (Rhino among them) import natively. Points are written against a local
  origin carried in the scan pose, because E57 stores coordinates as 32-bit
  floats and raw UTM values would quantize the cloud to roughly half a meter.
- `merged-point-cloud.preview.laz`
- `merged-point-cloud.preview.e57`
- `status.json` -- job status for the Cloudflare worker's `mesh_jobs`
  reconciliation: written with `state: "running"` before any work,
  `state: "completed"` after every output has been uploaded, and (best
  effort) `state: "failed"` with an `error` before re-raising so the message
  is redelivered. Last write wins; a successful redelivery overwrites an
  earlier failure.

When no message exists:

```text
Pulling one message from queue...

No messages found in queue.
```

---

# Troubleshooting

## Authentication Error (401)

Verify:

- API token is correct
- API token belongs to the correct Cloudflare account
- Account ID is correct
- Queue ID is correct

Validate token:

```bash
curl "https://api.cloudflare.com/client/v4/user/tokens/verify" \
  -H "Authorization: Bearer YOUR_TOKEN"
```

Expected:

```json
{
  "success": true
}
```

---

## HTTP Pull Not Enabled

Error:

```text
messages cannot be pulled unless http_pull mode is enabled
```

Fix:

```bash
wrangler queues consumer http add <queue-name>
```

---

# Point Cloud Registration Library

`scanproject_merger` registers overlapping `.scanproject` zones and writes one merged
LAS/LAZ point cloud, an optional E57 companion for CAD tools, and a JSON
registration report. Source packages are never modified; the first
input scan anchors the output frame.

```python
from scanproject_merger import merge_scan_projects

outputs = merge_scan_projects(
    ["path/to/scans"],                  # .scanproject dirs, or parent dirs containing them
    "path/to/results/merged.laz",       # merged LAS/LAZ output
    e57_output="path/to/results/merged.e57",  # optional: matching E57 output
    transformed_scans_dir="path/to/results/aligned",  # optional: one aligned LAZ per source
)

print(outputs.point_count, "points ->", outputs.output)
print("report:", outputs.report)
```

`merge_scan_projects` accepts keyword overrides for the registration and export
tuning (voxel sizes, confidence thresholds, ICP gates, loop tolerances, and
`use_visual_registration`); see its docstring for the full set. For finer control,
the lower-level `register_scans` and `export_*` functions are exported directly.

The queue worker invokes this library for `mesh.generate` messages after
downloading and extracting the R2 scan archives.

---

# Future Development

Planned additions include:

- Point cloud meshing (consuming the `scanproject_merger` registration output)
- Mesh refinement job processing
