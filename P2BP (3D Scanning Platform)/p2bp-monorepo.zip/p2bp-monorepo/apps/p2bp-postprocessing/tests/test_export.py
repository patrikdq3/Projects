import inspect
from pathlib import Path
from types import SimpleNamespace

import laspy
import numpy as np
import pye57
from pyproj import CRS
from test_format import make_project

from scanproject_merger.export import (
    _CloudData,
    _deduplicate_cloud_data,
    _mesh_attributes,
    export_merged_cloud,
    export_merged_cloud_e57,
    export_merged_cloud_outputs,
    export_original_scans,
    export_transformed_scans,
    prepare_merged_cloud_data,
)
from scanproject_merger.format import MeshAnchor, ScanProject
from scanproject_merger.registration import RegistrationResult, prepare_scans
from viewer_analysis import CEILING_FLAG, PointViewerAnalysis


def test_mesh_attributes_ignore_zero_vertex_anchors():
    anchor = MeshAnchor(
        transform=np.eye(4),
        vertices=np.empty((0, 3)),
        faces=np.empty((0, 3), dtype=np.uint32),
        normals=np.empty((0, 3)),
        face_classifications=np.empty(0, dtype=np.uint8),
    )
    project = SimpleNamespace(mesh_anchors=lambda: [anchor])
    points = np.array([[0.0, 0.0, 0.0]])

    normal_z, classification, flags = _mesh_attributes(project, np.eye(4), points)

    assert np.isnan(normal_z).all()
    np.testing.assert_array_equal(classification, [0])
    np.testing.assert_array_equal(flags, [0])


def test_mesh_attributes_map_only_structural_arkit_classes_to_building():
    arkit_classes = np.arange(1, 8, dtype=np.uint8)
    vertices = np.vstack(
        [
            [[x, 0.0, 0.0], [x + 0.05, 0.0, 0.0], [x, 0.05, 0.0]]
            for x in np.arange(len(arkit_classes), dtype=float)
        ]
    )
    anchor = MeshAnchor(
        transform=np.eye(4),
        vertices=vertices,
        faces=np.arange(len(vertices), dtype=np.uint32).reshape(-1, 3),
        normals=np.tile([0.0, 0.0, 1.0], (len(vertices), 1)),
        face_classifications=arkit_classes,
    )
    project = SimpleNamespace(mesh_anchors=lambda: [anchor])
    points = np.array([[x + 0.01, 0.01, 0.0] for x in range(7)])

    _, classification, flags = _mesh_attributes(project, np.eye(4), points)

    # wall, floor, ceiling, table, seat, window, door
    np.testing.assert_array_equal(classification, [6, 2, 6, 0, 0, 6, 6])
    np.testing.assert_array_equal(flags, [0, 0, CEILING_FLAG, 0, 0, 0, 0])


def test_exports_laz_with_crs_and_provenance(tmp_path: Path):
    path = make_project(
        tmp_path / "one.scanproject", np.array([[0, 0, 0], [1, 2, 3], [2, 4, 6]])
    )
    scan = ScanProject.open(path)
    prepared = prepare_scans([scan], voxel_size=0.01, minimum_confidence=0)
    result = RegistrationResult(prepared, [np.eye(4)], [])
    output = tmp_path / "merged.laz"
    assert (
        export_merged_cloud(result, output, minimum_confidence=0, deduplicate_voxel=0)
        == 3
    )
    cloud = laspy.read(output)
    assert cloud.header.parse_crs().to_epsg() == 32618
    assert cloud.header.point_format.size == 51
    assert {
        "confidence",
        "source_id",
        "scan_time",
        "p2bp_hag_cm",
        "p2bp_normal_z",
        "p2bp_surface_flags",
    } <= set(cloud.point_format.extra_dimension_names)
    np.testing.assert_array_equal(cloud.source_id, [0, 0, 0])
    fields = cloud.points.array.dtype.fields
    assert {
        name: fields[name][1]
        for name in (
            "confidence",
            "source_id",
            "scan_time",
            "p2bp_hag_cm",
            "p2bp_normal_z",
            "p2bp_surface_flags",
        )
    } == {
        "confidence": 36,
        "source_id": 37,
        "scan_time": 39,
        "p2bp_hag_cm": 47,
        "p2bp_normal_z": 49,
        "p2bp_surface_flags": 50,
    }


def test_laz_viewer_height_attribute_round_trips_in_centimeters(tmp_path: Path):
    grid_x, grid_z = np.meshgrid(np.arange(4), np.arange(4))
    ground = np.column_stack(
        (grid_x.reshape(-1), np.zeros(grid_x.size), grid_z.reshape(-1))
    )
    points = np.vstack((ground, [1.0, 2.5, 1.0]))
    path = make_project(tmp_path / "height.scanproject", points)
    scan = ScanProject.open(path)
    prepared = prepare_scans([scan], voxel_size=0.01, minimum_confidence=0)
    result = RegistrationResult(prepared, [np.eye(4)], [])
    output = tmp_path / "height.laz"

    export_merged_cloud(result, output, minimum_confidence=0, deduplicate_voxel=0)

    cloud = laspy.read(output)
    assert cloud.p2bp_hag_cm[-1] == 250
    assert cloud.p2bp_normal_z[-1] == -128
    assert cloud.p2bp_surface_flags[-1] == 0


def test_e57_writer_matches_the_pinned_pye57_internals():
    """Pin what `_open_e57_writer` relies on when it bypasses pye57's constructor.

    It builds the wrapper with `__new__` because the constructor writes a header
    whose `coordinateMetadata` is empty and libE57 refuses to overwrite a field.
    That bypass is only safe while the constructor sets nothing else the writer
    needs, so a pye57 upgrade that changes these should fail here rather than at
    export time.
    """
    # `root` is derived from `image_file`, not assigned state, so setting
    # `image_file` alone fully initializes the wrapper (and `root` cannot be
    # assigned even if one tried).
    assert isinstance(inspect.getattr_static(pye57.E57, "root"), property)
    assert inspect.getattr_static(pye57.E57, "root").fset is None
    assert "self.image_file.root()" in inspect.getsource(pye57.E57.root.fget)

    # The instance attributes the constructor sets, which _open_e57_writer
    # therefore has to set itself.
    assert {
        line.split("=")[0].strip()
        for line in inspect.getsource(pye57.E57.__init__).splitlines()
        if line.strip().startswith("self.") and "=" in line
    } == {"self.path", "self.image_file"}

    # write_e57_cloud closes through the wrapper.
    assert callable(pye57.E57.close)

    # The reason for the bypass: the stock header hardcodes an empty CRS.
    assert 'set("coordinateMetadata", libe57.StringNode(imf, "")' in inspect.getsource(
        pye57.E57.write_default_header
    )


def test_exports_e57_georeferenced_to_millimeter_precision(tmp_path: Path):
    path = make_project(
        tmp_path / "one.scanproject", np.array([[0, 0, 0], [1, 2, 3], [2, 4, 6]])
    )
    scan = ScanProject.open(path)
    prepared = prepare_scans([scan], voxel_size=0.01, minimum_confidence=0)
    result = RegistrationResult(prepared, [np.eye(4)], [])
    output = tmp_path / "merged.e57"

    assert (
        export_merged_cloud_e57(
            result, output, minimum_confidence=0, deduplicate_voxel=0
        )
        == 3
    )

    reader = pye57.E57(str(output))
    try:
        assert reader.scan_count == 1
        # The scan pose carries the UTM origin, so reading with transform=True
        # must land back on the same eastings/northings the LAZ export writes.
        scan_data = reader.read_scan(
            0, intensity=True, colors=True, ignore_missing_fields=True
        )
        assert (
            CRS.from_wkt(reader.root["coordinateMetadata"].value()).to_epsg() == 32618
        )
    finally:
        reader.image_file.close()

    points = np.column_stack(
        (
            scan_data["cartesianX"],
            scan_data["cartesianY"],
            scan_data["cartesianZ"],
        )
    )
    expected = np.array(
        [
            [500_000, 4_500_000, 100],
            [500_001, 4_499_997, 102],
            [500_002, 4_499_994, 104],
        ]
    )
    assert np.abs(points - expected).max() < 0.001
    np.testing.assert_array_equal(scan_data["colorRed"], [10, 10, 10])
    np.testing.assert_array_equal(scan_data["colorGreen"], [20, 20, 20])
    np.testing.assert_array_equal(scan_data["colorBlue"], [30, 30, 30])
    # Confidence 0/1/2 normalized onto E57's [0, 1] intensity range.
    np.testing.assert_allclose(scan_data["intensity"], [0.0, 0.5, 1.0])


def test_exports_laz_and_e57_from_the_same_filtered_points(tmp_path: Path):
    path = make_project(
        tmp_path / "one.scanproject",
        np.array(
            [
                [0, 0, 0],
                [0.001, 0.001, 0],
                [0.002, 0.002, 0],
                [2, 4, 6],
            ]
        ),
    )
    scan = ScanProject.open(path)
    prepared = prepare_scans([scan], voxel_size=0.0001, minimum_confidence=0)
    result = RegistrationResult(prepared, [np.eye(4)], [])
    laz_output = tmp_path / "merged.laz"
    e57_output = tmp_path / "merged.e57"

    count = export_merged_cloud_outputs(
        result,
        laz_output=laz_output,
        e57_output=e57_output,
        minimum_confidence=0,
        deduplicate_voxel=0.02,
    )

    assert count == 2
    cloud = laspy.read(laz_output)
    reader = pye57.E57(str(e57_output))
    try:
        scan_data = reader.read_scan(0, colors=True, ignore_missing_fields=True)
    finally:
        reader.image_file.close()
    points = np.column_stack(
        (
            scan_data["cartesianX"],
            scan_data["cartesianY"],
            scan_data["cartesianZ"],
        )
    )
    assert len(cloud.points) == len(points) == count
    np.testing.assert_allclose(
        points, np.column_stack((cloud.x, cloud.y, cloud.z)), atol=0.001
    )


def test_exports_e57_for_a_fully_filtered_cloud(tmp_path: Path):
    path = make_project(
        tmp_path / "one.scanproject", np.array([[0, 0, 0], [1, 2, 3], [2, 4, 6]])
    )
    scan = ScanProject.open(path)
    prepared = prepare_scans([scan], voxel_size=0.01, minimum_confidence=0)
    result = RegistrationResult(prepared, [np.eye(4)], [])
    output = tmp_path / "empty.e57"

    # Confidence tops out at 2, so this filters every point out.
    assert export_merged_cloud_e57(result, output, minimum_confidence=3) == 0

    reader = pye57.E57(str(output))
    try:
        assert reader.scan_count == 0
    finally:
        reader.image_file.close()


def test_exports_laz_from_filtered_points(tmp_path: Path):
    path = make_project(
        tmp_path / "one.scanproject",
        np.array(
            [
                [0, 0, 0],
                [0.001, 0.001, 0],
                [0.002, 0.002, 0],
                [2, 4, 6],
            ]
        ),
    )
    scan = ScanProject.open(path)
    prepared = prepare_scans([scan], voxel_size=0.0001, minimum_confidence=0)
    result = RegistrationResult(prepared, [np.eye(4)], [])
    laz_output = tmp_path / "merged.laz"

    count = export_merged_cloud_outputs(
        result,
        laz_output=laz_output,
        minimum_confidence=0,
        deduplicate_voxel=0.02,
    )

    assert count == 2
    cloud = laspy.read(laz_output)
    assert len(cloud.points) == count
    np.testing.assert_array_equal(cloud.confidence, [2, 0])


def test_prepare_analyzes_only_deduplicated_output_rows(tmp_path: Path, monkeypatch):
    path = make_project(
        tmp_path / "one.scanproject",
        np.array(
            [
                [0, 0, 0],
                [0.001, 0.001, 0],
                [0.002, 0.002, 0],
                [2, 4, 6],
            ]
        ),
    )
    scan = ScanProject.open(path)
    prepared = prepare_scans([scan], voxel_size=0.0001, minimum_confidence=0)
    result = RegistrationResult(prepared, [np.eye(4)], [])
    analyzed_counts = []

    from scanproject_merger import export as export_module

    original_analyze_points = export_module.analyze_points

    def record_analyzed_count(xyz, *args):
        analyzed_counts.append(len(xyz))
        return original_analyze_points(xyz, *args)

    monkeypatch.setattr(export_module, "analyze_points", record_analyzed_count)

    data = prepare_merged_cloud_data(
        result,
        minimum_confidence=0,
        deduplicate_voxel=0.02,
    )

    assert analyzed_counts == [2]
    assert len(data.xyz) == len(data.analysis.height_above_ground_cm) == 2
    np.testing.assert_array_equal(data.confidence, [2, 0])


def test_preview_deduplication_keeps_every_attribute_row_aligned():
    analysis = PointViewerAnalysis(
        floor_height=10.0,
        height_above_ground_cm=np.array([100, 200, 300, 400], dtype=np.uint16),
        normal_z=np.array([10, 20, 30, 40], dtype=np.int8),
        surface_flags=np.array([1, 2, 4, 8], dtype=np.uint8),
        outlines=[{"category": "building", "coordinates": []}],
        normal_coverage=0.25,
    )
    data = _CloudData(
        xyz=np.array(
            [
                [0.0, 0.0, 0.0],
                [0.001, 0.001, 0.0],
                [0.002, 0.002, 0.0],
                [2.0, 0.0, 0.0],
            ]
        ),
        rgb=np.arange(12, dtype=np.uint8).reshape(4, 3),
        confidence=np.array([0, 2, 1, 0], dtype=np.uint8),
        timestamps=np.array([1.0, 2.0, 3.0, 4.0]),
        source_ids=np.array([10, 20, 30, 40], dtype=np.uint16),
        classification=np.array([2, 4, 5, 6], dtype=np.uint8),
        analysis=analysis,
        epsg=32618,
        deduplicate_voxel=0,
    )

    deduplicated = _deduplicate_cloud_data(data, voxel_size=0.02)

    np.testing.assert_array_equal(deduplicated.confidence, [2, 0])
    np.testing.assert_array_equal(deduplicated.rgb, [[3, 4, 5], [9, 10, 11]])
    np.testing.assert_array_equal(deduplicated.timestamps, [2.0, 4.0])
    np.testing.assert_array_equal(deduplicated.source_ids, [20, 40])
    np.testing.assert_array_equal(deduplicated.classification, [4, 6])
    np.testing.assert_array_equal(
        deduplicated.analysis.height_above_ground_cm, [200, 400]
    )
    np.testing.assert_array_equal(deduplicated.analysis.normal_z, [20, 40])
    np.testing.assert_array_equal(deduplicated.analysis.surface_flags, [2, 8])
    assert deduplicated.analysis.outlines is analysis.outlines
    assert deduplicated.analysis.normal_coverage == 0.5


def test_exports_each_transformed_source_without_deduplication(tmp_path: Path):
    path = make_project(
        tmp_path / "B1-one.scanproject",
        np.array([[0, 0, 0], [1, 2, 3], [1, 2, 3], [2, 4, 6]]),
    )
    scan = ScanProject.open(path)
    prepared = prepare_scans([scan], voxel_size=0.01, minimum_confidence=0)
    result = RegistrationResult(prepared, [np.eye(4)], [])
    outputs = export_transformed_scans(
        result, tmp_path / "aligned", minimum_confidence=0
    )
    assert outputs == [tmp_path / "aligned" / "000-B1-one.laz"]
    cloud = laspy.read(outputs[0])
    assert len(cloud.points) == 4
    np.testing.assert_allclose(cloud.x, [500_000, 500_001, 500_001, 500_002])


def test_transformed_filenames_disambiguate_shared_stems(tmp_path: Path):
    (tmp_path / "a").mkdir()
    (tmp_path / "b").mkdir()
    points = np.array([[0, 0, 0], [1, 2, 3], [2, 4, 6]])
    first = ScanProject.open(make_project(tmp_path / "a" / "dup.scanproject", points))
    second = ScanProject.open(make_project(tmp_path / "b" / "dup.scanproject", points))
    prepared = prepare_scans([first, second], voxel_size=0.01, minimum_confidence=0)
    result = RegistrationResult(prepared, [np.eye(4), np.eye(4)], [])

    outputs = export_transformed_scans(
        result, tmp_path / "aligned", minimum_confidence=0
    )

    # Both packages share the stem "dup"; the source index keeps them distinct.
    assert outputs == [
        tmp_path / "aligned" / "000-dup.laz",
        tmp_path / "aligned" / "001-dup.laz",
    ]
    assert all(path.is_file() for path in outputs)


def test_exports_empty_cloud_when_confidence_filter_removes_all_points(tmp_path: Path):
    path = make_project(
        tmp_path / "one.scanproject", np.array([[0, 0, 0], [1, 2, 3], [2, 4, 6]])
    )
    scan = ScanProject.open(path)
    prepared = prepare_scans([scan], voxel_size=0.01, minimum_confidence=0)
    result = RegistrationResult(prepared, [np.eye(4)], [])
    output = tmp_path / "empty.laz"

    # A confidence threshold above every point's confidence filters them all out.
    assert (
        export_merged_cloud(result, output, minimum_confidence=5, deduplicate_voxel=0)
        == 0
    )

    cloud = laspy.read(output)
    assert len(cloud.points) == 0


def test_exports_each_original_source_as_laz(tmp_path: Path):
    path = make_project(
        tmp_path / "B1-one.scanproject",
        np.array([[0, 0, 0], [1, 2, 3], [2, 4, 6]]),
    )
    scan = ScanProject.open(path)
    prepared = prepare_scans([scan], voxel_size=0.01, minimum_confidence=0)
    result = RegistrationResult(prepared, [np.eye(4)], [])

    outputs = export_original_scans(result, tmp_path / "original", minimum_confidence=0)

    assert outputs == [tmp_path / "original" / "000-B1-one.laz"]
    cloud = laspy.read(outputs[0])
    assert len(cloud.points) == 3
    assert cloud.header.parse_crs().to_epsg() == 32618
    np.testing.assert_allclose(cloud.x, [500_000, 500_001, 500_002])
