from types import SimpleNamespace

import numpy as np
import pytest

import scanproject_merger.registration as registration_module
from config import ConfigError
from scanproject_merger.format import transform_points
from scanproject_merger.registration import (
    RegistrationEdge,
    RegistrationParams,
    optimize_pose_graph,
    rebase_transform,
    register_pair,
    rigid_transform,
    select_consistent_edges,
)
from scanproject_merger.visual import VisualRegistration


def test_registration_accuracy_defaults():
    params = RegistrationParams()
    assert params.voxel_size == 0.075
    assert params.minimum_overlap == 0.06


@pytest.mark.parametrize(
    ("environment_name", "field", "value", "expected"),
    [
        ("P2BP_REGISTRATION_VOXEL_SIZE", "voxel_size", "0.125", 0.125),
        (
            "P2BP_REGISTRATION_MINIMUM_CONFIDENCE",
            "minimum_confidence",
            "7",
            7,
        ),
        (
            "P2BP_REGISTRATION_CANDIDATE_PADDING",
            "candidate_padding",
            "0.125",
            0.125,
        ),
        (
            "P2BP_REGISTRATION_MAXIMUM_DISTANCE",
            "maximum_distance",
            "0.125",
            0.125,
        ),
        (
            "P2BP_REGISTRATION_MINIMUM_OVERLAP",
            "minimum_overlap",
            "0.125",
            0.125,
        ),
        ("P2BP_REGISTRATION_MAXIMUM_RMSE", "maximum_rmse", "0.125", 0.125),
        (
            "P2BP_REGISTRATION_MAXIMUM_LOOP_YAW_DEGREES",
            "maximum_loop_yaw_degrees",
            "0.125",
            0.125,
        ),
        (
            "P2BP_REGISTRATION_MAXIMUM_LOOP_HORIZONTAL_ERROR",
            "maximum_loop_horizontal_error",
            "0.125",
            0.125,
        ),
        (
            "P2BP_REGISTRATION_MAXIMUM_LOOP_VERTICAL_ERROR",
            "maximum_loop_vertical_error",
            "0.125",
            0.125,
        ),
        (
            "P2BP_REGISTRATION_USE_VISUAL_REGISTRATION",
            "use_visual_registration",
            "false",
            False,
        ),
        ("P2BP_REGISTRATION_ICP_ITERATIONS", "icp_iterations", "7", 7),
        (
            "P2BP_REGISTRATION_ICP_FINAL_DISTANCE",
            "icp_final_distance",
            "0.125",
            0.125,
        ),
        (
            "P2BP_REGISTRATION_ICP_MINIMUM_CORRESPONDENCES",
            "icp_minimum_correspondences",
            "7",
            7,
        ),
        (
            "P2BP_REGISTRATION_ICP_TRIM_QUANTILE",
            "icp_trim_quantile",
            "0.125",
            0.125,
        ),
        (
            "P2BP_REGISTRATION_EDGE_QUALITY_RMSE_FLOOR",
            "edge_quality_rmse_floor",
            "0.125",
            0.125,
        ),
        (
            "P2BP_REGISTRATION_POSE_GRAPH_YAW_SCALE",
            "pose_graph_yaw_scale",
            "0.125",
            0.125,
        ),
        (
            "P2BP_REGISTRATION_POSE_GRAPH_ROBUST_LOSS",
            "pose_graph_robust_loss",
            "huber",
            "huber",
        ),
        (
            "P2BP_REGISTRATION_POSE_GRAPH_ROBUST_LOSS_SCALE",
            "pose_graph_robust_loss_scale",
            "0.125",
            0.125,
        ),
        (
            "P2BP_REGISTRATION_VISUAL_MAXIMUM_KEYFRAMES",
            "visual_maximum_keyframes",
            "7",
            7,
        ),
        (
            "P2BP_REGISTRATION_VISUAL_SIFT_FEATURES",
            "visual_sift_features",
            "7",
            7,
        ),
        (
            "P2BP_REGISTRATION_VISUAL_SIFT_CONTRAST_THRESHOLD",
            "visual_sift_contrast_threshold",
            "0.125",
            0.125,
        ),
        (
            "P2BP_REGISTRATION_VISUAL_MAXIMUM_IMAGE_WIDTH",
            "visual_maximum_image_width",
            "0.125",
            0.125,
        ),
        (
            "P2BP_REGISTRATION_VISUAL_MINIMUM_KEYPOINTS",
            "visual_minimum_keypoints",
            "7",
            7,
        ),
        (
            "P2BP_REGISTRATION_VISUAL_MINIMUM_DEPTH",
            "visual_minimum_depth",
            "0.125",
            0.125,
        ),
        (
            "P2BP_REGISTRATION_VISUAL_MAXIMUM_DEPTH",
            "visual_maximum_depth",
            "0.125",
            0.125,
        ),
        (
            "P2BP_REGISTRATION_VISUAL_MINIMUM_DEPTH_CONFIDENCE",
            "visual_minimum_depth_confidence",
            "7",
            7,
        ),
        (
            "P2BP_REGISTRATION_VISUAL_FLANN_TREES",
            "visual_flann_trees",
            "7",
            7,
        ),
        (
            "P2BP_REGISTRATION_VISUAL_FLANN_CHECKS",
            "visual_flann_checks",
            "7",
            7,
        ),
        (
            "P2BP_REGISTRATION_VISUAL_MATCH_RATIO",
            "visual_match_ratio",
            "0.125",
            0.125,
        ),
        (
            "P2BP_REGISTRATION_VISUAL_MINIMUM_INLIERS",
            "visual_minimum_inliers",
            "7",
            7,
        ),
        (
            "P2BP_REGISTRATION_VISUAL_RANSAC_THRESHOLD",
            "visual_ransac_threshold",
            "0.125",
            0.125,
        ),
        (
            "P2BP_REGISTRATION_VISUAL_RANSAC_ITERATIONS",
            "visual_ransac_iterations",
            "7",
            7,
        ),
        (
            "P2BP_REGISTRATION_VISUAL_RANSAC_SEED",
            "visual_ransac_seed",
            "7",
            7,
        ),
        (
            "P2BP_REGISTRATION_VISUAL_ICP_MAXIMUM_DISTANCE",
            "visual_icp_maximum_distance",
            "0.125",
            0.125,
        ),
    ],
)
def test_registration_parameters_are_environment_overrideable(
    monkeypatch, environment_name, field, value, expected
):
    monkeypatch.setenv(environment_name, value)
    assert getattr(RegistrationParams.from_environment(), field) == expected


def test_registration_environment_rejects_invalid_combination(monkeypatch):
    monkeypatch.setenv("P2BP_REGISTRATION_MINIMUM_OVERLAP", "1.1")
    with pytest.raises(ConfigError, match="minimum_overlap"):
        RegistrationParams.from_environment()


def test_registration_environment_rejects_negative_visual_ransac_seed(monkeypatch):
    monkeypatch.setenv("P2BP_REGISTRATION_VISUAL_RANSAC_SEED", "-1")
    with pytest.raises(ConfigError, match="visual_ransac_seed must be at least 0"):
        RegistrationParams.from_environment()


def test_registration_parameters_drive_visual_icp_and_pose_pipeline(monkeypatch):
    captured = {}
    scans = [
        SimpleNamespace(
            project=object(),
            initial_transform=np.eye(4),
            projected_points=np.zeros((3, 3)),
        ),
        SimpleNamespace(
            project=object(),
            initial_transform=np.eye(4),
            projected_points=np.zeros((3, 3)),
        ),
    ]

    def fake_prepare(projects, voxel_size, minimum_confidence):
        captured["prepare"] = (projects, voxel_size, minimum_confidence)
        return scans

    def fake_candidate_pairs(prepared, padding):
        captured["candidate"] = (prepared, padding)
        return [(0, 1)]

    def fake_register_keyframes(*_args, **kwargs):
        captured["visual"] = kwargs
        return VisualRegistration(np.eye(4), 80, 40, 0.12)

    def fake_register_pair(_fixed, _moving, maximum_distance, **kwargs):
        captured["icp"] = (maximum_distance, kwargs)
        return np.eye(4), 100, 0.10, 0.50

    def fake_select(scan_count, edges, *thresholds):
        captured["select"] = (scan_count, thresholds)
        return edges, []

    def fake_optimize(scan_count, edges, **kwargs):
        captured["optimize"] = (scan_count, len(edges), kwargs)
        return [np.eye(4) for _ in range(scan_count)]

    monkeypatch.setattr(registration_module, "prepare_scans", fake_prepare)
    monkeypatch.setattr(registration_module, "candidate_pairs", fake_candidate_pairs)
    monkeypatch.setattr(
        registration_module, "register_keyframes", fake_register_keyframes
    )
    monkeypatch.setattr(registration_module, "register_pair", fake_register_pair)
    monkeypatch.setattr(registration_module, "select_consistent_edges", fake_select)
    monkeypatch.setattr(registration_module, "optimize_pose_graph", fake_optimize)

    params = RegistrationParams(
        voxel_size=0.12,
        minimum_confidence=2,
        candidate_padding=7.5,
        maximum_distance=4.0,
        maximum_loop_yaw_degrees=1.5,
        maximum_loop_horizontal_error=0.6,
        maximum_loop_vertical_error=0.7,
        icp_iterations=23,
        icp_final_distance=0.31,
        icp_minimum_correspondences=14,
        icp_trim_quantile=0.72,
        pose_graph_yaw_scale=8.0,
        pose_graph_robust_loss="cauchy",
        pose_graph_robust_loss_scale=0.18,
        visual_maximum_keyframes=17,
        visual_sift_features=321,
        visual_sift_contrast_threshold=0.031,
        visual_maximum_image_width=720,
        visual_minimum_keypoints=7,
        visual_minimum_depth=0.15,
        visual_maximum_depth=6.5,
        visual_minimum_depth_confidence=2,
        visual_flann_trees=8,
        visual_flann_checks=77,
        visual_match_ratio=0.68,
        visual_minimum_inliers=13,
        visual_ransac_threshold=0.14,
        visual_ransac_iterations=777,
        visual_ransac_seed=42,
        visual_icp_maximum_distance=0.44,
    )
    projects = [object(), object()]

    result = registration_module.register_scans(projects, params)

    assert captured["prepare"] == (projects, 0.12, 2)
    assert captured["candidate"] == (scans, 7.5)
    visual_kwargs = captured["visual"]
    assert visual_kwargs.pop("cache") == {}
    assert visual_kwargs == {
        "minimum_inliers": 13,
        "ransac_threshold": 0.14,
        "maximum_keyframes": 17,
        "sift_features": 321,
        "sift_contrast_threshold": 0.031,
        "maximum_image_width": 720,
        "minimum_keypoints": 7,
        "minimum_depth": 0.15,
        "maximum_depth": 6.5,
        "minimum_depth_confidence": 2,
        "flann_trees": 8,
        "flann_checks": 77,
        "match_ratio": 0.68,
        "ransac_iterations": 777,
        "ransac_seed": 42,
    }
    maximum_distance, icp_kwargs = captured["icp"]
    assert maximum_distance == 0.44
    np.testing.assert_array_equal(icp_kwargs.pop("initial_transform"), np.eye(4))
    assert icp_kwargs == {
        "iterations": 23,
        "final_distance": 0.31,
        "minimum_correspondences": 14,
        "trim_quantile": 0.72,
    }
    assert captured["select"] == (2, (1.5, 0.6, 0.7))
    assert captured["optimize"] == (
        2,
        1,
        {
            "yaw_scale": 8.0,
            "robust_loss": "cauchy",
            "robust_loss_scale": 0.18,
        },
    )
    assert result.edges[0].initialization == "rgbDepth"
    assert result.edges[0].visual_match_count == 80
    assert result.edges[0].visual_inlier_count == 40


def test_register_pair_recovers_yaw_and_translation():
    rng = np.random.default_rng(42)
    fixed = rng.uniform([-4, -2, -1], [4, 2, 2], size=(2_000, 3))
    expected = rigid_transform(0.07, [0.35, -0.22, 0.12])
    moving = transform_points(fixed, np.linalg.inv(expected))
    outcome = register_pair(fixed, moving, maximum_distance=1.0)
    assert outcome is not None
    actual, count, rmse, overlap = outcome
    np.testing.assert_allclose(actual, expected, atol=1e-3)
    assert count == len(fixed)
    assert rmse < 1e-3
    assert overlap == 1.0


def test_pose_graph_uses_pair_transform_as_moving_correction():
    transform = rigid_transform(0.05, [0.4, -0.1, 0.2])
    edge = RegistrationEdge(0, 1, transform, 100, 0.01, 0.5)
    corrections = optimize_pose_graph(2, [edge])
    np.testing.assert_allclose(corrections[0], np.eye(4), atol=1e-7)
    np.testing.assert_allclose(corrections[1], transform, atol=1e-6)


def test_pose_graph_handles_rotation_in_large_projected_coordinates():
    transform = rigid_transform(0.13, [-399_694.0, 85_842.0, -2.1])
    edge = RegistrationEdge(0, 1, transform, 100, 0.01, 0.5)
    corrections = optimize_pose_graph(2, [edge])
    np.testing.assert_allclose(corrections[1], transform, atol=1e-6)


def test_rebased_pose_graph_limits_multi_scan_loop_error():
    origin = np.array([465_182.0, 3_139_419.0, 27.0])
    centered_corrections = [
        np.eye(4),
        rigid_transform(0.075, [0.3, -0.2, 1.4]),
        rigid_transform(-0.055, [-0.4, 0.1, -0.6]),
    ]
    edges = []
    for fixed, moving, yaw_noise in [(0, 1, 0.001), (0, 2, -0.001), (1, 2, 0.0008)]:
        measured_centered = (
            np.linalg.inv(centered_corrections[fixed]) @ centered_corrections[moving]
        )
        measured_centered = (
            rigid_transform(yaw_noise, [0.02, -0.01, 0.01]) @ measured_centered
        )
        measured = rebase_transform(measured_centered, origin, to_centered=False)
        edges.append(RegistrationEdge(fixed, moving, measured, 100, 0.1, 0.4))
    centered = [
        RegistrationEdge(
            edge.fixed,
            edge.moving,
            rebase_transform(edge.moving_to_fixed, origin, to_centered=True),
            edge.correspondence_count,
            edge.rmse,
            edge.overlap_ratio,
        )
        for edge in edges
    ]
    optimized = optimize_pose_graph(3, centered)
    # A sub-degree inconsistent loop should stay local instead of becoming kilometre-scale translation.
    assert max(np.linalg.norm(transform[:2, 3]) for transform in optimized) < 2.0


def test_rejects_weaker_edge_with_contradictory_loop():
    strongest = RegistrationEdge(
        1, 2, rigid_transform(-0.05, [0.2, 0.1, -0.2]), 300, 0.15, 0.6
    )
    second = RegistrationEdge(
        0, 2, rigid_transform(-0.02, [0.1, 0.2, -0.1]), 200, 0.18, 0.4
    )
    contradictory = RegistrationEdge(
        0, 1, rigid_transform(-0.15, [-0.5, 0.3, 1.5]), 150, 0.27, 0.35
    )
    selected, rejected = select_consistent_edges(
        3,
        [contradictory, second, strongest],
        maximum_loop_yaw_degrees=3.0,
        maximum_loop_horizontal_error=1.0,
        maximum_loop_vertical_error=1.0,
    )
    assert selected[0] is strongest
    assert selected[1] is second
    assert len(rejected) == 1
    assert rejected[0].edge is contradictory
    assert rejected[0].loop_yaw_error_degrees > 3.0
