from pathlib import Path

import laspy
import numpy as np
import pye57
import pytest
from conftest import FakeClient
from test_format import make_project

from migrate_merged_point_cloud_e57 import (
    MergedCloudBinObject,
    Outcome,
    convert_laz_to_e57,
    migrate,
    plan_migration,
)
from scanproject_merger import export_merged_cloud
from scanproject_merger.format import ScanProject
from scanproject_merger.registration import RegistrationResult, prepare_scans

JOB_PREFIX = "organizations/org_1/projects/proj_1/mesh-jobs/job_1"
LEGACY_PREFIX = "organizations/org_1/projects/proj_2"


def _merged_laz_bytes(tmp_path: Path) -> bytes:
    """A real merged-cloud LAZ, so the migration exercises a genuine conversion."""

    path = make_project(
        tmp_path / "one.scanproject", np.array([[0, 0, 0], [1, 2, 3], [2, 4, 6]])
    )
    scan = ScanProject.open(path)
    prepared = prepare_scans([scan], voxel_size=0.01, minimum_confidence=0)
    result = RegistrationResult(prepared, [np.eye(4)], [])
    output = tmp_path / "merged.laz"
    export_merged_cloud(result, output, minimum_confidence=0, deduplicate_voxel=0)
    return output.read_bytes()


@pytest.fixture
def merged_laz(tmp_path: Path) -> bytes:
    source = tmp_path / "source"
    source.mkdir()
    return _merged_laz_bytes(source)


def test_plans_versioned_and_legacy_merged_clouds():
    planned = plan_migration(
        [
            f"{JOB_PREFIX}/merged-point-cloud.bin",
            f"{JOB_PREFIX}/merged-point-cloud.preview.bin",
            f"{LEGACY_PREFIX}/merged-point-cloud.bin",
        ]
    )

    assert planned == [
        MergedCloudBinObject(
            bin_key=f"{JOB_PREFIX}/merged-point-cloud.bin",
            laz_key=f"{JOB_PREFIX}/merged-point-cloud.laz",
            e57_key=f"{JOB_PREFIX}/merged-point-cloud.e57",
        ),
        MergedCloudBinObject(
            bin_key=f"{JOB_PREFIX}/merged-point-cloud.preview.bin",
            laz_key=f"{JOB_PREFIX}/merged-point-cloud.preview.laz",
            e57_key=f"{JOB_PREFIX}/merged-point-cloud.preview.e57",
        ),
        MergedCloudBinObject(
            bin_key=f"{LEGACY_PREFIX}/merged-point-cloud.bin",
            laz_key=f"{LEGACY_PREFIX}/merged-point-cloud.laz",
            e57_key=f"{LEGACY_PREFIX}/merged-point-cloud.e57",
        ),
    ]


def test_leaves_zone_scan_previews_and_other_objects_alone():
    assert (
        plan_migration(
            [
                "organizations/org_1/projects/proj_1/scans/upload_1.preview.bin",
                "organizations/org_1/projects/proj_1/scans/upload_1.zip",
                f"{JOB_PREFIX}/merged-point-cloud.laz",
                f"{JOB_PREFIX}/status.json",
                "merged-point-cloud.bin",  # No prefix: not a project artifact.
            ]
        )
        == []
    )


def test_migrates_bin_to_an_e57_rebuilt_from_the_laz(merged_laz: bytes, tmp_path: Path):
    client = FakeClient(
        payload=merged_laz,
        existing={
            f"{JOB_PREFIX}/merged-point-cloud.bin",
            f"{JOB_PREFIX}/merged-point-cloud.laz",
            f"{JOB_PREFIX}/status.json",
        },
    )

    counts = migrate(client, bucket="bucket", apply=True)

    assert counts[Outcome.MIGRATED] == 1
    assert [key for _, _, key in client.upload_calls] == [
        f"{JOB_PREFIX}/merged-point-cloud.e57"
    ]
    assert client.delete_calls == [("bucket", f"{JOB_PREFIX}/merged-point-cloud.bin")]

    # The uploaded E57 must hold the LAZ's points, georeferenced through the pose.
    uploaded = tmp_path / "uploaded.e57"
    uploaded.write_bytes(client.objects[f"{JOB_PREFIX}/merged-point-cloud.e57"])
    reader = pye57.E57(str(uploaded))
    try:
        scan_data = reader.read_scan(0, colors=True, ignore_missing_fields=True)
    finally:
        reader.image_file.close()
    source = tmp_path / "source.laz"
    source.write_bytes(merged_laz)
    cloud = laspy.read(str(source))
    np.testing.assert_allclose(
        np.column_stack(
            (
                scan_data["cartesianX"],
                scan_data["cartesianY"],
                scan_data["cartesianZ"],
            )
        ),
        np.column_stack((cloud.x, cloud.y, cloud.z)),
        atol=0.001,
    )


def test_dry_run_reports_without_writing_or_deleting(merged_laz: bytes):
    client = FakeClient(
        payload=merged_laz,
        existing={
            f"{JOB_PREFIX}/merged-point-cloud.bin",
            f"{JOB_PREFIX}/merged-point-cloud.laz",
        },
    )

    counts = migrate(client, bucket="bucket")

    assert counts[Outcome.MIGRATED] == 1
    assert client.upload_calls == []
    assert client.delete_calls == []
    assert client.calls == []  # Nothing downloaded either.


def test_deletes_the_bin_when_the_e57_already_exists(merged_laz: bytes):
    client = FakeClient(
        payload=merged_laz,
        existing={
            f"{JOB_PREFIX}/merged-point-cloud.bin",
            f"{JOB_PREFIX}/merged-point-cloud.laz",
            f"{JOB_PREFIX}/merged-point-cloud.e57",
        },
    )

    counts = migrate(client, bucket="bucket", apply=True)

    assert counts[Outcome.E57_ALREADY_PRESENT] == 1
    assert client.upload_calls == []
    assert client.delete_calls == [("bucket", f"{JOB_PREFIX}/merged-point-cloud.bin")]


def test_keeps_the_bin_when_its_laz_is_missing():
    client = FakeClient(existing={f"{JOB_PREFIX}/merged-point-cloud.bin"})

    counts = migrate(client, bucket="bucket", apply=True)

    assert counts[Outcome.MISSING_LAZ] == 1
    assert client.upload_calls == []
    assert client.delete_calls == []


def test_one_unconvertible_cloud_does_not_strand_the_others(merged_laz: bytes):
    other_prefix = "organizations/org_1/projects/proj_9/mesh-jobs/job_9"
    client = FakeClient(
        payload=merged_laz,
        existing={
            f"{JOB_PREFIX}/merged-point-cloud.bin",
            f"{JOB_PREFIX}/merged-point-cloud.laz",
            f"{other_prefix}/merged-point-cloud.bin",
            f"{other_prefix}/merged-point-cloud.laz",
        },
    )
    failing_key = f"{other_prefix}/merged-point-cloud.laz"
    original_download = client.download_file

    def download_file(bucket: str, key: str, dest: str) -> None:
        if key == failing_key:
            raise RuntimeError("object is corrupt")
        original_download(bucket, key, dest)

    client.download_file = download_file

    counts = migrate(client, bucket="bucket", apply=True)

    assert counts[Outcome.MIGRATED] == 1
    assert counts[Outcome.FAILED] == 1
    # The healthy cloud still migrated; the failed one kept its .bin.
    assert client.delete_calls == [("bucket", f"{JOB_PREFIX}/merged-point-cloud.bin")]


def test_conversion_requires_a_georeferenced_laz(tmp_path: Path):
    header = laspy.LasHeader(point_format=7, version="1.4")
    header.offsets = np.zeros(3)
    header.scales = np.array([0.001, 0.001, 0.001])
    cloud = laspy.LasData(header)
    cloud.x, cloud.y, cloud.z = np.array([[0.0], [0.0], [0.0]])
    laz_path = tmp_path / "no-crs.laz"
    cloud.write(str(laz_path))

    with pytest.raises(ValueError, match="no EPSG code"):
        convert_laz_to_e57(laz_path, tmp_path / "out.e57")
