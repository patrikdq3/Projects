import pytest

import config


def test_require_env_returns_value(monkeypatch):
    monkeypatch.setenv("P2BP_TEST_VAR", "value")
    assert config.require_env("P2BP_TEST_VAR") == "value"


def test_require_env_missing_raises(monkeypatch):
    monkeypatch.delenv("P2BP_TEST_VAR", raising=False)
    with pytest.raises(config.ConfigError):
        config.require_env("P2BP_TEST_VAR")


def test_require_env_empty_string_is_missing(monkeypatch):
    monkeypatch.setenv("P2BP_TEST_VAR", "")
    with pytest.raises(config.ConfigError):
        config.require_env("P2BP_TEST_VAR")


def test_config_error_is_runtime_error():
    assert issubclass(config.ConfigError, RuntimeError)


@pytest.mark.parametrize(
    ("value", "expected"),
    [("true", True), ("YES", True), ("0", False), ("off", False)],
)
def test_env_bool_parses_supported_values(monkeypatch, value, expected):
    monkeypatch.setenv("P2BP_TEST_VAR", value)
    assert config.env_bool("P2BP_TEST_VAR", not expected) is expected


def test_optional_environment_helpers_use_defaults(monkeypatch):
    monkeypatch.delenv("P2BP_TEST_VAR", raising=False)
    assert config.env_int("P2BP_TEST_VAR", 3) == 3
    assert config.env_float("P2BP_TEST_VAR", 0.25) == 0.25
    assert config.env_string("P2BP_TEST_VAR", "default") == "default"


@pytest.mark.parametrize("value", ["nan", "inf", "-inf", "not-a-number"])
def test_env_float_rejects_non_finite_or_invalid_values(monkeypatch, value):
    monkeypatch.setenv("P2BP_TEST_VAR", value)
    with pytest.raises(config.ConfigError):
        config.env_float("P2BP_TEST_VAR", 1.0)


def test_env_int_rejects_invalid_value(monkeypatch):
    monkeypatch.setenv("P2BP_TEST_VAR", "1.5")
    with pytest.raises(config.ConfigError):
        config.env_int("P2BP_TEST_VAR", 1)


def test_env_bool_rejects_invalid_value(monkeypatch):
    monkeypatch.setenv("P2BP_TEST_VAR", "sometimes")
    with pytest.raises(config.ConfigError):
        config.env_bool("P2BP_TEST_VAR", True)
