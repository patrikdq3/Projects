import json
from dataclasses import replace
from pathlib import Path

import numpy as np
import pytest
from shapely.geometry import MultiPoint

from viewer_analysis import (
    INFERRED_BLOCKER_FLAG,
    NORMAL_VALID_FLAG,
    _build_outlines,
    _despike_ground,
    _object_labels,
    _outline_polygon,
    _relax_ground,
    analyze_points,
    write_viewer_metadata,
)

FIXTURES = Path(__file__).parent / "fixtures"


def _reference_despike_ground(ground):
    source = ground.copy()
    result = source.copy()
    height, width = source.shape
    for y in range(height):
        for x in range(width):
            if not np.isfinite(source[y, x]):
                continue
            neighbors = source[
                max(0, y - 1) : min(height, y + 2),
                max(0, x - 1) : min(width, x + 2),
            ]
            values = neighbors[np.isfinite(neighbors)]
            if len(values) >= 4:
                median = float(np.median(values))
                if source[y, x] < median - 2.5:
                    result[y, x] = median
    return result


def _reference_relax_ground(ground, cell_size):
    result = ground.copy()
    axial = cell_size
    diagonal = axial * np.sqrt(2.0)
    height, width = result.shape
    for _ in range(2):
        for y in range(height):
            for x in range(width):
                candidates = [result[y, x]]
                if x > 0:
                    candidates.append(result[y, x - 1] + axial)
                if y > 0:
                    candidates.append(result[y - 1, x] + axial)
                    if x > 0:
                        candidates.append(result[y - 1, x - 1] + diagonal)
                    if x + 1 < width:
                        candidates.append(result[y - 1, x + 1] + diagonal)
                result[y, x] = min(candidates)
        for y in range(height - 1, -1, -1):
            for x in range(width - 1, -1, -1):
                candidates = [result[y, x]]
                if x + 1 < width:
                    candidates.append(result[y, x + 1] + axial)
                if y + 1 < height:
                    candidates.append(result[y + 1, x] + axial)
                    if x > 0:
                        candidates.append(result[y + 1, x - 1] + diagonal)
                    if x + 1 < width:
                        candidates.append(result[y + 1, x + 1] + diagonal)
                result[y, x] = min(candidates)
    return result


def test_vectorized_ground_filters_match_cellwise_algorithms():
    rng = np.random.default_rng(42)
    ground = rng.uniform(-2, 8, size=(9, 11)).astype(np.float32)
    ground[rng.random(ground.shape) < 0.3] = np.inf

    despiked = _despike_ground(ground)

    np.testing.assert_allclose(despiked, _reference_despike_ground(ground))
    np.testing.assert_allclose(
        _relax_ground(despiked, 0.75),
        _reference_relax_ground(despiked, 0.75),
        rtol=1e-6,
        atol=1e-6,
    )


def test_viewer_analysis_matches_cross_platform_golden_vector():
    golden = json.loads(
        (FIXTURES / "viewer_analysis_golden.json").read_text(encoding="utf-8")
    )
    normal_z = np.array(
        [np.nan if value is None else value for value in golden["normalZ"]]
    )

    analysis = analyze_points(
        np.array(golden["xyz"]),
        classification=np.array(golden["classification"], dtype=np.uint8),
        normal_z_values=normal_z,
        initial_surface_flags=np.array(golden["initialSurfaceFlags"], dtype=np.uint8),
    )

    assert golden["analysisVersion"] == 2
    assert analysis.floor_height == golden["floorHeight"]
    np.testing.assert_array_equal(
        analysis.height_above_ground_cm, golden["expectedHagCm"]
    )
    np.testing.assert_array_equal(analysis.normal_z, golden["expectedNormalZ"])
    np.testing.assert_array_equal(
        analysis.surface_flags, golden["expectedSurfaceFlags"]
    )


def test_analysis_safety_valve_clears_inference_when_most_points_are_removed():
    local_ground = np.array(
        [
            [0.0, 0.0, 0.0],
            [0.1, 0.0, 0.0],
            [0.0, 0.1, 0.0],
            [0.1, 0.1, 0.0],
            [3.0, 0.0, 0.0],
            [0.0, 3.0, 0.0],
        ]
    )
    overhead = np.column_stack(
        (
            np.linspace(0.2, 0.7, 50),
            np.linspace(0.7, 0.2, 50),
            np.full(50, 3.0),
        )
    )

    analysis = analyze_points(np.vstack((local_ground, overhead)))

    assert np.count_nonzero(analysis.surface_flags & INFERRED_BLOCKER_FLAG) == 0
    np.testing.assert_array_equal(analysis.height_above_ground_cm[-50:], 300)


def test_analysis_quantizes_normals_and_height_for_the_viewer():
    ground = np.column_stack(
        np.meshgrid(np.arange(4, dtype=float), np.arange(4, dtype=float))
    ).reshape(-1, 2)
    xyz = np.column_stack((ground, np.zeros(len(ground))))
    xyz = np.vstack((xyz, [1.0, 1.0, 2.5]))
    normals = np.full(len(xyz), np.nan)
    normals[-1] = -1.0

    analysis = analyze_points(xyz, normal_z_values=normals)

    assert analysis.height_above_ground_cm[-1] == 250
    assert analysis.normal_z[-1] == -127
    assert analysis.surface_flags[-1] & NORMAL_VALID_FLAG
    assert analysis.normal_coverage == 1 / len(xyz)


def test_analysis_keeps_normals_unknown_for_legacy_scans():
    xyz = np.array([[0.0, 0.0, 0.0], [2.0, 0.0, 2.5]])

    analysis = analyze_points(xyz)

    np.testing.assert_array_equal(analysis.normal_z, [-128, -128])
    assert analysis.normal_coverage == 0


def test_analysis_uses_finite_fallbacks_for_nan_height():
    xyz = np.array([[0.0, 0.0, 0.0], [0.1, 0.1, np.nan], [0.2, 0.2, 2.0]])

    analysis = analyze_points(xyz)

    assert np.isfinite(analysis.floor_height)
    assert analysis.height_above_ground_cm[1] == 0


def test_analysis_keeps_point_attributes_when_outline_generation_fails(
    monkeypatch,
):
    def raise_outline_error(*_args):
        raise RuntimeError("outline failure")

    monkeypatch.setattr("viewer_analysis._build_outlines", raise_outline_error)

    analysis = analyze_points(np.array([[0.0, 0.0, 2.5]]))

    assert analysis.height_above_ground_cm[0] == 0
    assert analysis.outlines == []


def test_viewer_metadata_writes_strict_json_and_coerces_non_finite_floor(tmp_path):
    analysis = analyze_points(np.array([[0.0, 0.0, 0.0]]))
    output = tmp_path / "viewer.json"

    write_viewer_metadata(
        output,
        replace(analysis, floor_height=np.nan),
        full_point_count=1,
        preview_point_count=1,
    )

    payload = json.loads(output.read_text(encoding="utf-8"))
    assert payload["floorHeight"] == 0.0
    assert set(payload) == {
        "analysisVersion",
        "floorHeight",
        "formatVersion",
        "fullPointCount",
        "normalCoverage",
        "outlines",
        "previewPointCount",
    }

    with pytest.raises(ValueError, match="Out of range float values"):
        write_viewer_metadata(
            output,
            replace(analysis, normal_coverage=np.nan),
            full_point_count=1,
            preview_point_count=1,
        )


def test_viewer_metadata_matches_swift_outline_contract(tmp_path):
    analysis = replace(
        analyze_points(np.array([[0.0, 0.0, 0.0]])),
        floor_height=12.5,
        normal_coverage=0.75,
        outlines=[
            {
                "category": "building",
                "coordinates": [
                    [500_000.0, 4_500_000.0, 12.5],
                    [500_001.0, 4_500_000.0, 12.5],
                ],
            }
        ],
    )
    output = tmp_path / "viewer.json"

    write_viewer_metadata(
        output,
        analysis,
        full_point_count=123,
        preview_point_count=45,
    )

    assert json.loads(output.read_text(encoding="utf-8")) == {
        "formatVersion": 1,
        "analysisVersion": 2,
        "floorHeight": 12.5,
        "normalCoverage": 0.75,
        "fullPointCount": 123,
        "previewPointCount": 45,
        "outlines": [
            {
                "category": "building",
                "coordinates": [
                    [500_000.0, 4_500_000.0, 12.5],
                    [500_001.0, 4_500_000.0, 12.5],
                ],
            }
        ],
    }


def test_viewer_metadata_preserves_existing_file_when_atomic_replace_fails(
    tmp_path,
    monkeypatch,
):
    analysis = analyze_points(np.array([[0.0, 0.0, 0.0]]))
    output = tmp_path / "viewer.json"
    output.write_text("existing", encoding="utf-8")

    def fail_replace(*_args):
        raise OSError("replace failed")

    monkeypatch.setattr("viewer_analysis.os.replace", fail_replace)

    with pytest.raises(OSError, match="replace failed"):
        write_viewer_metadata(
            output,
            analysis,
            full_point_count=1,
            preview_point_count=1,
        )

    assert output.read_text(encoding="utf-8") == "existing"
    assert list(tmp_path.iterdir()) == [output]


def test_object_labels_keep_component_when_all_seed_partitions_are_too_small():
    occupied = np.ones((2, 4), dtype=bool)
    support = np.zeros_like(occupied)
    support[:, 0] = True
    support[:, 3] = True

    labels, count = _object_labels(occupied, support)

    assert count == 1
    np.testing.assert_array_equal(labels, np.ones_like(labels))


def test_outlines_split_overlapping_crowns_using_separate_low_supports():
    x, y = np.meshgrid(np.linspace(-2.4, 2.4, 25), np.linspace(-1.4, 1.4, 15))
    overhead = np.column_stack((x.ravel(), y.ravel(), np.full(x.size, 3.0)))
    left_support = np.column_stack(
        (
            np.full(8, -1.5),
            np.linspace(-0.2, 0.2, 8),
            np.linspace(0.2, 1.4, 8),
        )
    )
    right_support = left_support.copy()
    right_support[:, 0] = 1.5
    xyz = np.vstack((overhead, left_support, right_support))
    classifications = np.zeros(len(xyz), dtype=np.uint8)
    flags = np.zeros(len(xyz), dtype=np.uint8)
    flags[: len(overhead)] = INFERRED_BLOCKER_FLAG
    heights = xyz[:, 2].copy()

    outlines = _build_outlines(xyz, classifications, flags, heights)

    assert [outline["category"] for outline in outlines] == ["inferred", "inferred"]


def test_outline_polygon_preserves_deep_concave_inset():
    centers = np.array(
        [(x, y) for x in range(7) for y in range(9) if x <= 1 or x >= 5 or y <= 1],
        dtype=float,
    )

    outline = _outline_polygon(centers, cell_size=1.0)

    assert outline.area < MultiPoint(centers).convex_hull.area
    assert len(outline.exterior.coords) >= 16
