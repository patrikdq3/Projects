import json
import logging
from pathlib import Path

import numpy as np
import pytest

from scanproject_merger.format import (
    POINT_DTYPE,
    ScanProject,
    ScanProjectError,
    transform_points,
)


def make_project(path: Path, points: np.ndarray, *, easting: float = 500_000.0) -> Path:
    path.mkdir()
    records = np.zeros(len(points), dtype=POINT_DTYPE)
    records["position"] = points
    records["color"] = [10, 20, 30]
    records["confidence"] = np.arange(len(points)) % 3
    records["timestamp"] = np.arange(len(points)) * 0.1
    records.tofile(path / "chunk-00001.bin")
    manifest = {
        "id": path.stem,
        "pointCount": len(points),
        "chunkCount": 1,
        "voxelSizeMeters": 0.02,
        "geoReference": {
            "epsgCode": 32618,
            "originEasting": easting,
            "originNorthing": 4_500_000.0,
            "originAltitude": 100.0,
            "originHorizontalAccuracy": 3.0,
            "originVerticalAccuracy": 5.0,
            "headingAccuracy": 8.0,
            "worldToENURotationRadians": 0.0,
        },
    }
    (path / "manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
    return path


def make_mesh_project(path: Path) -> tuple[Path, dict]:
    make_project(path, np.zeros((3, 3)))
    payloads = path / "mesh-anchors"
    payloads.mkdir()
    np.array([[0, 0, 0], [1, 0, 0], [0, 1, 0]], dtype="<f4").tofile(
        payloads / "anchor.vertices.bin"
    )
    np.array([[0, 0, -1]] * 3, dtype="<f4").tofile(payloads / "anchor.normals.bin")
    np.array([[0, 1, 2]], dtype="<u4").tofile(payloads / "anchor.faces.bin")
    np.array([3], dtype="u1").tofile(payloads / "anchor.classes.bin")
    catalog = {
        "formatVersion": 2,
        "anchors": [
            {
                "transform": np.eye(4, dtype=np.float32).T.reshape(-1).tolist(),
                "vertexCount": 3,
                "verticesFilename": "anchor.vertices.bin",
                "faceCount": 1,
                "faceIndexCountPerPrimitive": 3,
                "faceVertexIndicesFilename": "anchor.faces.bin",
                "vertexNormalsFilename": "anchor.normals.bin",
                "faceClassificationFilename": "anchor.classes.bin",
            }
        ],
    }
    (path / "mesh-anchors.json").write_text(json.dumps(catalog), encoding="utf-8")
    return path, catalog


def test_reads_binary_records_and_filters_confidence(tmp_path: Path):
    path = make_project(tmp_path / "one.scanproject", np.arange(18).reshape(6, 3))
    project = ScanProject.open(path)
    points = project.points(minimum_confidence=2)
    assert POINT_DTYPE.itemsize == 24
    np.testing.assert_array_equal(points.confidence, [2, 2])
    np.testing.assert_array_equal(points.colors, [[10, 20, 30], [10, 20, 30]])


def test_drops_non_finite_coordinates_and_keeps_records_aligned(
    tmp_path: Path, caplog: pytest.LogCaptureFixture
):
    path = make_project(
        tmp_path / "non-finite.scanproject",
        np.array(
            [
                [0, 0, 0],
                [np.nan, 1, 2],
                [3, 4, 5],
                [6, np.inf, 7],
            ]
        ),
    )
    project = ScanProject.open(path)

    with caplog.at_level(logging.WARNING, logger="scanproject_merger.format"):
        points = project.points()

    np.testing.assert_array_equal(points.positions, [[0, 0, 0], [3, 4, 5]])
    np.testing.assert_array_equal(points.confidence, [0, 2])
    np.testing.assert_array_equal(points.timestamps, [0.0, 0.2])
    assert "Dropped 2 point(s) with non-finite coordinates" in caplog.text
    assert str(path) in caplog.text


def test_georeference_matches_scanner_axis_mapping(tmp_path: Path):
    project = ScanProject.open(
        make_project(tmp_path / "one.scanproject", np.zeros((3, 3)))
    )
    actual = transform_points(
        np.array([[2.0, 3.0, 4.0]]), project.georeference.local_to_projected()
    )
    np.testing.assert_allclose(actual, [[500_002.0, 4_499_996.0, 103.0]])


def test_rejects_inconsistent_point_count(tmp_path: Path):
    path = make_project(tmp_path / "bad.scanproject", np.zeros((3, 3)))
    manifest = json.loads((path / "manifest.json").read_text())
    manifest["pointCount"] = 4
    (path / "manifest.json").write_text(json.dumps(manifest))
    with pytest.raises(ScanProjectError, match="chunks contain 3"):
        ScanProject.open(path)


def test_rejects_point_count_above_the_limit(tmp_path: Path):
    path = make_project(tmp_path / "huge.scanproject", np.zeros((3, 3)))
    manifest = json.loads((path / "manifest.json").read_text())
    manifest["pointCount"] = (
        10_000_000_000  # Absurd count that should be refused before reading chunks.
    )
    (path / "manifest.json").write_text(json.dumps(manifest))
    with pytest.raises(ScanProjectError, match="exceeding the"):
        ScanProject.open(path, maximum_points=1_000_000)


def test_rejects_negative_counts(tmp_path: Path):
    path = make_project(tmp_path / "neg.scanproject", np.zeros((3, 3)))
    manifest = json.loads((path / "manifest.json").read_text())
    manifest["pointCount"] = -1
    (path / "manifest.json").write_text(json.dumps(manifest))
    with pytest.raises(ScanProjectError, match="negative counts"):
        ScanProject.open(path)


def test_reads_v2_mesh_normals_and_face_classifications(tmp_path: Path):
    path = make_project(tmp_path / "mesh.scanproject", np.zeros((3, 3)))
    payloads = path / "mesh-anchors"
    payloads.mkdir()
    vertices = np.array([[0, 0, 0], [1, 0, 0], [0, 1, 0]], dtype="<f4")
    normals = np.array([[0, 0, -1]] * 3, dtype="<f4")
    faces = np.array([[0, 1, 2]], dtype="<u4")
    vertices.tofile(payloads / "anchor.vertices.bin")
    normals.tofile(payloads / "anchor.normals.bin")
    faces.tofile(payloads / "anchor.faces.bin")
    np.array([3], dtype="u1").tofile(payloads / "anchor.classes.bin")
    catalog = {
        "formatVersion": 2,
        "anchors": [
            {
                "transform": np.eye(4, dtype=np.float32).T.reshape(-1).tolist(),
                "vertexCount": 3,
                "verticesFilename": "anchor.vertices.bin",
                "faceCount": 1,
                "faceIndexCountPerPrimitive": 3,
                "faceVertexIndicesFilename": "anchor.faces.bin",
                "vertexNormalsFilename": "anchor.normals.bin",
                "faceClassificationFilename": "anchor.classes.bin",
            }
        ],
    }
    (path / "mesh-anchors.json").write_text(json.dumps(catalog), encoding="utf-8")

    anchors = ScanProject.open(path).mesh_anchors()

    assert len(anchors) == 1
    np.testing.assert_array_equal(anchors[0].vertices, vertices)
    np.testing.assert_array_equal(anchors[0].normals, normals)
    np.testing.assert_array_equal(anchors[0].faces, faces)
    np.testing.assert_array_equal(anchors[0].face_classifications, [3])


@pytest.mark.parametrize(
    "filename",
    ["../outside.bin", "/tmp/outside.bin"],
)
def test_mesh_anchors_reject_unsafe_payload_paths(tmp_path: Path, filename: str):
    path, catalog = make_mesh_project(tmp_path / "unsafe.scanproject")
    catalog["anchors"][0]["verticesFilename"] = filename
    (path / "mesh-anchors.json").write_text(json.dumps(catalog), encoding="utf-8")

    with pytest.raises(ScanProjectError, match="unsafe mesh payload path"):
        ScanProject.open(path).mesh_anchors()


@pytest.mark.parametrize(
    ("catalog_update", "message"),
    [
        ({"formatVersion": 3}, "unsupported mesh catalog format"),
        ({"anchors": {}}, "unsupported mesh catalog format"),
        ({"anchors": [None]}, "invalid mesh record"),
    ],
)
def test_mesh_anchors_reject_invalid_catalog_records(
    tmp_path: Path,
    catalog_update: dict,
    message: str,
):
    path, catalog = make_mesh_project(tmp_path / "invalid-catalog.scanproject")
    catalog.update(catalog_update)
    (path / "mesh-anchors.json").write_text(json.dumps(catalog), encoding="utf-8")

    with pytest.raises(ScanProjectError, match=message):
        ScanProject.open(path).mesh_anchors()


def test_mesh_anchors_reject_missing_payload(tmp_path: Path):
    path, catalog = make_mesh_project(tmp_path / "missing-payload.scanproject")
    catalog["anchors"][0]["verticesFilename"] = "missing.bin"
    (path / "mesh-anchors.json").write_text(json.dumps(catalog), encoding="utf-8")

    with pytest.raises(ScanProjectError, match="missing mesh payload"):
        ScanProject.open(path).mesh_anchors()


@pytest.mark.parametrize(
    ("field", "value"),
    [
        ("transform", [0.0] * 15),
        ("vertexCount", 4),
    ],
)
def test_mesh_anchors_reject_mismatched_payload_shapes(
    tmp_path: Path,
    field: str,
    value: object,
):
    path, catalog = make_mesh_project(tmp_path / "bad-shape.scanproject")
    catalog["anchors"][0][field] = value
    (path / "mesh-anchors.json").write_text(json.dumps(catalog), encoding="utf-8")

    with pytest.raises(ScanProjectError, match="invalid mesh record"):
        ScanProject.open(path).mesh_anchors()


def test_mesh_anchors_reject_mismatched_classification_count(tmp_path: Path):
    path, _ = make_mesh_project(tmp_path / "bad-classes.scanproject")
    np.array([2, 3], dtype="u1").tofile(path / "mesh-anchors" / "anchor.classes.bin")

    with pytest.raises(ScanProjectError, match="classification count"):
        ScanProject.open(path).mesh_anchors()


def test_mesh_anchors_reject_non_triangle_faces(tmp_path: Path):
    path, catalog = make_mesh_project(tmp_path / "bad-arity.scanproject")
    catalog["anchors"][0]["faceIndexCountPerPrimitive"] = 2
    np.array([[0, 1]], dtype="<u4").tofile(path / "mesh-anchors" / "anchor.faces.bin")
    (path / "mesh-anchors.json").write_text(json.dumps(catalog), encoding="utf-8")

    with pytest.raises(ScanProjectError, match="invalid mesh triangle indices"):
        ScanProject.open(path).mesh_anchors()


def test_mesh_anchors_reject_out_of_range_face_indices(tmp_path: Path):
    path, _ = make_mesh_project(tmp_path / "bad-index.scanproject")
    np.array([[0, 1, 3]], dtype="<u4").tofile(
        path / "mesh-anchors" / "anchor.faces.bin"
    )

    with pytest.raises(ScanProjectError, match="invalid mesh triangle indices"):
        ScanProject.open(path).mesh_anchors()
