"""LAS/LAZ, E57 and audit-report output for a registration result."""

from __future__ import annotations

import json
import os
import uuid
from dataclasses import dataclass
from pathlib import Path

import laspy
import numpy as np
import pye57
from pye57 import libe57
from pyproj import CRS
from scipy.spatial import cKDTree

from viewer_analysis import (
    CEILING_FLAG,
    PointViewerAnalysis,
    analyze_points,
)

from .format import transform_points
from .registration import RegistrationResult


def _temp_sibling(output: Path) -> Path:
    """A unique temp path beside ``output`` that preserves its suffix.

    laspy detects LAS vs LAZ from the file extension, so the temp file must end
    in the same suffix as the final output.
    """
    return output.with_suffix(f".{os.getpid()}.tmp{output.suffix}")


def _write_cloud(
    output: Path,
    xyz: np.ndarray,
    rgb: np.ndarray,
    confidence: np.ndarray,
    timestamps: np.ndarray,
    source_ids: np.ndarray,
    classification: np.ndarray,
    analysis: PointViewerAnalysis,
    epsg: int,
) -> None:
    header = laspy.LasHeader(
        point_format=7, version="1.4"
    )  # LAS 1.4 format 7 supports RGB.
    header.scales = np.array(
        [0.001, 0.001, 0.001]
    )  # Store coordinates at 1 mm resolution.
    # An all-filtered scan yields no points; fall back to a zero origin so the
    # empty cloud still writes instead of crashing on min() of an empty array.
    header.offsets = xyz.min(axis=0) if len(xyz) else np.zeros(3)
    header.add_crs(CRS.from_epsg(epsg))
    header.add_extra_dim(laspy.ExtraBytesParams(name="confidence", type=np.uint8))
    header.add_extra_dim(laspy.ExtraBytesParams(name="source_id", type=np.uint16))
    header.add_extra_dim(laspy.ExtraBytesParams(name="scan_time", type=np.float64))
    header.add_extra_dim(laspy.ExtraBytesParams(name="p2bp_hag_cm", type=np.uint16))
    header.add_extra_dim(laspy.ExtraBytesParams(name="p2bp_normal_z", type=np.int8))
    header.add_extra_dim(
        laspy.ExtraBytesParams(name="p2bp_surface_flags", type=np.uint8)
    )
    cloud = laspy.LasData(header)
    cloud.x, cloud.y, cloud.z = xyz.T
    # Expand 8-bit RGB to LAS 16-bit RGB; 255 * 257 maps exactly to 65535.
    cloud.red = rgb[:, 0].astype(np.uint16) * 257
    cloud.green = rgb[:, 1].astype(np.uint16) * 257
    cloud.blue = rgb[:, 2].astype(np.uint16) * 257
    cloud.confidence = confidence
    cloud.source_id = source_ids
    cloud.scan_time = timestamps
    cloud.classification = classification
    cloud.p2bp_hag_cm = analysis.height_above_ground_cm
    cloud.p2bp_normal_z = analysis.normal_z
    cloud.p2bp_surface_flags = analysis.surface_flags
    # Write to a sibling temp file then atomically replace, so a crash or a
    # concurrent reader never observes a half-written cloud.
    temp = _temp_sibling(output)
    try:
        cloud.write(str(temp))
        os.replace(temp, output)
    except BaseException:
        temp.unlink(missing_ok=True)
        raise


# E57 scan pose rotation: identity quaternion (w, x, y, z). The merged cloud is
# already in the output frame, so the pose only carries a translation.
_E57_IDENTITY_ROTATION = np.array([1.0, 0.0, 0.0, 0.0])

# ScanProject confidence is ARKit's 0-2 scale; E57 intensity is conventionally
# normalized, and readers that show intensity expect [0, 1].
_E57_MAX_CONFIDENCE = 2.0


def _open_e57_writer(output: Path, epsg: int) -> pye57.E57:
    """Open ``output`` for writing with the cloud's CRS in ``coordinateMetadata``.

    This is `pye57.E57(path, mode="w")` plus a georeference: pye57's constructor
    writes a header whose ``coordinateMetadata`` is the empty string, and libE57
    rejects overwriting an existing field (``ErrorSetTwice``), so the standard
    header is written here instead. Keep in sync with pye57's
    ``write_default_header`` when upgrading the dependency.
    """
    writer = pye57.E57.__new__(pye57.E57)
    writer.path = str(output)
    image_file = libe57.ImageFile(str(output), "w")
    writer.image_file = image_file
    try:
        image_file.extensionsAdd("", libe57.E57_V1_0_URI)
        root = image_file.root()
        root.set(
            "formatName",
            libe57.StringNode(image_file, "ASTM E57 3D Imaging Data File"),
        )
        root.set("guid", libe57.StringNode(image_file, f"{{{uuid.uuid4()}}}"))
        root.set(
            "versionMajor", libe57.IntegerNode(image_file, libe57.E57_FORMAT_MAJOR)
        )
        root.set(
            "versionMinor", libe57.IntegerNode(image_file, libe57.E57_FORMAT_MINOR)
        )
        root.set(
            "e57LibraryVersion",
            libe57.StringNode(image_file, libe57.E57_LIBRARY_ID),
        )
        root.set(
            "coordinateMetadata",
            libe57.StringNode(image_file, CRS.from_epsg(epsg).to_wkt()),
        )
        creation_date_time = libe57.StructureNode(image_file)
        creation_date_time.set("dateTimeValue", libe57.FloatNode(image_file, 0.0))
        creation_date_time.set(
            "isAtomicClockReferenced", libe57.IntegerNode(image_file, 0)
        )
        root.set("creationDateTime", creation_date_time)
        root.set("data3D", libe57.VectorNode(image_file, True))
        root.set("images2D", libe57.VectorNode(image_file, True))
    except BaseException:
        image_file.close()
        raise
    return writer


def write_e57_cloud(
    output: Path,
    xyz: np.ndarray,
    rgb: np.ndarray,
    confidence: np.ndarray,
    epsg: int,
) -> None:
    """Write the merged points as E57, the point format CAD tools import natively.

    Coordinates are written relative to a local origin that the scan pose
    translates back to the georeferenced frame. E57 stores cartesian values as
    32-bit floats, so writing UTM eastings/northings directly would quantize the
    cloud to roughly half a meter; against a local origin the same 32-bit floats
    hold a zone-sized cloud to well under a millimeter, and readers (Rhino
    included) apply the pose on import to recover the true position.
    """
    # Write to a sibling temp file then atomically replace, so a crash or a
    # concurrent reader never observes a half-written cloud.
    temp = _temp_sibling(output)
    try:
        writer = _open_e57_writer(temp, epsg)
        try:
            # An all-filtered scan yields no points, and the E57 writer cannot
            # derive bounds from an empty array; leave data3D empty so the file
            # still writes.
            if len(xyz):
                origin = np.floor(xyz.min(axis=0))
                local = xyz - origin
                writer.write_scan_raw(
                    {
                        "cartesianX": np.ascontiguousarray(local[:, 0]),
                        "cartesianY": np.ascontiguousarray(local[:, 1]),
                        "cartesianZ": np.ascontiguousarray(local[:, 2]),
                        "colorRed": np.ascontiguousarray(rgb[:, 0]),
                        "colorGreen": np.ascontiguousarray(rgb[:, 1]),
                        "colorBlue": np.ascontiguousarray(rgb[:, 2]),
                        "intensity": (confidence / _E57_MAX_CONFIDENCE).astype(
                            np.float32
                        ),
                    },
                    name="merged-point-cloud",
                    rotation=_E57_IDENTITY_ROTATION,
                    translation=origin,
                )
        finally:
            writer.close()
        os.replace(temp, output)
    except BaseException:
        temp.unlink(missing_ok=True)
        raise


@dataclass(frozen=True)
class _CloudData:
    xyz: np.ndarray
    rgb: np.ndarray
    confidence: np.ndarray
    timestamps: np.ndarray
    source_ids: np.ndarray
    classification: np.ndarray
    analysis: PointViewerAnalysis
    epsg: int
    deduplicate_voxel: float


def _mesh_attributes(
    project: object, transform: np.ndarray, points: np.ndarray
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Associate nearby mesh vertices with point normals and ARKit classes."""
    normal_z = np.full(len(points), np.nan, dtype=np.float32)
    classification = np.zeros(len(points), dtype=np.uint8)
    flags = np.zeros(len(points), dtype=np.uint8)
    vertices_parts: list[np.ndarray] = []
    normal_parts: list[np.ndarray] = []
    class_parts: list[np.ndarray] = []
    ceiling_parts: list[np.ndarray] = []
    for anchor in project.mesh_anchors():
        combined = transform @ anchor.transform
        vertices = transform_points(anchor.vertices, combined)
        if anchor.normals is not None:
            normals = anchor.normals @ combined[:3, :3].T
        else:
            normals = np.zeros_like(vertices)
            triangles = vertices[anchor.faces]
            face_normals = np.cross(
                triangles[:, 1] - triangles[:, 0],
                triangles[:, 2] - triangles[:, 0],
            )
            for corner in range(3):
                np.add.at(normals, anchor.faces[:, corner], face_normals)
        lengths = np.linalg.norm(normals, axis=1)
        valid = lengths > 1e-8
        normals[valid] /= lengths[valid, None]
        normals[~valid] = np.nan

        vertex_classes = np.zeros(len(vertices), dtype=np.uint8)
        vertex_ceiling = np.zeros(len(vertices), dtype=bool)
        if anchor.face_classifications is not None:
            # ARMeshClassification: wall=1, floor=2, ceiling=3, table=4,
            # seat=5, window=6, door=7. Map only structural faces to LAS building;
            # ARKit has no vegetation class, and furniture must remain unclassified.
            face_classes = anchor.face_classifications
            structural = np.isin(face_classes, [1, 3, 6, 7])
            las_classes = np.where(face_classes == 2, 2, np.where(structural, 6, 0))
            for corner in range(3):
                indices = anchor.faces[:, corner]
                np.maximum.at(
                    vertex_classes,
                    indices,
                    las_classes,
                )
                vertex_ceiling[indices[face_classes == 3]] = True
        vertices_parts.append(vertices)
        normal_parts.append(normals)
        class_parts.append(vertex_classes)
        ceiling_parts.append(vertex_ceiling)
    if not vertices_parts or not len(points):
        return normal_z, classification, flags
    vertices = np.concatenate(vertices_parts)
    normals = np.concatenate(normal_parts)
    vertex_classes = np.concatenate(class_parts)
    ceilings = np.concatenate(ceiling_parts)
    if len(vertices) == 0:
        return normal_z, classification, flags
    distances, nearest = cKDTree(vertices).query(
        points,
        distance_upper_bound=0.20,
        workers=-1,
    )
    matched = np.isfinite(distances)
    normal_z[matched] = normals[nearest[matched], 2]
    classification[matched] = vertex_classes[nearest[matched]]
    flags[matched & ceilings[nearest.clip(max=len(ceilings) - 1)]] |= CEILING_FLAG
    return normal_z, classification, flags


def _merged_cloud_data(
    result: RegistrationResult,
    minimum_confidence: int,
    deduplicate_voxel: float,
) -> _CloudData:
    """Build the merged output arrays shared by LAZ and BIN writers."""
    positions, colors, confidence, timestamps, source_ids = [], [], [], [], []
    normal_z_parts, classification_parts, flag_parts = [], [], []
    for source_id, (scan, transform) in enumerate(
        zip(result.scans, result.final_transforms)
    ):
        batch = scan.project.points(minimum_confidence)
        transformed = transform_points(batch.positions, transform)
        positions.append(transformed)
        colors.append(batch.colors)
        confidence.append(batch.confidence)
        timestamps.append(batch.timestamps)
        source_ids.append(np.full(len(batch.positions), source_id, dtype=np.uint16))
        normal_z, classification, flags = _mesh_attributes(
            scan.project, transform, transformed
        )
        normal_z_parts.append(normal_z)
        classification_parts.append(classification)
        flag_parts.append(flags)
    xyz = np.concatenate(positions)
    rgb = np.concatenate(colors)
    confidence_values = np.concatenate(confidence)
    timestamp_values = np.concatenate(timestamps)
    source_values = np.concatenate(source_ids)
    normal_z_values = np.concatenate(normal_z_parts)
    classification_values = np.concatenate(classification_parts)
    flag_values = np.concatenate(flag_parts)
    keep = _deduplicate_indices(xyz, confidence_values, deduplicate_voxel)
    xyz = xyz[keep]
    rgb = rgb[keep]
    confidence_values = confidence_values[keep]
    timestamp_values = timestamp_values[keep]
    source_values = source_values[keep]
    normal_z_values = normal_z_values[keep]
    classification_values = classification_values[keep]
    flag_values = flag_values[keep]
    analysis = analyze_points(xyz, classification_values, normal_z_values, flag_values)
    epsg = result.scans[
        0
    ].project.georeference.epsg_code  # validated during preparation
    return _CloudData(
        xyz,
        rgb,
        confidence_values,
        timestamp_values,
        source_values,
        classification_values,
        analysis,
        epsg,
        deduplicate_voxel,
    )


def _deduplicate_indices(
    xyz: np.ndarray,
    confidence: np.ndarray,
    voxel_size: float,
) -> np.ndarray:
    if voxel_size <= 0:
        return np.arange(len(xyz))
    keys = np.floor(xyz / voxel_size).astype(np.int64)
    order = np.argsort(-confidence.astype(np.int16), kind="stable")
    _, first = np.unique(keys[order], axis=0, return_index=True)
    return np.sort(order[first])


def _deduplicate_cloud_data(data: _CloudData, voxel_size: float) -> _CloudData:
    if voxel_size <= 0 or voxel_size == data.deduplicate_voxel:
        return data
    keep = _deduplicate_indices(data.xyz, data.confidence, voxel_size)
    analysis = PointViewerAnalysis(
        floor_height=data.analysis.floor_height,
        height_above_ground_cm=data.analysis.height_above_ground_cm[keep],
        normal_z=data.analysis.normal_z[keep],
        surface_flags=data.analysis.surface_flags[keep],
        outlines=data.analysis.outlines,
        normal_coverage=float(
            np.count_nonzero(data.analysis.surface_flags[keep] & 2) / len(keep)
        )
        if len(keep)
        else 0.0,
    )
    return _CloudData(
        xyz=data.xyz[keep],
        rgb=data.rgb[keep],
        confidence=data.confidence[keep],
        timestamps=data.timestamps[keep],
        source_ids=data.source_ids[keep],
        classification=data.classification[keep],
        analysis=analysis,
        epsg=data.epsg,
        deduplicate_voxel=voxel_size,
    )


def prepare_merged_cloud_data(
    result: RegistrationResult,
    minimum_confidence: int = 0,
    deduplicate_voxel: float = 0,
) -> _CloudData:
    """Deduplicate and analyze registered points for reuse by smaller exports."""
    return _merged_cloud_data(result, minimum_confidence, deduplicate_voxel)


def analyze_registration_result(
    result: RegistrationResult, minimum_confidence: int = 0
) -> PointViewerAnalysis:
    """Return the common full-resolution viewer analysis for metadata output."""
    return prepare_merged_cloud_data(result, minimum_confidence).analysis


def export_merged_cloud_outputs(
    result: RegistrationResult,
    laz_output: str | Path | None = None,
    e57_output: str | Path | None = None,
    minimum_confidence: int = 1,  # Export medium- and high-confidence points by default.
    deduplicate_voxel: float = 0.02,  # Keep one point per 2 cm output voxel.
    prepared_data: _CloudData | None = None,
) -> int:
    """Write the requested merged outputs and return the point count.

    Every requested format is written from the same prepared and deduplicated
    points, so the LAZ and E57 outputs always describe the same cloud.
    """
    if laz_output is None and e57_output is None:
        raise ValueError("at least one output path is required")
    raw_data = prepared_data or prepare_merged_cloud_data(
        result,
        minimum_confidence,
        deduplicate_voxel,
    )
    data = _deduplicate_cloud_data(raw_data, deduplicate_voxel)
    if laz_output is not None:
        _write_cloud(
            Path(laz_output),
            data.xyz,
            data.rgb,
            data.confidence,
            data.timestamps,
            data.source_ids,
            data.classification,
            data.analysis,
            data.epsg,
        )
    if e57_output is not None:
        write_e57_cloud(
            Path(e57_output), data.xyz, data.rgb, data.confidence, data.epsg
        )
    return len(data.xyz)


def export_merged_cloud_e57(
    result: RegistrationResult,
    output: str | Path,
    minimum_confidence: int = 1,  # Export medium- and high-confidence points by default.
    deduplicate_voxel: float = 0.02,  # Keep one point per 2 cm output voxel.
) -> int:
    """Write merged points as E57 for CAD tools that import it natively."""
    return export_merged_cloud_outputs(
        result,
        e57_output=output,
        minimum_confidence=minimum_confidence,
        deduplicate_voxel=deduplicate_voxel,
    )


def export_merged_cloud(
    result: RegistrationResult,
    output: str | Path,
    minimum_confidence: int = 1,  # Export medium- and high-confidence points by default.
    deduplicate_voxel: float = 0.02,  # Keep one point per 2 cm output voxel.
) -> int:
    """Write merged points and return the number of exported records."""
    return export_merged_cloud_outputs(
        result,
        laz_output=output,
        minimum_confidence=minimum_confidence,
        deduplicate_voxel=deduplicate_voxel,
    )


def export_transformed_scans(
    result: RegistrationResult,
    output_directory: str | Path,
    minimum_confidence: int = 1,
) -> list[Path]:
    """Write one aligned LAZ file per source scan without cross-scan deduplication."""
    directory = Path(output_directory)
    directory.mkdir(parents=True, exist_ok=True)
    epsg = result.scans[0].project.georeference.epsg_code
    outputs: list[Path] = []
    for source_id, (scan, transform) in enumerate(
        zip(result.scans, result.final_transforms)
    ):
        batch = scan.project.points(minimum_confidence)
        xyz = transform_points(batch.positions, transform)
        # Prefix with the source index so scans that share a stem cannot collide.
        output = directory / f"{source_id:03d}-{scan.project.path.stem}.laz"
        _write_cloud(
            output,
            xyz,
            batch.colors,
            batch.confidence,
            batch.timestamps,
            np.full(len(xyz), source_id, dtype=np.uint16),
            np.zeros(len(xyz), dtype=np.uint8),
            analyze_points(xyz),
            epsg,
        )
        outputs.append(output)
    return outputs


def export_original_scans(
    result: RegistrationResult,
    output_directory: str | Path,
    minimum_confidence: int = 1,
) -> list[Path]:
    """Convert each source scan to LAZ using its original georeference."""
    directory = Path(output_directory)
    directory.mkdir(parents=True, exist_ok=True)
    epsg = result.scans[0].project.georeference.epsg_code
    outputs: list[Path] = []
    for source_id, scan in enumerate(result.scans):
        batch = scan.project.points(minimum_confidence)
        xyz = transform_points(batch.positions, scan.initial_transform)
        # Prefix with the source index so scans that share a stem cannot collide.
        output = directory / f"{source_id:03d}-{scan.project.path.stem}.laz"
        _write_cloud(
            output,
            xyz,
            batch.colors,
            batch.confidence,
            batch.timestamps,
            np.full(len(xyz), source_id, dtype=np.uint16),
            np.zeros(len(xyz), dtype=np.uint8),
            analyze_points(xyz),
            epsg,
        )
        outputs.append(output)
    return outputs


def write_registration_report(
    result: RegistrationResult, output: str | Path, exported_points: int
) -> None:
    report = {
        "formatVersion": 1,  # Audit-report schema version.
        "exportedPointCount": exported_points,
        "anchorScan": result.scans[0].project.identifier,
        "scans": [
            {
                "sourceId": index,
                "id": scan.project.identifier,
                "path": str(scan.project.path),
                "pointCount": scan.project.point_count,
                "initialTransform": scan.initial_transform.tolist(),
                "correctionTransform": correction.tolist(),
                "finalTransform": final.tolist(),
            }
            for index, (scan, correction, final) in enumerate(
                zip(result.scans, result.correction_transforms, result.final_transforms)
            )
        ],
        "registrationEdges": [
            {
                "fixedSourceId": edge.fixed,
                "movingSourceId": edge.moving,
                "correspondenceCount": edge.correspondence_count,
                "rmseMeters": edge.rmse,
                "overlapRatio": edge.overlap_ratio,
                "initialization": edge.initialization,
                "visualMatchCount": edge.visual_match_count,
                "visualInlierCount": edge.visual_inlier_count,
                "visualRmseMeters": edge.visual_rmse,
                "movingToFixedTransform": edge.moving_to_fixed.tolist(),
            }
            for edge in result.edges
        ],
        "rejectedRegistrationEdges": [
            {
                "fixedSourceId": rejection.edge.fixed,
                "movingSourceId": rejection.edge.moving,
                "reason": rejection.reason,
                "correspondenceCount": rejection.edge.correspondence_count,
                "rmseMeters": rejection.edge.rmse,
                "overlapRatio": rejection.edge.overlap_ratio,
                "qualityScore": rejection.edge.quality_score,
                "loopYawErrorDegrees": rejection.loop_yaw_error_degrees,
                "loopHorizontalErrorMeters": rejection.loop_horizontal_error,
                "loopVerticalErrorMeters": rejection.loop_vertical_error,
                "movingToFixedTransform": rejection.edge.moving_to_fixed.tolist(),
            }
            for rejection in result.rejected_edges
        ],
    }
    destination = Path(output)
    temp = _temp_sibling(destination)
    try:
        temp.write_text(
            json.dumps(report, indent=2) + "\n", encoding="utf-8"
        )  # Two-space JSON indent.
        os.replace(temp, destination)  # Atomic so a reader never sees a partial report.
    except BaseException:
        temp.unlink(missing_ok=True)
        raise
