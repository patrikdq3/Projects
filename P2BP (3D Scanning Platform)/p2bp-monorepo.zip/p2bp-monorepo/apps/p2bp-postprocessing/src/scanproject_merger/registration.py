"""Overlap-aware rigid registration for independently georeferenced scans."""

from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass, field
from itertools import combinations
from typing import NamedTuple

import numpy as np
from numpy.typing import NDArray
from scipy.optimize import least_squares
from scipy.spatial import cKDTree

from config import ConfigError, env_bool, env_float, env_int, env_string

from .format import ScanProject, transform_points
from .visual import FeatureCache, register_keyframes


@dataclass
class PreparedScan:
    project: ScanProject
    points: NDArray[np.float64]
    initial_transform: NDArray[np.float64]
    projected_points: NDArray[np.float64]


@dataclass(frozen=True)
class RegistrationEdge:
    fixed: int
    moving: int
    moving_to_fixed: NDArray[np.float64]
    correspondence_count: int
    rmse: float
    overlap_ratio: float
    initialization: str = "georeference"
    visual_match_count: int = 0
    visual_inlier_count: int = 0
    visual_rmse: float | None = None
    quality_rmse_floor: float = 0.001

    @property
    def quality_score(self) -> float:
        """Rank useful overlap against geometric residual error."""
        return self.overlap_ratio / max(self.rmse, self.quality_rmse_floor)


@dataclass(frozen=True)
class RejectedRegistrationEdge:
    edge: RegistrationEdge
    reason: str
    loop_yaw_error_degrees: float
    loop_horizontal_error: float
    loop_vertical_error: float


@dataclass(frozen=True)
class RegistrationResult:
    scans: list[PreparedScan]
    correction_transforms: list[NDArray[np.float64]]
    edges: list[RegistrationEdge]
    rejected_edges: list[RejectedRegistrationEdge] = field(default_factory=list)

    @property
    def final_transforms(self) -> list[NDArray[np.float64]]:
        return [
            correction @ scan.initial_transform
            for correction, scan in zip(self.correction_transforms, self.scans)
        ]


def rigid_transform(yaw: float, translation: Iterable[float]) -> NDArray[np.float64]:
    cosine, sine = np.cos(yaw), np.sin(yaw)
    tx, ty, tz = translation
    return np.array(
        [
            [cosine, -sine, 0.0, tx],
            [sine, cosine, 0.0, ty],
            [0.0, 0.0, 1.0, tz],
            [0.0, 0.0, 0.0, 1.0],
        ],
        dtype=np.float64,
    )


def parameters(transform: NDArray[np.float64]) -> NDArray[np.float64]:
    return np.array(
        [np.arctan2(transform[1, 0], transform[0, 0]), *transform[:3, 3]],
        dtype=np.float64,
    )


def rebase_transform(
    transform: NDArray[np.float64], origin: NDArray[np.float64], *, to_centered: bool
) -> NDArray[np.float64]:
    """Change the coordinate origin used to express a rigid transform."""
    global_to_centered = rigid_transform(0.0, -origin)
    centered_to_global = rigid_transform(0.0, origin)
    if to_centered:
        return global_to_centered @ transform @ centered_to_global
    return centered_to_global @ transform @ global_to_centered


def voxel_downsample(
    points: NDArray[np.float64], voxel_size: float
) -> NDArray[np.float64]:
    if len(points) == 0:
        return points
    keys = np.floor(points / voxel_size).astype(np.int64)
    _, indices = np.unique(keys, axis=0, return_index=True)
    return points[np.sort(indices)]


def prepare_scans(
    projects: list[ScanProject], voxel_size: float, minimum_confidence: int
) -> list[PreparedScan]:
    if not projects:
        raise ValueError("at least one scan is required")
    epsg_codes = {
        project.georeference.epsg_code for project in projects if project.georeference
    }
    if len(epsg_codes) > 1:
        raise ValueError(
            f"scans use different projected coordinate systems: {sorted(epsg_codes)}"
        )
    prepared: list[PreparedScan] = []
    for project in projects:
        if project.georeference is None:
            raise ValueError(f"scan has no georeference: {project.path}")
        local = voxel_downsample(
            project.points(minimum_confidence).positions, voxel_size
        )
        if len(local) < 3:  # Minimum points needed to constrain a rigid transform.
            raise ValueError(f"scan has too few usable points: {project.path}")
        initial = project.georeference.local_to_projected()
        prepared.append(
            PreparedScan(project, local, initial, transform_points(local, initial))
        )
    return prepared


def candidate_pairs(scans: list[PreparedScan], padding: float) -> list[tuple[int, int]]:
    bounds = [
        (scan.projected_points.min(axis=0), scan.projected_points.max(axis=0))
        for scan in scans
    ]
    candidates = []
    for left, right in combinations(range(len(scans)), 2):
        left_min, left_max = bounds[left]
        right_min, right_max = bounds[right]
        # Candidate discovery is horizontal; phone altitude is too unreliable to gate adjacency.
        if np.all(left_min[:2] - padding <= right_max[:2]) and np.all(
            right_min[:2] - padding <= left_max[:2]
        ):
            candidates.append((left, right))
    return candidates


def _fit_yaw_translation(
    source: NDArray[np.float64], target: NDArray[np.float64]
) -> NDArray[np.float64]:
    source_center = source.mean(axis=0)
    target_center = target.mean(axis=0)
    source_xy = source[:, :2] - source_center[:2]
    target_xy = target[:, :2] - target_center[:2]
    covariance = source_xy.T @ target_xy
    yaw = np.arctan2(
        covariance[0, 1] - covariance[1, 0], covariance[0, 0] + covariance[1, 1]
    )
    rotation = rigid_transform(yaw, (0.0, 0.0, 0.0))
    translation = target_center - transform_points(source_center[None, :], rotation)[0]
    return rigid_transform(yaw, translation)


class PairRegistration(NamedTuple):
    """Result of aligning one moving cloud to a fixed cloud with ICP."""

    transform: NDArray[np.float64]
    correspondence_count: int
    rmse: float
    overlap_ratio: float


def register_pair(
    fixed: NDArray[np.float64],
    moving: NDArray[np.float64],
    maximum_distance: float,
    iterations: int = 40,  # Coarse-to-fine ICP correspondence gates.
    initial_transform: NDArray[np.float64] | None = None,
    final_distance: float = 0.50,
    minimum_correspondences: int = 12,
    trim_quantile: float = 0.80,
) -> PairRegistration | None:
    tree = cKDTree(fixed)
    transform = np.eye(4) if initial_transform is None else initial_transform.copy()
    minimum_gate = min(final_distance, maximum_distance)
    gates = np.geomspace(
        maximum_distance, minimum_gate, num=max(2, iterations)
    )  # At least coarse and fine gates.
    for gate in gates:
        transformed = transform_points(moving, transform)
        distances, indices = tree.query(transformed, distance_upper_bound=gate)
        keep = np.isfinite(distances)
        if keep.sum() < minimum_correspondences:
            return None
        # Trim the worst correspondences to reduce edge clutter and partial-overlap bias.
        cutoff = np.quantile(distances[keep], trim_quantile)
        keep &= distances <= cutoff
        increment = _fit_yaw_translation(transformed[keep], fixed[indices[keep]])
        transform = increment @ transform
    transformed = transform_points(moving, transform)
    distances, _ = tree.query(transformed, distance_upper_bound=minimum_gate)
    keep = np.isfinite(distances)
    count = int(keep.sum())
    if count < minimum_correspondences:
        return None
    return PairRegistration(
        transform,
        count,
        float(np.sqrt(np.mean(np.square(distances[keep])))),
        count / len(moving),
    )


def _reachable(scan_count: int, edges: list[RegistrationEdge]) -> bool:
    seen, pending = {0}, [0]
    while pending:
        current = pending.pop()
        for edge in edges:
            neighbor = (
                edge.moving
                if edge.fixed == current
                else edge.fixed
                if edge.moving == current
                else None
            )
            if neighbor is not None and neighbor not in seen:
                seen.add(neighbor)
                pending.append(neighbor)
    return len(seen) == scan_count


def _tree_poses(
    scan_count: int, edges: list[RegistrationEdge]
) -> list[NDArray[np.float64] | None]:
    poses: list[NDArray[np.float64] | None] = [None] * scan_count
    poses[0] = np.eye(4)
    pending = [0]
    while pending:
        current = pending.pop()
        for edge in edges:
            if edge.fixed == current and poses[edge.moving] is None:
                poses[edge.moving] = poses[current] @ edge.moving_to_fixed
                pending.append(edge.moving)
            elif edge.moving == current and poses[edge.fixed] is None:
                poses[edge.fixed] = poses[current] @ np.linalg.inv(edge.moving_to_fixed)
                pending.append(edge.fixed)
    return poses


def select_consistent_edges(
    scan_count: int,
    edges: list[RegistrationEdge],
    maximum_loop_yaw_degrees: float,
    maximum_loop_horizontal_error: float,
    maximum_loop_vertical_error: float,
) -> tuple[list[RegistrationEdge], list[RejectedRegistrationEdge]]:
    """Build a maximum-quality tree, then admit only loop-consistent extra edges."""
    parent = list(range(scan_count))

    def find(node: int) -> int:
        while parent[node] != node:
            parent[node] = parent[parent[node]]
            node = parent[node]
        return node

    selected: list[RegistrationEdge] = []
    remaining: list[RegistrationEdge] = []
    for edge in sorted(edges, key=lambda item: item.quality_score, reverse=True):
        fixed_root, moving_root = find(edge.fixed), find(edge.moving)
        if fixed_root != moving_root:
            parent[moving_root] = fixed_root
            selected.append(edge)
        else:
            remaining.append(edge)

    if not _reachable(scan_count, selected):
        raise ValueError("accepted registration edges do not connect every scan")

    rejected: list[RejectedRegistrationEdge] = []
    for edge in remaining:
        poses = _tree_poses(scan_count, selected)
        fixed_pose, moving_pose = poses[edge.fixed], poses[edge.moving]
        assert fixed_pose is not None and moving_pose is not None
        predicted = np.linalg.inv(fixed_pose) @ moving_pose
        closure_error = np.linalg.inv(predicted) @ edge.moving_to_fixed
        values = parameters(closure_error)
        yaw_degrees = abs(float(np.degrees(values[0])))
        horizontal = float(np.linalg.norm(values[1:3]))
        vertical = abs(float(values[3]))
        if (
            yaw_degrees <= maximum_loop_yaw_degrees
            and horizontal <= maximum_loop_horizontal_error
            and vertical <= maximum_loop_vertical_error
        ):
            selected.append(edge)
        else:
            rejected.append(
                RejectedRegistrationEdge(
                    edge=edge,
                    reason="loop closure exceeds configured tolerance",
                    loop_yaw_error_degrees=yaw_degrees,
                    loop_horizontal_error=horizontal,
                    loop_vertical_error=vertical,
                )
            )
    return selected, rejected


def optimize_pose_graph(
    scan_count: int,
    edges: list[RegistrationEdge],
    *,
    yaw_scale: float = 10.0,
    robust_loss: str = "soft_l1",
    robust_loss_scale: float = 0.25,
) -> list[NDArray[np.float64]]:
    if scan_count == 1:
        return [np.eye(4)]
    if not _reachable(scan_count, edges):
        raise ValueError("accepted registration edges do not connect every scan")

    # Seed every correction by traversing measured edges from the anchor. This is
    # essential in projected CRSs: expressing a small yaw around coordinate zero
    # legitimately requires a translation of hundreds of kilometres.
    initial = _tree_poses(scan_count, edges)
    initial_transforms = [transform for transform in initial if transform is not None]

    def residuals(values: NDArray[np.float64]) -> NDArray[np.float64]:
        poses = [np.eye(4)] + [
            rigid_transform(values[index * 4], values[index * 4 + 1 : index * 4 + 4])
            for index in range(scan_count - 1)
        ]
        residual: list[float] = []
        for edge in edges:
            predicted = (
                np.linalg.inv(poses[edge.fixed])
                @ poses[edge.moving]
                @ np.linalg.inv(edge.moving_to_fixed)
            )
            error = parameters(predicted)
            residual.extend([error[0] * yaw_scale, error[1], error[2], error[3]])
        return np.asarray(residual)

    initial_values = np.concatenate(
        [parameters(transform) for transform in initial_transforms[1:]]
    )
    solution = least_squares(
        residuals,
        initial_values,
        loss=robust_loss,
        f_scale=robust_loss_scale,
    )
    return [np.eye(4)] + [
        rigid_transform(values[0], values[1:]) for values in solution.x.reshape((-1, 4))
    ]


@dataclass(frozen=True)
class RegistrationParams:
    """Tuning parameters for :func:`register_scans`.

    Defined once here so callers (including ``merge_scan_projects``) share a single
    source of truth rather than restating these defaults.
    """

    voxel_size: float = 0.075  # 7.5 cm registration sampling grid.
    minimum_confidence: int = 1  # Exclude low-confidence (0) points from alignment.
    candidate_padding: float = 10.0  # Metres added to bounds when finding neighbors.
    maximum_distance: float = 5.0  # Initial ICP correspondence gate in metres.
    minimum_overlap: float = 0.06  # Require matches for 6% of the moving sample.
    maximum_rmse: float = 0.40  # Maximum accepted pair RMSE in metres.
    maximum_loop_yaw_degrees: float = 3.0
    maximum_loop_horizontal_error: float = 1.0
    maximum_loop_vertical_error: float = 1.0
    use_visual_registration: bool = True
    icp_iterations: int = 40
    icp_final_distance: float = 0.50
    icp_minimum_correspondences: int = 12
    icp_trim_quantile: float = 0.80
    edge_quality_rmse_floor: float = 0.001
    pose_graph_yaw_scale: float = 10.0
    pose_graph_robust_loss: str = "soft_l1"
    pose_graph_robust_loss_scale: float = 0.25
    visual_maximum_keyframes: int = 120
    visual_sift_features: int = 600
    visual_sift_contrast_threshold: float = 0.025
    visual_maximum_image_width: float = 960.0
    visual_minimum_keypoints: int = 8
    visual_minimum_depth: float = 0.05
    visual_maximum_depth: float = 8.0
    visual_minimum_depth_confidence: int = 1
    visual_flann_trees: int = 5
    visual_flann_checks: int = 64
    visual_match_ratio: float = 0.75
    visual_minimum_inliers: int = 20
    visual_ransac_threshold: float = 0.20
    visual_ransac_iterations: int = 2500
    visual_ransac_seed: int = 0
    visual_icp_maximum_distance: float = 0.75

    def __post_init__(self) -> None:
        positive_floats = {
            "voxel_size": self.voxel_size,
            "maximum_distance": self.maximum_distance,
            "maximum_rmse": self.maximum_rmse,
            "icp_final_distance": self.icp_final_distance,
            "edge_quality_rmse_floor": self.edge_quality_rmse_floor,
            "pose_graph_yaw_scale": self.pose_graph_yaw_scale,
            "pose_graph_robust_loss_scale": self.pose_graph_robust_loss_scale,
            "visual_maximum_image_width": self.visual_maximum_image_width,
            "visual_minimum_depth": self.visual_minimum_depth,
            "visual_maximum_depth": self.visual_maximum_depth,
            "visual_ransac_threshold": self.visual_ransac_threshold,
            "visual_icp_maximum_distance": self.visual_icp_maximum_distance,
        }
        for name, value in positive_floats.items():
            if value <= 0:
                raise ValueError(f"{name} must be greater than zero")
        nonnegative_floats = {
            "candidate_padding": self.candidate_padding,
            "maximum_loop_yaw_degrees": self.maximum_loop_yaw_degrees,
            "maximum_loop_horizontal_error": self.maximum_loop_horizontal_error,
            "maximum_loop_vertical_error": self.maximum_loop_vertical_error,
            "visual_sift_contrast_threshold": self.visual_sift_contrast_threshold,
        }
        for name, value in nonnegative_floats.items():
            if value < 0:
                raise ValueError(f"{name} must not be negative")
        unit_interval = {
            "minimum_overlap": self.minimum_overlap,
            "icp_trim_quantile": self.icp_trim_quantile,
            "visual_match_ratio": self.visual_match_ratio,
        }
        for name, value in unit_interval.items():
            if not 0 < value <= 1:
                raise ValueError(f"{name} must be greater than zero and at most one")
        minimum_ints = {
            "minimum_confidence": (self.minimum_confidence, 0),
            "icp_iterations": (self.icp_iterations, 2),
            "icp_minimum_correspondences": (self.icp_minimum_correspondences, 3),
            "visual_maximum_keyframes": (self.visual_maximum_keyframes, 1),
            "visual_sift_features": (self.visual_sift_features, 1),
            "visual_minimum_keypoints": (self.visual_minimum_keypoints, 3),
            "visual_minimum_depth_confidence": (
                self.visual_minimum_depth_confidence,
                0,
            ),
            "visual_flann_trees": (self.visual_flann_trees, 1),
            "visual_flann_checks": (self.visual_flann_checks, 1),
            "visual_minimum_inliers": (self.visual_minimum_inliers, 3),
            "visual_ransac_iterations": (self.visual_ransac_iterations, 1),
            "visual_ransac_seed": (self.visual_ransac_seed, 0),
        }
        for name, (value, minimum) in minimum_ints.items():
            if value < minimum:
                raise ValueError(f"{name} must be at least {minimum}")
        if self.visual_maximum_depth <= self.visual_minimum_depth:
            raise ValueError("visual_maximum_depth must exceed visual_minimum_depth")
        if self.pose_graph_robust_loss not in {
            "linear",
            "soft_l1",
            "huber",
            "cauchy",
            "arctan",
        }:
            raise ValueError("pose_graph_robust_loss is not supported")

    @classmethod
    def from_environment(cls) -> RegistrationParams:
        """Build registration tuning from ``P2BP_REGISTRATION_*`` variables."""

        defaults = cls()
        try:
            return cls(
                voxel_size=env_float(
                    "P2BP_REGISTRATION_VOXEL_SIZE", defaults.voxel_size
                ),
                minimum_confidence=env_int(
                    "P2BP_REGISTRATION_MINIMUM_CONFIDENCE",
                    defaults.minimum_confidence,
                ),
                candidate_padding=env_float(
                    "P2BP_REGISTRATION_CANDIDATE_PADDING",
                    defaults.candidate_padding,
                ),
                maximum_distance=env_float(
                    "P2BP_REGISTRATION_MAXIMUM_DISTANCE",
                    defaults.maximum_distance,
                ),
                minimum_overlap=env_float(
                    "P2BP_REGISTRATION_MINIMUM_OVERLAP", defaults.minimum_overlap
                ),
                maximum_rmse=env_float(
                    "P2BP_REGISTRATION_MAXIMUM_RMSE", defaults.maximum_rmse
                ),
                maximum_loop_yaw_degrees=env_float(
                    "P2BP_REGISTRATION_MAXIMUM_LOOP_YAW_DEGREES",
                    defaults.maximum_loop_yaw_degrees,
                ),
                maximum_loop_horizontal_error=env_float(
                    "P2BP_REGISTRATION_MAXIMUM_LOOP_HORIZONTAL_ERROR",
                    defaults.maximum_loop_horizontal_error,
                ),
                maximum_loop_vertical_error=env_float(
                    "P2BP_REGISTRATION_MAXIMUM_LOOP_VERTICAL_ERROR",
                    defaults.maximum_loop_vertical_error,
                ),
                use_visual_registration=env_bool(
                    "P2BP_REGISTRATION_USE_VISUAL_REGISTRATION",
                    defaults.use_visual_registration,
                ),
                icp_iterations=env_int(
                    "P2BP_REGISTRATION_ICP_ITERATIONS", defaults.icp_iterations
                ),
                icp_final_distance=env_float(
                    "P2BP_REGISTRATION_ICP_FINAL_DISTANCE",
                    defaults.icp_final_distance,
                ),
                icp_minimum_correspondences=env_int(
                    "P2BP_REGISTRATION_ICP_MINIMUM_CORRESPONDENCES",
                    defaults.icp_minimum_correspondences,
                ),
                icp_trim_quantile=env_float(
                    "P2BP_REGISTRATION_ICP_TRIM_QUANTILE",
                    defaults.icp_trim_quantile,
                ),
                edge_quality_rmse_floor=env_float(
                    "P2BP_REGISTRATION_EDGE_QUALITY_RMSE_FLOOR",
                    defaults.edge_quality_rmse_floor,
                ),
                pose_graph_yaw_scale=env_float(
                    "P2BP_REGISTRATION_POSE_GRAPH_YAW_SCALE",
                    defaults.pose_graph_yaw_scale,
                ),
                pose_graph_robust_loss=env_string(
                    "P2BP_REGISTRATION_POSE_GRAPH_ROBUST_LOSS",
                    defaults.pose_graph_robust_loss,
                ),
                pose_graph_robust_loss_scale=env_float(
                    "P2BP_REGISTRATION_POSE_GRAPH_ROBUST_LOSS_SCALE",
                    defaults.pose_graph_robust_loss_scale,
                ),
                visual_maximum_keyframes=env_int(
                    "P2BP_REGISTRATION_VISUAL_MAXIMUM_KEYFRAMES",
                    defaults.visual_maximum_keyframes,
                ),
                visual_sift_features=env_int(
                    "P2BP_REGISTRATION_VISUAL_SIFT_FEATURES",
                    defaults.visual_sift_features,
                ),
                visual_sift_contrast_threshold=env_float(
                    "P2BP_REGISTRATION_VISUAL_SIFT_CONTRAST_THRESHOLD",
                    defaults.visual_sift_contrast_threshold,
                ),
                visual_maximum_image_width=env_float(
                    "P2BP_REGISTRATION_VISUAL_MAXIMUM_IMAGE_WIDTH",
                    defaults.visual_maximum_image_width,
                ),
                visual_minimum_keypoints=env_int(
                    "P2BP_REGISTRATION_VISUAL_MINIMUM_KEYPOINTS",
                    defaults.visual_minimum_keypoints,
                ),
                visual_minimum_depth=env_float(
                    "P2BP_REGISTRATION_VISUAL_MINIMUM_DEPTH",
                    defaults.visual_minimum_depth,
                ),
                visual_maximum_depth=env_float(
                    "P2BP_REGISTRATION_VISUAL_MAXIMUM_DEPTH",
                    defaults.visual_maximum_depth,
                ),
                visual_minimum_depth_confidence=env_int(
                    "P2BP_REGISTRATION_VISUAL_MINIMUM_DEPTH_CONFIDENCE",
                    defaults.visual_minimum_depth_confidence,
                ),
                visual_flann_trees=env_int(
                    "P2BP_REGISTRATION_VISUAL_FLANN_TREES",
                    defaults.visual_flann_trees,
                ),
                visual_flann_checks=env_int(
                    "P2BP_REGISTRATION_VISUAL_FLANN_CHECKS",
                    defaults.visual_flann_checks,
                ),
                visual_match_ratio=env_float(
                    "P2BP_REGISTRATION_VISUAL_MATCH_RATIO",
                    defaults.visual_match_ratio,
                ),
                visual_minimum_inliers=env_int(
                    "P2BP_REGISTRATION_VISUAL_MINIMUM_INLIERS",
                    defaults.visual_minimum_inliers,
                ),
                visual_ransac_threshold=env_float(
                    "P2BP_REGISTRATION_VISUAL_RANSAC_THRESHOLD",
                    defaults.visual_ransac_threshold,
                ),
                visual_ransac_iterations=env_int(
                    "P2BP_REGISTRATION_VISUAL_RANSAC_ITERATIONS",
                    defaults.visual_ransac_iterations,
                ),
                visual_ransac_seed=env_int(
                    "P2BP_REGISTRATION_VISUAL_RANSAC_SEED",
                    defaults.visual_ransac_seed,
                ),
                visual_icp_maximum_distance=env_float(
                    "P2BP_REGISTRATION_VISUAL_ICP_MAXIMUM_DISTANCE",
                    defaults.visual_icp_maximum_distance,
                ),
            )
        except ValueError as error:
            raise ConfigError(f"Invalid registration configuration: {error}") from error


def register_scans(
    projects: list[ScanProject],
    params: RegistrationParams = RegistrationParams(),  # noqa: B008 - frozen, so a shared default is safe.
) -> RegistrationResult:
    scans = prepare_scans(projects, params.voxel_size, params.minimum_confidence)
    edges: list[RegistrationEdge] = []
    feature_cache: FeatureCache = {}  # Reuse keyframe features across pairs within this run only.
    for fixed, moving in candidate_pairs(scans, params.candidate_padding):
        visual = (
            register_keyframes(
                scans[fixed].project,
                scans[moving].project,
                scans[fixed].initial_transform,
                scans[moving].initial_transform,
                cache=feature_cache,
                minimum_inliers=params.visual_minimum_inliers,
                ransac_threshold=params.visual_ransac_threshold,
                maximum_keyframes=params.visual_maximum_keyframes,
                sift_features=params.visual_sift_features,
                sift_contrast_threshold=params.visual_sift_contrast_threshold,
                maximum_image_width=params.visual_maximum_image_width,
                minimum_keypoints=params.visual_minimum_keypoints,
                minimum_depth=params.visual_minimum_depth,
                maximum_depth=params.visual_maximum_depth,
                minimum_depth_confidence=params.visual_minimum_depth_confidence,
                flann_trees=params.visual_flann_trees,
                flann_checks=params.visual_flann_checks,
                match_ratio=params.visual_match_ratio,
                ransac_iterations=params.visual_ransac_iterations,
                ransac_seed=params.visual_ransac_seed,
            )
            if params.use_visual_registration
            else None
        )
        outcome = register_pair(
            scans[fixed].projected_points,
            scans[moving].projected_points,
            min(params.maximum_distance, params.visual_icp_maximum_distance)
            if visual
            else params.maximum_distance,
            iterations=params.icp_iterations,
            initial_transform=visual.moving_to_fixed if visual else None,
            final_distance=params.icp_final_distance,
            minimum_correspondences=params.icp_minimum_correspondences,
            trim_quantile=params.icp_trim_quantile,
        )
        if outcome is None:
            continue
        transform, count, rmse, overlap = outcome
        if overlap >= params.minimum_overlap and rmse <= params.maximum_rmse:
            edges.append(
                RegistrationEdge(
                    fixed,
                    moving,
                    transform,
                    count,
                    rmse,
                    overlap,
                    initialization="rgbDepth" if visual else "georeference",
                    visual_match_count=visual.match_count if visual else 0,
                    visual_inlier_count=visual.inlier_count if visual else 0,
                    visual_rmse=visual.rmse if visual else None,
                    quality_rmse_floor=params.edge_quality_rmse_floor,
                )
            )
    graph_origin = scans[0].initial_transform[:3, 3]
    centered_edges = [
        RegistrationEdge(
            edge.fixed,
            edge.moving,
            rebase_transform(edge.moving_to_fixed, graph_origin, to_centered=True),
            edge.correspondence_count,
            edge.rmse,
            edge.overlap_ratio,
            edge.initialization,
            edge.visual_match_count,
            edge.visual_inlier_count,
            edge.visual_rmse,
            edge.quality_rmse_floor,
        )
        for edge in edges
    ]
    selected_centered_edges, rejected_centered_edges = select_consistent_edges(
        len(scans),
        centered_edges,
        params.maximum_loop_yaw_degrees,
        params.maximum_loop_horizontal_error,
        params.maximum_loop_vertical_error,
    )
    centered_corrections = optimize_pose_graph(
        len(scans),
        selected_centered_edges,
        yaw_scale=params.pose_graph_yaw_scale,
        robust_loss=params.pose_graph_robust_loss,
        robust_loss_scale=params.pose_graph_robust_loss_scale,
    )
    corrections = [
        rebase_transform(correction, graph_origin, to_centered=False)
        for correction in centered_corrections
    ]
    selected_keys = {(edge.fixed, edge.moving) for edge in selected_centered_edges}
    selected_edges = [
        edge for edge in edges if (edge.fixed, edge.moving) in selected_keys
    ]
    rejected_by_key = {
        (rejection.edge.fixed, rejection.edge.moving): rejection
        for rejection in rejected_centered_edges
    }
    rejected_edges = [
        RejectedRegistrationEdge(
            edge=edge,
            reason=rejected_by_key[(edge.fixed, edge.moving)].reason,
            loop_yaw_error_degrees=rejected_by_key[
                (edge.fixed, edge.moving)
            ].loop_yaw_error_degrees,
            loop_horizontal_error=rejected_by_key[
                (edge.fixed, edge.moving)
            ].loop_horizontal_error,
            loop_vertical_error=rejected_by_key[
                (edge.fixed, edge.moving)
            ].loop_vertical_error,
        )
        for edge in edges
        if (edge.fixed, edge.moving) in rejected_by_key
    ]
    return RegistrationResult(scans, corrections, selected_edges, rejected_edges)
