"""Server-side analysis used by ScannerConsolidator's Metal point-cloud viewer."""

from __future__ import annotations

import json
import logging
import os
from dataclasses import dataclass
from pathlib import Path

import numpy as np
from scipy import ndimage
from shapely import concave_hull
from shapely.geometry import MultiPoint, Polygon

INFERRED_BLOCKER_FLAG = np.uint8(1 << 0)
NORMAL_VALID_FLAG = np.uint8(1 << 1)
CEILING_FLAG = np.uint8(1 << 2)

UNKNOWN_NORMAL_Z = np.int8(-128)
VIEWER_METADATA_FORMAT_VERSION = 1
VIEWER_ANALYSIS_VERSION = 2

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class PointViewerAnalysis:
    floor_height: float
    height_above_ground_cm: np.ndarray
    normal_z: np.ndarray
    surface_flags: np.ndarray
    outlines: list[dict[str, object]]
    normal_coverage: float


@dataclass(frozen=True)
class _GroundGrid:
    origin_x: float
    origin_y: float
    cell_size: float
    width: int
    height: int

    def indices(self, xyz: np.ndarray) -> np.ndarray:
        x = np.clip(
            ((xyz[:, 0] - self.origin_x) / self.cell_size).astype(np.int64),
            0,
            self.width - 1,
        )
        y = np.clip(
            ((xyz[:, 1] - self.origin_y) / self.cell_size).astype(np.int64),
            0,
            self.height - 1,
        )
        return y * self.width + x


def _make_ground_grid(xyz: np.ndarray) -> _GroundGrid | None:
    if len(xyz) == 0:
        return None
    minimum = np.min(xyz, axis=0)
    maximum = np.max(xyz, axis=0)
    extent = maximum - minimum
    planar_extent = float(max(extent[0], extent[1]))
    if planar_extent <= 1:
        return None
    area = max(float(extent[0] * extent[1]), 1.0)
    density_size = min(np.sqrt(12.0 * area / len(xyz)), 4.0)
    cell_size = max(planar_extent / 768.0, 0.75, float(density_size))
    width = min(int(extent[0] / cell_size) + 1, 769)
    height = min(int(extent[1] / cell_size) + 1, 769)
    return _GroundGrid(
        origin_x=float(minimum[0]),
        origin_y=float(minimum[1]),
        cell_size=cell_size,
        width=width,
        height=height,
    )


def _robust_ground_surface(xyz: np.ndarray, grid: _GroundGrid) -> np.ndarray:
    cells = grid.indices(xyz)
    order = np.lexsort((xyz[:, 2], cells))
    sorted_cells = cells[order]
    sorted_z = xyz[order, 2]
    unique, starts, counts = np.unique(
        sorted_cells, return_index=True, return_counts=True
    )
    ground = np.full(grid.width * grid.height, np.inf, dtype=np.float32)
    eligible = counts >= 4
    ground[unique[eligible]] = sorted_z[starts[eligible] + 3].astype(np.float32)
    return ground.reshape((grid.height, grid.width))


def _despike_ground(ground: np.ndarray) -> np.ndarray:
    source = ground.copy()
    finite = np.isfinite(source)
    height, width = source.shape
    padded = np.pad(source, 1, constant_values=np.inf)
    neighborhoods = np.lib.stride_tricks.sliding_window_view(padded, (3, 3)).reshape(
        height, width, 9
    )
    ordered = np.sort(neighborhoods, axis=2)
    counts = np.count_nonzero(np.isfinite(neighborhoods), axis=2)
    lower_indices = np.maximum((counts - 1) // 2, 0)[..., np.newaxis]
    upper_indices = (counts // 2)[..., np.newaxis]
    medians = (
        np.take_along_axis(ordered, lower_indices, axis=2)[..., 0]
        + np.take_along_axis(ordered, upper_indices, axis=2)[..., 0]
    ) * 0.5
    replace = finite & (counts >= 4) & (source < medians - 2.5)
    result = source.copy()
    result[replace] = medians[replace]
    return result


def _relax_ground(ground: np.ndarray, cell_size: float) -> np.ndarray:
    result = ground.copy()
    axial = cell_size
    diagonal = axial * np.sqrt(2.0)
    height, width = result.shape
    horizontal_offsets = np.arange(width, dtype=result.dtype) * axial
    for _ in range(2):
        for y in range(height):
            row = result[y]
            if y > 0:
                previous = result[y - 1]
                np.minimum(row, previous + axial, out=row)
                np.minimum(row[1:], previous[:-1] + diagonal, out=row[1:])
                np.minimum(row[:-1], previous[1:] + diagonal, out=row[:-1])
            row[:] = np.minimum.accumulate(row - horizontal_offsets) + (
                horizontal_offsets
            )
        for y in range(height - 1, -1, -1):
            row = result[y]
            if y + 1 < height:
                following = result[y + 1]
                np.minimum(row, following + axial, out=row)
                np.minimum(row[1:], following[:-1] + diagonal, out=row[1:])
                np.minimum(row[:-1], following[1:] + diagonal, out=row[:-1])
            reversed_row = row[::-1]
            reversed_row[:] = (
                np.minimum.accumulate(reversed_row - horizontal_offsets)
                + horizontal_offsets
            )
    return result


def _floor_height(xyz: np.ndarray, classification: np.ndarray) -> float:
    if len(xyz) == 0:
        return 0.0
    stride = max(1, len(xyz) // 65_536)
    sampled_z = xyz[::stride, 2]
    sampled_class = classification[::stride]
    finite = np.isfinite(sampled_z)
    classified_ground = sampled_z[(sampled_class == 2) & finite]
    if len(classified_ground) >= 64:
        return float(np.median(classified_ground))
    finite_z = sampled_z[finite]
    if len(finite_z) == 0:
        finite_z = xyz[np.isfinite(xyz[:, 2]), 2]
    return float(np.quantile(finite_z, 0.05)) if len(finite_z) else 0.0


def _outline_polygon(centers: np.ndarray, cell_size: float) -> object:
    """Return a smooth footprint around occupied cell centers."""
    geometry = concave_hull(MultiPoint(centers), ratio=0.18, allow_holes=False)
    # Cell centers understate the occupied footprint by half a cell. Expanding with
    # round joins both restores that area and removes the staircase/chamfer artifacts
    # caused by tracing square raster cells directly.
    return geometry.buffer(cell_size * 0.55, join_style="round").simplify(
        cell_size * 0.08, preserve_topology=True
    )


def _close_grid_gaps(mask: np.ndarray) -> np.ndarray:
    """Close one-cell sampling gaps without shrinking objects at the raster edge."""
    padded = np.pad(mask, 1, mode="constant", constant_values=False)
    closed = ndimage.binary_closing(
        padded,
        structure=ndimage.generate_binary_structure(2, 2),
        iterations=1,
    )
    return closed[1:-1, 1:-1]


def _object_labels(
    occupied: np.ndarray,
    support: np.ndarray,
) -> tuple[np.ndarray, int]:
    """Split touching overhead footprints using their disconnected low supports."""
    connectivity = ndimage.generate_binary_structure(2, 2)
    occupied_labels, occupied_count = ndimage.label(occupied, structure=connectivity)
    support_labels, support_count = ndimage.label(support, structure=connectivity)
    if support_count:
        support_sizes = np.bincount(support_labels.reshape(-1))
        valid_support = support_sizes >= 2
        valid_support[0] = False
        support_labels = np.where(valid_support[support_labels], support_labels, 0)

    result = np.zeros(occupied.shape, dtype=np.int32)
    result_count = 0
    component_slices = ndimage.find_objects(occupied_labels, max_label=occupied_count)
    for occupied_label, component_slice in enumerate(component_slices, start=1):
        if component_slice is None:
            continue
        component_crop = occupied_labels[component_slice] == occupied_label
        component_support = np.where(component_crop, support_labels[component_slice], 0)
        seeds = np.unique(component_support)
        seeds = seeds[seeds > 0]
        result_crop = result[component_slice]
        if len(seeds) < 2:
            result_count += 1
            result_crop[component_crop] = result_count
            continue

        nearest_indices = ndimage.distance_transform_edt(
            component_support == 0, return_distances=False, return_indices=True
        )
        nearest_labels = component_support[tuple(nearest_indices)]
        accepted_partition = False
        for seed in seeds:
            partition = component_crop & (nearest_labels == seed)
            if np.count_nonzero(partition) >= 5:
                result_count += 1
                result_crop[partition] = result_count
                accepted_partition = True
        if not accepted_partition:
            result_count += 1
            result_crop[component_crop] = result_count
    return result, result_count


def _build_outlines(
    xyz: np.ndarray,
    classification: np.ndarray,
    surface_flags: np.ndarray,
    height_above_ground: np.ndarray,
) -> list[dict[str, object]]:
    if len(xyz) == 0:
        return []
    result: list[dict[str, object]] = []
    categories = (
        ("building", classification == 6, classification == 6),
        (
            "vegetation",
            np.isin(classification, [4, 5]),
            np.isin(classification, [4, 5]),
        ),
        (
            "inferred",
            ((surface_flags & INFERRED_BLOCKER_FLAG) != 0)
            & ~np.isin(classification, [4, 5, 6]),
            classification == 0,
        ),
    )
    minimum = np.min(xyz, axis=0)
    maximum = np.max(xyz, axis=0)
    extent = maximum - minimum
    planar_extent = float(max(extent[0], extent[1]))
    if planar_extent <= 1:
        return []
    cell_size = max(planar_extent / 2048.0, 0.20)
    width = min(int(extent[0] / cell_size) + 1, 2049)
    height = min(int(extent[1] / cell_size) + 1, 2049)

    for category, selected, support_category in categories:
        points = xyz[selected]
        if len(points) < 5:
            continue
        cell_x = np.clip(
            ((points[:, 0] - minimum[0]) / cell_size).astype(np.int64),
            0,
            width - 1,
        )
        cell_y = np.clip(
            ((points[:, 1] - minimum[1]) / cell_size).astype(np.int64),
            0,
            height - 1,
        )
        occupied = np.zeros((height, width), dtype=bool)
        occupied[cell_y, cell_x] = True
        occupied = _close_grid_gaps(occupied)

        # A tree crown and roof can overlap in plan while their trunks/walls remain
        # separate near the ground. Use those low supports as seeds, then assign the
        # shared overhead footprint to its nearest seed.
        supports = (
            support_category
            & (height_above_ground >= 0.15)
            & (height_above_ground <= 1.60)
        )
        support_points = xyz[supports]
        support_grid = np.zeros((height, width), dtype=bool)
        if len(support_points):
            support_x = np.clip(
                ((support_points[:, 0] - minimum[0]) / cell_size).astype(np.int64),
                0,
                width - 1,
            )
            support_y = np.clip(
                ((support_points[:, 1] - minimum[1]) / cell_size).astype(np.int64),
                0,
                height - 1,
            )
            support_grid[support_y, support_x] = True
        # Mesh/point sampling can leave one-cell gaps through a trunk or wall. Close only
        # those tiny gaps; genuinely separate supports remain distinct at this resolution.
        support_grid = _close_grid_gaps(support_grid)
        support_grid &= ndimage.binary_dilation(occupied, iterations=1)

        object_labels, object_count = _object_labels(occupied, support_grid)
        point_labels = object_labels[cell_y, cell_x]
        minimum_z = np.full(object_count + 1, np.inf)
        np.minimum.at(minimum_z, point_labels, points[:, 2])
        object_slices = ndimage.find_objects(object_labels, max_label=object_count)
        for object_label, object_slice in enumerate(object_slices, start=1):
            if object_slice is None:
                continue
            component_cells = np.argwhere(object_labels[object_slice] == object_label)
            if len(component_cells) < 5:
                continue
            component_cells[:, 0] += object_slice[0].start
            component_cells[:, 1] += object_slice[1].start
            centers = np.column_stack(
                (
                    minimum[0] + (component_cells[:, 1] + 0.5) * cell_size,
                    minimum[1] + (component_cells[:, 0] + 0.5) * cell_size,
                )
            )
            geometry = _outline_polygon(centers, cell_size)
            polygons = (
                [geometry]
                if isinstance(geometry, Polygon)
                else list(getattr(geometry, "geoms", []))
            )
            z = (
                float(minimum_z[object_label])
                if np.isfinite(minimum_z[object_label])
                else float(minimum[2])
            )
            for polygon in polygons:
                coordinates = [
                    [float(x), float(y), z] for x, y in polygon.exterior.coords
                ]
                if len(coordinates) >= 4:
                    result.append({"category": category, "coordinates": coordinates})
    return result


def analyze_points(
    xyz: np.ndarray,
    classification: np.ndarray | None = None,
    normal_z_values: np.ndarray | None = None,
    initial_surface_flags: np.ndarray | None = None,
) -> PointViewerAnalysis:
    """Calculate viewer attributes for one registered, non-deduplicated cloud."""
    count = len(xyz)
    classes = (
        np.zeros(count, dtype=np.uint8)
        if classification is None
        else classification.astype(np.uint8, copy=False)
    )
    flags = (
        np.zeros(count, dtype=np.uint8)
        if initial_surface_flags is None
        else initial_surface_flags.astype(np.uint8, copy=True)
    )
    normal_z = np.full(count, UNKNOWN_NORMAL_Z, dtype=np.int8)
    if normal_z_values is not None:
        valid = np.isfinite(normal_z_values)
        normal_z[valid] = np.clip(
            np.rint(normal_z_values[valid] * 127.0), -127, 127
        ).astype(np.int8)
        flags[valid] |= NORMAL_VALID_FLAG

    floor = _floor_height(xyz, classes)
    height_m = np.zeros(count)
    finite_z = np.isfinite(xyz[:, 2])
    height_m[finite_z] = np.maximum(xyz[finite_z, 2] - floor, 0.0)
    grid = _make_ground_grid(xyz)
    if grid is not None:
        ground = _relax_ground(
            _despike_ground(_robust_ground_surface(xyz, grid)), grid.cell_size
        )
        cells = grid.indices(xyz)
        local_ground = ground.reshape(-1)[cells]
        valid_ground = np.isfinite(local_ground)
        height_m[valid_ground] = np.maximum(
            xyz[valid_ground, 2] - local_ground[valid_ground], 0.0
        )
        blocker_height = max(1.8, grid.cell_size * 0.6)
        candidates = valid_ground & (height_m >= blocker_height)
        candidate_counts = np.bincount(
            cells[candidates], minlength=grid.width * grid.height
        )
        inferred = candidates & (candidate_counts[cells] >= 3)
        if np.count_nonzero(inferred) <= count * 0.85:
            flags[inferred] |= INFERRED_BLOCKER_FLAG

    hag_cm = np.clip(np.rint(height_m * 100.0), 0, 65_534).astype(np.uint16)
    try:
        outlines = _build_outlines(xyz, classes, flags, height_m)
    except Exception:
        logger.exception("Viewer outline generation failed; using client-side fallback")
        outlines = []
    coverage = (
        float(np.count_nonzero(flags & NORMAL_VALID_FLAG) / count) if count else 0.0
    )
    return PointViewerAnalysis(
        floor_height=floor,
        height_above_ground_cm=hag_cm,
        normal_z=normal_z,
        surface_flags=flags,
        outlines=outlines,
        normal_coverage=coverage,
    )


def write_viewer_metadata(
    output: str | Path,
    analysis: PointViewerAnalysis,
    *,
    full_point_count: int,
    preview_point_count: int,
) -> None:
    payload = {
        "formatVersion": VIEWER_METADATA_FORMAT_VERSION,
        "analysisVersion": VIEWER_ANALYSIS_VERSION,
        "floorHeight": (
            analysis.floor_height if np.isfinite(analysis.floor_height) else 0.0
        ),
        "normalCoverage": analysis.normal_coverage,
        "fullPointCount": full_point_count,
        "previewPointCount": preview_point_count,
        "outlines": analysis.outlines,
    }
    encoded = json.dumps(
        payload,
        allow_nan=False,
        separators=(",", ":"),
        sort_keys=True,
    )
    destination = Path(output)
    temp = destination.with_suffix(f".{os.getpid()}.tmp{destination.suffix}")
    try:
        temp.write_text(encoded, encoding="utf-8")
        os.replace(temp, destination)
    except BaseException:
        temp.unlink(missing_ok=True)
        raise
