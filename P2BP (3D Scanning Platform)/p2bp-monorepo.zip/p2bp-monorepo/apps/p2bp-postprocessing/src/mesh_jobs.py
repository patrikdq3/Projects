"""Pydantic models for messages produced by p2bp-cf-worker on the MESH_JOBS queue.

Each message carries a `type` for dispatch and a `version` that is pinned per
variant: a consumer validates only the exact schema version it was built for
and rejects any other version, so an incompatible producer fails loudly rather
than being silently mis-parsed. The discriminated union below mirrors the
`MeshJobQueueMessage` type defined in
`p2bp-cf-worker/src/lib/mesh/job-contract.ts`.

Field names are intentionally camelCase to match that JSON wire contract
exactly. Do not rename them to snake_case -- it would break deserialization
of messages produced by the worker.
"""

from typing import Annotated, Literal

from pydantic import BaseModel, ConfigDict, Field, StringConstraints, TypeAdapter

# Identifier that is stripped of surrounding whitespace and must be non-empty,
# so values like " " are rejected rather than treated as valid ids.
NonEmptyId = Annotated[str, StringConstraints(strip_whitespace=True, min_length=1)]

__all__ = [
    "MESH_GENERATE_TYPE",
    "MESH_GENERATE_VERSION",
    "MESH_REFINE_TYPE",
    "MESH_REFINE_VERSION",
    "MeshGenerateJob",
    "MeshJobMessage",
    "MeshRefineJob",
    "parse_mesh_job_message",
]

MESH_GENERATE_TYPE = "mesh.generate"
MESH_REFINE_TYPE = "mesh.refine"

MESH_GENERATE_VERSION = 3
MESH_REFINE_VERSION = 1


class _MeshJobBase(BaseModel):
    """Fields and config shared by every mesh job message."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    organizationId: NonEmptyId
    projectId: NonEmptyId


class MeshGenerateJob(_MeshJobBase):
    """Mesh generation job: build a mesh from uploaded zone scan archives.

    Version 3 adds viewer analysis artifacts. It retains the v2 fields, including
    the worker-assigned ``jobId``; outputs and the job's
    ``status.json`` are written under the versioned per-job prefix
    ``organizations/{organizationId}/projects/{projectId}/mesh-jobs/{jobId}/``.
    """

    type: Literal[MESH_GENERATE_TYPE] = MESH_GENERATE_TYPE
    version: Literal[MESH_GENERATE_VERSION] = MESH_GENERATE_VERSION
    jobId: NonEmptyId
    zoneScanObjectKeys: list[NonEmptyId] = Field(min_length=1)


class MeshRefineJob(_MeshJobBase):
    """Mesh refinement job: refine an existing mesh for a project."""

    type: Literal[MESH_REFINE_TYPE] = MESH_REFINE_TYPE
    version: Literal[MESH_REFINE_VERSION] = MESH_REFINE_VERSION


# The v3 payload has the same input fields as v2; parsing normalizes queued v2
# messages during the rolling deployment window. Older incompatible versions
# still fail validation and dead-letter.
MeshJobMessage = Annotated[
    MeshGenerateJob | MeshRefineJob,
    Field(discriminator="type"),
]

mesh_job_message_adapter: TypeAdapter[MeshJobMessage] = TypeAdapter(MeshJobMessage)


def parse_mesh_job_message(data: object) -> MeshJobMessage:
    """Validate arbitrary data into a :class:`MeshJobMessage` variant."""
    if (
        isinstance(data, dict)
        and data.get("type") == MESH_GENERATE_TYPE
        and data.get("version") == 2
    ):
        data = {**data, "version": MESH_GENERATE_VERSION}
    return mesh_job_message_adapter.validate_python(data)
