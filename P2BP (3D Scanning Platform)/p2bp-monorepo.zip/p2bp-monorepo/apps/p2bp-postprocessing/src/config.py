"""Shared configuration helpers.

Small, dependency-free utilities for reading required configuration from the
environment. Library modules should let `ConfigError` propagate; entry-point
scripts catch it and decide how to report/exit.
"""

import math
import os

__all__ = [
    "ConfigError",
    "env_bool",
    "env_float",
    "env_int",
    "env_string",
    "require_env",
]


class ConfigError(RuntimeError):
    """Raised when required configuration (e.g. an env var) is missing."""


def require_env(name: str) -> str:
    """Return the value of env var `name`, or raise ConfigError if unset.

    An empty string is treated as missing.
    """

    value = os.getenv(name)

    if not value:
        raise ConfigError(f"Missing required environment variable: {name}")

    return value


def env_string(name: str, default: str) -> str:
    """Return an optional non-empty string environment value."""

    value = os.getenv(name)
    if value is None:
        return default
    value = value.strip()
    if not value:
        raise ConfigError(f"Environment variable {name} must not be empty")
    return value


def env_int(name: str, default: int) -> int:
    """Return an optional integer environment value, or ``default`` when unset."""

    value = os.getenv(name)
    if value is None:
        return default
    try:
        return int(value)
    except ValueError as error:
        raise ConfigError(f"Environment variable {name} must be an integer") from error


def env_float(name: str, default: float) -> float:
    """Return an optional finite float environment value."""

    value = os.getenv(name)
    if value is None:
        return default
    try:
        parsed = float(value)
    except ValueError as error:
        raise ConfigError(f"Environment variable {name} must be a number") from error
    if not math.isfinite(parsed):
        raise ConfigError(f"Environment variable {name} must be finite")
    return parsed


def env_bool(name: str, default: bool) -> bool:
    """Return an optional boolean environment value.

    Accepted values are ``true``/``false``, ``1``/``0``, ``yes``/``no``, and
    ``on``/``off`` (case-insensitive).
    """

    value = os.getenv(name)
    if value is None:
        return default
    normalized = value.strip().lower()
    if normalized in {"1", "true", "yes", "on"}:
        return True
    if normalized in {"0", "false", "no", "off"}:
        return False
    raise ConfigError(f"Environment variable {name} must be a boolean")
