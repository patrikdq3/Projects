"""One-off migration: replace merged point cloud `.bin` outputs with `.e57`.

Merged clouds used to be published as LAZ plus a packed `.bin` companion for the
iOS viewer. The `.bin` outputs are no longer produced, served, or read; E57 (the
format CAD tools such as Rhino import natively) took their place. This script
brings already-stored merges in line with that: every `merged-point-cloud.bin`
and `merged-point-cloud.preview.bin` in R2 gets an E57 sibling generated from
the LAZ next to it, and only then is the `.bin` deleted.

The E57 is regenerated from the LAZ rather than converted from the `.bin`: the
LAZ is the full-precision output (millimeter-scaled coordinates, CRS, and
per-point confidence), whereas the `.bin` stored 32-bit float coordinates that
had already lost precision at UTM magnitudes. Converting the `.bin` would carry
that error forward.

Both key layouts are covered: the versioned per-job outputs under
`organizations/{orgId}/projects/{projectId}/mesh-jobs/{jobId}/` and the legacy
fixed keys directly under `organizations/{orgId}/projects/{projectId}/`. Zone
scan previews (`.../scans/{uploadId}.preview.bin`) are a different artifact that
is still in use, and are never matched: only the exact filenames below are.

Usage:

    # Report what would change, touching nothing (the default).
    uv run migrate-merged-point-cloud-e57

    # Perform the migration.
    uv run migrate-merged-point-cloud-e57 --apply

    # Scope to one organization or project.
    uv run migrate-merged-point-cloud-e57 --prefix organizations/org_123/

Requires the same R2 environment variables as the queue worker
(CLOUDFLARE_ACCOUNT_ID, R2_ACCESS_KEY_ID, R2_SECRET_ACCESS_KEY, R2_BUCKET).

Deletes are permanent, and re-running is safe: a cloud whose E57 already exists
skips straight to deleting its `.bin`, and a `.bin` whose LAZ is missing is
reported and left alone, because there would be nothing to replace it with.

Running this also spares re-merges. The Worker only reuses a completed mesh job
that still has every output the pipeline publishes (`hasCurrentMeshJobOutputs`
in `p2bp-cf-worker`), so without a backfill the next launch for unchanged scans
re-runs the whole merge just to produce the E57. Backfilled jobs pass that check
and are reused as before -- except for merges old enough to also predate
`merged-point-cloud.viewer.json`, which this script does not generate; those
still re-merge once.
"""

from __future__ import annotations

import argparse
import logging
import sys
from collections.abc import Iterable, Sequence
from dataclasses import dataclass
from enum import Enum
from pathlib import Path

import laspy
import numpy as np
from botocore.client import BaseClient

from r2 import (
    create_r2_client,
    default_bucket,
    delete_object,
    download_object,
    iter_object_keys,
    temp_download_dir,
    upload_object,
)
from scanproject_merger import write_e57_cloud

logger = logging.getLogger("migrate-merged-point-cloud-e57")

DEFAULT_PREFIX = "organizations/"

# Merged cloud filenames, keyed by the `.bin` being retired. Matching is on the
# whole final path segment so zone scan previews (`{uploadId}.preview.bin`)
# cannot match.
MERGED_POINT_CLOUD_BIN_FILENAMES: dict[str, tuple[str, str]] = {
    # bin filename: (source LAZ filename, E57 filename to publish)
    "merged-point-cloud.bin": (
        "merged-point-cloud.laz",
        "merged-point-cloud.e57",
    ),
    "merged-point-cloud.preview.bin": (
        "merged-point-cloud.preview.laz",
        "merged-point-cloud.preview.e57",
    ),
}


class Outcome(str, Enum):
    """What happened (or would happen) to one `.bin` object."""

    MIGRATED = "migrated"  # E57 written from the LAZ, then the .bin deleted.
    E57_ALREADY_PRESENT = "e57-already-present"  # Only the .bin needed deleting.
    MISSING_LAZ = "missing-laz"  # No source to rebuild from; .bin left in place.
    FAILED = "failed"


@dataclass(frozen=True)
class MergedCloudBinObject:
    """A `.bin` to retire, with the keys it is replaced from and by."""

    bin_key: str
    laz_key: str
    e57_key: str


def plan_migration(keys: Iterable[str]) -> list[MergedCloudBinObject]:
    """Pair every merged cloud `.bin` key with its LAZ source and E57 target."""

    planned: list[MergedCloudBinObject] = []
    for key in sorted(keys):
        prefix, _, filename = key.rpartition("/")
        names = MERGED_POINT_CLOUD_BIN_FILENAMES.get(filename)
        if not prefix or names is None:
            continue
        laz_filename, e57_filename = names
        planned.append(
            MergedCloudBinObject(
                bin_key=key,
                laz_key=f"{prefix}/{laz_filename}",
                e57_key=f"{prefix}/{e57_filename}",
            )
        )
    return planned


def convert_laz_to_e57(laz_path: Path, e57_path: Path) -> int:
    """Write `laz_path` back out as E57, returning the point count.

    Reads the same fields the merge job's E57 export writes -- position, color,
    and confidence -- so a migrated cloud is indistinguishable from one produced
    by a fresh merge.
    """

    cloud = laspy.read(str(laz_path))
    crs = cloud.header.parse_crs()
    epsg = crs.to_epsg() if crs else None
    if epsg is None:
        raise ValueError(f"{laz_path.name} has no EPSG code; cannot georeference E57")

    xyz = np.column_stack((cloud.x, cloud.y, cloud.z))
    # LAS stores 16-bit RGB; the merge job scales 8-bit channels up by 257.
    rgb = (np.column_stack((cloud.red, cloud.green, cloud.blue)) // 257).astype(
        np.uint8
    )
    if "confidence" in cloud.point_format.extra_dimension_names:
        confidence = np.asarray(cloud.confidence)
    else:
        # Pre-confidence clouds still convert; they just carry no intensity.
        confidence = np.zeros(len(xyz), dtype=np.uint8)

    write_e57_cloud(e57_path, xyz, rgb, confidence, epsg)
    return len(xyz)


def migrate_object(
    client: BaseClient,
    target: MergedCloudBinObject,
    *,
    bucket: str,
    existing_keys: set[str],
    apply: bool,
) -> Outcome:
    """Publish the E57 for one `.bin` and delete it. No writes unless `apply`."""

    if target.e57_key in existing_keys:
        logger.info("%s: E57 already present, deleting the .bin only", target.bin_key)
        if apply:
            delete_object(client, target.bin_key, bucket=bucket)
        return Outcome.E57_ALREADY_PRESENT

    if target.laz_key not in existing_keys:
        logger.warning(
            "%s: no %s to rebuild from; leaving the .bin in place",
            target.bin_key,
            Path(target.laz_key).name,
        )
        return Outcome.MISSING_LAZ

    logger.info("%s: writing %s from the LAZ", target.bin_key, target.e57_key)
    if not apply:
        return Outcome.MIGRATED

    with temp_download_dir("merged-point-cloud-e57") as workspace:
        laz_path = workspace / Path(target.laz_key).name
        e57_path = workspace / Path(target.e57_key).name
        download_object(client, target.laz_key, laz_path, bucket=bucket)
        point_count = convert_laz_to_e57(laz_path, e57_path)
        upload_object(client, e57_path, target.e57_key, bucket=bucket, overwrite=True)
        logger.info("%s: wrote %d points", target.e57_key, point_count)

    # Deleting only after the upload returned keeps a failed conversion from
    # destroying the .bin, which is the last copy of nothing else but is still
    # the object the operator would look for if this run has to be re-examined.
    delete_object(client, target.bin_key, bucket=bucket)
    return Outcome.MIGRATED


def migrate(
    client: BaseClient,
    *,
    bucket: str,
    prefix: str = DEFAULT_PREFIX,
    apply: bool = False,
) -> dict[Outcome, int]:
    """Migrate every merged cloud `.bin` under `prefix`, returning outcome counts."""

    logger.info(
        "Listing r2://%s/%s (%s)",
        bucket,
        prefix,
        "applying changes" if apply else "dry run",
    )
    existing_keys = set(iter_object_keys(client, prefix, bucket=bucket))
    targets = plan_migration(existing_keys)
    logger.info(
        "Found %d merged point cloud .bin object(s) among %d key(s)",
        len(targets),
        len(existing_keys),
    )

    counts: dict[Outcome, int] = {outcome: 0 for outcome in Outcome}
    for target in targets:
        try:
            outcome = migrate_object(
                client,
                target,
                bucket=bucket,
                existing_keys=existing_keys,
                apply=apply,
            )
        except Exception:
            # One unreadable or unconvertible cloud should not strand the rest;
            # the run reports a non-zero exit so the failures get looked at.
            logger.exception("%s: migration failed", target.bin_key)
            outcome = Outcome.FAILED
        counts[outcome] += 1
    return counts


def _parse_args(argv: Sequence[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Replace merged point cloud .bin objects in R2 with E57 exports "
            "rebuilt from the LAZ beside them."
        )
    )
    parser.add_argument(
        "--prefix",
        default=DEFAULT_PREFIX,
        help=f"Key prefix to scan (default: {DEFAULT_PREFIX})",
    )
    parser.add_argument(
        "--bucket",
        default=None,
        help="R2 bucket (defaults to the R2_BUCKET environment variable)",
    )
    parser.add_argument(
        "--apply",
        action="store_true",
        help="Perform the migration. Without it, the run only reports.",
    )
    return parser.parse_args(argv)


def main(argv: Sequence[str] | None = None) -> int:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(message)s",
    )
    args = _parse_args(argv)
    counts = migrate(
        create_r2_client(),
        bucket=args.bucket or default_bucket(),
        prefix=args.prefix,
        apply=args.apply,
    )

    verb = "Migrated" if args.apply else "Would migrate"
    logger.info(
        "%s %d cloud(s); %d already had an E57; %d missing a LAZ source; %d failed",
        verb,
        counts[Outcome.MIGRATED],
        counts[Outcome.E57_ALREADY_PRESENT],
        counts[Outcome.MISSING_LAZ],
        counts[Outcome.FAILED],
    )
    if not args.apply and (
        counts[Outcome.MIGRATED] or counts[Outcome.E57_ALREADY_PRESENT]
    ):
        logger.info("Dry run: nothing was written or deleted. Re-run with --apply.")

    # Anything left unmigrated needs a human, so surface it in the exit code.
    return 1 if counts[Outcome.FAILED] or counts[Outcome.MISSING_LAZ] else 0


if __name__ == "__main__":
    sys.exit(main())
