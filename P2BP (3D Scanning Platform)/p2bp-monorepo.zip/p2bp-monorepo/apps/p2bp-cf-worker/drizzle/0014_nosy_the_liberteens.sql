PRAGMA foreign_keys=OFF;--> statement-breakpoint
CREATE TABLE `__new_zones` (
	`id` text PRIMARY KEY NOT NULL,
	`project_id` text NOT NULL,
	`x` integer NOT NULL,
	`y` integer NOT NULL,
	`scanned_at` integer NOT NULL,
	`duration` real,
	`point_count` integer,
	`scan_object_key` text,
	`scan_upload_status` text,
	`scan_upload_expires_at` integer,
	`scan_uploaded_at` integer,
	`metadata` text,
	`created_at` integer DEFAULT (unixepoch()) NOT NULL,
	FOREIGN KEY (`project_id`) REFERENCES `projects`(`id`) ON UPDATE no action ON DELETE cascade,
	CONSTRAINT "duration_check" CHECK(duration IS NULL OR duration >= 0),
	CONSTRAINT "point_count_check" CHECK(point_count IS NULL OR point_count >= 0),
	CONSTRAINT "scan_object_key_check" CHECK(scan_object_key IS NULL OR length(scan_object_key) <= 2048),
	CONSTRAINT "scan_upload_status_check" CHECK(scan_upload_status IS NULL OR scan_upload_status IN ('pending', 'uploaded', 'expired')),
	CONSTRAINT "scan_upload_state_check" CHECK((
				scan_upload_status IS NULL
				AND scan_object_key IS NULL
				AND scan_upload_expires_at IS NULL
				AND scan_uploaded_at IS NULL
			) OR (
				scan_upload_status = 'pending'
				AND scan_object_key IS NOT NULL
				AND scan_upload_expires_at IS NOT NULL
				AND scan_uploaded_at IS NULL
			) OR (
				scan_upload_status = 'uploaded'
				AND scan_object_key IS NOT NULL
				AND scan_upload_expires_at IS NOT NULL
				AND scan_uploaded_at IS NOT NULL
			) OR (
				scan_upload_status = 'expired'
				AND scan_object_key IS NOT NULL
				AND scan_upload_expires_at IS NOT NULL
				AND scan_uploaded_at IS NULL
			)),
	CONSTRAINT "metadata_check" CHECK(metadata IS NULL OR json_valid(metadata))
);
--> statement-breakpoint
INSERT INTO `__new_zones`("id", "project_id", "x", "y", "scanned_at", "duration", "point_count", "scan_object_key", "scan_upload_status", "scan_upload_expires_at", "scan_uploaded_at", "metadata", "created_at") SELECT "id", "project_id", "x", "y", "scanned_at", "duration", "point_count", NULL, NULL, NULL, NULL, "metadata", "created_at" FROM `zones`;--> statement-breakpoint
DROP TABLE `zones`;--> statement-breakpoint
ALTER TABLE `__new_zones` RENAME TO `zones`;--> statement-breakpoint
PRAGMA foreign_keys=ON;--> statement-breakpoint
CREATE UNIQUE INDEX `zones_project_xy_unique` ON `zones` (`project_id`,`x`,`y`);--> statement-breakpoint
CREATE UNIQUE INDEX `zones_scan_object_key_unique` ON `zones` (`scan_object_key`);