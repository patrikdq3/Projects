-- Custom Drizzle migration: data backfill for personal-workspace organizations and owner memberships.
INSERT INTO `organization` (`id`, `name`, `slug`, `created_at`)
SELECT
	substr('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', abs(random()) % 62 + 1, 1) ||
	substr('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', abs(random()) % 62 + 1, 1) ||
	substr('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', abs(random()) % 62 + 1, 1) ||
	substr('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', abs(random()) % 62 + 1, 1) ||
	substr('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', abs(random()) % 62 + 1, 1) ||
	substr('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', abs(random()) % 62 + 1, 1) ||
	substr('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', abs(random()) % 62 + 1, 1) ||
	substr('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', abs(random()) % 62 + 1, 1) ||
	substr('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', abs(random()) % 62 + 1, 1) ||
	substr('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', abs(random()) % 62 + 1, 1) ||
	substr('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', abs(random()) % 62 + 1, 1) ||
	substr('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', abs(random()) % 62 + 1, 1) ||
	substr('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', abs(random()) % 62 + 1, 1) ||
	substr('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', abs(random()) % 62 + 1, 1) ||
	substr('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', abs(random()) % 62 + 1, 1) ||
	substr('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', abs(random()) % 62 + 1, 1) ||
	substr('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', abs(random()) % 62 + 1, 1) ||
	substr('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', abs(random()) % 62 + 1, 1) ||
	substr('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', abs(random()) % 62 + 1, 1) ||
	substr('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', abs(random()) % 62 + 1, 1) ||
	substr('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', abs(random()) % 62 + 1, 1) ||
	substr('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', abs(random()) % 62 + 1, 1) ||
	substr('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', abs(random()) % 62 + 1, 1) ||
	substr('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', abs(random()) % 62 + 1, 1) ||
	substr('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', abs(random()) % 62 + 1, 1) ||
	substr('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', abs(random()) % 62 + 1, 1) ||
	substr('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', abs(random()) % 62 + 1, 1) ||
	substr('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', abs(random()) % 62 + 1, 1) ||
	substr('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', abs(random()) % 62 + 1, 1) ||
	substr('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', abs(random()) % 62 + 1, 1) ||
	substr('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', abs(random()) % 62 + 1, 1) ||
	substr('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', abs(random()) % 62 + 1, 1),
	CASE
		WHEN `user`.`username` IS NOT NULL THEN `user`.`username`
		ELSE `user`.`name`
	END || '-workspace',
	`user`.`id` || '-workspace',
	cast(unixepoch('subsecond') * 1000 as integer)
FROM `user`
LEFT JOIN `organization`
	ON `organization`.`slug` = `user`.`id` || '-workspace'
WHERE `organization`.`id` IS NULL;
--> statement-breakpoint
INSERT INTO `member` (`id`, `organization_id`, `user_id`, `role`, `created_at`)
SELECT
	substr('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', abs(random()) % 62 + 1, 1) ||
	substr('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', abs(random()) % 62 + 1, 1) ||
	substr('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', abs(random()) % 62 + 1, 1) ||
	substr('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', abs(random()) % 62 + 1, 1) ||
	substr('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', abs(random()) % 62 + 1, 1) ||
	substr('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', abs(random()) % 62 + 1, 1) ||
	substr('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', abs(random()) % 62 + 1, 1) ||
	substr('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', abs(random()) % 62 + 1, 1) ||
	substr('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', abs(random()) % 62 + 1, 1) ||
	substr('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', abs(random()) % 62 + 1, 1) ||
	substr('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', abs(random()) % 62 + 1, 1) ||
	substr('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', abs(random()) % 62 + 1, 1) ||
	substr('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', abs(random()) % 62 + 1, 1) ||
	substr('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', abs(random()) % 62 + 1, 1) ||
	substr('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', abs(random()) % 62 + 1, 1) ||
	substr('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', abs(random()) % 62 + 1, 1) ||
	substr('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', abs(random()) % 62 + 1, 1) ||
	substr('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', abs(random()) % 62 + 1, 1) ||
	substr('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', abs(random()) % 62 + 1, 1) ||
	substr('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', abs(random()) % 62 + 1, 1) ||
	substr('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', abs(random()) % 62 + 1, 1) ||
	substr('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', abs(random()) % 62 + 1, 1) ||
	substr('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', abs(random()) % 62 + 1, 1) ||
	substr('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', abs(random()) % 62 + 1, 1) ||
	substr('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', abs(random()) % 62 + 1, 1) ||
	substr('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', abs(random()) % 62 + 1, 1) ||
	substr('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', abs(random()) % 62 + 1, 1) ||
	substr('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', abs(random()) % 62 + 1, 1) ||
	substr('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', abs(random()) % 62 + 1, 1) ||
	substr('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', abs(random()) % 62 + 1, 1) ||
	substr('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', abs(random()) % 62 + 1, 1) ||
	substr('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', abs(random()) % 62 + 1, 1),
	`organization`.`id`,
	`user`.`id`,
	'owner',
	cast(unixepoch('subsecond') * 1000 as integer)
FROM `user`
INNER JOIN `organization`
	ON `organization`.`slug` = `user`.`id` || '-workspace'
LEFT JOIN `member`
	ON `member`.`organization_id` = `organization`.`id`
	AND `member`.`user_id` = `user`.`id`
WHERE `member`.`id` IS NULL;
--> statement-breakpoint
UPDATE `member`
SET `role` = 'owner'
WHERE `role` <> 'owner'
	AND EXISTS (
		SELECT 1
		FROM `organization`
		WHERE `organization`.`id` = `member`.`organization_id`
			AND `organization`.`slug` = `member`.`user_id` || '-workspace'
	);
