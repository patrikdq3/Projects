-- Custom Drizzle migration: create zone scan archive history and backfill current scan pointers.
-- The INSERT preserves any current versioned scan object already present on zones; legacy file_url values were intentionally discarded in 0014.
CREATE TABLE `zone_scan_archives` (
	`id` text PRIMARY KEY NOT NULL,
	`zone_id` text NOT NULL,
	`object_key` text NOT NULL,
	`upload_status` text NOT NULL,
	`upload_expires_at` integer NOT NULL,
	`uploaded_at` integer,
	`created_at` integer DEFAULT (unixepoch()) NOT NULL,
	FOREIGN KEY (`zone_id`) REFERENCES `zones`(`id`) ON UPDATE no action ON DELETE cascade,
	CONSTRAINT "zone_scan_archives_object_key_check" CHECK(length(object_key) <= 2048),
	CONSTRAINT "zone_scan_archives_upload_status_check" CHECK(upload_status IN ('pending', 'uploaded', 'expired')),
	CONSTRAINT "zone_scan_archives_upload_state_check" CHECK((
				upload_status = 'pending'
				AND uploaded_at IS NULL
			) OR (
				upload_status = 'uploaded'
				AND uploaded_at IS NOT NULL
			) OR (
				upload_status = 'expired'
				AND uploaded_at IS NULL
			))
);
--> statement-breakpoint
CREATE UNIQUE INDEX `zone_scan_archives_object_key_unique` ON `zone_scan_archives` (`object_key`);--> statement-breakpoint
INSERT INTO `zone_scan_archives`("id", "zone_id", "object_key", "upload_status", "upload_expires_at", "uploaded_at", "created_at") SELECT CASE WHEN instr("scan_object_key", '/scans/') > 0 AND substr("scan_object_key", -4) = '.zip' THEN substr("scan_object_key", instr("scan_object_key", '/scans/') + 7, length("scan_object_key") - instr("scan_object_key", '/scans/') - 10) ELSE lower(hex(randomblob(4))) || '-' || lower(hex(randomblob(2))) || '-4' || substr(lower(hex(randomblob(2))), 2) || '-' || substr('89ab', abs(random()) % 4 + 1, 1) || substr(lower(hex(randomblob(2))), 2) || '-' || lower(hex(randomblob(6))) END, "id", "scan_object_key", "scan_upload_status", "scan_upload_expires_at", "scan_uploaded_at", unixepoch() FROM `zones` WHERE "scan_object_key" IS NOT NULL AND "scan_upload_status" IS NOT NULL AND "scan_upload_expires_at" IS NOT NULL;
