PRAGMA foreign_keys=OFF;--> statement-breakpoint
CREATE TABLE `__new_projects` (
	`id` text PRIMARY KEY NOT NULL,
	`organization_id` text NOT NULL,
	`name` text NOT NULL,
	`description` text,
	`initial_lat` real NOT NULL,
	`initial_long` real NOT NULL,
	`zone_size` integer NOT NULL,
	`created_at` integer DEFAULT (unixepoch()) NOT NULL,
	FOREIGN KEY (`organization_id`) REFERENCES `organization`(`id`) ON UPDATE no action ON DELETE cascade,
	CONSTRAINT "projects_name_check" CHECK(length(name) >= 1 AND length(name) <= 100),
	CONSTRAINT "description_check" CHECK(description IS NULL OR length(description) <= 1000),
	CONSTRAINT "projects_initial_lat_check" CHECK(initial_lat >= -90 AND initial_lat <= 90),
	CONSTRAINT "projects_initial_long_check" CHECK(initial_long >= -180 AND initial_long <= 180),
	CONSTRAINT "projects_zone_size_check" CHECK(zone_size > 0)
);
--> statement-breakpoint
INSERT INTO `__new_projects`("id", "organization_id", "name", "description", "initial_lat", "initial_long", "zone_size", "created_at") SELECT "id", "organization_id", "name", "description", "initial_lat", "initial_long", "zone_size", "created_at" FROM `projects`;--> statement-breakpoint
DROP TABLE `projects`;--> statement-breakpoint
ALTER TABLE `__new_projects` RENAME TO `projects`;--> statement-breakpoint
PRAGMA foreign_keys=ON;--> statement-breakpoint
CREATE TABLE `__new_boundary_points` (
	`id` text PRIMARY KEY NOT NULL,
	`project_id` text NOT NULL,
	`latitude` real NOT NULL,
	`longitude` real NOT NULL,
	FOREIGN KEY (`project_id`) REFERENCES `projects`(`id`) ON UPDATE no action ON DELETE cascade,
	CONSTRAINT "boundary_lat_check" CHECK(latitude >= -90 AND latitude <= 90),
	CONSTRAINT "boundary_long_check" CHECK(longitude >= -180 AND longitude <= 180)
);
--> statement-breakpoint
INSERT INTO `__new_boundary_points`("id", "project_id", "latitude", "longitude") SELECT "id", "project_id", "latitude", "longitude" FROM `boundary_points`;--> statement-breakpoint
DROP TABLE `boundary_points`;--> statement-breakpoint
ALTER TABLE `__new_boundary_points` RENAME TO `boundary_points`;