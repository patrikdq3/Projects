PRAGMA foreign_keys=OFF;--> statement-breakpoint
CREATE TABLE `__backup_boundary_points` AS SELECT * FROM `boundary_points`;--> statement-breakpoint
CREATE TABLE `__backup_zones` AS SELECT * FROM `zones`;--> statement-breakpoint
CREATE TABLE `__new_projects` (
	`id` text PRIMARY KEY NOT NULL,
	`organization_id` text NOT NULL,
	`name` text NOT NULL,
	`description` text,
	`initial_lat` real NOT NULL,
	`initial_long` real NOT NULL,
	`zone_size` integer NOT NULL,
	`created_at` integer DEFAULT (unixepoch()) NOT NULL,
	FOREIGN KEY (`organization_id`) REFERENCES `organization`(`id`) ON UPDATE no action ON DELETE cascade,
	CONSTRAINT "projects_name_check" CHECK(length(name) >= 1 AND length(name) <= 100),
	CONSTRAINT "description_check" CHECK(description IS NULL OR length(description) <= 1000),
	CONSTRAINT "projects_initial_lat_check" CHECK(initial_lat > -90 AND initial_lat < 90),
	CONSTRAINT "projects_initial_long_check" CHECK(initial_long >= -180 AND initial_long <= 180),
	CONSTRAINT "projects_zone_size_check" CHECK(zone_size > 0)
);
--> statement-breakpoint
INSERT INTO `__new_projects`("id", "organization_id", "name", "description", "initial_lat", "initial_long", "zone_size", "created_at") SELECT "id", "organization_id", "name", "description", "initial_lat", "initial_long", "zone_size", "created_at" FROM `projects`;--> statement-breakpoint
DROP TABLE `projects`;--> statement-breakpoint
ALTER TABLE `__new_projects` RENAME TO `projects`;--> statement-breakpoint
DELETE FROM `boundary_points`;--> statement-breakpoint
DELETE FROM `zones`;--> statement-breakpoint
INSERT INTO `boundary_points`("id", "project_id", "latitude", "longitude", "sort_order") SELECT "id", "project_id", "latitude", "longitude", "sort_order" FROM `__backup_boundary_points`;--> statement-breakpoint
INSERT INTO `zones`("id", "project_id", "x", "y", "scanned_at", "duration", "point_count", "file_url", "metadata", "created_at") SELECT "id", "project_id", "x", "y", "scanned_at", "duration", "point_count", "file_url", "metadata", "created_at" FROM `__backup_zones`;--> statement-breakpoint
DROP TABLE `__backup_boundary_points`;--> statement-breakpoint
DROP TABLE `__backup_zones`;--> statement-breakpoint
PRAGMA foreign_keys=ON;