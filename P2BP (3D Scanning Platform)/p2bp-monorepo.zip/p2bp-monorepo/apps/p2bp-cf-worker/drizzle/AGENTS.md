# Agent Notes

- `drizzle/` is generated via `bun run db:generate`; treat the SQL files and `meta/` snapshots as generated output unless a deliberate manual migration edit is required.
- Generated-file verification runs through `bun run ci:check-generated-files`; it reruns `better-auth-gen-schema`, `db:generate`, and `cf-typegen`, then applies `bun run biome:fix` before diffing `drizzle/`, `src/db/schema/better-auth.schema.ts`, and `worker-configuration.d.ts` against the checked-in state.
- Custom SQL migrations generated with `drizzle-kit generate --custom` should start with a top-of-file `-- Custom Drizzle migration: ...` comment so they are visibly distinct from schema-generated SQL.
- Do not read `meta/*_snapshot.json` files. They are large, regenerated Drizzle state snapshots; treat them as opaque. Only inspect a specific snapshot when a Drizzle migration/journal issue cannot be diagnosed from the SQL migration files or `_journal.json` alone.
