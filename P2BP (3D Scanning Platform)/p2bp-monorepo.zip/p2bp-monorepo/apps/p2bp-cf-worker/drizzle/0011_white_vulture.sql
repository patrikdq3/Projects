PRAGMA foreign_keys=OFF;--> statement-breakpoint
CREATE TABLE `__new_zones` (
	`id` text PRIMARY KEY NOT NULL,
	`project_id` text NOT NULL,
	`x` integer NOT NULL,
	`y` integer NOT NULL,
	`scanned_at` integer NOT NULL,
	`duration` real,
	`point_count` integer,
	`file_url` text,
	`metadata` text,
	`created_at` integer DEFAULT (unixepoch()) NOT NULL,
	FOREIGN KEY (`project_id`) REFERENCES `projects`(`id`) ON UPDATE no action ON DELETE cascade,
	CONSTRAINT "duration_check" CHECK(duration IS NULL OR duration >= 0),
	CONSTRAINT "point_count_check" CHECK(point_count IS NULL OR point_count >= 0),
	CONSTRAINT "file_url_check" CHECK(file_url IS NULL OR length(file_url) <= 2048),
	CONSTRAINT "metadata_check" CHECK(metadata IS NULL OR json_valid(metadata))
);
--> statement-breakpoint
INSERT INTO `__new_zones`("id", "project_id", "x", "y", "scanned_at", "duration", "point_count", "file_url", "metadata", "created_at") SELECT "id", "project_id", "x", "y", "scanned_at", "duration", "point_count", "file_url", "metadata", "created_at" FROM `zones`;--> statement-breakpoint
DROP TABLE `zones`;--> statement-breakpoint
ALTER TABLE `__new_zones` RENAME TO `zones`;--> statement-breakpoint
PRAGMA foreign_keys=ON;--> statement-breakpoint
CREATE UNIQUE INDEX `zones_project_xy_unique` ON `zones` (`project_id`,`x`,`y`);