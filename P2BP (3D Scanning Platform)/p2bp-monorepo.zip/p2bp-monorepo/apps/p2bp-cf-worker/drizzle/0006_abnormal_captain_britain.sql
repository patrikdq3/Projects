CREATE TABLE `boundary_points` (
	`id` text PRIMARY KEY NOT NULL,
	`project_id` text NOT NULL,
	`latitude` real NOT NULL,
	`longitude` real NOT NULL,
	FOREIGN KEY (`project_id`) REFERENCES `projects`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
ALTER TABLE `projects` ADD `initial_lat` real;--> statement-breakpoint
ALTER TABLE `projects` ADD `initial_long` real;--> statement-breakpoint
ALTER TABLE `projects` ADD `zone_size` integer;