CREATE TABLE `projects` (
	`id` text PRIMARY KEY NOT NULL,
	`organization_id` text NOT NULL,
	`name` text NOT NULL,
	`description` text,
	`created_at` integer DEFAULT (unixepoch()) NOT NULL,
	FOREIGN KEY (`organization_id`) REFERENCES `organization`(`id`) ON UPDATE no action ON DELETE cascade,
	CONSTRAINT "projects_name_check" CHECK(length(name) >= 1 AND length(name) <= 100),
	CONSTRAINT "description_check" CHECK(description IS NULL OR length(description) <= 1000)
);
--> statement-breakpoint
CREATE TABLE `zones` (
	`id` text PRIMARY KEY NOT NULL,
	`project_id` text NOT NULL,
	`longitude` real,
	`latitude` real,
	`scanned_at` integer NOT NULL,
	`duration` real,
	`point_count` integer,
	`file_url` text,
	`metadata` text,
	`created_at` integer DEFAULT (unixepoch()) NOT NULL,
	FOREIGN KEY (`project_id`) REFERENCES `projects`(`id`) ON UPDATE no action ON DELETE cascade,
	CONSTRAINT "longitude_check" CHECK(longitude IS NULL OR (longitude >= -180 AND longitude <= 180)),
	CONSTRAINT "latitude_check" CHECK(latitude IS NULL OR (latitude >= -90 AND latitude <= 90)),
	CONSTRAINT "duration_check" CHECK(duration IS NULL OR duration >= 0),
	CONSTRAINT "point_count_check" CHECK(point_count IS NULL OR point_count >= 0),
	CONSTRAINT "file_url_check" CHECK(file_url IS NULL OR length(file_url) <= 2048),
	CONSTRAINT "metadata_check" CHECK(metadata IS NULL OR json_valid(metadata))
);
--> statement-breakpoint
ALTER TABLE `user` ADD `username` text;--> statement-breakpoint
ALTER TABLE `user` ADD `display_username` text;--> statement-breakpoint
CREATE UNIQUE INDEX `user_username_unique` ON `user` (`username`);