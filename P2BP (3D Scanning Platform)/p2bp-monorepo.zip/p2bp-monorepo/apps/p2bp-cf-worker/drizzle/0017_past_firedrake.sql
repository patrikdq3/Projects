PRAGMA foreign_keys=OFF;--> statement-breakpoint
CREATE TABLE `__new_zone_scan_archives` (
	`id` text PRIMARY KEY NOT NULL,
	`zone_id` text NOT NULL,
	`object_key` text NOT NULL,
	`upload_status` text NOT NULL,
	`upload_expires_at` integer NOT NULL,
	`uploaded_at` integer,
	`preview_object_key` text,
	`preview_upload_status` text,
	`preview_upload_expires_at` integer,
	`preview_uploaded_at` integer,
	`created_at` integer DEFAULT (unixepoch()) NOT NULL,
	FOREIGN KEY (`zone_id`) REFERENCES `zones`(`id`) ON UPDATE no action ON DELETE cascade,
	CONSTRAINT "zone_scan_archives_object_key_check" CHECK(length(object_key) <= 2048),
	CONSTRAINT "zone_scan_archives_preview_object_key_check" CHECK(preview_object_key IS NULL OR length(preview_object_key) <= 2048),
	CONSTRAINT "zone_scan_archives_upload_status_check" CHECK(upload_status IN ('pending', 'uploaded', 'expired')),
	CONSTRAINT "zone_scan_archives_preview_upload_status_check" CHECK(preview_upload_status IS NULL OR preview_upload_status IN ('pending', 'uploaded', 'expired')),
	CONSTRAINT "zone_scan_archives_upload_state_check" CHECK((
				upload_status = 'pending'
				AND uploaded_at IS NULL
			) OR (
				upload_status = 'uploaded'
				AND uploaded_at IS NOT NULL
			) OR (
				upload_status = 'expired'
				AND uploaded_at IS NULL
			)),
	CONSTRAINT "zone_scan_archives_preview_upload_state_check" CHECK((
				preview_upload_status IS NULL
				AND preview_object_key IS NULL
				AND preview_upload_expires_at IS NULL
				AND preview_uploaded_at IS NULL
			) OR (
				preview_upload_status = 'pending'
				AND preview_object_key IS NOT NULL
				AND preview_upload_expires_at IS NOT NULL
				AND preview_uploaded_at IS NULL
			) OR (
				preview_upload_status = 'uploaded'
				AND preview_object_key IS NOT NULL
				AND preview_upload_expires_at IS NOT NULL
				AND preview_uploaded_at IS NOT NULL
			) OR (
				preview_upload_status = 'expired'
				AND preview_object_key IS NOT NULL
				AND preview_upload_expires_at IS NOT NULL
				AND preview_uploaded_at IS NULL
			))
);
--> statement-breakpoint
INSERT INTO `__new_zone_scan_archives`("id", "zone_id", "object_key", "upload_status", "upload_expires_at", "uploaded_at", "created_at") SELECT "id", "zone_id", "object_key", "upload_status", "upload_expires_at", "uploaded_at", "created_at" FROM `zone_scan_archives`;--> statement-breakpoint
DROP TABLE `zone_scan_archives`;--> statement-breakpoint
ALTER TABLE `__new_zone_scan_archives` RENAME TO `zone_scan_archives`;--> statement-breakpoint
PRAGMA foreign_keys=ON;--> statement-breakpoint
CREATE UNIQUE INDEX `zone_scan_archives_object_key_unique` ON `zone_scan_archives` (`object_key`);--> statement-breakpoint
CREATE UNIQUE INDEX `zone_scan_archives_preview_object_key_unique` ON `zone_scan_archives` (`preview_object_key`);--> statement-breakpoint
CREATE INDEX `zone_scan_archives_zone_created_id_index` ON `zone_scan_archives` (`zone_id`,`created_at`,`id`);