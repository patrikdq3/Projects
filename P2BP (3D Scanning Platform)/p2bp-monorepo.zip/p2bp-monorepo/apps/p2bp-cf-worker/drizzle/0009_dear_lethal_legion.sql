ALTER TABLE `zones` ADD `x` integer;--> statement-breakpoint
ALTER TABLE `zones` ADD `y` integer;--> statement-breakpoint
CREATE UNIQUE INDEX `zones_project_xy_unique` ON `zones` (`project_id`,`x`,`y`);