-- Custom Drizzle migration: backfill zone grid indices

DELETE FROM `zones`
WHERE `latitude` IS NULL OR `longitude` IS NULL;

UPDATE `zones`
SET
	`x` = CAST(((`zones`.`longitude` - `projects`.`initial_long`) * 111320.0 * cos(`projects`.`initial_lat` * 0.017453292519943295)) / `projects`.`zone_size` AS integer)
		- ((((`zones`.`longitude` - `projects`.`initial_long`) * 111320.0 * cos(`projects`.`initial_lat` * 0.017453292519943295)) / `projects`.`zone_size`) < CAST(((`zones`.`longitude` - `projects`.`initial_long`) * 111320.0 * cos(`projects`.`initial_lat` * 0.017453292519943295)) / `projects`.`zone_size` AS integer)),
	`y` = CAST(((`zones`.`latitude` - `projects`.`initial_lat`) * 111320.0) / `projects`.`zone_size` AS integer)
		- ((((`zones`.`latitude` - `projects`.`initial_lat`) * 111320.0) / `projects`.`zone_size`) < CAST(((`zones`.`latitude` - `projects`.`initial_lat`) * 111320.0) / `projects`.`zone_size` AS integer))
FROM `projects`
WHERE `zones`.`project_id` = `projects`.`id`;
