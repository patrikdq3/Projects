PRAGMA foreign_keys=OFF;--> statement-breakpoint
CREATE TABLE `__new_boundary_points` (
	`id` text PRIMARY KEY NOT NULL,
	`project_id` text NOT NULL,
	`latitude` real NOT NULL,
	`longitude` real NOT NULL,
	`sort_order` integer DEFAULT 0 NOT NULL,
	FOREIGN KEY (`project_id`) REFERENCES `projects`(`id`) ON UPDATE no action ON DELETE cascade,
	CONSTRAINT "boundary_lat_check" CHECK(latitude >= -90 AND latitude <= 90),
	CONSTRAINT "boundary_long_check" CHECK(longitude >= -180 AND longitude <= 180),
	CONSTRAINT "boundary_sort_order_check" CHECK(sort_order >= 0)
);
--> statement-breakpoint
INSERT INTO `__new_boundary_points`("id", "project_id", "latitude", "longitude", "sort_order")
SELECT
	"id",
	"project_id",
	"latitude",
	"longitude",
	row_number() OVER (PARTITION BY "project_id" ORDER BY rowid) - 1
FROM `boundary_points`;--> statement-breakpoint
DROP TABLE `boundary_points`;--> statement-breakpoint
ALTER TABLE `__new_boundary_points` RENAME TO `boundary_points`;--> statement-breakpoint
PRAGMA foreign_keys=ON;
