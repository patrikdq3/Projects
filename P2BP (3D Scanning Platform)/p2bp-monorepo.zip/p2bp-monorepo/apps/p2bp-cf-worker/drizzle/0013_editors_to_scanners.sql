-- Custom Drizzle migration: replace the removed editor role with scanner.
UPDATE `member`
SET `role` = CASE
	WHEN instr(',' || `role` || ',', ',scanner,') > 0
		THEN trim(replace(',' || `role` || ',', ',editor,', ','), ',')
	ELSE trim(replace(',' || `role` || ',', ',editor,', ',scanner,'), ',')
END
WHERE instr(',' || `role` || ',', ',editor,') > 0;
--> statement-breakpoint
UPDATE `invitation`
SET `role` = CASE
	WHEN instr(',' || `role` || ',', ',scanner,') > 0
		THEN trim(replace(',' || `role` || ',', ',editor,', ','), ',')
	ELSE trim(replace(',' || `role` || ',', ',editor,', ',scanner,'), ',')
END
WHERE instr(',' || `role` || ',', ',editor,') > 0;
