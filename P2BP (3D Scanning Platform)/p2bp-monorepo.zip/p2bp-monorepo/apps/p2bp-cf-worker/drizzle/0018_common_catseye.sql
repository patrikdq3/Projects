CREATE TABLE `mesh_jobs` (
	`id` text PRIMARY KEY NOT NULL,
	`project_id` text NOT NULL,
	`type` text NOT NULL,
	`message_version` integer NOT NULL,
	`status` text NOT NULL,
	`input_fingerprint` text NOT NULL,
	`zone_scan_object_keys` text NOT NULL,
	`error` text,
	`started_at` integer,
	`completed_at` integer,
	`created_at` integer DEFAULT (unixepoch()) NOT NULL,
	FOREIGN KEY (`project_id`) REFERENCES `projects`(`id`) ON UPDATE no action ON DELETE cascade,
	CONSTRAINT "mesh_jobs_type_check" CHECK(type IN ('mesh.generate', 'mesh.refine')),
	CONSTRAINT "mesh_jobs_status_check" CHECK(status IN ('queued', 'running', 'completed', 'failed')),
	CONSTRAINT "mesh_jobs_input_fingerprint_check" CHECK(length(input_fingerprint) = 64),
	CONSTRAINT "mesh_jobs_zone_scan_object_keys_check" CHECK(json_valid(zone_scan_object_keys)),
	CONSTRAINT "mesh_jobs_state_check" CHECK((
				status = 'queued'
				AND started_at IS NULL
				AND completed_at IS NULL
				AND error IS NULL
			) OR (
				status = 'running'
				AND started_at IS NOT NULL
				AND completed_at IS NULL
				AND error IS NULL
			) OR (
				status = 'completed'
				AND completed_at IS NOT NULL
				AND error IS NULL
			) OR (
				status = 'failed'
				AND completed_at IS NOT NULL
				AND error IS NOT NULL
			))
);
--> statement-breakpoint
CREATE INDEX `mesh_jobs_project_created_id_index` ON `mesh_jobs` (`project_id`,`created_at`,`id`);--> statement-breakpoint
CREATE INDEX `mesh_jobs_cache_lookup_index` ON `mesh_jobs` (`project_id`,`type`,`input_fingerprint`,`created_at`);