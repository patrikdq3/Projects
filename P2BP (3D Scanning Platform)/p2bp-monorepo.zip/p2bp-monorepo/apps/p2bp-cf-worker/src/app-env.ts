import type { HonoLogLayerVariables } from "@loglayer/hono";

export type WorkerAppEnv = {
	Bindings: CloudflareBindings;
	Variables: HonoLogLayerVariables;
};
