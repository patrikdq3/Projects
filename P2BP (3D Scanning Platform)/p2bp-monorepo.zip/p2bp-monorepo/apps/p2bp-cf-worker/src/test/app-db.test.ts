import { describe, expect, it } from "bun:test";
import { createAppTestDb, listAppTestMigrationFiles } from "./app-db";

describe("createAppTestDb", () => {
	it("applies migrations through a selected migration", () => {
		const { appliedMigrations, close, sqlite } = createAppTestDb({
			migrations: { through: "0018" },
		});
		try {
			expect(appliedMigrations.at(-1)?.startsWith("0018_")).toBe(true);
			expect(
				sqlite
					.query(
						"SELECT name FROM sqlite_master WHERE type = 'table' AND name = 'mesh_jobs'",
					)
					.get(),
			).not.toBeNull();
			expect(
				sqlite
					.query(
						"SELECT name FROM sqlite_master WHERE type = 'index' AND name = 'mesh_jobs_active_input_unique'",
					)
					.get(),
			).toBeNull();
		} finally {
			close();
		}
	});

	it("applies an explicit migration list by prefix", () => {
		const firstMigration = listAppTestMigrationFiles()[0];
		const { appliedMigrations, close, sqlite } = createAppTestDb({
			migrations: ["0000"],
		});
		try {
			expect(appliedMigrations).toEqual([firstMigration]);
			expect(
				sqlite
					.query(
						"SELECT name FROM sqlite_master WHERE type = 'table' AND name = 'user'",
					)
					.get(),
			).not.toBeNull();
			expect(
				sqlite
					.query(
						"SELECT name FROM sqlite_master WHERE type = 'table' AND name = 'projects'",
					)
					.get(),
			).toBeNull();
		} finally {
			close();
		}
	});
});

describe("listAppTestMigrationFiles", () => {
	it("lists checked-in Drizzle SQL migrations in order", () => {
		const migrations = listAppTestMigrationFiles();

		expect(migrations.length).toBeGreaterThan(0);
		expect(migrations[0]?.startsWith("0000_")).toBe(true);
		// Assert the ordering as a property -- every entry is an NNNN_*.sql file
		// with a unique, strictly increasing numeric prefix -- so a new migration
		// does not require editing this test.
		expect(migrations.every((name) => /^\d{4}_.+\.sql$/.test(name))).toBe(true);
		const prefixes = migrations.map((name) => Number(name.slice(0, 4)));
		expect(prefixes).toEqual([...prefixes].sort((left, right) => left - right));
		expect(new Set(prefixes).size).toBe(prefixes.length);
	});
});
