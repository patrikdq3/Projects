import { Database } from "bun:sqlite";
import { readdirSync, readFileSync } from "node:fs";
import { join } from "node:path";
import { drizzle } from "drizzle-orm/bun-sqlite";
import type { getDb } from "../db";
import * as schema from "../db/schema";

const migrationsDirectory = join(import.meta.dir, "..", "..", "drizzle");
const migrationFilePattern = /^\d{4}_.+\.sql$/;
const statementBreakpoint = "--> statement-breakpoint";

export type AppTestMigrationSelection =
	| "all"
	| readonly string[]
	| { through: string };

export const listAppTestMigrationFiles = () =>
	readdirSync(migrationsDirectory)
		.filter((fileName) => migrationFilePattern.test(fileName))
		.sort();

const resolveMigrationFileName = (
	identifier: string,
	availableMigrations: readonly string[],
) => {
	const fileName = identifier.endsWith(".sql")
		? identifier
		: availableMigrations.find((migration) =>
				migration.startsWith(`${identifier}_`),
			);

	if (!fileName || !availableMigrations.includes(fileName)) {
		throw new Error(`Unknown Drizzle migration: ${identifier}`);
	}

	return fileName;
};

const selectAppTestMigrations = (
	selection: AppTestMigrationSelection = "all",
) => {
	const availableMigrations = listAppTestMigrationFiles();

	if (selection === "all") {
		return availableMigrations;
	}

	if (!("through" in selection)) {
		return selection.map((migration) =>
			resolveMigrationFileName(migration, availableMigrations),
		);
	}

	const throughMigration = resolveMigrationFileName(
		selection.through,
		availableMigrations,
	);
	const throughIndex = availableMigrations.indexOf(throughMigration);
	return availableMigrations.slice(0, throughIndex + 1);
};

export const applyAppTestMigrations = (
	sqlite: Database,
	selection: AppTestMigrationSelection = "all",
) => {
	const migrations = selectAppTestMigrations(selection);

	for (const migration of migrations) {
		const migrationSql = readFileSync(
			join(migrationsDirectory, migration),
			"utf8",
		).replaceAll(statementBreakpoint, "\n");

		sqlite.run(migrationSql);
	}

	return migrations;
};

export const createAppTestDb = ({
	migrations = "all",
}: {
	migrations?: AppTestMigrationSelection;
} = {}) => {
	const sqlite = new Database(":memory:");
	const appliedMigrations = applyAppTestMigrations(sqlite, migrations);

	return {
		appliedMigrations,
		close: () => sqlite.close(),
		db: drizzle(sqlite, { schema }) as unknown as ReturnType<typeof getDb>,
		sqlite,
	};
};
