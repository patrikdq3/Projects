import { describe, expect, it } from "bun:test";
import { zoneScanArchives, zones } from "../../db/schema/app.schema";
import { projectsRoutes } from "./projects";
import {
	reconcilePendingZoneScanArchives,
	type ZoneRecord,
	type ZoneScanArchiveRecord,
} from "./zones.scan-reconciliation";

const now = new Date("2026-06-14T09:00:00.000Z");

const buildZone = (overrides: Partial<ZoneRecord> = {}): ZoneRecord =>
	({
		createdAt: now,
		duration: null,
		id: "zone-123",
		metadata: null,
		pointCount: null,
		projectId: "project-123",
		scannedAt: now,
		scanObjectKey:
			"organizations/org-123/projects/project-123/zones/zone-123/scans/upload-123.zip",
		scanUploadedAt: null,
		scanUploadExpiresAt: new Date("2026-01-01T00:00:00.000Z"),
		scanUploadStatus: "pending",
		x: 0,
		y: 0,
		...overrides,
	}) as ZoneRecord;

const buildArchive = (
	overrides: Partial<ZoneScanArchiveRecord> = {},
): ZoneScanArchiveRecord =>
	({
		createdAt: now,
		id: "upload-123",
		objectKey:
			"organizations/org-123/projects/project-123/zones/zone-123/scans/upload-123.zip",
		uploadedAt: null,
		uploadExpiresAt: new Date("2026-01-01T00:00:00.000Z"),
		uploadStatus: "pending",
		zoneId: "zone-123",
		...overrides,
	}) as ZoneScanArchiveRecord;

describe("projectsRoutes project creation validation", () => {
	it("rejects project creation without a boundary", async () => {
		const response = await projectsRoutes.request(
			"/organizations/org-123/projects",
			{
				method: "POST",
				headers: {
					"Content-Type": "application/json",
				},
				body: JSON.stringify({
					name: "North Plaza Survey",
					initialLat: 40.7128,
					initialLong: -74.006,
					zoneSize: 10,
				}),
			},
		);

		expect(response.status).toBe(400);
	});

	it("rejects project creation when the boundary has fewer than 3 vertices", async () => {
		const response = await projectsRoutes.request(
			"/organizations/org-123/projects",
			{
				method: "POST",
				headers: {
					"Content-Type": "application/json",
				},
				body: JSON.stringify({
					name: "North Plaza Survey",
					initialLat: 40.7128,
					initialLong: -74.006,
					zoneSize: 10,
					boundary: [
						{ latitude: 40.7128, longitude: -74.006 },
						{ latitude: 40.713, longitude: -74.0058 },
					],
				}),
			},
		);

		expect(response.status).toBe(400);
	});
});

describe("reconcilePendingZoneScanArchives", () => {
	it("expires stale pending scan archives before grid-change blocking", async () => {
		const archiveUpdates: unknown[] = [];
		const zoneUpdates: unknown[] = [];
		const archive = buildArchive();
		const zone = buildZone();
		const db = {
			batch: async (statements: Array<{ run: () => Promise<unknown> }>) =>
				Promise.all(statements.map((statement) => statement.run())),
			select: () => ({
				from: () => ({
					innerJoin: () => ({
						where: () => ({
							all: async () => [{ archive, zone }],
						}),
					}),
				}),
			}),
			update: (table: unknown) => ({
				set: (values: unknown) => ({
					where: () => ({
						run: async () => {
							if (table === zoneScanArchives) {
								archiveUpdates.push(values);
								return { meta: { changes: 1 } };
							}

							if (table === zones) {
								zoneUpdates.push(values);
								return { meta: { changes: 1 } };
							}

							return { meta: { changes: 0 } };
						},
					}),
				}),
			}),
		};
		const env = {
			BUCKET: {
				head: async () => null,
			},
		} as unknown as CloudflareBindings;

		await reconcilePendingZoneScanArchives(env, db as never, "project-123");

		expect(archiveUpdates).toEqual([
			{
				uploadedAt: null,
				uploadStatus: "expired",
			},
		]);
		expect(zoneUpdates).toEqual([
			{
				scanUploadedAt: null,
				scanUploadStatus: "expired",
			},
		]);
	});
});
