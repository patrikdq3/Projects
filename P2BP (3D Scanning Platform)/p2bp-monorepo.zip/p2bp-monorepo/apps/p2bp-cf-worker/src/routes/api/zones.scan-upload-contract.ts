import { z } from "@hono/zod-openapi";

export const zoneScanArchiveContentType = "application/zip" as const;

export const zoneScanUploadRequiredHeaders = {
	"Content-Type": zoneScanArchiveContentType,
} as const;

export const ZoneScanUploadRequiredHeadersSchema = z.object({
	"Content-Type": z.literal(zoneScanArchiveContentType),
});

export const zoneScanPreviewContentType = "application/octet-stream" as const;

export const zoneScanPreviewUploadRequiredHeaders = {
	"Content-Type": zoneScanPreviewContentType,
} as const;

export const ZoneScanPreviewUploadRequiredHeadersSchema = z.object({
	"Content-Type": z.literal(zoneScanPreviewContentType),
});
