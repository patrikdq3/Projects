import { describe, expect, it } from "bun:test";
import { meshJobOutputFilenames } from "./mesh.jobs.keys";
import {
	buildLegacyMergedPointCloudObjectKey,
	pointCloudVariants,
} from "./mesh.point-cloud";

describe("merged point cloud object keys", () => {
	it("builds the legacy point cloud object key", () => {
		expect(
			buildLegacyMergedPointCloudObjectKey({
				orgId: "org-123",
				projectId: "project-123",
				filename: meshJobOutputFilenames.pointCloud,
			}),
		).toBe("organizations/org-123/projects/project-123/merged-point-cloud.laz");
	});

	it("builds the legacy point cloud preview object key", () => {
		expect(
			buildLegacyMergedPointCloudObjectKey({
				orgId: "org-123",
				projectId: "project-123",
				filename: meshJobOutputFilenames.pointCloudPreview,
			}),
		).toBe(
			"organizations/org-123/projects/project-123/merged-point-cloud.preview.laz",
		);
	});

	it("serves the E57 exports under their own path suffixes", () => {
		expect(
			pointCloudVariants
				.filter((variant) => variant.filename.endsWith(".e57"))
				.map((variant) => [variant.pathSuffix, variant.filename]),
		).toEqual([
			["merged-point-cloud/e57", meshJobOutputFilenames.pointCloudE57],
			[
				"merged-point-cloud/preview/e57",
				meshJobOutputFilenames.pointCloudPreviewE57,
			],
		]);
	});

	it("maps every mesh job output filename to a download route", () => {
		expect(
			pointCloudVariants
				.map((variant) => variant.filename)
				.toSorted((left, right) => left.localeCompare(right)),
		).toEqual(
			Object.values(meshJobOutputFilenames).toSorted((left, right) =>
				left.localeCompare(right),
			),
		);
	});
});
