import { describe, expect, it } from "bun:test";
import {
	buildMeshJobObjectKey,
	buildMeshJobStatusObjectKey,
	meshJobOutputFilenames,
	optionalMeshJobOutputFilenames,
	requiredMeshJobOutputFilenames,
} from "./mesh.jobs.keys";

describe("mesh job object keys", () => {
	it("builds versioned output object keys under the job prefix", () => {
		expect(
			buildMeshJobObjectKey({
				orgId: "org-123",
				projectId: "project-123",
				jobId: "job-123",
				filename: meshJobOutputFilenames.pointCloud,
			}),
		).toBe(
			"organizations/org-123/projects/project-123/mesh-jobs/job-123/merged-point-cloud.laz",
		);
	});

	it("keeps the output filenames aligned with the consumer contract", () => {
		expect(meshJobOutputFilenames).toEqual({
			pointCloud: "merged-point-cloud.laz",
			pointCloudE57: "merged-point-cloud.e57",
			pointCloudPreview: "merged-point-cloud.preview.laz",
			pointCloudPreviewE57: "merged-point-cloud.preview.e57",
			viewerMetadata: "merged-point-cloud.viewer.json",
		});
		expect(requiredMeshJobOutputFilenames).toEqual({
			pointCloud: "merged-point-cloud.laz",
			pointCloudPreview: "merged-point-cloud.preview.laz",
		});
		expect(optionalMeshJobOutputFilenames).toEqual({
			pointCloudE57: "merged-point-cloud.e57",
			pointCloudPreviewE57: "merged-point-cloud.preview.e57",
			viewerMetadata: "merged-point-cloud.viewer.json",
		});
	});

	it("builds the status object key", () => {
		expect(
			buildMeshJobStatusObjectKey({
				orgId: "org-123",
				projectId: "project-123",
				jobId: "job-123",
			}),
		).toBe(
			"organizations/org-123/projects/project-123/mesh-jobs/job-123/status.json",
		);
	});
});
