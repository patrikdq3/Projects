import { describe, expect, it } from "bun:test";
import type { getDb } from "../../db";
import { meshJobs, projects, zones } from "../../db/schema/app.schema";
import { organization } from "../../db/schema/better-auth.schema";
import { meshJobDefinitions } from "../../lib/mesh/job-contract";
import { createAppTestDb } from "../../test/app-db";
import { computeMeshJobInputFingerprint } from "./mesh.jobs.builder";
import {
	meshJobOutputFilenames,
	requiredMeshJobOutputFilenames,
} from "./mesh.jobs.keys";
import {
	isMeshJobActiveInputConflict,
	type MeshJobRecord,
	meshJobReconcileWindowMs,
	meshJobTimeoutMs,
	reconcileMeshJob,
	resolveActiveMeshGenerateJob,
	resolveCurrentMeshGenerateJobCandidates,
	resolveLatestCompletedMeshGenerateJob,
	resolveReusableMeshGenerateJob,
	shouldReconcileMeshJob,
} from "./mesh.jobs.reconciliation";

const now = new Date("2026-06-14T09:00:00.000Z");

const buildJob = (overrides: Partial<MeshJobRecord> = {}): MeshJobRecord =>
	({
		id: "job-123",
		projectId: "project-123",
		type: "mesh.generate",
		messageVersion: 2,
		status: "queued",
		inputFingerprint: "f".repeat(64),
		zoneScanObjectKeys: ["zones/zone-1/scan.zip"],
		error: null,
		startedAt: null,
		completedAt: null,
		createdAt: now,
		...overrides,
	}) as MeshJobRecord;

const insertOrganization = (db: ReturnType<typeof getDb>) =>
	db
		.insert(organization)
		.values({
			createdAt: now,
			id: "org-123",
			logo: null,
			metadata: null,
			name: "Organization",
			slug: "org-123",
		})
		.run();

const insertProject = async (db: ReturnType<typeof getDb>) => {
	await insertOrganization(db);
	return db
		.insert(projects)
		.values({
			createdAt: now,
			description: null,
			id: "project-123",
			initialLat: 1,
			initialLong: 2,
			name: "Project",
			organizationId: "org-123",
			zoneSize: 10,
		})
		.run();
};

const insertUploadedZoneScans = (
	db: ReturnType<typeof getDb>,
	scanObjectKeys: string[],
) =>
	db
		.insert(zones)
		.values(
			scanObjectKeys.map((scanObjectKey, index) => ({
				createdAt: now,
				duration: null,
				id: `zone-${index}`,
				metadata: null,
				pointCount: null,
				projectId: "project-123",
				scannedAt: now,
				scanObjectKey,
				scanUploadedAt: now,
				scanUploadExpiresAt: now,
				scanUploadStatus: "uploaded" as const,
				x: index,
				y: 0,
			})),
		)
		.run();

type FakeDbOptions = {
	updateChanges?: number;
	updateError?: Error;
	latestJob?: MeshJobRecord;
	fallbackJobResults?: Array<MeshJobRecord | null | undefined>;
	recentJobs?: MeshJobRecord[];
	recentJobResults?: MeshJobRecord[][];
};

const createFakeDb = ({
	updateChanges = 1,
	updateError,
	fallbackJobResults,
	latestJob,
	recentJobs = [],
	recentJobResults,
}: FakeDbOptions = {}) => {
	const updates: Array<Record<string, unknown>> = [];
	let fallbackJobResultIndex = 0;
	let recentJobResultIndex = 0;

	const db = {
		select: () => ({
			from: () => ({
				// collectMeshGenerateZoneScanObjectKeys joins zones with projects.
				innerJoin: () => ({
					where: () => ({
						orderBy: () => ({
							all: async () => [],
						}),
					}),
				}),
				where: (predicate: unknown) => {
					void predicate;
					return {
						get: async () => latestJob,
						orderBy: () => ({
							limit: () => ({
								all: async () =>
									recentJobResults?.[recentJobResultIndex++] ?? recentJobs,
								get: async () => {
									if (!fallbackJobResults) return undefined;
									return (
										fallbackJobResults[fallbackJobResultIndex++] ?? undefined
									);
								},
							}),
						}),
					};
				},
			}),
		}),
		update: () => ({
			set: (values: Record<string, unknown>) => ({
				where: () => ({
					run: async () => {
						if (updateError) throw updateError;
						updates.push(values);
						return { meta: { changes: updateChanges } };
					},
				}),
			}),
		}),
	};

	return { db: db as never, updates };
};

const createEnv = (
	statusFile: unknown,
	options: {
		existingObjectKeys?: string[];
		getError?: boolean;
		jsonError?: boolean;
		size?: number;
	} = {},
) => {
	const existingObjectKeys = new Set(options.existingObjectKeys ?? []);
	const headKeys: string[] = [];
	const jsonReads: string[] = [];
	const readKeys: string[] = [];
	const env = {
		BUCKET: {
			get: async (key: string) => {
				readKeys.push(key);
				if (options.getError) throw new Error("R2 unavailable");
				if (statusFile === undefined) return null;
				return {
					json: async () => {
						jsonReads.push(key);
						if (options.jsonError) throw new Error("invalid json");
						return statusFile;
					},
					size: options.size ?? 128,
				};
			},
			head: async (key: string) => {
				headKeys.push(key);
				return existingObjectKeys.has(key) ? {} : null;
			},
		},
	} as unknown as CloudflareBindings;
	return { env, headKeys, jsonReads, readKeys };
};

const buildRequiredOutputObjectKeys = (jobId = "job-123") =>
	Object.values(requiredMeshJobOutputFilenames).map(
		(filename) =>
			`organizations/org-123/projects/project-123/mesh-jobs/${jobId}/${filename}`,
	);

// Every output a current merge publishes, required and optional -- what a
// completed job must still have to be reused.
const buildCurrentOutputObjectKeys = (jobId = "job-123") =>
	Object.values(meshJobOutputFilenames).map(
		(filename) =>
			`organizations/org-123/projects/project-123/mesh-jobs/${jobId}/${filename}`,
	);

describe("shouldReconcileMeshJob", () => {
	it("skips completed jobs", () => {
		expect(shouldReconcileMeshJob(buildJob({ status: "completed" }), now)).toBe(
			false,
		);
	});

	it("reconciles queued, running, and recently failed jobs", () => {
		expect(shouldReconcileMeshJob(buildJob({ status: "queued" }), now)).toBe(
			true,
		);
		expect(shouldReconcileMeshJob(buildJob({ status: "running" }), now)).toBe(
			true,
		);
		expect(shouldReconcileMeshJob(buildJob({ status: "failed" }), now)).toBe(
			true,
		);
	});

	it("keeps reconciling queued and running jobs older than the queue redelivery window", () => {
		const old = new Date(now.getTime() + meshJobReconcileWindowMs + 1000);
		const createdAt = new Date(now.getTime() - meshJobReconcileWindowMs - 1000);
		expect(shouldReconcileMeshJob(buildJob({ createdAt }), old)).toBe(true);
		expect(
			shouldReconcileMeshJob(buildJob({ createdAt, status: "running" }), old),
		).toBe(true);
	});

	it("stops reconciling failed jobs older than the queue redelivery window", () => {
		const old = new Date(now.getTime() + meshJobReconcileWindowMs + 1000);
		expect(shouldReconcileMeshJob(buildJob({ status: "failed" }), old)).toBe(
			false,
		);
	});
});

describe("isMeshJobActiveInputConflict", () => {
	it("matches active-input unique violations in the D1 message shapes", () => {
		expect(
			isMeshJobActiveInputConflict(
				new Error(
					"D1_ERROR: UNIQUE constraint failed: index 'mesh_jobs_active_input_unique'",
				),
			),
		).toBe(true);
		expect(
			isMeshJobActiveInputConflict(
				new Error(
					"UNIQUE constraint failed: mesh_jobs.project_id, mesh_jobs.type, mesh_jobs.input_fingerprint: SQLITE_CONSTRAINT",
				),
			),
		).toBe(true);
	});

	it("does not match other constraint failures", () => {
		expect(
			isMeshJobActiveInputConflict(
				new Error("CHECK constraint failed: mesh_jobs_state_check"),
			),
		).toBe(false);
		expect(
			isMeshJobActiveInputConflict(new Error("FOREIGN KEY constraint failed")),
		).toBe(false);
		expect(
			isMeshJobActiveInputConflict(
				new Error(
					"UNIQUE constraint failed: mesh_jobs.some_future_unique_column: SQLITE_CONSTRAINT_UNIQUE",
				),
			),
		).toBe(false);
		expect(isMeshJobActiveInputConflict("not an error")).toBe(false);
	});

	it("unwraps drizzle query errors to find the driver message", () => {
		// drizzle-orm >= 0.44 throws DrizzleQueryError whose message is only
		// "Failed query: <sql>"; the D1 text is on the cause chain. This is the
		// shape production actually sees.
		const wrapped = new Error(
			'Failed query: insert into "mesh_jobs" (...) values (...)',
			{
				cause: new Error(
					"D1_ERROR: UNIQUE constraint failed: index 'mesh_jobs_active_input_unique'",
				),
			},
		);
		expect(isMeshJobActiveInputConflict(wrapped)).toBe(true);

		const doublyWrapped = new Error("Failed query: update ...", {
			cause: new Error("D1_ERROR", {
				cause: new Error(
					"UNIQUE constraint failed: mesh_jobs.project_id, mesh_jobs.type, mesh_jobs.input_fingerprint: SQLITE_CONSTRAINT",
				),
			}),
		});
		expect(isMeshJobActiveInputConflict(doublyWrapped)).toBe(true);
	});

	it("does not match wrapped non-unique failures or cyclic causes", () => {
		const wrappedCheck = new Error("Failed query: update ...", {
			cause: new Error("CHECK constraint failed: mesh_jobs_state_check"),
		});
		expect(isMeshJobActiveInputConflict(wrappedCheck)).toBe(false);

		const cyclic = new Error("Failed query: update ...");
		cyclic.cause = cyclic;
		expect(isMeshJobActiveInputConflict(cyclic)).toBe(false);
	});

	it("matches the real error a duplicate active insert throws", async () => {
		// Canary against the migration-backed schema: the matcher recognizes the
		// error text an actual mesh_jobs_active_input_unique violation produces,
		// not just hand-written message shapes. If a driver/drizzle upgrade
		// changes that text this fails loudly, instead of a real conflict being
		// silently routed away from conflict handling in production.
		const { close, db } = createAppTestDb();
		try {
			await insertProject(db);
			const base = buildJob({ status: "queued" });
			await db.insert(meshJobs).values(base).run();

			let caught: unknown;
			try {
				await db
					.insert(meshJobs)
					.values({ ...base, id: "job-duplicate" })
					.run();
			} catch (error) {
				caught = error;
			}

			expect(caught).toBeDefined();
			expect(isMeshJobActiveInputConflict(caught)).toBe(true);
		} finally {
			close();
		}
	});
});

describe("reconcileMeshJob", () => {
	it("returns completed jobs without reading the status object", async () => {
		const { env, readKeys } = createEnv(undefined);
		const { db, updates } = createFakeDb();
		const job = buildJob({
			status: "completed",
			completedAt: now,
		});

		expect(
			await reconcileMeshJob(env, db, { orgId: "org-123" }, job, now),
		).toBe(job);
		expect(readKeys).toEqual([]);
		expect(updates).toEqual([]);
	});

	it("reads the status object from the job's versioned prefix", async () => {
		const { env, readKeys } = createEnv(undefined);
		const { db } = createFakeDb();

		await reconcileMeshJob(env, db, { orgId: "org-123" }, buildJob(), now);

		expect(readKeys).toEqual([
			"organizations/org-123/projects/project-123/mesh-jobs/job-123/status.json",
		]);
	});

	it("marks a queued job completed from a completed status object", async () => {
		const { env } = createEnv({
			state: "completed",
			jobId: "job-123",
			startedAt: "2026-06-14T08:00:00.000Z",
			completedAt: "2026-06-14T08:30:00.000Z",
		});
		const { db, updates } = createFakeDb();

		const resolved = await reconcileMeshJob(
			env,
			db,
			{ orgId: "org-123" },
			buildJob(),
			now,
		);

		expect(resolved.status).toBe("completed");
		expect(resolved.startedAt).toEqual(new Date("2026-06-14T08:00:00.000Z"));
		expect(resolved.completedAt).toEqual(new Date("2026-06-14T08:30:00.000Z"));
		expect(resolved.error).toBeNull();
		expect(updates).toHaveLength(1);
	});

	it("treats a status object for a different job as absent", async () => {
		const { env } = createEnv({
			state: "completed",
			jobId: "job-other",
			completedAt: "2026-06-14T08:30:00.000Z",
		});
		const { db, updates } = createFakeDb();
		const job = buildJob();

		expect(
			await reconcileMeshJob(env, db, { orgId: "org-123" }, job, now),
		).toBe(job);
		expect(updates).toEqual([]);
	});

	it("accepts +00:00 offset timestamps in status objects", async () => {
		// The consumer normalizes to Z, but an offset-form timestamp is equally
		// valid ISO and must not get the whole status file dropped as invalid.
		const { env } = createEnv({
			state: "completed",
			startedAt: "2026-06-14T08:00:00.000+00:00",
			completedAt: "2026-06-14T08:30:00.000+00:00",
		});
		const { db } = createFakeDb();

		const resolved = await reconcileMeshJob(
			env,
			db,
			{ orgId: "org-123" },
			buildJob(),
			now,
		);

		expect(resolved.status).toBe("completed");
		expect(resolved.completedAt).toEqual(new Date("2026-06-14T08:30:00.000Z"));
	});

	it("caps future completed status timestamps at the reconciliation time", async () => {
		const { env } = createEnv({
			state: "completed",
			startedAt: "2026-06-14T10:00:00.000Z",
			completedAt: "2026-06-14T10:30:00.000Z",
		});
		const { db } = createFakeDb();

		const resolved = await reconcileMeshJob(
			env,
			db,
			{ orgId: "org-123" },
			buildJob(),
			now,
		);

		expect(resolved.status).toBe("completed");
		expect(resolved.startedAt).toEqual(now);
		expect(resolved.completedAt).toEqual(now);
	});

	it("marks a queued job failed from a failed status object", async () => {
		const { env } = createEnv({
			state: "failed",
			startedAt: "2026-06-14T08:00:00.000Z",
			error: "merge crashed",
		});
		const { db } = createFakeDb();

		const resolved = await reconcileMeshJob(
			env,
			db,
			{ orgId: "org-123" },
			buildJob(),
			now,
		);

		expect(resolved.status).toBe("failed");
		expect(resolved.error).toBe("merge crashed");
		expect(resolved.completedAt).toEqual(now);
	});

	it("redacts internal locations from failed status object errors", async () => {
		const { env } = createEnv({
			state: "failed",
			error: [
				"Traceback in C:\\worker\\pull_queue.py",
				"while reading /home/ec2-user/p2bp/cache/input.zip",
				"from https://internal.example.test/private?token=secret",
				"at organizations/org-123/projects/project-123/mesh-jobs/job-123/status.json",
				"x".repeat(600),
			].join(" "),
		});
		const { db } = createFakeDb();

		const resolved = await reconcileMeshJob(
			env,
			db,
			{ orgId: "org-123" },
			buildJob(),
			now,
		);

		expect(resolved.status).toBe("failed");
		expect(resolved.error).toContain("[path]");
		expect(resolved.error).toContain("[url]");
		expect(resolved.error).toContain("[object-key]");
		expect(resolved.error).not.toContain("C:\\worker");
		expect(resolved.error).not.toContain("/home/ec2-user");
		expect(resolved.error).not.toContain("https://internal.example.test");
		expect(resolved.error).not.toContain("organizations/org-123");
		expect(resolved.error?.length).toBeLessThanOrEqual(500);
	});

	it("uses a generic failed message when the status object error is blank", async () => {
		const { env } = createEnv({
			state: "failed",
			error: "   ",
		});
		const { db } = createFakeDb();

		const resolved = await reconcileMeshJob(
			env,
			db,
			{ orgId: "org-123" },
			buildJob(),
			now,
		);

		expect(resolved.status).toBe("failed");
		expect(resolved.error).toBe("Mesh job failed");
	});

	it("marks a queued job running from a running status object", async () => {
		const { env } = createEnv({
			state: "running",
			startedAt: "2026-06-14T08:55:00.000Z",
		});
		const { db } = createFakeDb();

		const resolved = await reconcileMeshJob(
			env,
			db,
			{ orgId: "org-123" },
			buildJob(),
			now,
		);

		expect(resolved.status).toBe("running");
		expect(resolved.startedAt).toEqual(new Date("2026-06-14T08:55:00.000Z"));
	});

	it("caps a future running status start at the reconciliation time", async () => {
		const { env } = createEnv({
			state: "running",
			startedAt: "2026-06-14T10:00:00.000Z",
		});
		const { db } = createFakeDb();

		const resolved = await reconcileMeshJob(
			env,
			db,
			{ orgId: "org-123" },
			buildJob(),
			now,
		);

		expect(resolved.status).toBe("running");
		expect(resolved.startedAt).toEqual(now);
	});

	it("resurrects a failed job that a redelivery later completed", async () => {
		const { env } = createEnv({
			state: "completed",
			completedAt: "2026-06-14T08:45:00.000Z",
		});
		const { db } = createFakeDb();
		const job = buildJob({
			status: "failed",
			error: "first attempt crashed",
			completedAt: new Date("2026-06-14T08:10:00.000Z"),
		});

		const resolved = await reconcileMeshJob(
			env,
			db,
			{ orgId: "org-123" },
			job,
			now,
		);

		expect(resolved.status).toBe("completed");
		expect(resolved.error).toBeNull();
	});

	it("resurrects a timed-out failed job from a later running redelivery", async () => {
		const { env } = createEnv({
			state: "running",
			startedAt: "2026-06-14T08:55:00.000Z",
		});
		const { db } = createFakeDb();
		const job = buildJob({
			status: "failed",
			createdAt: new Date(now.getTime() - meshJobTimeoutMs - 1000),
			completedAt: new Date("2026-06-13T08:00:00.000Z"),
			error: "Mesh job timed out without reporting a result",
		});

		const resolved = await reconcileMeshJob(
			env,
			db,
			{ orgId: "org-123" },
			job,
			now,
		);

		expect(resolved.status).toBe("running");
		expect(resolved.startedAt).toEqual(new Date("2026-06-14T08:55:00.000Z"));
		expect(resolved.completedAt).toBeNull();
		expect(resolved.error).toBeNull();
	});

	it("keeps a timed-out failed job failed when running status is stale", async () => {
		const { env } = createEnv({
			state: "running",
			startedAt: "2026-06-14T08:00:00.000Z",
		});
		const { db, updates } = createFakeDb();
		const completedAt = new Date("2026-06-14T08:30:00.000Z");
		const job = buildJob({
			status: "failed",
			createdAt: new Date(now.getTime() - meshJobTimeoutMs - 1000),
			completedAt,
			error: "Mesh job timed out without reporting a result",
		});

		const resolved = await reconcileMeshJob(
			env,
			db,
			{ orgId: "org-123" },
			job,
			now,
		);

		expect(resolved).toBe(job);
		expect(resolved.status).toBe("failed");
		expect(resolved.completedAt).toBe(completedAt);
		expect(updates).toEqual([]);
	});

	it("recovers a stale running job when required outputs exist without optional artifacts", async () => {
		const completedAt = new Date("2026-06-14T08:45:00.000Z");
		const { env, headKeys } = createEnv(
			{
				state: "running",
				startedAt: "2026-06-14T08:00:00.000Z",
				completedAt: completedAt.toISOString(),
			},
			{ existingObjectKeys: buildRequiredOutputObjectKeys() },
		);
		const { db } = createFakeDb();
		const job = buildJob({
			status: "running",
			startedAt: new Date("2026-06-14T08:00:00.000Z"),
		});

		const resolved = await reconcileMeshJob(
			env,
			db,
			{ orgId: "org-123" },
			job,
			now,
		);

		expect(resolved.status).toBe("completed");
		expect(resolved.completedAt).toEqual(completedAt);
		expect(headKeys).toEqual(buildRequiredOutputObjectKeys());
	});

	it("recovers a stale failed job when required outputs exist without optional artifacts", async () => {
		const { env } = createEnv(
			{
				state: "failed",
				startedAt: "2026-06-14T08:00:00.000Z",
				error: "redelivery crashed after a previous completion",
			},
			{ existingObjectKeys: buildRequiredOutputObjectKeys() },
		);
		const { db } = createFakeDb();

		const resolved = await reconcileMeshJob(
			env,
			db,
			{ orgId: "org-123" },
			buildJob({ status: "running" }),
			now,
		);

		expect(resolved.status).toBe("completed");
		expect(resolved.error).toBeNull();
	});

	it("does not mark a job completed from stale status when only some outputs exist", async () => {
		const partialOutputKeys = buildRequiredOutputObjectKeys().slice(0, 1);
		const { env } = createEnv(
			{
				state: "running",
				startedAt: "2026-06-14T08:00:00.000Z",
			},
			{ existingObjectKeys: partialOutputKeys },
		);
		const { db } = createFakeDb();

		const resolved = await reconcileMeshJob(
			env,
			db,
			{ orgId: "org-123" },
			buildJob({ status: "running" }),
			now,
		);

		expect(resolved.status).toBe("running");
	});

	it("keeps a failed job failed when resurrecting it would collide with an active retry", async () => {
		// A retry job with the same fingerprint is already queued, so moving
		// this failed job back to `running` violates the active-input unique
		// index. The conflict must resolve like a lost optimistic race (re-read
		// the row), not propagate a 500 out of every read path.
		const { env } = createEnv({
			state: "running",
			startedAt: "2026-06-14T08:55:00.000Z",
		});
		const failedJob = buildJob({
			status: "failed",
			error: "first attempt crashed",
			completedAt: new Date("2026-06-14T08:10:00.000Z"),
		});
		const { db } = createFakeDb({
			// Production shape: drizzle wraps the D1 error, message on the cause.
			updateError: new Error('Failed query: update "mesh_jobs" set ...', {
				cause: new Error(
					"D1_ERROR: UNIQUE constraint failed: index 'mesh_jobs_active_input_unique'",
				),
			}),
			latestJob: failedJob,
		});

		const resolved = await reconcileMeshJob(
			env,
			db,
			{ orgId: "org-123" },
			failedJob,
			now,
		);

		expect(resolved.status).toBe("failed");
	});

	it("propagates non-unique constraint errors from transitions", async () => {
		const { env } = createEnv({
			state: "running",
			startedAt: "2026-06-14T08:55:00.000Z",
		});
		const { db } = createFakeDb({
			updateError: new Error(
				"D1_ERROR: CHECK constraint failed: mesh_jobs_state_check",
			),
		});

		await expect(
			reconcileMeshJob(env, db, { orgId: "org-123" }, buildJob(), now),
		).rejects.toThrow("CHECK constraint failed");
	});

	it("leaves a young queued job untouched when no status object exists", async () => {
		const { env } = createEnv(undefined);
		const { db, updates } = createFakeDb();
		const job = buildJob();

		expect(
			await reconcileMeshJob(env, db, { orgId: "org-123" }, job, now),
		).toBe(job);
		expect(updates).toEqual([]);
	});

	it("times out a queued job past the deadline with no terminal evidence", async () => {
		const { env } = createEnv(undefined);
		const { db } = createFakeDb();
		const job = buildJob({
			createdAt: new Date(now.getTime() - meshJobTimeoutMs - 1000),
		});

		const resolved = await reconcileMeshJob(
			env,
			db,
			{ orgId: "org-123" },
			job,
			now,
		);

		expect(resolved.status).toBe("failed");
		expect(resolved.error).toBe(
			"Mesh job timed out without reporting a result",
		);
	});

	it("times out a queued job even after the queue redelivery window", async () => {
		const { env } = createEnv(undefined);
		const { db } = createFakeDb();
		const job = buildJob({
			createdAt: new Date(now.getTime() - meshJobReconcileWindowMs - 1000),
		});

		const resolved = await reconcileMeshJob(
			env,
			db,
			{ orgId: "org-123" },
			job,
			now,
		);

		expect(resolved.status).toBe("failed");
		expect(resolved.error).toBe(
			"Mesh job timed out without reporting a result",
		);
	});

	it("marks an old queued job completed from a late status object", async () => {
		const { env } = createEnv({
			state: "completed",
			completedAt: "2026-06-13T08:00:00.000Z",
		});
		const { db } = createFakeDb();
		const job = buildJob({
			createdAt: new Date(now.getTime() - meshJobReconcileWindowMs - 1000),
		});

		const resolved = await reconcileMeshJob(
			env,
			db,
			{ orgId: "org-123" },
			job,
			now,
		);

		expect(resolved.status).toBe("completed");
		expect(resolved.completedAt).toEqual(new Date("2026-06-13T08:00:00.000Z"));
	});

	it("times out a job whose last status write still says running", async () => {
		const { env } = createEnv({ state: "running" });
		const { db } = createFakeDb();
		const job = buildJob({
			status: "running",
			startedAt: new Date(now.getTime() - meshJobTimeoutMs - 2000),
			createdAt: new Date(now.getTime() - meshJobTimeoutMs - 2000),
		});

		const resolved = await reconcileMeshJob(
			env,
			db,
			{ orgId: "org-123" },
			job,
			now,
		);

		expect(resolved.status).toBe("failed");
	});

	it("keeps a redelivered running job alive until the fresh start times out", async () => {
		const startedAt = new Date(now.getTime() - meshJobTimeoutMs + 1000);
		const { env } = createEnv({
			state: "running",
			startedAt: startedAt.toISOString(),
		});
		const { db, updates } = createFakeDb();
		const job = buildJob({
			status: "running",
			startedAt,
			createdAt: new Date(now.getTime() - meshJobReconcileWindowMs - 1000),
		});

		const resolved = await reconcileMeshJob(
			env,
			db,
			{ orgId: "org-123" },
			job,
			now,
		);

		expect(resolved).toBe(job);
		expect(updates).toEqual([]);
	});

	it("starts a past-deadline queued job whose fresh start is only in status.json", async () => {
		// The queued row has sat past the 24h deadline (createdAt old, no DB
		// startedAt), but the consumer just picked it up and wrote a fresh running
		// start to status.json. It must move to running, not be timed out.
		const freshStart = new Date(now.getTime() - 60_000);
		const { env } = createEnv({
			state: "running",
			startedAt: freshStart.toISOString(),
		});
		const { db, updates } = createFakeDb();
		const job = buildJob({
			status: "queued",
			startedAt: null,
			createdAt: new Date(now.getTime() - meshJobTimeoutMs - 1000),
		});

		const resolved = await reconcileMeshJob(
			env,
			db,
			{ orgId: "org-123" },
			job,
			now,
		);

		expect(resolved.status).toBe("running");
		expect(resolved.startedAt).toEqual(freshStart);
		expect(updates).toHaveLength(1);
	});

	it("does not time out a running job the consumer restarted per status.json", async () => {
		// DB startedAt is a stale run past the deadline, but status.json reports a
		// fresh restart start not yet copied into the row. The timeout must be
		// measured from the fresh start, so the active run is not failed.
		const freshStart = new Date(now.getTime() - 60_000);
		const { env } = createEnv({
			state: "running",
			startedAt: freshStart.toISOString(),
		});
		const { db, updates } = createFakeDb();
		const job = buildJob({
			status: "running",
			startedAt: new Date(now.getTime() - meshJobTimeoutMs - 2000),
			createdAt: new Date(now.getTime() - meshJobTimeoutMs - 2000),
		});

		const resolved = await reconcileMeshJob(
			env,
			db,
			{ orgId: "org-123" },
			job,
			now,
		);

		expect(resolved.status).toBe("running");
		expect(resolved.startedAt).toEqual(freshStart);
		expect(updates).toEqual([
			{
				startedAt: freshStart,
				completedAt: null,
				error: null,
			},
		]);
	});

	it("still times out a stale queued job whose running status has no fresh start", async () => {
		// A running status file without a startedAt gives no evidence the run is
		// alive, so a past-deadline queued job is still failed.
		const { env } = createEnv({ state: "running" });
		const { db } = createFakeDb();
		const job = buildJob({
			status: "queued",
			startedAt: null,
			createdAt: new Date(now.getTime() - meshJobTimeoutMs - 1000),
		});

		const resolved = await reconcileMeshJob(
			env,
			db,
			{ orgId: "org-123" },
			job,
			now,
		);

		expect(resolved.status).toBe("failed");
		expect(resolved.error).toBe(
			"Mesh job timed out without reporting a result",
		);
	});

	it("does not time out a job a redelivery restarted since the stale read", async () => {
		// The snapshot is a long-dead run past the deadline, but the live row was
		// restarted by a queue redelivery with a fresh start. The timeout write
		// must not clobber the running row it never saw.
		const { close, db } = createAppTestDb();
		const { env } = createEnv(undefined);
		const staleStartedAt = new Date(now.getTime() - meshJobTimeoutMs - 2000);
		const freshStartedAt = new Date(now.getTime() - 1000);
		const staleSnapshot = buildJob({
			status: "running",
			startedAt: staleStartedAt,
			createdAt: staleStartedAt,
		});
		try {
			await insertProject(db);
			await db
				.insert(meshJobs)
				.values({ ...staleSnapshot, startedAt: freshStartedAt })
				.run();

			const resolved = await reconcileMeshJob(
				env,
				db,
				{ orgId: "org-123" },
				staleSnapshot,
				now,
			);

			expect(resolved.status).toBe("running");
			expect(resolved.startedAt).toEqual(freshStartedAt);
		} finally {
			close();
		}
	});

	it("treats a malformed status object as absent", async () => {
		const { env } = createEnv({ state: "finished?" });
		const { db, updates } = createFakeDb();
		const job = buildJob();

		expect(
			await reconcileMeshJob(env, db, { orgId: "org-123" }, job, now),
		).toBe(job);
		expect(updates).toEqual([]);
	});

	it("treats an oversized status object as absent without parsing it", async () => {
		const { env, jsonReads } = createEnv(
			{ state: "completed", completedAt: "2026-06-14T08:30:00.000Z" },
			{ size: 16 * 1024 + 1 },
		);
		const { db, updates } = createFakeDb();
		const job = buildJob();

		expect(
			await reconcileMeshJob(env, db, { orgId: "org-123" }, job, now),
		).toBe(job);
		expect(jsonReads).toEqual([]);
		expect(updates).toEqual([]);
	});

	it("treats invalid status JSON as absent", async () => {
		const { env } = createEnv({}, { jsonError: true });
		const { db, updates } = createFakeDb();
		const job = buildJob();

		expect(
			await reconcileMeshJob(env, db, { orgId: "org-123" }, job, now),
		).toBe(job);
		expect(updates).toEqual([]);
	});

	it("propagates status object read errors", async () => {
		const { env } = createEnv({}, { getError: true });
		const { db } = createFakeDb();

		await expect(
			reconcileMeshJob(env, db, { orgId: "org-123" }, buildJob(), now),
		).rejects.toThrow("R2 unavailable");
	});

	it("returns the latest row when a concurrent reconciliation won the update", async () => {
		const winner = buildJob({ status: "completed", completedAt: now });
		const { env } = createEnv({ state: "running" });
		const { db } = createFakeDb({ updateChanges: 0, latestJob: winner });

		expect(
			await reconcileMeshJob(env, db, { orgId: "org-123" }, buildJob(), now),
		).toBe(winner);
	});
});

describe("resolveLatestCompletedMeshGenerateJob", () => {
	it("returns the newest completed job among recent jobs", async () => {
		const completed = buildJob({
			id: "job-completed",
			status: "completed",
			completedAt: now,
		});
		const { env } = createEnv(undefined);
		const { db } = createFakeDb({
			recentJobs: [buildJob({ id: "job-newer-queued" }), completed],
		});

		const resolved = await resolveLatestCompletedMeshGenerateJob(
			env,
			db,
			{
				orgId: "org-123",
				projectId: "project-123",
			},
			now,
		);

		expect(resolved?.id).toBe("job-completed");
	});

	it("falls back to an older completed job when recent jobs are all in flight", async () => {
		const older = buildJob({
			id: "job-older-completed",
			status: "completed",
			completedAt: now,
		});
		const { env } = createEnv(undefined);
		const { db } = createFakeDb({
			recentJobs: [buildJob({ id: "job-queued" })],
			fallbackJobResults: [older],
		});

		const resolved = await resolveLatestCompletedMeshGenerateJob(
			env,
			db,
			{
				orgId: "org-123",
				projectId: "project-123",
			},
			now,
		);

		expect(resolved?.id).toBe("job-older-completed");
	});

	it("returns null when no job has completed", async () => {
		const { env } = createEnv(undefined);
		const { db } = createFakeDb({ recentJobs: [] });

		expect(
			await resolveLatestCompletedMeshGenerateJob(
				env,
				db,
				{
					orgId: "org-123",
					projectId: "project-123",
				},
				now,
			),
		).toBeNull();
	});

	it("only considers jobs matching a given input fingerprint", async () => {
		const { close, db } = createAppTestDb();
		const matching = buildJob({
			createdAt: now,
			id: "job-matching",
			status: "completed",
			completedAt: now,
			inputFingerprint: "a".repeat(64),
		});
		const newerOther = buildJob({
			createdAt: new Date(now.getTime() + 1000),
			id: "job-newer-other",
			status: "completed",
			completedAt: now,
			inputFingerprint: "b".repeat(64),
		});
		const { env } = createEnv(undefined);
		try {
			await insertProject(db);
			await db.insert(meshJobs).values([newerOther, matching]).run();

			const resolved = await resolveLatestCompletedMeshGenerateJob(
				env,
				db,
				{
					orgId: "org-123",
					projectId: "project-123",
					inputFingerprint: "a".repeat(64),
				},
				now,
			);

			expect(resolved?.id).toBe("job-matching");
		} finally {
			close();
		}
	});

	it("uses the caller-provided clock while reconciling recent jobs", async () => {
		const almostTimedOut = buildJob({
			id: "job-almost-timed-out",
			createdAt: new Date(now.getTime() - meshJobTimeoutMs + 1000),
		});
		const { env } = createEnv(undefined);
		const { db, updates } = createFakeDb({ recentJobs: [almostTimedOut] });

		const resolved = await resolveLatestCompletedMeshGenerateJob(
			env,
			db,
			{
				orgId: "org-123",
				projectId: "project-123",
			},
			now,
		);

		expect(resolved).toBeNull();
		expect(updates).toEqual([]);
	});
});

describe("resolveReusableMeshGenerateJob", () => {
	const scope = {
		inputFingerprint: "a".repeat(64),
		orgId: "org-123",
		projectId: "project-123",
	};

	it("falls back to an older completed job hidden behind newer failed attempts", async () => {
		const olderCompleted = buildJob({
			id: "job-older-completed",
			status: "completed",
			completedAt: now,
			inputFingerprint: scope.inputFingerprint,
		});
		const recentFailedJobs = Array.from({ length: 5 }, (_, index) =>
			buildJob({
				id: `job-failed-${index}`,
				status: "failed",
				completedAt: now,
				error: "merge failed",
				inputFingerprint: scope.inputFingerprint,
			}),
		);
		const { env } = createEnv(undefined, {
			existingObjectKeys: buildCurrentOutputObjectKeys("job-older-completed"),
		});
		const { db } = createFakeDb({
			fallbackJobResults: [olderCompleted],
			recentJobs: recentFailedJobs,
		});

		const resolved = await resolveReusableMeshGenerateJob(env, db, scope, now);

		expect(resolved?.id).toBe("job-older-completed");
	});

	it("reuses a completed job that still has every current output", async () => {
		const completed = buildJob({
			id: "job-completed",
			status: "completed",
			completedAt: now,
			inputFingerprint: scope.inputFingerprint,
		});
		const { env } = createEnv(undefined, {
			existingObjectKeys: buildCurrentOutputObjectKeys("job-completed"),
		});
		const { db } = createFakeDb({ recentJobs: [completed] });

		const resolved = await resolveReusableMeshGenerateJob(env, db, scope, now);

		expect(resolved?.id).toBe("job-completed");
	});

	it("declines to reuse a completed job that predates an output", async () => {
		// A merge from before the E57 exports existed: complete, downloadable as
		// LAZ, but reusing it would leave the E57 endpoints 404 forever.
		const preE57 = buildJob({
			id: "job-pre-e57",
			status: "completed",
			completedAt: now,
			inputFingerprint: scope.inputFingerprint,
		});
		const { env } = createEnv(undefined, {
			existingObjectKeys: buildRequiredOutputObjectKeys("job-pre-e57"),
		});
		const { db } = createFakeDb({ recentJobs: [preE57] });

		const resolved = await resolveReusableMeshGenerateJob(env, db, scope, now);

		expect(resolved).toBeNull();
	});

	it("prefers an older complete job over a newer one missing an output", async () => {
		const newerIncomplete = buildJob({
			id: "job-newer-incomplete",
			status: "completed",
			completedAt: now,
			inputFingerprint: scope.inputFingerprint,
		});
		const olderComplete = buildJob({
			id: "job-older-complete",
			status: "completed",
			completedAt: now,
			inputFingerprint: scope.inputFingerprint,
		});
		const { env } = createEnv(undefined, {
			existingObjectKeys: [
				...buildRequiredOutputObjectKeys("job-newer-incomplete"),
				...buildCurrentOutputObjectKeys("job-older-complete"),
			],
		});
		const { db } = createFakeDb({
			recentJobs: [newerIncomplete, olderComplete],
		});

		const resolved = await resolveReusableMeshGenerateJob(env, db, scope, now);

		expect(resolved?.id).toBe("job-older-complete");
	});

	it("reuses an older complete job hidden behind newer incomplete ones", async () => {
		// The recency window is full of forced re-runs from before E57 existed, and
		// the older job that does have every output sits outside it. Reusing it
		// beats re-running the merge, and the newest rows must not stop the search.
		const { close, db } = createAppTestDb();
		try {
			await insertProject(db);
			const olderComplete = buildJob({
				id: "job-older-complete",
				status: "completed",
				completedAt: now,
				createdAt: new Date(now.getTime() - 60_000),
				inputFingerprint: scope.inputFingerprint,
			});
			// More than the (private) recency window size, so the window is full of
			// jobs the gate rejects.
			const newerIncomplete = Array.from({ length: 12 }, (_, index) =>
				buildJob({
					id: `job-incomplete-${index}`,
					status: "completed",
					completedAt: now,
					createdAt: new Date(now.getTime() - 1000 * index),
					inputFingerprint: scope.inputFingerprint,
				}),
			);
			await db
				.insert(meshJobs)
				.values([...newerIncomplete, olderComplete])
				.run();
			const { env, headKeys } = createEnv(undefined, {
				existingObjectKeys: [
					...newerIncomplete.flatMap((job) =>
						buildRequiredOutputObjectKeys(job.id),
					),
					...buildCurrentOutputObjectKeys("job-older-complete"),
				],
			});

			const resolved = await resolveReusableMeshGenerateJob(
				env,
				db,
				scope,
				now,
			);

			expect(resolved?.id).toBe("job-older-complete");
			// Each rejected job is examined once: the fallback query excludes the
			// ids the recency pass already turned down.
			const incompleteHeadKeys = headKeys.filter((key) =>
				key.includes("job-incomplete-0/"),
			);
			expect(incompleteHeadKeys.length).toBe(
				Object.values(meshJobOutputFilenames).length,
			);
		} finally {
			close();
		}
	});

	it("stops after the bounded fallback walk instead of scanning forever", async () => {
		const { close, db } = createAppTestDb();
		try {
			await insertProject(db);
			const incompleteJobs = Array.from({ length: 20 }, (_, index) =>
				buildJob({
					id: `job-incomplete-${index}`,
					status: "completed",
					completedAt: now,
					createdAt: new Date(now.getTime() - 1000 * index),
					inputFingerprint: scope.inputFingerprint,
				}),
			);
			await db.insert(meshJobs).values(incompleteJobs).run();
			const { env } = createEnv(undefined, {
				existingObjectKeys: incompleteJobs.flatMap((job) =>
					buildRequiredOutputObjectKeys(job.id),
				),
			});

			const resolved = await resolveReusableMeshGenerateJob(
				env,
				db,
				scope,
				now,
			);

			expect(resolved).toBeNull();
		} finally {
			close();
		}
	});

	it("still reuses in-flight work, which has not written outputs yet", async () => {
		const queued = buildJob({
			id: "job-queued",
			inputFingerprint: scope.inputFingerprint,
		});
		const { env } = createEnv(undefined);
		const { db } = createFakeDb({ recentJobs: [queued] });

		const resolved = await resolveReusableMeshGenerateJob(env, db, scope, now);

		expect(resolved?.id).toBe("job-queued");
	});

	it("falls back to an older in-flight job when no completed job exists", async () => {
		const olderQueued = buildJob({
			id: "job-older-queued",
			inputFingerprint: scope.inputFingerprint,
		});
		const { env } = createEnv(undefined);
		const { db } = createFakeDb({
			fallbackJobResults: [null, olderQueued],
			recentJobs: [
				buildJob({
					id: "job-failed",
					status: "failed",
					completedAt: now,
					error: "merge failed",
					inputFingerprint: scope.inputFingerprint,
				}),
			],
		});

		const resolved = await resolveReusableMeshGenerateJob(env, db, scope, now);

		expect(resolved?.id).toBe("job-older-queued");
	});

	it("ignores an older in-flight fallback that reconciles to failed", async () => {
		const timedOut = buildJob({
			id: "job-timed-out",
			createdAt: new Date(now.getTime() - meshJobTimeoutMs - 1000),
			inputFingerprint: scope.inputFingerprint,
		});
		const { env } = createEnv(undefined);
		const { db } = createFakeDb({
			fallbackJobResults: [null, timedOut],
		});

		const resolved = await resolveReusableMeshGenerateJob(env, db, scope, now);

		expect(resolved).toBeNull();
	});
});

describe("resolveActiveMeshGenerateJob", () => {
	const scope = {
		inputFingerprint: "a".repeat(64),
		orgId: "org-123",
		projectId: "project-123",
	};

	it("prefers in-flight work over a newer completed job for the same inputs", async () => {
		const completed = buildJob({
			id: "job-completed",
			status: "completed",
			completedAt: now,
			inputFingerprint: scope.inputFingerprint,
		});
		const queued = buildJob({
			id: "job-queued",
			inputFingerprint: scope.inputFingerprint,
		});
		const { env } = createEnv(undefined);
		const { db } = createFakeDb({ recentJobs: [completed, queued] });

		const resolved = await resolveActiveMeshGenerateJob(env, db, scope, now);

		expect(resolved?.id).toBe("job-queued");
	});

	it("returns null when only completed or failed jobs exist", async () => {
		const completed = buildJob({
			id: "job-completed",
			status: "completed",
			completedAt: now,
			inputFingerprint: scope.inputFingerprint,
		});
		const { env } = createEnv(undefined);
		const { db } = createFakeDb({
			recentJobs: [completed],
		});

		expect(await resolveActiveMeshGenerateJob(env, db, scope, now)).toBeNull();
	});

	it("returns an older in-flight fallback hidden behind newer terminal jobs", async () => {
		const olderQueued = buildJob({
			id: "job-older-queued",
			inputFingerprint: scope.inputFingerprint,
		});
		const { env } = createEnv(undefined);
		const { db } = createFakeDb({
			fallbackJobResults: [olderQueued],
			recentJobs: [
				buildJob({
					id: "job-failed",
					status: "failed",
					completedAt: now,
					error: "merge failed",
					inputFingerprint: scope.inputFingerprint,
				}),
			],
		});

		const resolved = await resolveActiveMeshGenerateJob(env, db, scope, now);

		expect(resolved?.id).toBe("job-older-queued");
	});

	it("ignores an in-flight fallback that reconciles to failed", async () => {
		const timedOut = buildJob({
			id: "job-timed-out",
			createdAt: new Date(now.getTime() - meshJobTimeoutMs - 1000),
			inputFingerprint: scope.inputFingerprint,
		});
		const { env } = createEnv(undefined);
		const { db } = createFakeDb({ fallbackJobResults: [timedOut] });

		expect(await resolveActiveMeshGenerateJob(env, db, scope, now)).toBeNull();
	});
});

describe("resolveCurrentMeshGenerateJobCandidates", () => {
	const selectedKeys = ["zones/zone-1/scan-v1.zip"];
	const selectionFingerprint = () =>
		computeMeshJobInputFingerprint({
			type: meshJobDefinitions.generate.type,
			version: meshJobDefinitions.generate.version,
			zoneScanObjectKeys: selectedKeys,
		});

	it("orders the selection match before the newest completed job", async () => {
		const { close, db } = createAppTestDb();
		const selectionJob = buildJob({
			id: "job-selection",
			status: "completed",
			completedAt: now,
			inputFingerprint: await selectionFingerprint(),
		});
		const newerJob = buildJob({
			createdAt: new Date(now.getTime() + 1000),
			id: "job-newer",
			status: "completed",
			completedAt: now,
			inputFingerprint: "b".repeat(64),
		});
		const { env } = createEnv(undefined);
		try {
			await insertProject(db);
			await insertUploadedZoneScans(db, selectedKeys);
			await db.insert(meshJobs).values([newerJob, selectionJob]).run();

			const candidates = await resolveCurrentMeshGenerateJobCandidates(
				env,
				db,
				{
					orgId: "org-123",
					projectId: "project-123",
				},
				now,
			);

			expect(candidates.map((job) => job.id)).toEqual([
				"job-selection",
				"job-newer",
			]);
		} finally {
			close();
		}
	});

	it("returns a single candidate when the selection match is also the newest completed job", async () => {
		const { close, db } = createAppTestDb();
		const selectionJob = buildJob({
			id: "job-selection",
			status: "completed",
			completedAt: now,
			inputFingerprint: await selectionFingerprint(),
		});
		const { env } = createEnv(undefined);
		try {
			await insertProject(db);
			await insertUploadedZoneScans(db, selectedKeys);
			await db.insert(meshJobs).values(selectionJob).run();

			const candidates = await resolveCurrentMeshGenerateJobCandidates(
				env,
				db,
				{
					orgId: "org-123",
					projectId: "project-123",
				},
				now,
			);

			expect(candidates.map((job) => job.id)).toEqual(["job-selection"]);
		} finally {
			close();
		}
	});

	it("reconciles a job shared by both tiers only once", async () => {
		// A running job with the selection fingerprint appears in both the
		// fingerprint-scoped and unscoped recency windows and is reconciled (unlike
		// a completed job). Its status.json must be read once per request, not once
		// per tier.
		const { close, db } = createAppTestDb();
		const runningJob = buildJob({
			id: "job-running",
			status: "running",
			startedAt: now,
			createdAt: now,
			inputFingerprint: await selectionFingerprint(),
		});
		const selectionJob = buildJob({
			id: "job-selection",
			status: "completed",
			completedAt: now,
			createdAt: new Date(now.getTime() - 1000),
			inputFingerprint: await selectionFingerprint(),
		});
		const { env, readKeys } = createEnv(undefined);
		try {
			await insertProject(db);
			await insertUploadedZoneScans(db, selectedKeys);
			await db.insert(meshJobs).values([runningJob, selectionJob]).run();

			await resolveCurrentMeshGenerateJobCandidates(
				env,
				db,
				{ orgId: "org-123", projectId: "project-123" },
				now,
			);

			const runningReads = readKeys.filter((key) =>
				key.includes("job-running"),
			);
			expect(runningReads).toHaveLength(1);
		} finally {
			close();
		}
	});

	it("falls back to the newest completed job when the selection was never merged", async () => {
		const { close, db } = createAppTestDb();
		const newerJob = buildJob({
			id: "job-newer",
			status: "completed",
			completedAt: now,
			inputFingerprint: "b".repeat(64),
		});
		const { env } = createEnv(undefined);
		try {
			await insertProject(db);
			await insertUploadedZoneScans(db, selectedKeys);
			await db.insert(meshJobs).values(newerJob).run();

			const candidates = await resolveCurrentMeshGenerateJobCandidates(
				env,
				db,
				{
					orgId: "org-123",
					projectId: "project-123",
				},
				now,
			);

			expect(candidates.map((job) => job.id)).toEqual(["job-newer"]);
		} finally {
			close();
		}
	});

	it("skips selection matching when no zones have uploaded scans", async () => {
		const { close, db } = createAppTestDb();
		const completed = buildJob({
			id: "job-completed",
			status: "completed",
			completedAt: now,
		});
		const { env } = createEnv(undefined);
		try {
			await insertProject(db);
			await db.insert(meshJobs).values(completed).run();

			const candidates = await resolveCurrentMeshGenerateJobCandidates(
				env,
				db,
				{
					orgId: "org-123",
					projectId: "project-123",
				},
				now,
			);

			expect(candidates.map((job) => job.id)).toEqual(["job-completed"]);
		} finally {
			close();
		}
	});
});
