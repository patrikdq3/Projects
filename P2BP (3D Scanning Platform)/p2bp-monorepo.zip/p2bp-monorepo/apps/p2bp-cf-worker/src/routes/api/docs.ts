import type { OpenAPIHono } from "@hono/zod-openapi";
import { Scalar } from "@scalar/hono-api-reference";
import type { WorkerAppEnv } from "../../app-env";

export const registerDocsRoutes = (app: OpenAPIHono<WorkerAppEnv>) => {
	app.doc("/open-api", {
		openapi: "3.0.0",
		info: {
			title: "P2BP API",
			version: "1.0.0",
		},
		servers: [{ url: "/api" }],
	});

	app.get(
		"/scalar",
		Scalar({
			theme: "deepSpace",
			sources: [
				{ url: "/api/open-api", title: "P2BP API" },
				{ url: "/api/auth/open-api/generate-schema", title: "Auth" },
			],
		}),
	);
};
