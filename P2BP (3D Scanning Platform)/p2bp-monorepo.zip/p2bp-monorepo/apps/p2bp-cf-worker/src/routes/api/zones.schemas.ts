import { z } from "@hono/zod-openapi";
import { LatitudeSchema, LongitudeSchema } from "../../lib/schemas/geo";
import { zoneScanUploadStatuses } from "../../lib/zones/scan-upload-status";
import {
	ZoneScanPreviewUploadRequiredHeadersSchema,
	ZoneScanUploadRequiredHeadersSchema,
} from "./zones.scan-upload-contract";

const ZoneMetadataSchema = z.unknown().nullable();

const ZoneScannedAtSchema = z.iso.datetime({ offset: true });

const ZoneDurationSchema = z.number().min(0).nullable();

const ZonePointCountSchema = z.number().int().min(0).nullable();

const ZoneScanObjectKeySchema = z.string().max(2048).nullable();

const ZoneScanUploadStatusSchema = z.enum(zoneScanUploadStatuses).nullable();

const ZoneScanUploadTimestampSchema = z.iso.datetime().nullable();

const ZoneCornerSchema = z.object({
	latitude: LatitudeSchema,
	longitude: LongitudeSchema,
});

export const ZoneScanArchivesQuerySchema = z.object({
	limit: z.coerce.number().int().min(1).max(100).default(50),
	reconcileLimit: z.coerce.number().int().min(0).max(10).default(5),
});

export const ZoneSchema = z
	.object({
		id: z.string(),
		projectId: z.string(),
		x: z.number().int(),
		y: z.number().int(),
		corners: z.array(ZoneCornerSchema).length(4),
		scannedAt: ZoneScannedAtSchema,
		duration: ZoneDurationSchema,
		pointCount: ZonePointCountSchema,
		scanObjectKey: ZoneScanObjectKeySchema,
		scanUploadStatus: ZoneScanUploadStatusSchema,
		scanUploadExpiresAt: ZoneScanUploadTimestampSchema,
		scanUploadedAt: ZoneScanUploadTimestampSchema,
		metadata: ZoneMetadataSchema,
		createdAt: z.string(),
	})
	.openapi("Zone");

export const ZoneScanUploadUrlResponseSchema = z
	.object({
		objectKey: ZoneScanObjectKeySchema.unwrap(),
		requiredHeaders: ZoneScanUploadRequiredHeadersSchema,
		uploadUrl: z.url(),
		expiresAt: z.iso.datetime(),
		previewObjectKey: ZoneScanObjectKeySchema.unwrap(),
		previewRequiredHeaders: ZoneScanPreviewUploadRequiredHeadersSchema,
		previewUploadUrl: z.url(),
		previewExpiresAt: z.iso.datetime(),
		zone: ZoneSchema,
	})
	.openapi("ZoneScanUploadURLResponse");

export const ZoneScanArchiveDownloadUrlResponseSchema = z
	.object({
		objectKey: ZoneScanObjectKeySchema.unwrap(),
		downloadUrl: z.url().nullable(),
		uploadStatus: z.enum(zoneScanUploadStatuses),
		expiresAt: z.iso.datetime(),
	})
	.openapi("ZoneScanArchiveDownloadURLResponse");

export const ZoneScanPreviewDownloadUrlResponseSchema = z
	.object({
		previewObjectKey: ZoneScanObjectKeySchema,
		downloadUrl: z.url().nullable(),
		previewUploadStatus: ZoneScanUploadStatusSchema,
		expiresAt: z.iso.datetime(),
	})
	.openapi("ZoneScanPreviewDownloadURLResponse");

export const ZoneScanArchiveSchema = z
	.object({
		id: z.string(),
		zoneId: z.string(),
		objectKey: ZoneScanObjectKeySchema.unwrap(),
		uploadStatus: z.enum(zoneScanUploadStatuses),
		uploadExpiresAt: z.iso.datetime(),
		uploadedAt: z.iso.datetime().nullable(),
		previewObjectKey: ZoneScanObjectKeySchema,
		previewUploadStatus: ZoneScanUploadStatusSchema,
		previewUploadExpiresAt: z.iso.datetime().nullable(),
		previewUploadedAt: z.iso.datetime().nullable(),
		createdAt: z.iso.datetime(),
	})
	.openapi("ZoneScanArchive");

export const UpdateZoneBodySchema = z
	.object({
		scannedAt: ZoneScannedAtSchema.optional(),
		duration: ZoneDurationSchema.optional(),
		pointCount: ZonePointCountSchema.optional(),
		metadata: ZoneMetadataSchema.optional(),
	})
	.refine((body) => Object.values(body).some((value) => value !== undefined), {
		message: "At least one field must be provided",
	})
	.openapi("UpdateZoneRequest");
