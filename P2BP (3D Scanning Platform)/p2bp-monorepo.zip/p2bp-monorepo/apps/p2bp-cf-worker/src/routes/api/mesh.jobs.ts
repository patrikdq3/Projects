import { createRoute, OpenAPIHono, z } from "@hono/zod-openapi";
import { and, desc, eq } from "drizzle-orm";
import type { Context } from "hono";
import type { WorkerAppEnv } from "../../app-env";
import type { getDb } from "../../db";
import { meshJobs } from "../../db/schema/app.schema";
import { appLogger } from "../../lib/logger";
import {
	meshJobDefinitions,
	meshJobStatuses,
	meshJobTypes,
} from "../../lib/mesh/job-contract";
import { loadRouteProject } from "../../lib/route-project";
import {
	notFoundErrorResponse,
	organizationMembershipForbiddenErrorResponse,
	unauthorizedErrorResponse,
} from "../../lib/route-responses";
import {
	buildMeshGenerateQueueMessage,
	collectMeshGenerateZoneScanObjectKeys,
	computeMeshJobInputFingerprint,
} from "./mesh.jobs.builder";
import {
	isMeshJobActiveInputConflict,
	type MeshJobRecord,
	reconcileMeshJob,
	resolveActiveMeshGenerateJob,
	resolveReusableMeshGenerateJob,
} from "./mesh.jobs.reconciliation";
import { reconcilePendingZoneScanArchives } from "./zones.scan-reconciliation";

const noUploadedScansMessage =
	"No uploaded zone scans available for this project" as const;
const meshJobBuildErrorMessage = "Mesh job message could not be built" as const;
const meshJobCreateErrorMessage = "Mesh job could not be created" as const;
const meshJobSendErrorMessage = "Mesh job message could not be sent" as const;
const meshJobSendCleanupErrorMessage =
	"Mesh job send-failure cleanup could not mark job failed" as const;
const meshInstanceUnstartableMessage =
	"Mesh processing instance cannot be started" as const;
const meshInstanceStartErrorMessage =
	"Mesh job was enqueued but the processing instance could not be started" as const;
const meshJobPublicFailedErrorMessage = "Mesh job failed" as const;

// Bounded retries when an insert races another job for the same active-input
// slot: each conflict either hands back the winning job or, if that job went
// terminal and freed the slot, retries the insert. Six attempts still bounds a
// slot that keeps flipping while covering short bursts of terminal winners.
const maxMeshJobInsertAttempts = 6;
const MeshJobSchema = z.object({
	id: z.string(),
	type: z.enum(meshJobTypes),
	status: z.enum(meshJobStatuses),
	inputFingerprint: z
		.string()
		.describe(
			"Opaque mesh-job input identity. Compare for equality only; do not parse it or persist semantic meaning from it.",
		),
	zoneScanObjectKeys: z.array(z.string()),
	error: z
		.string()
		.nullable()
		.describe(
			"Generic public failure message. Detailed internal job errors are not exposed through this API.",
		),
	createdAt: z.iso.datetime(),
	startedAt: z.iso.datetime().nullable(),
	completedAt: z.iso.datetime().nullable(),
});

export const serializeMeshJob = (
	job: MeshJobRecord,
): z.infer<typeof MeshJobSchema> => ({
	id: job.id,
	type: job.type,
	status: job.status,
	inputFingerprint: job.inputFingerprint,
	zoneScanObjectKeys: job.zoneScanObjectKeys,
	error: job.status === "failed" ? meshJobPublicFailedErrorMessage : null,
	createdAt: job.createdAt.toISOString(),
	startedAt: job.startedAt?.toISOString() ?? null,
	completedAt: job.completedAt?.toISOString() ?? null,
});

const markMeshJobSendFailure = async (
	db: ReturnType<typeof getDb>,
	job: Pick<MeshJobRecord, "id">,
	now = new Date(),
) =>
	db
		.update(meshJobs)
		.set({
			status: "failed",
			completedAt: now,
			error: meshJobSendErrorMessage,
		})
		.where(and(eq(meshJobs.id, job.id), eq(meshJobs.status, "queued")))
		.run();

export const recordMeshJobSendFailure = async ({
	db,
	job,
	now = new Date(),
	orgId,
	projectId,
	sendError,
}: {
	db: ReturnType<typeof getDb>;
	job: Pick<MeshJobRecord, "id">;
	now?: Date;
	orgId: string;
	projectId: string;
	sendError: unknown;
}) => {
	try {
		await markMeshJobSendFailure(db, job, now);
	} catch (cleanupError) {
		appLogger
			.withError(cleanupError)
			.withMetadata({ jobId: job.id, orgId, projectId })
			.error(meshJobSendCleanupErrorMessage);
	}

	appLogger
		.withError(sendError)
		.withMetadata({ jobId: job.id, orgId, projectId })
		.error(meshJobSendErrorMessage);
};

const routeParamsSchema = z.object({
	orgId: z.string(),
	projectId: z.string(),
});

const ensureMeshInstanceRunning = async (
	c: Context<WorkerAppEnv>,
	{ orgId, projectId }: { orgId: string; projectId: string },
) => {
	try {
		const ec2Result =
			await c.env.EC2_STARTER.getByName("mesh-jobs").ensureRunning();
		appLogger
			.withMetadata({ ...ec2Result, orgId, projectId })
			.info("EC2 Instance Result");
		if (ec2Result.action === "unstartable") {
			appLogger
				.withMetadata({ orgId, projectId })
				.error(meshInstanceUnstartableMessage);
			return c.json(
				{
					success: false,
					error: meshInstanceUnstartableMessage,
				},
				500,
			);
		}
	} catch (error) {
		appLogger
			.withError(error)
			.withMetadata({ orgId, projectId })
			.error(meshInstanceStartErrorMessage);
		return c.json(
			{
				success: false,
				error: meshInstanceStartErrorMessage,
			},
			500,
		);
	}

	return null;
};

const respondWithReusableMeshJob = async (
	c: Context<WorkerAppEnv>,
	reusableJob: MeshJobRecord,
	{ orgId, projectId }: { orgId: string; projectId: string },
) => {
	if (reusableJob.status !== "completed") {
		// The reused job's message may still be waiting in the queue, so make
		// sure the consumer instance is (or becomes) available.
		const instanceError = await ensureMeshInstanceRunning(c, {
			orgId,
			projectId,
		});
		if (instanceError) return instanceError;
	}
	return c.json(
		{
			success: true as const,
			reused: true,
			job: serializeMeshJob(reusableJob),
		},
		200,
	);
};

const createMeshJobRoute = createRoute({
	method: "post",
	path: "/organizations/{orgId}/projects/{projectId}/mesh-jobs",
	operationId: "createMeshJob",
	tags: ["Mesh Jobs"],
	description:
		"Enqueue a mesh.generate processing job for a project (organization owners and admins only). The job consumes each zone's currently selected scan version. mesh.refine is an unsupported contract stub and is not enqueueable. When a job for the exact same set of selected zone scans already exists (completed, queued, or running), that job is reused instead of repeating the work; a completed job is only reused while it still has every output the current pipeline publishes, so a merge predating an output (for example the E57 exports) is re-run rather than reused. Pass `force=true` to bypass completed-job reuse and enqueue a fresh job unless identical work is already queued or running.",
	request: {
		params: routeParamsSchema,
		query: z.object({
			force: z
				.enum(["true", "false"])
				.transform((value) => value === "true")
				.optional(),
		}),
	},
	responses: {
		200: {
			description:
				"Mesh job enqueued, or an existing job for identical inputs reused (`reused: true`).",
			content: {
				"application/json": {
					schema: z.object({
						success: z.literal(true),
						reused: z.boolean(),
						job: MeshJobSchema,
					}),
				},
			},
		},
		400: {
			description: noUploadedScansMessage,
			content: {
				"application/json": {
					schema: z.object({
						success: z.literal(false),
						error: z.literal(noUploadedScansMessage),
					}),
				},
			},
		},
		401: unauthorizedErrorResponse,
		403: organizationMembershipForbiddenErrorResponse,
		404: notFoundErrorResponse,
		500: {
			description:
				"Mesh job message could not be built or sent, or the processing instance could not be started.",
			content: {
				"application/json": {
					schema: z.object({
						success: z.literal(false),
						error: z.string(),
					}),
				},
			},
		},
	},
});

export const meshJobRoutes = new OpenAPIHono<WorkerAppEnv>();

meshJobRoutes.openapi(createMeshJobRoute, async (c) => {
	const { orgId, projectId } = c.req.valid("param");
	const { force } = c.req.valid("query");
	const routeProject = await loadRouteProject({
		c,
		orgId,
		projectId,
		permission: { meshJob: ["enqueue"] },
	});

	if (!routeProject.ok) return routeProject.response;

	const { db } = routeProject;
	const queue = c.env.MESH_JOBS;

	await reconcilePendingZoneScanArchives(c.env, db, projectId);

	let zoneScanObjectKeys: string[];
	let inputFingerprint: string;
	try {
		zoneScanObjectKeys = await collectMeshGenerateZoneScanObjectKeys({
			db,
			orgId,
			projectId,
		});
		inputFingerprint = await computeMeshJobInputFingerprint({
			type: meshJobDefinitions.generate.type,
			version: meshJobDefinitions.generate.version,
			zoneScanObjectKeys,
		});
	} catch (error) {
		appLogger
			.withError(error)
			.withMetadata({ orgId, projectId })
			.error(meshJobBuildErrorMessage);
		return c.json(
			{
				success: false,
				error: meshJobBuildErrorMessage,
			},
			500,
		);
	}

	if (zoneScanObjectKeys.length === 0) {
		return c.json(
			{
				success: false,
				error: noUploadedScansMessage,
			},
			400,
		);
	}

	if (!force) {
		// Reuse cache: identical inputs (same scan versions for the same zones)
		// under the same message contract hash to the same fingerprint.
		const reusableJob = await resolveReusableMeshGenerateJob(c.env, db, {
			inputFingerprint,
			orgId,
			projectId,
		});

		if (reusableJob) {
			return respondWithReusableMeshJob(c, reusableJob, { orgId, projectId });
		}
	}

	const insertMeshJob = () =>
		db
			.insert(meshJobs)
			.values({
				projectId,
				type: meshJobDefinitions.generate.type,
				messageVersion: meshJobDefinitions.generate.version,
				status: "queued",
				inputFingerprint,
				zoneScanObjectKeys,
			})
			.returning()
			.get();

	const respondToCreateError = (error: unknown) => {
		appLogger
			.withError(error)
			.withMetadata({ orgId, projectId })
			.error(meshJobCreateErrorMessage);
		return c.json(
			{
				success: false,
				error: meshJobCreateErrorMessage,
			},
			500,
		);
	};

	const resolveConflictingMeshJob = () => {
		if (!force) {
			return resolveReusableMeshGenerateJob(c.env, db, {
				inputFingerprint,
				orgId,
				projectId,
			});
		}

		// force=true asked to bypass completed-job reuse, so answering the
		// conflict with a completed job would return exactly the cached result
		// the caller rejected. Only in-flight identical work satisfies a
		// forced request.
		return resolveActiveMeshGenerateJob(c.env, db, {
			inputFingerprint,
			orgId,
			projectId,
		});
	};

	// Insert, resolving active-input conflicts as we go. On a conflict we hand
	// back a reusable/in-flight job if one exists; otherwise the conflicting job
	// went terminal (e.g. a stale queued row timed out), freeing the unique-index
	// slot, so we retry the insert (bounded by maxMeshJobInsertAttempts).
	let job: MeshJobRecord | undefined;
	let lastConflictError: unknown;

	for (let attempt = 0; attempt < maxMeshJobInsertAttempts; attempt += 1) {
		try {
			job = await insertMeshJob();
			break;
		} catch (error) {
			if (!isMeshJobActiveInputConflict(error)) {
				return respondToCreateError(error);
			}
			lastConflictError = error;

			const conflictingJob = await resolveConflictingMeshJob();
			if (conflictingJob) {
				return respondWithReusableMeshJob(c, conflictingJob, {
					orgId,
					projectId,
				});
			}
		}
	}

	if (!job) {
		return respondToCreateError(lastConflictError);
	}

	const message = buildMeshGenerateQueueMessage({
		jobId: job.id,
		organizationId: orgId,
		projectId,
		zoneScanObjectKeys,
	});

	try {
		await queue.send(message);
	} catch (error) {
		// The job never entered the queue; mark it failed so any racing reuse
		// response points at visible terminal state rather than a disappearing row.
		await recordMeshJobSendFailure({
			db,
			job,
			orgId,
			projectId,
			sendError: error,
		});
		return c.json(
			{
				success: false,
				error: meshJobSendErrorMessage,
			},
			500,
		);
	}

	const instanceError = await ensureMeshInstanceRunning(c, {
		orgId,
		projectId,
	});
	if (instanceError) return instanceError;

	return c.json(
		{
			success: true as const,
			reused: false,
			job: serializeMeshJob(job),
		},
		200,
	);
});

const listMeshJobsRoute = createRoute({
	method: "get",
	path: "/organizations/{orgId}/projects/{projectId}/mesh-jobs",
	operationId: "listMeshJobs",
	tags: ["Mesh Jobs"],
	description:
		"List a project's mesh jobs, newest first, with statuses reconciled against the consumer-written status objects in R2.",
	request: {
		params: routeParamsSchema,
		query: z.object({
			limit: z.coerce.number().int().min(1).max(100).default(20),
		}),
	},
	responses: {
		200: {
			description: "Mesh jobs for the project, newest first.",
			content: {
				"application/json": {
					schema: z.object({
						jobs: z.array(MeshJobSchema),
					}),
				},
			},
		},
		401: unauthorizedErrorResponse,
		403: organizationMembershipForbiddenErrorResponse,
		404: notFoundErrorResponse,
	},
});

meshJobRoutes.openapi(listMeshJobsRoute, async (c) => {
	const { orgId, projectId } = c.req.valid("param");
	const { limit } = c.req.valid("query");
	const routeProject = await loadRouteProject({
		c,
		orgId,
		projectId,
		permission: { project: ["view"] },
	});

	if (!routeProject.ok) return routeProject.response;

	const { db } = routeProject;
	const jobs = await db
		.select()
		.from(meshJobs)
		.where(eq(meshJobs.projectId, projectId))
		.orderBy(desc(meshJobs.createdAt), desc(meshJobs.id))
		.limit(limit)
		.all();

	const resolvedJobs = await Promise.all(
		jobs.map((job) => reconcileMeshJob(c.env, db, { orgId }, job)),
	);

	return c.json({ jobs: resolvedJobs.map(serializeMeshJob) }, 200);
});

const getMeshJobRoute = createRoute({
	method: "get",
	path: "/organizations/{orgId}/projects/{projectId}/mesh-jobs/{jobId}",
	operationId: "getMeshJob",
	tags: ["Mesh Jobs"],
	description:
		"Get a single mesh job, with its status reconciled against the consumer-written status object in R2.",
	request: {
		params: routeParamsSchema.extend({
			jobId: z.string(),
		}),
	},
	responses: {
		200: {
			description: "The mesh job.",
			content: {
				"application/json": {
					schema: z.object({
						job: MeshJobSchema,
					}),
				},
			},
		},
		401: unauthorizedErrorResponse,
		403: organizationMembershipForbiddenErrorResponse,
		404: notFoundErrorResponse,
	},
});

meshJobRoutes.openapi(getMeshJobRoute, async (c) => {
	const { orgId, projectId, jobId } = c.req.valid("param");
	const routeProject = await loadRouteProject({
		c,
		orgId,
		projectId,
		permission: { project: ["view"] },
	});

	if (!routeProject.ok) return routeProject.response;

	const { db } = routeProject;
	const job = await db
		.select()
		.from(meshJobs)
		.where(and(eq(meshJobs.id, jobId), eq(meshJobs.projectId, projectId)))
		.get();

	if (!job) return c.json({ error: "Not found" as const }, 404);

	const resolvedJob = await reconcileMeshJob(c.env, db, { orgId }, job);

	return c.json({ job: serializeMeshJob(resolvedJob) }, 200);
});
