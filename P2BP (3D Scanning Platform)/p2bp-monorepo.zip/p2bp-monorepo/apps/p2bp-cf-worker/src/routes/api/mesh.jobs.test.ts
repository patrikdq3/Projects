import { describe, expect, it, spyOn } from "bun:test";
import type { getDb } from "../../db";
import { projects, zones } from "../../db/schema/app.schema";
import { organization } from "../../db/schema/better-auth.schema";
import { meshJobDefinitions } from "../../lib/mesh/job-contract";
import { createAppTestDb } from "../../test/app-db";
import { recordMeshJobSendFailure, serializeMeshJob } from "./mesh.jobs";
import {
	buildMeshGenerateQueueMessage,
	collectMeshGenerateZoneScanObjectKeys,
	computeMeshJobInputFingerprint,
} from "./mesh.jobs.builder";
import type { MeshJobRecord } from "./mesh.jobs.reconciliation";

const now = new Date("2026-06-14T09:00:00.000Z");

const buildJob = (overrides: Partial<MeshJobRecord> = {}): MeshJobRecord =>
	({
		id: "job-123",
		projectId: "project-123",
		type: meshJobDefinitions.generate.type,
		messageVersion: meshJobDefinitions.generate.version,
		status: "queued",
		inputFingerprint: "f".repeat(64),
		zoneScanObjectKeys: ["zones/zone-1/scan.zip"],
		error: null,
		startedAt: null,
		completedAt: null,
		createdAt: now,
		...overrides,
	}) as MeshJobRecord;

const buildSendFailureDb = ({ fail = false }: { fail?: boolean } = {}) => {
	const updates: Array<Record<string, unknown>> = [];
	const db = {
		update: () => ({
			set: (values: Record<string, unknown>) => ({
				where: () => ({
					run: async () => {
						updates.push(values);
						if (fail) throw new Error("cleanup update failed");
						return { meta: { changes: 1 } };
					},
				}),
			}),
		}),
	} as unknown as ReturnType<typeof getDb>;

	return { db, updates };
};

const insertOrganization = (
	db: ReturnType<typeof getDb>,
	{ id, slug }: { id: string; slug: string },
) =>
	db
		.insert(organization)
		.values({
			createdAt: now,
			id,
			logo: null,
			metadata: null,
			name: id,
			slug,
		})
		.run();

describe("collectMeshGenerateZoneScanObjectKeys", () => {
	it("collects only uploaded zone scan object keys in zone grid order", async () => {
		const { close, db } = createAppTestDb();
		try {
			await insertOrganization(db, { id: "org-123", slug: "org-123" });
			await insertOrganization(db, { id: "org-other", slug: "org-other" });
			await db
				.insert(projects)
				.values([
					{
						createdAt: now,
						description: null,
						id: "project-123",
						initialLat: 1,
						initialLong: 2,
						name: "Project",
						organizationId: "org-123",
						zoneSize: 10,
					},
					{
						createdAt: now,
						description: null,
						id: "project-other",
						initialLat: 1,
						initialLong: 2,
						name: "Other",
						organizationId: "org-other",
						zoneSize: 10,
					},
				])
				.run();
			await db
				.insert(zones)
				.values([
					{
						createdAt: now,
						duration: null,
						id: "zone-3",
						metadata: null,
						pointCount: null,
						projectId: "project-123",
						scannedAt: now,
						scanObjectKey: "zones/zone-3/scan.laz",
						scanUploadedAt: now,
						scanUploadExpiresAt: now,
						scanUploadStatus: "uploaded",
						x: 2,
						y: 0,
					},
					{
						createdAt: now,
						duration: null,
						id: "zone-pending",
						metadata: null,
						pointCount: null,
						projectId: "project-123",
						scannedAt: now,
						scanObjectKey: "zones/pending/scan.laz",
						scanUploadedAt: null,
						scanUploadExpiresAt: now,
						scanUploadStatus: "pending",
						x: 1,
						y: 1,
					},
					{
						createdAt: now,
						duration: null,
						id: "zone-1",
						metadata: null,
						pointCount: null,
						projectId: "project-123",
						scannedAt: now,
						scanObjectKey: "zones/zone-1/scan.laz",
						scanUploadedAt: now,
						scanUploadExpiresAt: now,
						scanUploadStatus: "uploaded",
						x: 0,
						y: 0,
					},
					{
						createdAt: now,
						duration: null,
						id: "zone-2",
						metadata: null,
						pointCount: null,
						projectId: "project-123",
						scannedAt: now,
						scanObjectKey: "zones/zone-2/scan.laz",
						scanUploadedAt: now,
						scanUploadExpiresAt: now,
						scanUploadStatus: "uploaded",
						x: 1,
						y: 0,
					},
					{
						createdAt: now,
						duration: null,
						id: "zone-other-project",
						metadata: null,
						pointCount: null,
						projectId: "project-other",
						scannedAt: now,
						scanObjectKey: "zones/other/scan.laz",
						scanUploadedAt: now,
						scanUploadExpiresAt: now,
						scanUploadStatus: "uploaded",
						x: 0,
						y: 0,
					},
				])
				.run();

			expect(
				await collectMeshGenerateZoneScanObjectKeys({
					db,
					orgId: "org-123",
					projectId: "project-123",
				}),
			).toEqual([
				"zones/zone-1/scan.laz",
				"zones/zone-2/scan.laz",
				"zones/zone-3/scan.laz",
			]);
		} finally {
			close();
		}
	});

	it("returns an empty array when no zones have uploaded scans", async () => {
		const { close, db } = createAppTestDb();
		try {
			await insertOrganization(db, { id: "org-123", slug: "org-123" });
			await db
				.insert(projects)
				.values({
					createdAt: now,
					description: null,
					id: "project-123",
					initialLat: 1,
					initialLong: 2,
					name: "Project",
					organizationId: "org-123",
					zoneSize: 10,
				})
				.run();
			await db
				.insert(zones)
				.values({
					createdAt: now,
					duration: null,
					id: "zone-1",
					metadata: null,
					pointCount: null,
					projectId: "project-123",
					scannedAt: now,
					scanObjectKey: null,
					scanUploadedAt: null,
					scanUploadExpiresAt: null,
					scanUploadStatus: null,
					x: 0,
					y: 0,
				})
				.run();

			expect(
				await collectMeshGenerateZoneScanObjectKeys({
					db,
					orgId: "org-123",
					projectId: "project-123",
				}),
			).toEqual([]);
		} finally {
			close();
		}
	});

	it("propagates database errors from the zone scan query", async () => {
		const db = {
			select: () => ({
				from: () => ({
					innerJoin: () => ({
						where: () => ({
							orderBy: () => ({
								all: () => {
									throw new Error("D1 query failed");
								},
							}),
						}),
					}),
				}),
			}),
		} as unknown as ReturnType<typeof getDb>;
		await expect(
			collectMeshGenerateZoneScanObjectKeys({
				db,
				orgId: "org-123",
				projectId: "project-123",
			}),
		).rejects.toThrow("D1 query failed");
	});
});

describe("buildMeshGenerateQueueMessage", () => {
	it("builds a versioned mesh.generate message carrying the job id", () => {
		expect(
			buildMeshGenerateQueueMessage({
				jobId: "job-123",
				organizationId: "org-123",
				projectId: "project-123",
				zoneScanObjectKeys: ["zones/zone-1/scan.zip"],
			}),
		).toEqual({
			type: "mesh.generate",
			version: 3,
			jobId: "job-123",
			organizationId: "org-123",
			projectId: "project-123",
			zoneScanObjectKeys: ["zones/zone-1/scan.zip"],
		});
	});

	it("pins the mesh.generate contract version consumed by P2BP-Postprocessing", () => {
		expect(meshJobDefinitions.generate).toEqual({
			type: "mesh.generate",
			version: 3,
		});
		expect(meshJobDefinitions.refine).toEqual({
			type: "mesh.refine",
			version: 1,
		});
	});
});

describe("computeMeshJobInputFingerprint", () => {
	const baseInput = {
		type: meshJobDefinitions.generate.type,
		version: meshJobDefinitions.generate.version,
		zoneScanObjectKeys: ["zones/a.zip", "zones/b.zip"],
	} as const;

	it("is deterministic and hex-encoded", async () => {
		const first = await computeMeshJobInputFingerprint(baseInput);
		const second = await computeMeshJobInputFingerprint(baseInput);
		expect(first).toBe(second);
		expect(first).toMatch(/^[0-9a-f]{64}$/);
	});

	it("ignores zone scan key ordering", async () => {
		const reversed = await computeMeshJobInputFingerprint({
			...baseInput,
			zoneScanObjectKeys: ["zones/b.zip", "zones/a.zip"],
		});
		expect(reversed).toBe(await computeMeshJobInputFingerprint(baseInput));
	});

	it("changes when the scan key set changes", async () => {
		const different = await computeMeshJobInputFingerprint({
			...baseInput,
			zoneScanObjectKeys: ["zones/a.zip", "zones/c.zip"],
		});
		expect(different).not.toBe(await computeMeshJobInputFingerprint(baseInput));
	});

	it("changes when the message version changes", async () => {
		const different = await computeMeshJobInputFingerprint({
			...baseInput,
			version: baseInput.version + 1,
		});
		expect(different).not.toBe(await computeMeshJobInputFingerprint(baseInput));
	});
});

describe("serializeMeshJob", () => {
	it("does not expose stored internal failure details in API responses", () => {
		const serialized = serializeMeshJob(
			buildJob({
				status: "failed",
				error:
					"Authorization: Bearer secret-token at C:\\worker\\pull_queue.py",
			}),
		);

		expect(serialized.error).toBe("Mesh job failed");
		expect(serialized.error).not.toContain("secret-token");
		expect(serialized.error).not.toContain("pull_queue.py");
	});

	it("does not expose stale stored errors for non-failed jobs", () => {
		const serialized = serializeMeshJob(
			buildJob({
				status: "running",
				error: "stale internal failure text",
			}),
		);

		expect(serialized.error).toBeNull();
	});
});

describe("recordMeshJobSendFailure", () => {
	it("marks the queued job failed when queue send fails", async () => {
		const { db, updates } = buildSendFailureDb();
		const completedAt = new Date("2026-06-14T09:05:00.000Z");

		await recordMeshJobSendFailure({
			db,
			job: buildJob(),
			now: completedAt,
			orgId: "org-123",
			projectId: "project-123",
			sendError: new Error("queue send failed"),
		});

		expect(updates).toEqual([
			{
				status: "failed",
				completedAt,
				error: "Mesh job message could not be sent",
			},
		]);
	});

	it("does not throw when the cleanup update also fails", async () => {
		const { db } = buildSendFailureDb({ fail: true });
		const consoleError = spyOn(console, "error").mockImplementation(() => {});
		try {
			await expect(
				recordMeshJobSendFailure({
					db,
					job: buildJob(),
					orgId: "org-123",
					projectId: "project-123",
					sendError: new Error("queue send failed"),
				}),
			).resolves.toBeUndefined();
		} finally {
			consoleError.mockRestore();
		}
	});
});
