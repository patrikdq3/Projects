import { and, asc, eq } from "drizzle-orm";
import type { getDb } from "../../db";
import { projects, zones } from "../../db/schema/app.schema";
import {
	type MeshJobQueueMessage,
	type MeshJobType,
	meshJobDefinitions,
} from "../../lib/mesh/job-contract";

/**
 * Collect the object keys of every uploaded zone scan for the project,
 * ordered by zone grid position. Each scan upload gets a unique object key,
 * so this list exactly identifies which scan version of which zone feeds a
 * mesh.generate job.
 */
export const collectMeshGenerateZoneScanObjectKeys = async ({
	db,
	orgId,
	projectId,
}: {
	db: ReturnType<typeof getDb>;
	orgId: string;
	projectId: string;
}): Promise<string[]> => {
	const zoneRows = await db
		.select({ scanObjectKey: zones.scanObjectKey })
		.from(zones)
		.innerJoin(projects, eq(zones.projectId, projects.id))
		.where(
			and(
				eq(zones.projectId, projectId),
				eq(projects.organizationId, orgId),
				eq(zones.scanUploadStatus, "uploaded"),
			),
		)
		.orderBy(asc(zones.x), asc(zones.y))
		.all();
	return zoneRows
		.map((row) => row.scanObjectKey)
		.filter((key): key is string => key !== null);
};

const toHex = (buffer: ArrayBuffer) =>
	Array.from(new Uint8Array(buffer))
		.map((byte) => byte.toString(16).padStart(2, "0"))
		.join("");

/**
 * Deterministic fingerprint of a mesh job's inputs, used to reuse a completed
 * job instead of re-running identical work. Keys are sorted so the
 * fingerprint depends only on the set of scan versions, not zone ordering;
 * the type and message version are included so pipeline contract changes
 * never reuse outputs produced under an older contract.
 */
export const computeMeshJobInputFingerprint = async ({
	type,
	version,
	zoneScanObjectKeys,
}: {
	type: MeshJobType;
	version: number;
	zoneScanObjectKeys: readonly string[];
}): Promise<string> => {
	// The canonical JSON shape is part of the reuse contract: changing it
	// intentionally invalidates existing mesh_jobs.input_fingerprint matches.
	const canonical = JSON.stringify({
		type,
		version,
		zoneScanObjectKeys: [...zoneScanObjectKeys].sort(),
	});
	const digest = await crypto.subtle.digest(
		"SHA-256",
		new TextEncoder().encode(canonical),
	);
	return toHex(digest);
};

export const buildMeshGenerateQueueMessage = ({
	jobId,
	organizationId,
	projectId,
	zoneScanObjectKeys,
}: {
	jobId: string;
	organizationId: string;
	projectId: string;
	zoneScanObjectKeys: string[];
}): MeshJobQueueMessage => ({
	type: meshJobDefinitions.generate.type,
	version: meshJobDefinitions.generate.version,
	jobId,
	organizationId,
	projectId,
	zoneScanObjectKeys,
});
