import { OpenAPIHono } from "@hono/zod-openapi";
import type { WorkerAppEnv } from "../../app-env";
import { getAuth } from "../../lib/better-auth";

const authRoutes = new OpenAPIHono<WorkerAppEnv>();

authRoutes.all("/*", (c) => {
	return getAuth(c.env).handler(c.req.raw);
});

export { authRoutes };
