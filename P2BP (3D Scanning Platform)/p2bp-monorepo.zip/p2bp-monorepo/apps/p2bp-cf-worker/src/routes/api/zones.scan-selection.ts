import { and, eq } from "drizzle-orm";
import type { getDb } from "../../db";
import { zones } from "../../db/schema/app.schema";
import { readRowChanges } from "../../lib/db-changes";
import type {
	ZoneRecord,
	ZoneScanArchiveRecord,
} from "./zones.scan-reconciliation";

export type ZoneScanSelectionResult =
	| { ok: true; zone: ZoneRecord }
	| {
			ok: false;
			reason:
				| "archive-not-uploaded"
				| "archive-zone-mismatch"
				| "zone-not-found";
	  };

/**
 * Point a zone's current scan at an uploaded archive version. Mesh jobs
 * collect each zone's current scan pointer, so selection directly controls
 * which scan version feeds the next mesh.generate run.
 *
 * Selection intentionally overwrites whatever the pointer held before --
 * including a pending upload -- because it is an explicit administrative
 * action, exactly like requesting a new upload URL. The displaced pending
 * archive still reconciles on its own row; the key-guarded zone updates in
 * zones.scan-reconciliation.ts prevent it from clobbering this selection.
 */
export const selectZoneScanArchive = async (
	db: ReturnType<typeof getDb>,
	{
		archive,
		zone,
	}: {
		archive: ZoneScanArchiveRecord;
		zone: ZoneRecord;
	},
): Promise<ZoneScanSelectionResult> => {
	if (archive.zoneId !== zone.id) {
		// loadZoneScanArchive normally pre-filters the archive by this zone, but
		// keep this defensive check because callers pass independent snapshots.
		return { ok: false, reason: "archive-zone-mismatch" };
	}

	if (archive.uploadStatus !== "uploaded" || !archive.uploadedAt) {
		return { ok: false, reason: "archive-not-uploaded" };
	}

	const result = await db
		.update(zones)
		.set({
			scanObjectKey: archive.objectKey,
			scanUploadedAt: archive.uploadedAt,
			scanUploadExpiresAt: archive.uploadExpiresAt,
			scanUploadStatus: "uploaded",
		})
		.where(and(eq(zones.id, zone.id), eq(zones.projectId, zone.projectId)))
		.run();

	if (readRowChanges(result) === 0) {
		return { ok: false, reason: "zone-not-found" };
	}

	return {
		ok: true,
		zone: {
			...zone,
			scanObjectKey: archive.objectKey,
			scanUploadedAt: archive.uploadedAt,
			scanUploadExpiresAt: archive.uploadExpiresAt,
			scanUploadStatus: "uploaded",
		},
	};
};
