import type { InferInsertModel } from "drizzle-orm";
import type { zones } from "../../db/schema/app.schema";
import {
	buildGeneratedZoneGridCells,
	zoneGenerationConstraints,
} from "../../lib/zones/grid";
import type { ProjectBoundaryPoint } from "./projects.boundary";

type GeneratedZoneInsert = Pick<
	InferInsertModel<typeof zones>,
	"id" | "projectId" | "x" | "y" | "scannedAt"
>;

export const buildGeneratedZoneInsertValues = ({
	boundary,
	initialLat,
	initialLong,
	projectId,
	scannedAt,
	zoneSize,
}: {
	boundary: ProjectBoundaryPoint[];
	initialLat: number;
	initialLong: number;
	projectId: string;
	scannedAt: Date;
	zoneSize: number;
}): GeneratedZoneInsert[] => {
	const gridCells = buildGeneratedZoneGridCells({
		boundary,
		initialLat,
		initialLong,
		zoneSize,
	});

	return gridCells.map(({ x, y }) => ({
		id: crypto.randomUUID(),
		projectId,
		scannedAt,
		x,
		y,
	}));
};

export const chunkZoneInsertValues = <T>(
	values: T[],
	chunkSize = zoneGenerationConstraints.insertChunkSize,
) =>
	Array.from({ length: Math.ceil(values.length / chunkSize) }, (_, index) =>
		values.slice(index * chunkSize, (index + 1) * chunkSize),
	);
