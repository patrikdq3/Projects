import { createRoute, OpenAPIHono, z } from "@hono/zod-openapi";
import type { WorkerAppEnv } from "../../app-env";

const rootRoute = createRoute({
	method: "get",
	path: "/",
	operationId: "getAPIRoot",
	tags: ["System"],
	responses: {
		200: {
			content: {
				"application/json": {
					schema: z.string(),
				},
			},
			description: 'Says "Hello Hono!".',
		},
	},
});

const rootRoutes = new OpenAPIHono<WorkerAppEnv>();

rootRoutes.openapi(rootRoute, (c) => {
	return c.json("Hello Hono!");
});

export { rootRoutes };
