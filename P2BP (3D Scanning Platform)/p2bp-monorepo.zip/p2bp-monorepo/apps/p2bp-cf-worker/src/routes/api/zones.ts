import { createRoute, OpenAPIHono, z } from "@hono/zod-openapi";
import { and, asc, desc, eq, type InferSelectModel } from "drizzle-orm";
import type { Context } from "hono";
import type { WorkerAppEnv } from "../../app-env";
import type { getDb } from "../../db";
import { projects, zoneScanArchives, zones } from "../../db/schema/app.schema";
import { readRowChanges } from "../../lib/db-changes";
import { appLogger } from "../../lib/logger";
import {
	createR2PresignedPutUrl,
	floorDateToSecond,
	localR2S3Endpoint,
	presignR2DownloadUrl,
	r2DownloadUrlExpiresAt,
} from "../../lib/r2/presign";
import type { RoutePermission } from "../../lib/route-access";
import { loadRouteProject } from "../../lib/route-project";
import {
	notFoundErrorResponse,
	organizationMembershipForbiddenErrorResponse,
	unauthorizedErrorResponse,
} from "../../lib/route-responses";
import { buildZoneCorners } from "../../lib/zones/grid";
import {
	resolveZoneScanArchiveState,
	resolveZoneScanUploadState,
	type ZoneRecord,
	type ZoneScanArchiveRecord,
} from "./zones.scan-reconciliation";
import { selectZoneScanArchive } from "./zones.scan-selection";
import {
	zoneScanPreviewUploadRequiredHeaders,
	zoneScanUploadRequiredHeaders,
} from "./zones.scan-upload-contract";
import {
	buildVersionedZoneScanObjectKey,
	buildVersionedZoneScanPreviewObjectKey,
} from "./zones.scan-uploads";
import {
	UpdateZoneBodySchema,
	ZoneScanArchiveDownloadUrlResponseSchema,
	ZoneScanArchiveSchema,
	ZoneScanArchivesQuerySchema,
	ZoneScanPreviewDownloadUrlResponseSchema,
	ZoneScanUploadUrlResponseSchema,
	ZoneSchema,
} from "./zones.schemas";

const zonesRoutes = new OpenAPIHono<WorkerAppEnv>();

type ProjectGridRecord = Pick<
	InferSelectModel<typeof projects>,
	"id" | "initialLat" | "initialLong" | "zoneSize"
>;

const serializeZone = (zone: ZoneRecord, project: ProjectGridRecord) => ({
	...zone,
	corners: buildZoneCorners({
		initialLat: project.initialLat,
		initialLong: project.initialLong,
		x: zone.x,
		y: zone.y,
		zoneSize: project.zoneSize,
	}),
	createdAt: zone.createdAt.toISOString(),
	scanUploadExpiresAt: zone.scanUploadExpiresAt?.toISOString() ?? null,
	scanUploadedAt: zone.scanUploadedAt?.toISOString() ?? null,
	scannedAt: zone.scannedAt.toISOString(),
});

const serializeZoneScanArchive = (archive: ZoneScanArchiveRecord) => ({
	...archive,
	createdAt: archive.createdAt.toISOString(),
	uploadedAt: archive.uploadedAt?.toISOString() ?? null,
	uploadExpiresAt: archive.uploadExpiresAt.toISOString(),
	previewUploadExpiresAt: archive.previewUploadExpiresAt?.toISOString() ?? null,
	previewUploadedAt: archive.previewUploadedAt?.toISOString() ?? null,
});

const zoneWithProjectGridSelection = {
	project: {
		id: projects.id,
		initialLat: projects.initialLat,
		initialLong: projects.initialLong,
		zoneSize: projects.zoneSize,
	},
	zone: zones,
};

const getProjectGridForOrganization = ({
	db,
	orgId,
	projectId,
}: {
	db: ReturnType<typeof getDb>;
	orgId: string;
	projectId: string;
}) =>
	db
		.select({
			id: projects.id,
			initialLat: projects.initialLat,
			initialLong: projects.initialLong,
			zoneSize: projects.zoneSize,
		})
		.from(projects)
		.where(and(eq(projects.id, projectId), eq(projects.organizationId, orgId)))
		.get();

const parseScannedAt = (value: string) => new Date(value);

const scanUploadUrlExpiresInSeconds = 30 * 60;

const getZoneWithProjectGrid = (
	db: ReturnType<typeof getDb>,
	orgId: string,
	projectId: string,
	zoneId: string,
) =>
	db
		.select(zoneWithProjectGridSelection)
		.from(zones)
		.innerJoin(projects, eq(zones.projectId, projects.id))
		.where(
			and(
				eq(zones.id, zoneId),
				eq(zones.projectId, projectId),
				eq(projects.organizationId, orgId),
			),
		)
		.get();

const loadZoneRouteProject = async ({
	c,
	orgId,
	permission,
	projectId,
}: {
	c: Context<WorkerAppEnv>;
	orgId: string;
	permission: RoutePermission;
	projectId: string;
}) => {
	return loadRouteProject({
		c,
		getProject: getProjectGridForOrganization,
		orgId,
		permission,
		projectId,
	});
};

const loadZoneRouteZone = async ({
	c,
	orgId,
	permission,
	projectId,
	zoneId,
}: {
	c: Context<WorkerAppEnv>;
	orgId: string;
	permission: RoutePermission;
	projectId: string;
	zoneId: string;
}) => {
	const routeProject = await loadZoneRouteProject({
		c,
		orgId,
		permission,
		projectId,
	});

	if (!routeProject.ok) return routeProject;

	const result = await getZoneWithProjectGrid(
		routeProject.db,
		orgId,
		projectId,
		zoneId,
	);

	if (!result) {
		return {
			ok: false as const,
			response: c.json({ error: "Not found" as const }, 404),
		};
	}

	return {
		db: routeProject.db,
		ok: true as const,
		project: result.project,
		zone: result.zone,
	};
};

const routeParamsSchema = z.object({
	orgId: z.string(),
	projectId: z.string(),
});

const zoneRouteParamsSchema = routeParamsSchema.extend({
	zoneId: z.string(),
});

const getZonesRoute = createRoute({
	method: "get",
	path: "/organizations/{orgId}/projects/{projectId}/zones",
	operationId: "listZones",
	tags: ["Zones"],
	description:
		"List zones for a project in an organization the authenticated caller belongs to. This is a DB-only snapshot; fetch a single zone or scan archive history to reconcile pending upload state with R2.",
	request: {
		params: routeParamsSchema,
	},
	responses: {
		200: {
			description: "List of zones",
			content: {
				"application/json": {
					schema: z.array(ZoneSchema),
				},
			},
		},
		401: unauthorizedErrorResponse,
		403: organizationMembershipForbiddenErrorResponse,
		404: notFoundErrorResponse,
	},
});

zonesRoutes.openapi(getZonesRoute, async (c) => {
	const { orgId, projectId } = c.req.valid("param");
	const routeProject = await loadZoneRouteProject({
		c,
		orgId,
		permission: { zone: ["view"] },
		projectId,
	});

	if (!routeProject.ok) return routeProject.response;

	const result = await routeProject.db
		.select(zoneWithProjectGridSelection)
		.from(zones)
		.innerJoin(projects, eq(zones.projectId, projects.id))
		.where(
			and(eq(zones.projectId, projectId), eq(projects.organizationId, orgId)),
		)
		.orderBy(asc(zones.x), asc(zones.y))
		.all();

	return c.json(
		result.map(({ project, zone }) => serializeZone(zone, project)),
		200,
	);
});

const getZoneRoute = createRoute({
	method: "get",
	path: "/organizations/{orgId}/projects/{projectId}/zones/{zoneId}",
	operationId: "getZone",
	tags: ["Zones"],
	description:
		"Fetch a zone for a project in an organization the authenticated caller belongs to.",
	request: {
		params: zoneRouteParamsSchema,
	},
	responses: {
		200: {
			description: "Single zone",
			content: {
				"application/json": {
					schema: ZoneSchema,
				},
			},
		},
		401: unauthorizedErrorResponse,
		403: organizationMembershipForbiddenErrorResponse,
		404: notFoundErrorResponse,
	},
});

zonesRoutes.openapi(getZoneRoute, async (c) => {
	const { orgId, projectId, zoneId } = c.req.valid("param");
	const routeZone = await loadZoneRouteZone({
		c,
		orgId,
		permission: { zone: ["view"] },
		projectId,
		zoneId,
	});

	if (!routeZone.ok) return routeZone.response;

	return c.json(
		serializeZone(
			await resolveZoneScanUploadState(c.env, routeZone.db, routeZone.zone),
			routeZone.project,
		),
		200,
	);
});

const getZoneScanArchivesRoute = createRoute({
	method: "get",
	path: "/organizations/{orgId}/projects/{projectId}/zones/{zoneId}/scan-archives",
	operationId: "listZoneScanArchives",
	tags: ["Zone Scan Archives"],
	description:
		"List versioned scan archive uploads for a zone in newest-first order and reconcile pending archive state with R2.",
	request: {
		params: zoneRouteParamsSchema,
		query: ZoneScanArchivesQuerySchema,
	},
	responses: {
		200: {
			description: "Zone scan archive versions",
			content: {
				"application/json": {
					schema: z.array(ZoneScanArchiveSchema),
				},
			},
		},
		401: unauthorizedErrorResponse,
		403: organizationMembershipForbiddenErrorResponse,
		404: notFoundErrorResponse,
	},
});

zonesRoutes.openapi(getZoneScanArchivesRoute, async (c) => {
	const { orgId, projectId, zoneId } = c.req.valid("param");
	const { limit, reconcileLimit } = c.req.valid("query");
	const routeZone = await loadZoneRouteZone({
		c,
		orgId,
		permission: { zone: ["view"] },
		projectId,
		zoneId,
	});

	if (!routeZone.ok) return routeZone.response;

	const archiveRows = await routeZone.db
		.select()
		.from(zoneScanArchives)
		.where(eq(zoneScanArchives.zoneId, zoneId))
		.orderBy(desc(zoneScanArchives.createdAt), desc(zoneScanArchives.id))
		.limit(limit)
		.all();
	let pendingReconciliations = 0;

	return c.json(
		(
			await Promise.all(
				archiveRows.map((archive) => {
					const shouldReconcile =
						archive.uploadStatus !== "pending" ||
						pendingReconciliations < reconcileLimit;

					if (archive.uploadStatus === "pending" && shouldReconcile) {
						pendingReconciliations += 1;
					}

					return shouldReconcile
						? resolveZoneScanArchiveState(
								c.env,
								routeZone.db,
								archive,
								routeZone.zone,
							)
						: archive;
				}),
			)
		).map(serializeZoneScanArchive),
		200,
	);
});

const updateZoneRoute = createRoute({
	method: "patch",
	path: "/organizations/{orgId}/projects/{projectId}/zones/{zoneId}",
	operationId: "updateZone",
	tags: ["Zones"],
	description:
		"Update a zone for a project in an organization the authenticated caller belongs to.",
	request: {
		params: zoneRouteParamsSchema,
		body: {
			content: {
				"application/json": {
					schema: UpdateZoneBodySchema,
				},
			},
		},
	},
	responses: {
		200: {
			description: "Zone updated",
			content: {
				"application/json": {
					schema: ZoneSchema,
				},
			},
		},
		400: { description: "Invalid input" },
		401: unauthorizedErrorResponse,
		403: organizationMembershipForbiddenErrorResponse,
		404: notFoundErrorResponse,
	},
});

zonesRoutes.openapi(updateZoneRoute, async (c) => {
	const { orgId, projectId, zoneId } = c.req.valid("param");
	const body = c.req.valid("json");
	const routeZone = await loadZoneRouteZone({
		c,
		orgId,
		permission: { zone: ["update"] },
		projectId,
		zoneId,
	});

	if (!routeZone.ok) return routeZone.response;

	const updatedZone = await routeZone.db
		.update(zones)
		.set({
			...(body.scannedAt !== undefined && {
				scannedAt: parseScannedAt(body.scannedAt),
			}),
			...(body.duration !== undefined && { duration: body.duration }),
			...(body.pointCount !== undefined && { pointCount: body.pointCount }),
			...(body.metadata !== undefined && { metadata: body.metadata }),
		})
		.where(and(eq(zones.id, zoneId), eq(zones.projectId, projectId)))
		.returning({ id: zones.id })
		.get();

	if (!updatedZone) return c.json({ error: "Not found" as const }, 404);

	const result = await getZoneWithProjectGrid(
		routeZone.db,
		orgId,
		projectId,
		updatedZone.id,
	);

	if (!result) return c.json({ error: "Not found" as const }, 404);

	return c.json(
		serializeZone(
			await resolveZoneScanUploadState(c.env, routeZone.db, result.zone),
			result.project,
		),
		200,
	);
});

const createZoneScanUploadUrlRoute = createRoute({
	method: "post",
	path: "/organizations/{orgId}/projects/{projectId}/zones/{zoneId}/scan-archive/upload-url",
	operationId: "createZoneScanUploadURL",
	tags: ["Zone Scan Archives"],
	description:
		"Create a short-lived direct-to-R2 upload URL for a zipped iOS scan folder and mark the zone upload pending.",
	request: {
		params: zoneRouteParamsSchema,
	},
	responses: {
		200: {
			description: "Presigned upload URL created",
			content: {
				"application/json": {
					schema: ZoneScanUploadUrlResponseSchema,
				},
			},
		},
		401: unauthorizedErrorResponse,
		403: organizationMembershipForbiddenErrorResponse,
		404: notFoundErrorResponse,
		500: {
			description: "Presigned scan upload URL could not be created.",
			content: {
				"application/json": {
					schema: z.object({
						error: z.literal("Scan upload URL could not be created"),
					}),
				},
			},
		},
	},
});

zonesRoutes.openapi(createZoneScanUploadUrlRoute, async (c) => {
	const { orgId, projectId, zoneId } = c.req.valid("param");
	const routeZone = await loadZoneRouteZone({
		c,
		orgId,
		permission: { zone: ["update"] },
		projectId,
		zoneId,
	});

	if (!routeZone.ok) return routeZone.response;

	const uploadId = crypto.randomUUID();
	const objectKey = buildVersionedZoneScanObjectKey({
		orgId,
		projectId,
		uploadId,
		zoneId,
	});
	const previewObjectKey = buildVersionedZoneScanPreviewObjectKey({
		orgId,
		projectId,
		uploadId,
		zoneId,
	});
	const now = floorDateToSecond(new Date());
	const expiresAt = new Date(
		now.getTime() + scanUploadUrlExpiresInSeconds * 1000,
	);
	let uploadUrl: string;
	let previewUploadUrl: string;
	try {
		[uploadUrl, previewUploadUrl] = await Promise.all([
			createR2PresignedPutUrl({
				accessKeyId: c.env.R2_ACCESS_KEY_ID,
				accountId: c.env.CLOUDFLARE_ACCOUNT_ID,
				bucketName: c.env.R2_BUCKET_NAME,
				endpointOverride: localR2S3Endpoint(c.env),
				expiresInSeconds: scanUploadUrlExpiresInSeconds,
				objectKey,
				requiredHeaders: zoneScanUploadRequiredHeaders,
				secretAccessKey: c.env.R2_SECRET_ACCESS_KEY,
			}),
			createR2PresignedPutUrl({
				accessKeyId: c.env.R2_ACCESS_KEY_ID,
				accountId: c.env.CLOUDFLARE_ACCOUNT_ID,
				bucketName: c.env.R2_BUCKET_NAME,
				endpointOverride: localR2S3Endpoint(c.env),
				expiresInSeconds: scanUploadUrlExpiresInSeconds,
				objectKey: previewObjectKey,
				requiredHeaders: zoneScanPreviewUploadRequiredHeaders,
				secretAccessKey: c.env.R2_SECRET_ACCESS_KEY,
			}),
		]);
	} catch (error) {
		appLogger
			.withError(error)
			.withMetadata({
				objectKey,
				orgId,
				previewObjectKey,
				projectId,
				zoneId,
			})
			.error("Scan upload URL could not be created");
		return c.json(
			{
				error: "Scan upload URL could not be created" as const,
			},
			500,
		);
	}

	const [, zoneUpdateResult] = await routeZone.db.batch([
		routeZone.db.insert(zoneScanArchives).values({
			id: uploadId,
			objectKey,
			uploadExpiresAt: expiresAt,
			uploadStatus: "pending",
			previewObjectKey,
			previewUploadExpiresAt: expiresAt,
			previewUploadStatus: "pending",
			zoneId,
		}),
		routeZone.db
			.update(zones)
			.set({
				scanObjectKey: objectKey,
				scanUploadedAt: null,
				scanUploadExpiresAt: expiresAt,
				scanUploadStatus: "pending",
			})
			.where(and(eq(zones.id, zoneId), eq(zones.projectId, projectId))),
	]);

	if (readRowChanges(zoneUpdateResult) === 0) {
		return c.json({ error: "Not found" as const }, 404);
	}

	const result = await getZoneWithProjectGrid(
		routeZone.db,
		orgId,
		projectId,
		zoneId,
	);

	if (!result) return c.json({ error: "Not found" as const }, 404);

	return c.json(
		{
			expiresAt: expiresAt.toISOString(),
			objectKey,
			requiredHeaders: zoneScanUploadRequiredHeaders,
			previewExpiresAt: expiresAt.toISOString(),
			previewObjectKey,
			previewRequiredHeaders: zoneScanPreviewUploadRequiredHeaders,
			previewUploadUrl,
			zone: serializeZone(result.zone, result.project),
			uploadUrl,
		},
		200,
	);
});

const archiveRouteParamsSchema = zoneRouteParamsSchema.extend({
	archiveId: z.string(),
});

const loadZoneScanArchive = async ({
	c,
	orgId,
	permission = { zone: ["view"] },
	projectId,
	zoneId,
	archiveId,
}: {
	c: Context<WorkerAppEnv>;
	orgId: string;
	permission?: RoutePermission;
	projectId: string;
	zoneId: string;
	archiveId: string;
}) => {
	const routeZone = await loadZoneRouteZone({
		c,
		orgId,
		permission,
		projectId,
		zoneId,
	});

	if (!routeZone.ok) return routeZone;

	const archive = await routeZone.db
		.select()
		.from(zoneScanArchives)
		.where(
			and(
				eq(zoneScanArchives.id, archiveId),
				eq(zoneScanArchives.zoneId, zoneId),
			),
		)
		.get();

	if (!archive) {
		return {
			ok: false as const,
			response: c.json({ error: "Not found" as const }, 404),
		};
	}

	return {
		archive: await resolveZoneScanArchiveState(
			c.env,
			routeZone.db,
			archive,
			routeZone.zone,
		),
		db: routeZone.db,
		ok: true as const,
		project: routeZone.project,
		zone: routeZone.zone,
	};
};

const scanDownloadUrlErrorResponse = {
	description: "Presigned scan download URL could not be created.",
	content: {
		"application/json": {
			schema: z.object({
				error: z.literal("Scan download URL could not be created"),
			}),
		},
	},
} as const;

const createZoneScanArchiveDownloadUrlRoute = createRoute({
	method: "get",
	path: "/organizations/{orgId}/projects/{projectId}/zones/{zoneId}/scan-archives/{archiveId}/scan/download-url",
	operationId: "getZoneScanArchiveDownloadURL",
	tags: ["Zone Scan Archives"],
	description:
		"Create a short-lived direct-from-R2 download URL for an uploaded zone scan archive (zip), reconciling pending state first.",
	request: {
		params: archiveRouteParamsSchema,
	},
	responses: {
		200: {
			description: "Presigned scan download URL created",
			content: {
				"application/json": {
					schema: ZoneScanArchiveDownloadUrlResponseSchema,
				},
			},
		},
		401: unauthorizedErrorResponse,
		403: organizationMembershipForbiddenErrorResponse,
		404: notFoundErrorResponse,
		500: scanDownloadUrlErrorResponse,
	},
});

zonesRoutes.openapi(createZoneScanArchiveDownloadUrlRoute, async (c) => {
	const { archiveId, orgId, projectId, zoneId } = c.req.valid("param");
	const result = await loadZoneScanArchive({
		archiveId,
		c,
		orgId,
		projectId,
		zoneId,
	});

	if (!result.ok) return result.response;

	const { archive } = result;

	try {
		const presignResult =
			archive.uploadStatus === "uploaded"
				? await presignR2DownloadUrl(c.env, archive.objectKey)
				: null;

		return c.json(
			{
				downloadUrl: presignResult?.downloadUrl ?? null,
				expiresAt: (
					presignResult?.expiresAt ?? r2DownloadUrlExpiresAt()
				).toISOString(),
				objectKey: archive.objectKey,
				uploadStatus: archive.uploadStatus,
			},
			200,
		);
	} catch (error) {
		appLogger
			.withError(error)
			.withMetadata({
				archiveId,
				objectKey: archive.objectKey,
				orgId,
				projectId,
				zoneId,
			})
			.error("Scan download URL could not be created");
		return c.json(
			{ error: "Scan download URL could not be created" as const },
			500,
		);
	}
});

const createZoneScanArchivePreviewDownloadUrlRoute = createRoute({
	method: "get",
	path: "/organizations/{orgId}/projects/{projectId}/zones/{zoneId}/scan-archives/{archiveId}/preview/download-url",
	operationId: "getZoneScanArchivePreviewDownloadURL",
	tags: ["Zone Scan Archives"],
	description:
		"Create a short-lived direct-from-R2 download URL for an uploaded zone scan preview, reconciling pending state first.",
	request: {
		params: archiveRouteParamsSchema,
	},
	responses: {
		200: {
			description: "Presigned preview download URL created",
			content: {
				"application/json": {
					schema: ZoneScanPreviewDownloadUrlResponseSchema,
				},
			},
		},
		401: unauthorizedErrorResponse,
		403: organizationMembershipForbiddenErrorResponse,
		404: notFoundErrorResponse,
		500: scanDownloadUrlErrorResponse,
	},
});

zonesRoutes.openapi(createZoneScanArchivePreviewDownloadUrlRoute, async (c) => {
	const { archiveId, orgId, projectId, zoneId } = c.req.valid("param");
	const result = await loadZoneScanArchive({
		archiveId,
		c,
		orgId,
		projectId,
		zoneId,
	});

	if (!result.ok) return result.response;

	const { archive } = result;

	try {
		const presignResult =
			archive.previewUploadStatus === "uploaded" && archive.previewObjectKey
				? await presignR2DownloadUrl(c.env, archive.previewObjectKey)
				: null;

		return c.json(
			{
				downloadUrl: presignResult?.downloadUrl ?? null,
				expiresAt: (
					presignResult?.expiresAt ?? r2DownloadUrlExpiresAt()
				).toISOString(),
				previewObjectKey: archive.previewObjectKey,
				previewUploadStatus: archive.previewUploadStatus,
			},
			200,
		);
	} catch (error) {
		appLogger
			.withError(error)
			.withMetadata({
				archiveId,
				orgId,
				previewObjectKey: archive.previewObjectKey,
				projectId,
				zoneId,
			})
			.error("Scan preview download URL could not be created");
		return c.json(
			{ error: "Scan download URL could not be created" as const },
			500,
		);
	}
});

const archiveNotUploadedMessage =
	"Only uploaded scan archives can be selected as a zone's current scan" as const;

const selectZoneScanArchiveRoute = createRoute({
	method: "post",
	path: "/organizations/{orgId}/projects/{projectId}/zones/{zoneId}/scan-archives/{archiveId}/select",
	operationId: "selectZoneScanArchive",
	tags: ["Zone Scan Archives"],
	description:
		"Select an uploaded scan archive version as the zone's current scan (organization owners and admins only). Mesh jobs consume each zone's current scan, so this controls which version feeds the next mesh job.",
	request: {
		params: archiveRouteParamsSchema,
	},
	responses: {
		200: {
			description: "Zone repointed at the selected scan archive",
			content: {
				"application/json": {
					schema: ZoneSchema,
				},
			},
		},
		401: unauthorizedErrorResponse,
		403: organizationMembershipForbiddenErrorResponse,
		404: notFoundErrorResponse,
		409: {
			description: archiveNotUploadedMessage,
			content: {
				"application/json": {
					schema: z.object({
						error: z.literal(archiveNotUploadedMessage),
					}),
				},
			},
		},
	},
});

zonesRoutes.openapi(selectZoneScanArchiveRoute, async (c) => {
	const { archiveId, orgId, projectId, zoneId } = c.req.valid("param");
	const result = await loadZoneScanArchive({
		archiveId,
		c,
		orgId,
		permission: { zoneScan: ["select"] },
		projectId,
		zoneId,
	});

	if (!result.ok) return result.response;

	const selection = await selectZoneScanArchive(result.db, {
		archive: result.archive,
		zone: result.zone,
	});

	if (!selection.ok) {
		switch (selection.reason) {
			case "zone-not-found":
			case "archive-zone-mismatch":
				return c.json({ error: "Not found" as const }, 404);
			case "archive-not-uploaded":
				return c.json({ error: archiveNotUploadedMessage }, 409);
			default: {
				const unhandled: never = selection.reason;
				throw new RangeError(
					`Unhandled zone scan selection reason: ${String(unhandled)}`,
				);
			}
		}
	}

	return c.json(serializeZone(selection.zone, result.project), 200);
});

export { zonesRoutes };
