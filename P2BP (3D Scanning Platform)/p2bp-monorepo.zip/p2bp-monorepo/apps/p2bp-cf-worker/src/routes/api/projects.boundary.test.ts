import { describe, expect, it } from "bun:test";
import {
	buildBoundaryPointInsertValues,
	ProjectBoundarySchema,
	serializeProjectBoundary,
} from "./projects.boundary";

describe("ProjectBoundarySchema", () => {
	it("requires at least 3 boundary vertices", () => {
		const result = ProjectBoundarySchema.safeParse([
			{ latitude: 1, longitude: 1 },
			{ latitude: 2, longitude: 2 },
		]);

		expect(result.success).toBe(false);
	});

	it("limits boundaries to 16 vertices", () => {
		const result = ProjectBoundarySchema.safeParse(
			Array.from({ length: 17 }, (_, index) => ({
				latitude: index,
				longitude: index,
			})),
		);

		expect(result.success).toBe(false);
	});
});

describe("buildBoundaryPointInsertValues", () => {
	it("preserves boundary vertex order when building insert rows", () => {
		const rows = buildBoundaryPointInsertValues({
			boundary: [
				{ latitude: 10, longitude: 20 },
				{ latitude: 30, longitude: 40 },
				{ latitude: 50, longitude: 60 },
			],
			projectId: "project-123",
		});

		expect(
			rows.map(({ latitude, longitude, projectId, sortOrder }) => ({
				latitude,
				longitude,
				projectId,
				sortOrder,
			})),
		).toEqual([
			{
				latitude: 10,
				longitude: 20,
				projectId: "project-123",
				sortOrder: 0,
			},
			{
				latitude: 30,
				longitude: 40,
				projectId: "project-123",
				sortOrder: 1,
			},
			{
				latitude: 50,
				longitude: 60,
				projectId: "project-123",
				sortOrder: 2,
			},
		]);
	});
});

describe("serializeProjectBoundary", () => {
	it("returns boundary vertices in sort order", () => {
		expect(
			serializeProjectBoundary([
				{ latitude: 30, longitude: 40, sortOrder: 1 },
				{ latitude: 50, longitude: 60, sortOrder: 2 },
				{ latitude: 10, longitude: 20, sortOrder: 0 },
			]),
		).toEqual([
			{ latitude: 10, longitude: 20 },
			{ latitude: 30, longitude: 40 },
			{ latitude: 50, longitude: 60 },
		]);
	});
});
