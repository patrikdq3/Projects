import { and, eq, type InferSelectModel, sql } from "drizzle-orm";
import type { WorkerAppEnv } from "../../app-env";
import type { getDb } from "../../db";
import { zoneScanArchives, zones } from "../../db/schema/app.schema";
import { readRowChanges } from "../../lib/db-changes";
import type { ZoneScanUploadStatus } from "../../lib/zones/scan-upload-status";
import {
	isUploadedZoneScanObjectValid,
	isUploadedZoneScanPreviewObjectValid,
} from "./zones.scan-uploads";

export type ZoneRecord = InferSelectModel<typeof zones>;
export type ZoneScanArchiveRecord = InferSelectModel<typeof zoneScanArchives>;

const updateCurrentZoneScanState = async (
	db: ReturnType<typeof getDb>,
	{
		objectKey,
		uploadedAt,
		uploadStatus,
		zoneId,
	}: {
		objectKey: string;
		uploadedAt: Date | null;
		uploadStatus: Extract<ZoneScanUploadStatus, "uploaded" | "expired">;
		zoneId: string;
	},
) =>
	db
		.update(zones)
		.set({
			scanUploadedAt: uploadedAt,
			scanUploadStatus: uploadStatus,
		})
		// See AGENTS.md: this scanObjectKey predicate is an optimistic-concurrency guard.
		.where(and(eq(zones.id, zoneId), eq(zones.scanObjectKey, objectKey)))
		.run();

const transitionPendingZoneScanArchive = async (
	db: ReturnType<typeof getDb>,
	archive: ZoneScanArchiveRecord,
	{
		currentZone,
		uploadedAt,
		uploadStatus,
	}: {
		currentZone?: ZoneRecord;
		uploadedAt: Date | null;
		uploadStatus: Extract<ZoneScanUploadStatus, "uploaded" | "expired">;
	},
) => {
	const archiveUpdate = db
		.update(zoneScanArchives)
		.set({
			uploadedAt,
			uploadStatus,
		})
		.where(
			and(
				eq(zoneScanArchives.id, archive.id),
				eq(zoneScanArchives.uploadStatus, "pending"),
			),
		);

	const zoneMatchesArchive = currentZone?.scanObjectKey === archive.objectKey;
	const zoneUpdate =
		zoneMatchesArchive && currentZone
			? db
					.update(zones)
					.set({
						scanUploadedAt: uploadedAt,
						scanUploadStatus: uploadStatus,
					})
					.where(
						and(
							eq(zones.id, currentZone.id),
							eq(zones.scanObjectKey, archive.objectKey),
							// See AGENTS.md: keep zone state aligned with the archive transition winner.
							sql`EXISTS (
								SELECT 1
								FROM ${zoneScanArchives}
								WHERE ${zoneScanArchives.id} = ${archive.id}
								AND ${zoneScanArchives.uploadStatus} = ${uploadStatus}
							)`,
						),
					)
			: null;

	const [result] = zoneUpdate
		? await db.batch([archiveUpdate, zoneUpdate])
		: [await archiveUpdate.run()];

	if (readRowChanges(result) > 0) {
		return {
			...archive,
			uploadedAt,
			uploadStatus,
		};
	}

	const latestArchive = await db
		.select()
		.from(zoneScanArchives)
		.where(eq(zoneScanArchives.id, archive.id))
		.get();

	return latestArchive ?? archive;
};

const transitionPendingZoneScanArchivePreview = async (
	db: ReturnType<typeof getDb>,
	archive: ZoneScanArchiveRecord,
	{
		previewUploadedAt,
		previewUploadStatus,
	}: {
		previewUploadedAt: Date | null;
		previewUploadStatus: Extract<ZoneScanUploadStatus, "uploaded" | "expired">;
	},
) => {
	const result = await db
		.update(zoneScanArchives)
		.set({
			previewUploadedAt,
			previewUploadStatus,
		})
		.where(
			and(
				eq(zoneScanArchives.id, archive.id),
				eq(zoneScanArchives.previewUploadStatus, "pending"),
			),
		)
		.run();

	if (readRowChanges(result) > 0) {
		return {
			...archive,
			previewUploadedAt,
			previewUploadStatus,
		};
	}

	const latestArchive = await db
		.select()
		.from(zoneScanArchives)
		.where(eq(zoneScanArchives.id, archive.id))
		.get();

	return latestArchive ?? archive;
};

// Previews live only on the archive row (never mirrored to `zones`), so this
// transition does not need the optimistic-concurrency guards the zip path uses.
const resolveZoneScanArchivePreviewState = async (
	env: WorkerAppEnv["Bindings"],
	db: ReturnType<typeof getDb>,
	archive: ZoneScanArchiveRecord,
	now: Date = new Date(),
) => {
	if (archive.previewUploadStatus !== "pending" || !archive.previewObjectKey) {
		return archive;
	}

	const uploadedObject = await env.BUCKET.head(archive.previewObjectKey);

	if (uploadedObject && isUploadedZoneScanPreviewObjectValid(uploadedObject)) {
		return transitionPendingZoneScanArchivePreview(db, archive, {
			previewUploadedAt: uploadedObject.uploaded ?? now,
			previewUploadStatus: "uploaded",
		});
	}

	if (archive.previewUploadExpiresAt && archive.previewUploadExpiresAt <= now) {
		return transitionPendingZoneScanArchivePreview(db, archive, {
			previewUploadedAt: null,
			previewUploadStatus: "expired",
		});
	}

	return archive;
};

export const resolveZoneScanArchiveState = async (
	env: WorkerAppEnv["Bindings"],
	db: ReturnType<typeof getDb>,
	archive: ZoneScanArchiveRecord,
	currentZone?: ZoneRecord,
	now: Date = new Date(),
) => {
	const zipResolvedArchive = await resolveZoneScanArchiveZipState(
		env,
		db,
		archive,
		currentZone,
		now,
	);

	return resolveZoneScanArchivePreviewState(env, db, zipResolvedArchive, now);
};

const resolveZoneScanArchiveZipState = async (
	env: WorkerAppEnv["Bindings"],
	db: ReturnType<typeof getDb>,
	archive: ZoneScanArchiveRecord,
	currentZone?: ZoneRecord,
	now: Date = new Date(),
) => {
	const zoneMatchesArchive = currentZone?.scanObjectKey === archive.objectKey;

	if (archive.uploadStatus !== "pending") {
		if (zoneMatchesArchive && currentZone?.scanUploadStatus === "pending") {
			await updateCurrentZoneScanState(db, {
				objectKey: archive.objectKey,
				uploadedAt: archive.uploadedAt,
				uploadStatus: archive.uploadStatus,
				zoneId: currentZone.id,
			});
		}

		return archive;
	}

	const uploadedObject = await env.BUCKET.head(archive.objectKey);

	if (uploadedObject && isUploadedZoneScanObjectValid(uploadedObject)) {
		const uploadedAt = uploadedObject.uploaded ?? now;
		return transitionPendingZoneScanArchive(db, archive, {
			currentZone,
			uploadedAt,
			uploadStatus: "uploaded",
		});
	}

	if (archive.uploadExpiresAt <= now) {
		return transitionPendingZoneScanArchive(db, archive, {
			currentZone,
			uploadedAt: null,
			uploadStatus: "expired",
		});
	}

	return archive;
};

export const resolveZoneScanUploadState = async (
	env: WorkerAppEnv["Bindings"],
	db: ReturnType<typeof getDb>,
	zone: ZoneRecord,
	now: Date = new Date(),
) => {
	if (
		zone.scanUploadStatus !== "pending" ||
		!zone.scanObjectKey ||
		!zone.scanUploadExpiresAt
	) {
		return zone;
	}

	const archive = await db
		.select()
		.from(zoneScanArchives)
		.where(eq(zoneScanArchives.objectKey, zone.scanObjectKey))
		.get();

	if (!archive) return zone;

	const resolvedArchive = await resolveZoneScanArchiveState(
		env,
		db,
		archive,
		zone,
		now,
	);

	if (resolvedArchive.uploadStatus !== zone.scanUploadStatus) {
		const latestZone = await db
			.select()
			.from(zones)
			.where(eq(zones.id, zone.id))
			.get();

		return latestZone ?? zone;
	}

	return zone;
};

export const reconcilePendingZoneScanArchives = async (
	env: WorkerAppEnv["Bindings"],
	db: ReturnType<typeof getDb>,
	projectId: string,
	now: Date = new Date(),
) => {
	const pendingArchives = await db
		.select({
			archive: zoneScanArchives,
			zone: zones,
		})
		.from(zoneScanArchives)
		.innerJoin(zones, eq(zoneScanArchives.zoneId, zones.id))
		.where(
			and(
				eq(zones.projectId, projectId),
				eq(zoneScanArchives.uploadStatus, "pending"),
			),
		)
		.all();

	await Promise.all(
		pendingArchives.map(({ archive, zone }) =>
			resolveZoneScanArchiveState(env, db, archive, zone, now),
		),
	);
};
