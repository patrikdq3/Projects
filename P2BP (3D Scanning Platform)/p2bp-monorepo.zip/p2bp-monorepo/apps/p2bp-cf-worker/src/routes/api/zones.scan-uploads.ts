import { zoneScanArchiveContentType } from "./zones.scan-upload-contract";

export const isUploadedZoneScanObjectValid = (object: R2Object) =>
	object.size > 0 &&
	object.httpMetadata?.contentType?.toLowerCase() ===
		zoneScanArchiveContentType;

// Previews are raw binary point subsets; only a non-empty object is required.
export const isUploadedZoneScanPreviewObjectValid = (object: R2Object) =>
	object.size > 0;

export const buildVersionedZoneScanObjectKey = ({
	orgId,
	projectId,
	uploadId,
	zoneId,
}: {
	orgId: string;
	projectId: string;
	uploadId: string;
	zoneId: string;
}) =>
	`organizations/${orgId}/projects/${projectId}/zones/${zoneId}/scans/${uploadId}.zip`;

export const buildVersionedZoneScanPreviewObjectKey = ({
	orgId,
	projectId,
	uploadId,
	zoneId,
}: {
	orgId: string;
	projectId: string;
	uploadId: string;
	zoneId: string;
}) =>
	`organizations/${orgId}/projects/${projectId}/zones/${zoneId}/scans/${uploadId}.preview.bin`;
