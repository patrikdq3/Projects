import { describe, expect, it } from "bun:test";
import {
	resolveZoneScanArchiveState,
	resolveZoneScanUploadState,
	type ZoneRecord,
	type ZoneScanArchiveRecord,
} from "./zones.scan-reconciliation";

const now = new Date("2026-06-14T09:00:00.000Z");

const buildZone = (overrides: Partial<ZoneRecord> = {}): ZoneRecord =>
	({
		createdAt: now,
		duration: null,
		id: "zone-123",
		metadata: null,
		pointCount: null,
		projectId: "project-123",
		scannedAt: now,
		scanObjectKey:
			"organizations/org-123/projects/project-123/zones/zone-123/scans/upload-123.zip",
		scanUploadedAt: null,
		scanUploadExpiresAt: new Date("2026-06-14T09:30:00.000Z"),
		scanUploadStatus: "pending",
		x: 0,
		y: 0,
		...overrides,
	}) as ZoneRecord;

const buildArchive = (
	overrides: Partial<ZoneScanArchiveRecord> = {},
): ZoneScanArchiveRecord =>
	({
		createdAt: now,
		id: "upload-123",
		objectKey:
			"organizations/org-123/projects/project-123/zones/zone-123/scans/upload-123.zip",
		uploadedAt: null,
		uploadExpiresAt: new Date("2026-06-14T09:30:00.000Z"),
		uploadStatus: "pending",
		zoneId: "zone-123",
		...overrides,
	}) as ZoneScanArchiveRecord;

type FakeDbOptions = {
	archiveChanges?: number;
	latestArchive?: ZoneScanArchiveRecord;
	latestZone?: ZoneRecord;
	selectedArchive?: ZoneScanArchiveRecord;
	zoneChanges?: number;
};

const createFakeDb = ({
	archiveChanges = 1,
	latestArchive,
	latestZone,
	selectedArchive,
	zoneChanges = 1,
}: FakeDbOptions = {}) => {
	const archiveUpdates: unknown[] = [];
	const zoneUpdates: unknown[] = [];
	const selectResults = [latestArchive ?? selectedArchive, latestZone].filter(
		(row) => row !== undefined,
	);
	let batchCalls = 0;

	const db = {
		batch: async (statements: Array<{ run: () => Promise<unknown> }>) => {
			batchCalls += 1;
			return Promise.all(statements.map((statement) => statement.run()));
		},
		select: () => ({
			from: () => ({
				where: () => ({
					get: async () => selectResults.shift(),
				}),
			}),
		}),
		update: () => ({
			set: (values: unknown) => ({
				where: () => ({
					run: async () => {
						if (
							"uploadStatus" in (values as Record<string, unknown>) ||
							"previewUploadStatus" in (values as Record<string, unknown>)
						) {
							archiveUpdates.push(values);
							return { meta: { changes: archiveChanges } };
						}

						if ("scanUploadStatus" in (values as Record<string, unknown>)) {
							const matchedArchiveTransition =
								archiveChanges > 0 ||
								latestArchive?.uploadStatus ===
									(values as { scanUploadStatus: unknown }).scanUploadStatus;
							if (zoneChanges > 0 && matchedArchiveTransition) {
								zoneUpdates.push(values);
							}
							return {
								meta: {
									changes: matchedArchiveTransition ? zoneChanges : 0,
								},
							};
						}

						return { meta: { changes: 0 } };
					},
				}),
			}),
		}),
	};

	return {
		batchCalls: () => batchCalls,
		db,
		archiveUpdates,
		zoneUpdates,
	};
};

const createEnv = (object: R2Object | null) =>
	({
		BUCKET: {
			head: async () => object,
		},
	}) as unknown as CloudflareBindings;

const validUploadedObject = {
	httpMetadata: {
		contentType: "application/zip",
	},
	size: 1,
	uploaded: new Date("2026-06-14T09:05:00.000Z"),
} as R2Object;

describe("zone scan reconciliation", () => {
	it("updates the current zone when a matching pending archive uploads", async () => {
		const fake = createFakeDb();
		const archive = buildArchive();

		const resolved = await resolveZoneScanArchiveState(
			createEnv(validUploadedObject),
			fake.db as never,
			archive,
			buildZone(),
		);

		expect(resolved.uploadStatus).toBe("uploaded");
		expect(fake.batchCalls()).toBe(1);
		expect(fake.archiveUpdates).toEqual([
			{
				uploadedAt: validUploadedObject.uploaded,
				uploadStatus: "uploaded",
			},
		]);
		expect(fake.zoneUpdates).toEqual([
			{
				scanUploadedAt: validUploadedObject.uploaded,
				scanUploadStatus: "uploaded",
			},
		]);
	});

	it("does not update the zone when the current pointer moved to another upload", async () => {
		const fake = createFakeDb();

		await resolveZoneScanArchiveState(
			createEnv(validUploadedObject),
			fake.db as never,
			buildArchive(),
			buildZone({
				scanObjectKey:
					"organizations/org-123/projects/project-123/zones/zone-123/scans/upload-456.zip",
			}),
		);

		expect(fake.batchCalls()).toBe(0);
		expect(fake.archiveUpdates).toHaveLength(1);
		expect(fake.zoneUpdates).toHaveLength(0);
	});

	it("returns the winning archive state without writing the zone after losing a race", async () => {
		const latestArchive = buildArchive({
			uploadedAt: null,
			uploadStatus: "expired",
		});
		const fake = createFakeDb({
			archiveChanges: 0,
			latestArchive,
		});

		const resolved = await resolveZoneScanArchiveState(
			createEnv(validUploadedObject),
			fake.db as never,
			buildArchive(),
			buildZone(),
		);

		expect(resolved.uploadStatus).toBe("expired");
		expect(fake.batchCalls()).toBe(1);
		expect(fake.zoneUpdates).toHaveLength(0);
	});

	it("marks an expired pending archive when R2 has no valid object after expiry", async () => {
		const fake = createFakeDb();
		const archive = buildArchive({
			uploadExpiresAt: new Date("2026-01-01T00:00:00.000Z"),
		});

		const resolved = await resolveZoneScanArchiveState(
			createEnv(null),
			fake.db as never,
			archive,
			buildZone(),
			now,
		);

		expect(resolved.uploadStatus).toBe("expired");
		expect(resolved.uploadedAt).toBeNull();
		expect(fake.archiveUpdates).toEqual([
			{
				uploadedAt: null,
				uploadStatus: "expired",
			},
		]);
		expect(fake.zoneUpdates).toEqual([
			{
				scanUploadedAt: null,
				scanUploadStatus: "expired",
			},
		]);
	});

	it("repairs a pending zone from a matching terminal archive without R2 head", async () => {
		const fake = createFakeDb();
		let headCalls = 0;
		const env = {
			BUCKET: {
				head: async () => {
					headCalls += 1;
					return validUploadedObject;
				},
			},
		} as unknown as CloudflareBindings;
		const archive = buildArchive({
			uploadedAt: validUploadedObject.uploaded,
			uploadStatus: "uploaded",
		});

		const resolved = await resolveZoneScanArchiveState(
			env,
			fake.db as never,
			archive,
			buildZone(),
		);

		expect(resolved).toBe(archive);
		expect(headCalls).toBe(0);
		expect(fake.zoneUpdates).toEqual([
			{
				scanUploadedAt: validUploadedObject.uploaded,
				scanUploadStatus: "uploaded",
			},
		]);
	});

	it("marks a pending preview as uploaded when R2 has a valid preview object", async () => {
		const fake = createFakeDb();
		const previewObject = {
			size: 1,
			uploaded: new Date("2026-06-14T09:06:00.000Z"),
		} as R2Object;
		const archive = buildArchive({
			previewObjectKey:
				"organizations/org-123/projects/project-123/zones/zone-123/scans/upload-123.preview.bin",
			previewUploadExpiresAt: new Date("2026-06-14T09:30:00.000Z"),
			previewUploadStatus: "pending",
			uploadedAt: validUploadedObject.uploaded,
			uploadStatus: "uploaded",
		});

		const resolved = await resolveZoneScanArchiveState(
			createEnv(previewObject),
			fake.db as never,
			archive,
		);

		expect(resolved.previewUploadStatus).toBe("uploaded");
		expect(resolved.previewUploadedAt).toEqual(previewObject.uploaded);
		expect(fake.archiveUpdates).toEqual([
			{
				previewUploadedAt: previewObject.uploaded,
				previewUploadStatus: "uploaded",
			},
		]);
	});

	it("marks a pending preview as expired after expiry when R2 has no object", async () => {
		const fake = createFakeDb();
		const archive = buildArchive({
			previewObjectKey:
				"organizations/org-123/projects/project-123/zones/zone-123/scans/upload-123.preview.bin",
			previewUploadExpiresAt: new Date("2026-01-01T00:00:00.000Z"),
			previewUploadStatus: "pending",
			uploadedAt: validUploadedObject.uploaded,
			uploadStatus: "uploaded",
		});

		const resolved = await resolveZoneScanArchiveState(
			createEnv(null),
			fake.db as never,
			archive,
			undefined,
			now,
		);

		expect(resolved.previewUploadStatus).toBe("expired");
		expect(resolved.previewUploadedAt).toBeNull();
		expect(fake.archiveUpdates).toEqual([
			{
				previewUploadedAt: null,
				previewUploadStatus: "expired",
			},
		]);
	});

	it("resolves a pending zone through its current archive", async () => {
		const latestZone = buildZone({
			scanUploadedAt: validUploadedObject.uploaded,
			scanUploadStatus: "uploaded",
		});
		const fake = createFakeDb({
			latestZone,
			selectedArchive: buildArchive(),
		});

		const resolved = await resolveZoneScanUploadState(
			createEnv(validUploadedObject),
			fake.db as never,
			buildZone(),
		);

		expect(resolved).toBe(latestZone);
		expect(fake.archiveUpdates).toHaveLength(1);
		expect(fake.zoneUpdates).toHaveLength(1);
	});

	it("returns the latest zone after a guarded zone update loses a race", async () => {
		const latestZone = buildZone({
			scanObjectKey:
				"organizations/org-123/projects/project-123/zones/zone-123/scans/upload-456.zip",
			scanUploadExpiresAt: new Date("2026-06-14T09:45:00.000Z"),
			scanUploadStatus: "pending",
		});
		const fake = createFakeDb({
			latestZone,
			selectedArchive: buildArchive(),
			zoneChanges: 0,
		});

		const resolved = await resolveZoneScanUploadState(
			createEnv(validUploadedObject),
			fake.db as never,
			buildZone(),
		);

		expect(resolved).toBe(latestZone);
		expect(resolved.scanObjectKey).toBe(latestZone.scanObjectKey);
		expect(resolved.scanUploadStatus).toBe("pending");
		expect(fake.archiveUpdates).toHaveLength(1);
		expect(fake.zoneUpdates).toHaveLength(0);
	});

	it("leaves zones unchanged when there is no pending scan pointer to resolve", async () => {
		const fake = createFakeDb({
			selectedArchive: buildArchive(),
		});
		const zone = buildZone({
			scanObjectKey: null,
			scanUploadExpiresAt: null,
			scanUploadStatus: null,
		});

		const resolved = await resolveZoneScanUploadState(
			createEnv(validUploadedObject),
			fake.db as never,
			zone,
		);

		expect(resolved).toBe(zone);
		expect(fake.archiveUpdates).toHaveLength(0);
		expect(fake.zoneUpdates).toHaveLength(0);
	});

	it("evaluates archive expiry against the injected clock, not the wall clock", async () => {
		const fake = createFakeDb();
		// Expiry is before the real wall clock but after the injected `now`, so a
		// wall-clock read would wrongly expire this still-pending archive.
		const archive = buildArchive({
			uploadExpiresAt: new Date("2026-06-14T09:30:00.000Z"),
		});

		const resolved = await resolveZoneScanArchiveState(
			createEnv(null),
			fake.db as never,
			archive,
			buildZone(),
			now,
		);

		expect(resolved.uploadStatus).toBe("pending");
		expect(fake.archiveUpdates).toHaveLength(0);

		// Advancing the injected clock past expiry marks it expired.
		const expired = await resolveZoneScanArchiveState(
			createEnv(null),
			fake.db as never,
			archive,
			buildZone(),
			new Date("2026-06-14T10:00:00.000Z"),
		);

		expect(expired.uploadStatus).toBe("expired");
	});
});
