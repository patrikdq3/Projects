# Agent Notes

- Mesh job route changes often have cross-repo impact: `src/lib/mesh/job-contract.ts`, `mesh.jobs.keys.ts`, and `P2BP-Postprocessing/pull_queue.py` must stay in sync for message versions, status shape, output filenames, and R2 key paths.
- Mesh job reconciliation is read-driven. Keep terminal/status transitions guarded in `mesh.jobs.reconciliation.ts`; `completed` is final, `failed` can only resurrect to `running` for a later queue redelivery, and in-flight duplicate work is constrained by `mesh_jobs_active_input_unique`.
- Project-level point-cloud downloads intentionally use a snapshot-and-fallback chain: current selection match, newest completed job, then legacy pre-versioned object keys. Preserve the legacy builders and the candidate order.
- Zone scan reconciliation must keep the `zones.scanObjectKey` guard and archive-terminal `EXISTS` check when mirroring archive state onto `zones`; those predicates prevent stale R2 `head()` results from clobbering a newer upload or selection.
- `selectZoneScanArchive` receives archive and zone snapshots independently. Keep the archive/zone mismatch guard even when callers pre-filter by zone.
