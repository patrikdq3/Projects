import { createRoute, OpenAPIHono, z } from "@hono/zod-openapi";
import { and, asc, eq, type InferSelectModel } from "drizzle-orm";
import type { Context } from "hono";
import type { WorkerAppEnv } from "../../app-env";
import { getDb } from "../../db";
import {
	boundaryPoints,
	projects,
	zoneScanArchives,
	zones,
} from "../../db/schema/app.schema";
import {
	resolveRouteAccess,
	respondToRouteAccessError,
} from "../../lib/route-access";
import {
	notFoundErrorResponse,
	organizationMembershipForbiddenErrorResponse,
	unauthorizedErrorResponse,
} from "../../lib/route-responses";
import { ZoneGenerationLimitError } from "../../lib/zones/grid";
import {
	BoundaryPointSchema,
	buildBoundaryPointInsertValues,
	ProjectBoundarySchema,
	serializeProjectBoundary,
} from "./projects.boundary";
import {
	CreateProjectBodySchema,
	ProjectSchema,
	UpdateProjectBodySchema,
} from "./projects.schemas";
import {
	buildGeneratedZoneInsertValues,
	chunkZoneInsertValues,
} from "./projects.zones";
import { reconcilePendingZoneScanArchives } from "./zones.scan-reconciliation";

const projectsRoutes = new OpenAPIHono<WorkerAppEnv>();

type ProjectRecord = InferSelectModel<typeof projects>;
type ProjectReadDb = Pick<ReturnType<typeof getDb>, "select">;
type GeneratedZones = ReturnType<typeof buildGeneratedZoneInsertValues>;

const serializeProject = (project: ProjectRecord) => ({
	...project,
	createdAt: project.createdAt.toISOString(),
});

const getProjectBoundary = async (db: ProjectReadDb, projectId: string) => {
	const result = await db
		.select({
			latitude: boundaryPoints.latitude,
			longitude: boundaryPoints.longitude,
			sortOrder: boundaryPoints.sortOrder,
		})
		.from(boundaryPoints)
		.where(eq(boundaryPoints.projectId, projectId))
		.orderBy(asc(boundaryPoints.sortOrder))
		.all();

	return serializeProjectBoundary(result);
};

const hasPendingZoneScanArchives = async (
	db: ProjectReadDb,
	projectId: string,
) => {
	const pendingArchive = await db
		.select({ id: zoneScanArchives.id })
		.from(zoneScanArchives)
		.innerJoin(zones, eq(zoneScanArchives.zoneId, zones.id))
		.where(
			and(
				eq(zones.projectId, projectId),
				eq(zoneScanArchives.uploadStatus, "pending"),
			),
		)
		.limit(1)
		.get();

	return Boolean(pendingArchive);
};

const StoredProjectBoundarySchema = z.array(BoundaryPointSchema);

const ProjectWithBoundarySchema = ProjectSchema.extend({
	boundary: StoredProjectBoundarySchema,
});

const CreatedProjectWithBoundarySchema = ProjectSchema.extend({
	boundary: ProjectBoundarySchema,
});

const buildGeneratedZonesOrResponse = ({
	boundary,
	c,
	initialLat,
	initialLong,
	projectId,
	zoneSize,
}: {
	boundary: Parameters<typeof buildGeneratedZoneInsertValues>[0]["boundary"];
	c: Context<WorkerAppEnv>;
	initialLat: number;
	initialLong: number;
	projectId: string;
	zoneSize: number;
}): { ok: true; zones: GeneratedZones } | { ok: false; response: Response } => {
	try {
		return {
			ok: true,
			zones: buildGeneratedZoneInsertValues({
				boundary,
				initialLat,
				initialLong,
				projectId,
				scannedAt: new Date(),
				zoneSize,
			}),
		};
	} catch (error) {
		if (error instanceof ZoneGenerationLimitError) {
			return {
				ok: false,
				response: c.json({ error: error.message }, 400),
			};
		}

		throw error;
	}
};

/* =========================
   GET ALL PROJECTS
========================= */
const getProjectsRoute = createRoute({
	method: "get",
	path: "/organizations/{orgId}/projects",
	operationId: "listProjects",
	tags: ["Projects"],
	description:
		"List projects for an organization the authenticated caller belongs to.",
	request: {
		params: z.object({
			orgId: z.string(),
		}),
	},
	responses: {
		200: {
			description: "List of projects",
			content: {
				"application/json": {
					schema: z.array(ProjectSchema),
				},
			},
		},
		401: unauthorizedErrorResponse,
		403: organizationMembershipForbiddenErrorResponse,
	},
});

projectsRoutes.openapi(getProjectsRoute, async (c) => {
	const { orgId } = c.req.valid("param");
	const access = await resolveRouteAccess(c.env, c.req.raw.headers, orgId, {
		project: ["view"],
	});

	if (!access.ok) return respondToRouteAccessError(c, access);

	const db = getDb(c.env);

	const result = await db
		.select()
		.from(projects)
		.where(eq(projects.organizationId, orgId))
		.all();

	return c.json(result.map(serializeProject), 200);
});

/* =========================
   GET SINGLE PROJECT
========================= */
const getProjectRoute = createRoute({
	method: "get",
	path: "/organizations/{orgId}/projects/{projectId}",
	operationId: "getProject",
	tags: ["Projects"],
	description:
		"Fetch a project within an organization the authenticated caller belongs to.",
	request: {
		params: z.object({
			orgId: z.string(),
			projectId: z.string(),
		}),
	},
	responses: {
		200: {
			description: "Single project",
			content: {
				"application/json": {
					schema: ProjectWithBoundarySchema,
				},
			},
		},
		401: unauthorizedErrorResponse,
		403: organizationMembershipForbiddenErrorResponse,
		404: notFoundErrorResponse,
	},
});

projectsRoutes.openapi(getProjectRoute, async (c) => {
	const { orgId, projectId } = c.req.valid("param");
	const access = await resolveRouteAccess(c.env, c.req.raw.headers, orgId, {
		project: ["view"],
	});

	if (!access.ok) return respondToRouteAccessError(c, access);

	const db = getDb(c.env);

	const result = await db
		.select()
		.from(projects)
		.where(and(eq(projects.id, projectId), eq(projects.organizationId, orgId)))
		.get();

	if (!result) return c.json({ error: "Not found" as const }, 404);

	return c.json(
		{
			...serializeProject(result),
			boundary: await getProjectBoundary(db, result.id),
		},
		200,
	);
});

/* =========================
   CREATE PROJECT
========================= */
const createProjectRoute = createRoute({
	method: "post",
	path: "/organizations/{orgId}/projects",
	operationId: "createProject",
	tags: ["Projects"],
	description:
		"Create a project in an organization the authenticated caller belongs to.",
	request: {
		params: z.object({
			orgId: z.string(),
		}),
		body: {
			content: {
				"application/json": {
					schema: CreateProjectBodySchema.extend({
						boundary: ProjectBoundarySchema,
					}),
				},
			},
		},
	},
	responses: {
		201: {
			description: "Project created",
			content: {
				"application/json": {
					schema: CreatedProjectWithBoundarySchema,
				},
			},
		},
		400: { description: "Invalid input" },
		401: unauthorizedErrorResponse,
		403: organizationMembershipForbiddenErrorResponse,
	},
});

projectsRoutes.openapi(createProjectRoute, async (c) => {
	const { orgId } = c.req.valid("param");
	const body = c.req.valid("json");
	const access = await resolveRouteAccess(c.env, c.req.raw.headers, orgId, {
		project: ["create"],
	});

	if (!access.ok) return respondToRouteAccessError(c, access);

	const db = getDb(c.env);
	const projectId = crypto.randomUUID();
	const initialLat =
		body.initialLat ?? Math.min(...body.boundary.map((p) => p.latitude));
	const initialLong =
		body.initialLong ?? Math.min(...body.boundary.map((p) => p.longitude));
	const generatedZones = buildGeneratedZonesOrResponse({
		boundary: body.boundary,
		c,
		initialLat,
		initialLong,
		projectId,
		zoneSize: body.zoneSize,
	});

	if (!generatedZones.ok) return generatedZones.response;

	await db.batch([
		db.insert(projects).values({
			id: projectId,
			organizationId: orgId,
			name: body.name,
			description: body.description,
			initialLat,
			initialLong,
			zoneSize: body.zoneSize,
		}),
		db.insert(boundaryPoints).values(
			buildBoundaryPointInsertValues({
				boundary: body.boundary,
				projectId,
			}),
		),
		...chunkZoneInsertValues(generatedZones.zones).map((chunk) =>
			db.insert(zones).values(chunk),
		),
	]);

	const result = await db
		.select()
		.from(projects)
		.where(and(eq(projects.id, projectId), eq(projects.organizationId, orgId)))
		.get();

	if (!result) {
		throw new Error("Created project could not be reloaded after insert.");
	}

	return c.json(
		{
			...serializeProject(result),
			boundary: body.boundary,
		},
		201,
	);
});

/* =========================
   UPDATE PROJECT
========================= */
const updateProjectRoute = createRoute({
	method: "patch",
	path: "/organizations/{orgId}/projects/{projectId}",
	operationId: "updateProject",
	tags: ["Projects"],
	description:
		"Update a project in an organization the authenticated caller belongs to.",
	request: {
		params: z.object({
			orgId: z.string(),
			projectId: z.string(),
		}),
		body: {
			content: {
				"application/json": {
					schema: UpdateProjectBodySchema,
				},
			},
		},
	},
	responses: {
		200: {
			description: "Project updated",
			content: {
				"application/json": {
					schema: ProjectSchema,
				},
			},
		},
		400: { description: "Invalid input" },
		401: unauthorizedErrorResponse,
		403: organizationMembershipForbiddenErrorResponse,
		404: notFoundErrorResponse,
		409: {
			description: "Project grid cannot change while scan uploads are pending",
			content: {
				"application/json": {
					schema: z.object({
						error: z.literal(
							"Project grid cannot change while scan uploads are pending",
						),
					}),
				},
			},
		},
	},
});

projectsRoutes.openapi(updateProjectRoute, async (c) => {
	const { orgId, projectId } = c.req.valid("param");
	const body = c.req.valid("json");
	const access = await resolveRouteAccess(c.env, c.req.raw.headers, orgId, {
		project: ["update"],
	});

	if (!access.ok) return respondToRouteAccessError(c, access);

	const db = getDb(c.env);

	const existingProject = await db
		.select()
		.from(projects)
		.where(and(eq(projects.id, projectId), eq(projects.organizationId, orgId)))
		.get();

	if (!existingProject) return c.json({ error: "Not found" as const }, 404);

	const gridChanged =
		body.zoneSize !== undefined ||
		body.initialLat !== undefined ||
		body.initialLong !== undefined;
	const nextProject = {
		...existingProject,
		...(body.initialLat !== undefined && { initialLat: body.initialLat }),
		...(body.initialLong !== undefined && {
			initialLong: body.initialLong,
		}),
		...(body.zoneSize !== undefined && { zoneSize: body.zoneSize }),
	};
	let generatedZones: GeneratedZones = [];

	if (gridChanged) {
		await reconcilePendingZoneScanArchives(c.env, db, projectId);

		if (await hasPendingZoneScanArchives(db, projectId)) {
			return c.json(
				{
					error:
						"Project grid cannot change while scan uploads are pending" as const,
				},
				409,
			);
		}

		const generatedZonesResult = buildGeneratedZonesOrResponse({
			boundary: await getProjectBoundary(db, projectId),
			c,
			initialLat: nextProject.initialLat,
			initialLong: nextProject.initialLong,
			projectId,
			zoneSize: nextProject.zoneSize,
		});

		if (!generatedZonesResult.ok) return generatedZonesResult.response;

		generatedZones = generatedZonesResult.zones;
	}

	await db.batch([
		db
			.update(projects)
			.set({
				...(body.name && { name: body.name }),
				...(body.description !== undefined && {
					description: body.description,
				}),
				...(body.initialLat !== undefined && { initialLat: body.initialLat }),
				...(body.initialLong !== undefined && {
					initialLong: body.initialLong,
				}),
				...(body.zoneSize !== undefined && { zoneSize: body.zoneSize }),
			})
			.where(
				and(eq(projects.id, projectId), eq(projects.organizationId, orgId)),
			),
		...(gridChanged
			? [
					db.delete(zones).where(eq(zones.projectId, projectId)),
					...chunkZoneInsertValues(generatedZones).map((chunk) =>
						db.insert(zones).values(chunk),
					),
				]
			: []),
	]);

	const result = await db
		.select()
		.from(projects)
		.where(and(eq(projects.id, projectId), eq(projects.organizationId, orgId)))
		.get();

	if (!result) return c.json({ error: "Not found" as const }, 404);

	return c.json(serializeProject(result), 200);
});

/* =========================
   DELETE PROJECT
========================= */
const deleteProjectRoute = createRoute({
	method: "delete",
	path: "/organizations/{orgId}/projects/{projectId}",
	operationId: "deleteProject",
	tags: ["Projects"],
	description:
		"Delete a project in an organization the authenticated caller belongs to.",
	request: {
		params: z.object({
			orgId: z.string(),
			projectId: z.string(),
		}),
	},
	responses: {
		200: {
			description: "Project deleted",
			content: {
				"application/json": {
					schema: z.object({
						success: z.boolean(),
					}),
				},
			},
		},
		401: unauthorizedErrorResponse,
		403: organizationMembershipForbiddenErrorResponse,
		404: notFoundErrorResponse,
	},
});

projectsRoutes.openapi(deleteProjectRoute, async (c) => {
	const { orgId, projectId } = c.req.valid("param");
	const access = await resolveRouteAccess(c.env, c.req.raw.headers, orgId, {
		project: ["delete"],
	});

	if (!access.ok) return respondToRouteAccessError(c, access);

	const db = getDb(c.env);

	const deleted = await db
		.delete(projects)
		.where(and(eq(projects.id, projectId), eq(projects.organizationId, orgId)))
		.returning()
		.get();

	if (!deleted) return c.json({ error: "Not found" as const }, 404);

	return c.json({ success: true }, 200);
});

export { projectsRoutes };
