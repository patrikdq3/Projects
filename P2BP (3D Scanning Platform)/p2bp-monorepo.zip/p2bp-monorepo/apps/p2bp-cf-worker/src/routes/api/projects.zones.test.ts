import { describe, expect, it } from "bun:test";
import {
	buildGeneratedZoneGridCells,
	buildZoneCorners,
	ZoneGenerationLimitError,
	zoneGenerationConstraints,
} from "../../lib/zones/grid";
import {
	buildGeneratedZoneInsertValues,
	chunkZoneInsertValues,
} from "./projects.zones";

describe("buildGeneratedZoneInsertValues", () => {
	it("includes zones that partially intersect the boundary", () => {
		const zones = buildGeneratedZoneInsertValues({
			boundary: [
				{ latitude: 0, longitude: 0 },
				{ latitude: 0, longitude: 0.00013 },
				{ latitude: 0.00013, longitude: 0 },
			],
			initialLat: 0,
			initialLong: 0,
			projectId: "project-123",
			scannedAt: new Date("2026-01-01T00:00:00.000Z"),
			zoneSize: 10,
		});

		expect(zones.map(({ x, y }) => ({ x, y }))).toContainEqual({
			x: 1,
			y: 0,
		});
		expect(zones.map(({ x, y }) => ({ x, y }))).toContainEqual({
			x: 0,
			y: 1,
		});
	});

	it("builds grid cells without database insert fields", () => {
		const gridCells = buildGeneratedZoneGridCells({
			boundary: [
				{ latitude: 0, longitude: 0 },
				{ latitude: 0, longitude: 0.00013 },
				{ latitude: 0.00013, longitude: 0 },
			],
			initialLat: 0,
			initialLong: 0,
			zoneSize: 10,
		});

		expect(gridCells).toContainEqual({ x: 0, y: 0 });
		expect(gridCells[0]).not.toContainKey("id");
		expect(gridCells[0]).not.toContainKey("projectId");
	});

	it("generates negative grid indices for boundaries before the origin", () => {
		const zones = buildGeneratedZoneInsertValues({
			boundary: [
				{ latitude: -0.0001, longitude: -0.0001 },
				{ latitude: -0.0001, longitude: -0.00001 },
				{ latitude: -0.00001, longitude: -0.0001 },
			],
			initialLat: 0,
			initialLong: 0,
			projectId: "project-123",
			scannedAt: new Date("2026-01-01T00:00:00.000Z"),
			zoneSize: 10,
		});

		expect(zones.some(({ x, y }) => x < 0 && y < 0)).toBe(true);
	});

	it("ignores tiny sliver overlaps near grid boundaries", () => {
		const initialLat = 28.38054532981038;
		const initialLong = -81.35549241959954;
		const zones = buildGeneratedZoneInsertValues({
			boundary: [
				{ latitude: initialLat, longitude: initialLong },
				{ latitude: 28.38065801199665, longitude: -81.3554890667898 },
				{ latitude: 28.380655062098832, longitude: -81.35534757999342 },
				{ latitude: 28.380641493037547, longitude: -81.35534758001917 },
				{ latitude: 28.380638543193964, longitude: -81.35531137013366 },
				{ latitude: 28.380541789896647, longitude: -81.35531271145216 },
			],
			initialLat,
			initialLong,
			projectId: "project-123",
			scannedAt: new Date("2026-01-01T00:00:00.000Z"),
			zoneSize: 9,
		});

		expect(zones.map(({ x, y }) => ({ x, y }))).toEqual([
			{ x: 0, y: 0 },
			{ x: 0, y: 1 },
			{ x: 1, y: 0 },
			{ x: 1, y: 1 },
		]);
	});

	it("includes the best overlapping zone for a tiny boundary inside a large zone", () => {
		const zones = buildGeneratedZoneInsertValues({
			boundary: [
				{ latitude: 0.00001, longitude: 0.00001 },
				{ latitude: 0.00001, longitude: 0.00002 },
				{ latitude: 0.00002, longitude: 0.00001 },
			],
			initialLat: 0,
			initialLong: 0,
			projectId: "project-123",
			scannedAt: new Date("2026-01-01T00:00:00.000Z"),
			zoneSize: 1000,
		});

		expect(zones.map(({ x, y }) => ({ x, y }))).toEqual([{ x: 0, y: 0 }]);
	});

	it("rejects boundaries that would scan too many candidate zones", () => {
		expect(() =>
			buildGeneratedZoneInsertValues({
				boundary: [
					{ latitude: 0, longitude: 0 },
					{ latitude: 0, longitude: 1 },
					{ latitude: 1, longitude: 1 },
					{ latitude: 1, longitude: 0 },
				],
				initialLat: 0,
				initialLong: 0,
				projectId: "project-123",
				scannedAt: new Date("2026-01-01T00:00:00.000Z"),
				zoneSize: 1,
			}),
		).toThrow(ZoneGenerationLimitError);
	});

	it("builds lat/lon corners for a zone square", () => {
		const corners = buildZoneCorners({
			initialLat: 0,
			initialLong: 0,
			x: 0,
			y: 0,
			zoneSize: 10,
		});

		expect(corners).toHaveLength(4);
		expect(corners[0]).toEqual({ latitude: 0, longitude: 0 });
		expect(corners[2].latitude).toBeCloseTo(10 / 111_320);
		expect(corners[2].longitude).toBeCloseTo(10 / 111_320);
	});

	it("chunks zone inserts below D1 SQL variable limits", () => {
		const values = Array.from(
			{ length: zoneGenerationConstraints.insertChunkSize + 1 },
			(_, index) => ({
				id: String(index),
			}),
		);

		expect(chunkZoneInsertValues(values)).toEqual([
			values.slice(0, zoneGenerationConstraints.insertChunkSize),
			values.slice(zoneGenerationConstraints.insertChunkSize),
		]);
	});
});
