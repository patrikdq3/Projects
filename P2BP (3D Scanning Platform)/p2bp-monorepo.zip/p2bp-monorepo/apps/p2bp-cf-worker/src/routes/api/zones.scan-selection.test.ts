import { describe, expect, it } from "bun:test";
import type { getDb } from "../../db";
import type {
	ZoneRecord,
	ZoneScanArchiveRecord,
} from "./zones.scan-reconciliation";
import { selectZoneScanArchive } from "./zones.scan-selection";

const now = new Date("2026-06-14T09:00:00.000Z");
const uploadedAt = new Date("2026-06-13T12:00:00.000Z");
const expiresAt = new Date("2026-06-13T12:30:00.000Z");

const buildZone = (overrides: Partial<ZoneRecord> = {}): ZoneRecord =>
	({
		createdAt: now,
		duration: null,
		id: "zone-123",
		metadata: null,
		pointCount: null,
		projectId: "project-123",
		scannedAt: now,
		scanObjectKey:
			"organizations/org-123/projects/project-123/zones/zone-123/scans/upload-456.zip",
		scanUploadedAt: null,
		scanUploadExpiresAt: new Date("2026-06-14T09:30:00.000Z"),
		scanUploadStatus: "pending",
		x: 0,
		y: 0,
		...overrides,
	}) as ZoneRecord;

const buildArchive = (
	overrides: Partial<ZoneScanArchiveRecord> = {},
): ZoneScanArchiveRecord =>
	({
		createdAt: uploadedAt,
		id: "upload-123",
		objectKey:
			"organizations/org-123/projects/project-123/zones/zone-123/scans/upload-123.zip",
		uploadedAt,
		uploadExpiresAt: expiresAt,
		uploadStatus: "uploaded",
		zoneId: "zone-123",
		...overrides,
	}) as ZoneScanArchiveRecord;

const createFakeDb = ({ changes = 1 }: { changes?: number } = {}) => {
	const updates: Array<Record<string, unknown>> = [];

	const db = {
		update: () => ({
			set: (values: Record<string, unknown>) => ({
				where: () => ({
					run: async () => {
						updates.push(values);
						return { meta: { changes } };
					},
				}),
			}),
		}),
	} as unknown as ReturnType<typeof getDb>;

	return { db, updates };
};

describe("selectZoneScanArchive", () => {
	it("repoints the zone at an uploaded archive version", async () => {
		const { db, updates } = createFakeDb();
		const archive = buildArchive();

		const result = await selectZoneScanArchive(db, {
			archive,
			zone: buildZone(),
		});

		expect(result).toEqual({
			ok: true,
			zone: expect.objectContaining({
				id: "zone-123",
				scanObjectKey: archive.objectKey,
				scanUploadedAt: uploadedAt,
				scanUploadExpiresAt: expiresAt,
				scanUploadStatus: "uploaded",
			}),
		});
		expect(updates).toEqual([
			{
				scanObjectKey: archive.objectKey,
				scanUploadedAt: uploadedAt,
				scanUploadExpiresAt: expiresAt,
				scanUploadStatus: "uploaded",
			},
		]);
	});

	it("rejects a pending archive without touching the zone", async () => {
		const { db, updates } = createFakeDb();

		const result = await selectZoneScanArchive(db, {
			archive: buildArchive({ uploadStatus: "pending", uploadedAt: null }),
			zone: buildZone(),
		});

		expect(result).toEqual({ ok: false, reason: "archive-not-uploaded" });
		expect(updates).toEqual([]);
	});

	it("rejects an archive from a different zone without touching the zone", async () => {
		const { db, updates } = createFakeDb();

		const result = await selectZoneScanArchive(db, {
			archive: buildArchive({ zoneId: "zone-other" }),
			zone: buildZone(),
		});

		expect(result).toEqual({ ok: false, reason: "archive-zone-mismatch" });
		expect(updates).toEqual([]);
	});

	it("rejects an expired archive without touching the zone", async () => {
		const { db, updates } = createFakeDb();

		const result = await selectZoneScanArchive(db, {
			archive: buildArchive({ uploadStatus: "expired", uploadedAt: null }),
			zone: buildZone(),
		});

		expect(result).toEqual({ ok: false, reason: "archive-not-uploaded" });
		expect(updates).toEqual([]);
	});

	it("reports zone-not-found when the update matches no row", async () => {
		const { db } = createFakeDb({ changes: 0 });

		const result = await selectZoneScanArchive(db, {
			archive: buildArchive(),
			zone: buildZone(),
		});

		expect(result).toEqual({ ok: false, reason: "zone-not-found" });
	});
});
