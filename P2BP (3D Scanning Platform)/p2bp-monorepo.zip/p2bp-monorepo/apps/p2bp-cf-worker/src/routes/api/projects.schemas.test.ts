import { describe, expect, it } from "bun:test";
import {
	CreateProjectBodySchema,
	ProjectSchema,
	UpdateProjectBodySchema,
} from "./projects.schemas";

describe("project schemas", () => {
	it("accepts a null description for create and update payloads", () => {
		expect(
			CreateProjectBodySchema.safeParse({
				name: "North Plaza Survey",
				description: null,
				initialLat: 40.7128,
				initialLong: -74.006,
				zoneSize: 10,
			}).success,
		).toBe(true);

		expect(
			UpdateProjectBodySchema.safeParse({
				description: null,
			}).success,
		).toBe(true);
	});

	it("accepts a persisted null description in project responses", () => {
		expect(
			ProjectSchema.safeParse({
				id: "project-123",
				organizationId: "org-123",
				name: "North Plaza Survey",
				description: null,
				initialLat: 40.7128,
				initialLong: -74.006,
				zoneSize: 10,
				createdAt: "2026-05-24T00:00:00.000Z",
			}).success,
		).toBe(true);
	});

	it("accepts a create payload without initialLat and initialLong", () => {
		expect(
			CreateProjectBodySchema.safeParse({
				name: "North Plaza Survey",
				zoneSize: 10,
			}).success,
		).toBe(true);
	});

	it("rejects project grid origins at the poles", () => {
		for (const initialLat of [-90, 90]) {
			expect(
				CreateProjectBodySchema.safeParse({
					name: "Polar Survey",
					initialLat,
					initialLong: 0,
					zoneSize: 10,
				}).success,
			).toBe(false);

			expect(
				UpdateProjectBodySchema.safeParse({
					initialLat,
				}).success,
			).toBe(false);
		}
	});
});
