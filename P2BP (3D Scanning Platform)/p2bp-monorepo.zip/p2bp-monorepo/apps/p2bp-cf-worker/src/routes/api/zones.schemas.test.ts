import { describe, expect, it } from "bun:test";
import {
	UpdateZoneBodySchema,
	ZoneScanArchiveSchema,
	ZoneScanArchivesQuerySchema,
	ZoneScanUploadUrlResponseSchema,
} from "./zones.schemas";

describe("zone schemas", () => {
	it("rejects an empty update payload", () => {
		expect(UpdateZoneBodySchema.safeParse({}).success).toBe(false);
	});

	it("accepts an update payload with at least one field", () => {
		expect(
			UpdateZoneBodySchema.safeParse({
				pointCount: 12,
			}).success,
		).toBe(true);
	});

	it("rejects scannedAt values without an explicit timezone", () => {
		expect(
			UpdateZoneBodySchema.safeParse({
				scannedAt: "2026-06-14T09:00:00",
			}).success,
		).toBe(false);
	});

	it("accepts scannedAt values with an explicit timezone", () => {
		expect(
			UpdateZoneBodySchema.safeParse({
				scannedAt: "2026-06-14T09:00:00Z",
			}).success,
		).toBe(true);
		expect(
			UpdateZoneBodySchema.safeParse({
				scannedAt: "2026-06-14T09:00:00-04:00",
			}).success,
		).toBe(true);
	});

	it("accepts the zone scan upload URL response shape", () => {
		expect(
			ZoneScanUploadUrlResponseSchema.safeParse({
				expiresAt: "2026-06-14T09:30:00.000Z",
				objectKey:
					"organizations/org-123/projects/project-123/zones/zone-123/scans/upload-123.zip",
				requiredHeaders: {
					"Content-Type": "application/zip",
				},
				uploadUrl:
					"https://main-bucket.account-id.r2.cloudflarestorage.com/organizations/org-123/projects/project-123/zones/zone-123/scans/upload-123.zip?X-Amz-Algorithm=AWS4-HMAC-SHA256",
				previewExpiresAt: "2026-06-14T09:30:00.000Z",
				previewObjectKey:
					"organizations/org-123/projects/project-123/zones/zone-123/scans/upload-123.preview.bin",
				previewRequiredHeaders: {
					"Content-Type": "application/octet-stream",
				},
				previewUploadUrl:
					"https://main-bucket.account-id.r2.cloudflarestorage.com/organizations/org-123/projects/project-123/zones/zone-123/scans/upload-123.preview.bin?X-Amz-Algorithm=AWS4-HMAC-SHA256",
				zone: {
					id: "zone-123",
					projectId: "project-123",
					x: 0,
					y: 0,
					corners: [
						{ latitude: 0, longitude: 0 },
						{ latitude: 0, longitude: 1 },
						{ latitude: 1, longitude: 1 },
						{ latitude: 1, longitude: 0 },
					],
					scannedAt: "2026-06-14T09:00:00Z",
					duration: null,
					pointCount: null,
					scanObjectKey:
						"organizations/org-123/projects/project-123/zones/zone-123/scans/upload-123.zip",
					scanUploadStatus: "pending",
					scanUploadExpiresAt: "2026-06-14T09:30:00.000Z",
					scanUploadedAt: null,
					metadata: null,
					createdAt: "2026-06-14T09:00:00.000Z",
				},
			}).success,
		).toBe(true);
	});

	it("accepts the zone scan archive response shape", () => {
		expect(
			ZoneScanArchiveSchema.safeParse({
				createdAt: "2026-06-14T09:00:00.000Z",
				id: "upload-123",
				objectKey:
					"organizations/org-123/projects/project-123/zones/zone-123/scans/upload-123.zip",
				uploadedAt: "2026-06-14T09:05:00.000Z",
				uploadExpiresAt: "2026-06-14T09:30:00.000Z",
				uploadStatus: "uploaded",
				previewObjectKey:
					"organizations/org-123/projects/project-123/zones/zone-123/scans/upload-123.preview.bin",
				previewUploadStatus: "uploaded",
				previewUploadExpiresAt: "2026-06-14T09:30:00.000Z",
				previewUploadedAt: "2026-06-14T09:05:00.000Z",
				zoneId: "zone-123",
			}).success,
		).toBe(true);
	});

	it("defaults and bounds scan archive query parameters", () => {
		expect(ZoneScanArchivesQuerySchema.parse({})).toEqual({
			limit: 50,
			reconcileLimit: 5,
		});
		expect(
			ZoneScanArchivesQuerySchema.safeParse({
				limit: "100",
				reconcileLimit: "10",
			}).success,
		).toBe(true);
		expect(
			ZoneScanArchivesQuerySchema.safeParse({
				limit: "101",
				reconcileLimit: "11",
			}).success,
		).toBe(false);
	});

	it("rejects scan response object keys over the database limit", () => {
		const objectKey = "x".repeat(2049);

		expect(
			ZoneScanUploadUrlResponseSchema.safeParse({
				expiresAt: "2026-06-14T09:30:00.000Z",
				objectKey,
				requiredHeaders: {
					"Content-Type": "application/zip",
				},
				uploadUrl: "https://example.com/upload",
				previewExpiresAt: "2026-06-14T09:30:00.000Z",
				previewObjectKey: objectKey,
				previewRequiredHeaders: {
					"Content-Type": "application/octet-stream",
				},
				previewUploadUrl: "https://example.com/upload-preview",
				zone: {
					id: "zone-123",
					projectId: "project-123",
					x: 0,
					y: 0,
					corners: [
						{ latitude: 0, longitude: 0 },
						{ latitude: 0, longitude: 1 },
						{ latitude: 1, longitude: 1 },
						{ latitude: 1, longitude: 0 },
					],
					scannedAt: "2026-06-14T09:00:00Z",
					duration: null,
					pointCount: null,
					scanObjectKey: null,
					scanUploadStatus: null,
					scanUploadExpiresAt: null,
					scanUploadedAt: null,
					metadata: null,
					createdAt: "2026-06-14T09:00:00.000Z",
				},
			}).success,
		).toBe(false);

		expect(
			ZoneScanArchiveSchema.safeParse({
				createdAt: "2026-06-14T09:00:00.000Z",
				id: "upload-123",
				objectKey,
				uploadedAt: "2026-06-14T09:05:00.000Z",
				uploadExpiresAt: "2026-06-14T09:30:00.000Z",
				uploadStatus: "uploaded",
				previewObjectKey: null,
				previewUploadStatus: null,
				previewUploadExpiresAt: null,
				previewUploadedAt: null,
				zoneId: "zone-123",
			}).success,
		).toBe(false);
	});
});
