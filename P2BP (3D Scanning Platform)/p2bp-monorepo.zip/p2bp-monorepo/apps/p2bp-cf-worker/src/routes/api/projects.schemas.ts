import { z } from "@hono/zod-openapi";
import { LatitudeSchema, LongitudeSchema } from "../../lib/schemas/geo";

export const projectConstraints = {
	name: {
		minLength: 1,
		maxLength: 100,
	},
	description: {
		maxLength: 1000,
	},
	initialLat: {
		maxExclusive: 90,
		minExclusive: -90,
	},
	zoneSize: {
		min: 1,
	},
} as const;

export const ProjectNameSchema = z
	.string()
	.min(projectConstraints.name.minLength)
	.max(projectConstraints.name.maxLength);

export const ProjectNameInputSchema = z
	.string()
	.trim()
	.min(projectConstraints.name.minLength)
	.max(projectConstraints.name.maxLength);

export const ProjectDescriptionSchema = z
	.string()
	.max(projectConstraints.description.maxLength)
	.nullable();

export const OptionalProjectDescriptionSchema =
	ProjectDescriptionSchema.optional();

export const ProjectInitialLatSchema = LatitudeSchema.gt(
	projectConstraints.initialLat.minExclusive,
	{ message: "Must be greater than -90" },
).lt(projectConstraints.initialLat.maxExclusive, {
	message: "Must be less than 90",
});

export const ProjectInitialLongSchema = LongitudeSchema;

export const ProjectZoneSizeSchema = z
	.number()
	.int()
	.min(projectConstraints.zoneSize.min);

export const ProjectSchema = z
	.object({
		id: z.string(),
		organizationId: z.string(),
		name: ProjectNameSchema,
		description: ProjectDescriptionSchema,
		initialLat: ProjectInitialLatSchema,
		initialLong: ProjectInitialLongSchema,
		zoneSize: ProjectZoneSizeSchema,
		createdAt: z.string(),
	})
	.openapi("Project");

export const CreateProjectBodySchema = z
	.object({
		name: ProjectNameInputSchema,
		description: OptionalProjectDescriptionSchema,
		initialLat: ProjectInitialLatSchema.optional(),
		initialLong: ProjectInitialLongSchema.optional(),
		zoneSize: ProjectZoneSizeSchema,
	})
	.openapi("CreateProjectRequest");

export const UpdateProjectBodySchema = z
	.object({
		name: ProjectNameInputSchema.optional(),
		description: OptionalProjectDescriptionSchema,
		initialLat: ProjectInitialLatSchema.optional(),
		initialLong: ProjectInitialLongSchema.optional(),
		zoneSize: ProjectZoneSizeSchema.optional(),
	})
	.openapi("UpdateProjectRequest");
