import type { WorkerAppEnv } from "../../app-env";
import { appLogger } from "../../lib/logger";
import {
	type MeshJobStatusFile,
	meshJobStatusFileSchema,
} from "../../lib/mesh/job-contract";

const meshJobStatusFileMaxBytes = 16 * 1024;

export const readMeshJobStatusFile = async (
	env: WorkerAppEnv["Bindings"],
	{ expectedJobId, objectKey }: { expectedJobId: string; objectKey: string },
): Promise<MeshJobStatusFile | null> => {
	const object = await env.BUCKET.get(objectKey);
	if (!object) return null;

	if (object.size > meshJobStatusFileMaxBytes) {
		appLogger
			.withMetadata({
				maxBytes: meshJobStatusFileMaxBytes,
				objectKey,
				size: object.size,
			})
			.warn("Mesh job status file is too large");
		return null;
	}

	let parsed: unknown;
	try {
		parsed = await object.json();
	} catch (error) {
		appLogger
			.withError(error)
			.withMetadata({ objectKey })
			.warn("Mesh job status file could not be parsed as JSON");
		return null;
	}

	const result = meshJobStatusFileSchema.safeParse(parsed);
	if (!result.success) {
		appLogger
			.withMetadata({
				issues: result.error.issues.map((issue) => ({
					code: issue.code,
					message: issue.message,
					path: issue.path.join("."),
				})),
				objectKey,
			})
			.warn("Mesh job status file failed validation");
		return null;
	}

	if (result.data.jobId && result.data.jobId !== expectedJobId) {
		appLogger
			.withMetadata({
				expectedJobId,
				objectKey,
				statusJobId: result.data.jobId,
			})
			.warn("Mesh job status file jobId did not match the reconciled job");
		return null;
	}

	return result.data;
};
