import {
	type MeshJobOutputFilename,
	meshJobStatusFilename,
} from "../../lib/mesh/job-contract";

export {
	type MeshJobOutputFilename,
	meshJobOutputFilenames,
	optionalMeshJobOutputFilenames,
	requiredMeshJobOutputFilenames,
} from "../../lib/mesh/job-contract";

const buildMeshJobPrefix = ({
	orgId,
	projectId,
	jobId,
}: {
	orgId: string;
	projectId: string;
	jobId: string;
}) => `organizations/${orgId}/projects/${projectId}/mesh-jobs/${jobId}`;

export const buildMeshJobObjectKey = ({
	orgId,
	projectId,
	jobId,
	filename,
}: {
	orgId: string;
	projectId: string;
	jobId: string;
	filename: MeshJobOutputFilename;
}) => `${buildMeshJobPrefix({ orgId, projectId, jobId })}/${filename}`;

export const buildMeshJobStatusObjectKey = ({
	orgId,
	projectId,
	jobId,
}: {
	orgId: string;
	projectId: string;
	jobId: string;
}) =>
	`${buildMeshJobPrefix({ orgId, projectId, jobId })}/${meshJobStatusFilename}`;
