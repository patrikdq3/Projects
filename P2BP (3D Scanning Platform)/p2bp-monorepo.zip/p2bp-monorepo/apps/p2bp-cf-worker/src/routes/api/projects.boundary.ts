import { z } from "@hono/zod-openapi";
import type { InferSelectModel } from "drizzle-orm";
import type { boundaryPoints } from "../../db/schema/app.schema";
import { LatitudeSchema, LongitudeSchema } from "../../lib/schemas/geo";

export const BoundaryPointSchema = z
	.object({
		latitude: LatitudeSchema,
		longitude: LongitudeSchema,
	})
	.openapi("BoundaryPoint");

export const ProjectBoundarySchema = z
	.array(BoundaryPointSchema)
	.min(3)
	.max(16)
	.openapi("ProjectBoundary");

type BoundaryPointRecord = Pick<
	InferSelectModel<typeof boundaryPoints>,
	"latitude" | "longitude" | "sortOrder"
>;

export type ProjectBoundaryPoint = z.infer<typeof BoundaryPointSchema>;

export const buildBoundaryPointInsertValues = ({
	boundary,
	projectId,
}: {
	boundary: ProjectBoundaryPoint[];
	projectId: string;
}) =>
	boundary.map((point, sortOrder) => ({
		projectId,
		latitude: point.latitude,
		longitude: point.longitude,
		sortOrder,
	}));

export const serializeProjectBoundary = (boundary: BoundaryPointRecord[]) =>
	[...boundary]
		.sort((left, right) => left.sortOrder - right.sortOrder)
		.map(({ latitude, longitude }) => ({
			latitude,
			longitude,
		}));
