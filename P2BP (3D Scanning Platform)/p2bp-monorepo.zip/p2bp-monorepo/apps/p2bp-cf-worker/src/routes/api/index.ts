import { OpenAPIHono } from "@hono/zod-openapi";
import type { WorkerAppEnv } from "../../app-env";
import { authRoutes } from "./auth";
import { registerDocsRoutes } from "./docs";
import { meshJobRoutes } from "./mesh.jobs";
import { meshPointCloudRoutes } from "./mesh.point-cloud";
import { projectsRoutes } from "./projects";
import { rootRoutes } from "./root";
import { zonesRoutes } from "./zones";

const api = new OpenAPIHono<WorkerAppEnv>();

api.route("/", rootRoutes);
api.route("/auth", authRoutes);
api.route("/", meshJobRoutes);
api.route("/", meshPointCloudRoutes);
api.route("/", projectsRoutes);
api.route("/", zonesRoutes);
registerDocsRoutes(api);

export { api };
