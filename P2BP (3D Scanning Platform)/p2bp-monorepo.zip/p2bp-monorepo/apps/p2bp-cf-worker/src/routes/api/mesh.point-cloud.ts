import { createRoute, OpenAPIHono, z } from "@hono/zod-openapi";
import { and, eq } from "drizzle-orm";
import type { Context } from "hono";
import type { WorkerAppEnv } from "../../app-env";
import { meshJobs } from "../../db/schema/app.schema";
import { appLogger } from "../../lib/logger";
import { presignR2DownloadUrl } from "../../lib/r2/presign";
import { loadRouteProject } from "../../lib/route-project";
import {
	notFoundErrorResponse,
	organizationMembershipForbiddenErrorResponse,
	unauthorizedErrorResponse,
} from "../../lib/route-responses";
import {
	buildMeshJobObjectKey,
	type MeshJobOutputFilename,
	meshJobOutputFilenames,
} from "./mesh.jobs.keys";
import { resolveCurrentMeshGenerateJobCandidates } from "./mesh.jobs.reconciliation";

const meshPointCloudRoutes = new OpenAPIHono<WorkerAppEnv>();

// Legacy fixed (non-versioned) key written by the consumer before mesh jobs
// were versioned. Kept as a download fallback for projects whose last merge
// predates versioned job outputs. The filename matches the versioned output;
// only the prefix differs (no mesh-jobs/{jobId} segment).
export const buildLegacyMergedPointCloudObjectKey = ({
	orgId,
	projectId,
	filename,
}: {
	orgId: string;
	projectId: string;
	filename: MeshJobOutputFilename;
}) => `organizations/${orgId}/projects/${projectId}/${filename}`;

const MergedPointCloudDownloadUrlResponseSchema = z.object({
	objectKey: z.string(),
	downloadUrl: z.url(),
	expiresAt: z.iso.datetime(),
});

const pointCloudDownloadUrlErrorResponse = {
	description:
		"Presigned merged point cloud download URL could not be created.",
	content: {
		"application/json": {
			schema: z.object({
				error: z.literal(
					"Merged point cloud download URL could not be created",
				),
			}),
		},
	},
} as const;

const routeParamsSchema = z.object({
	orgId: z.string(),
	projectId: z.string(),
});

const jobRouteParamsSchema = routeParamsSchema.extend({
	jobId: z.string(),
});

const resolveMergedPointCloudDownloadUrl = async (
	c: Context<WorkerAppEnv>,
	objectKeys: string[],
) => {
	let objectKey: string | null = null;
	for (const candidate of objectKeys) {
		const exists = await c.env.BUCKET.head(candidate);
		if (exists) {
			objectKey = candidate;
			break;
		}
	}

	if (!objectKey) {
		return {
			ok: false as const,
			response: c.json({ error: "Not found" as const }, 404),
		};
	}

	try {
		const { downloadUrl, expiresAt } = await presignR2DownloadUrl(
			c.env,
			objectKey,
		);

		return {
			body: {
				objectKey,
				downloadUrl,
				expiresAt: expiresAt.toISOString(),
			},
			ok: true as const,
		};
	} catch (error) {
		appLogger
			.withError(error)
			.withMetadata({ objectKey })
			.error("Merged point cloud download URL could not be created");
		return {
			ok: false as const,
			response: c.json(
				{
					error:
						"Merged point cloud download URL could not be created" as const,
				},
				500,
			),
		};
	}
};

type PointCloudVariant = {
	pathSuffix: string;
	label: string;
	filename: MeshJobOutputFilename;
	projectOperationId: string;
	jobOperationId: string;
};

export const pointCloudVariants: PointCloudVariant[] = [
	{
		pathSuffix: "merged-point-cloud",
		label: "merged point cloud (`merged-point-cloud.laz`)",
		filename: meshJobOutputFilenames.pointCloud,
		projectOperationId: "getProjectMergedPointCloudDownloadURL",
		jobOperationId: "getJobMergedPointCloudDownloadURL",
	},
	{
		pathSuffix: "merged-point-cloud/e57",
		label: "merged point cloud E57 (`merged-point-cloud.e57`)",
		filename: meshJobOutputFilenames.pointCloudE57,
		projectOperationId: "getProjectMergedPointCloudE57DownloadURL",
		jobOperationId: "getJobMergedPointCloudE57DownloadURL",
	},
	{
		pathSuffix: "merged-point-cloud/preview",
		label: "merged point cloud preview (`merged-point-cloud.preview.laz`)",
		filename: meshJobOutputFilenames.pointCloudPreview,
		projectOperationId: "getProjectMergedPointCloudPreviewDownloadURL",
		jobOperationId: "getJobMergedPointCloudPreviewDownloadURL",
	},
	{
		pathSuffix: "merged-point-cloud/preview/e57",
		label: "merged point cloud preview E57 (`merged-point-cloud.preview.e57`)",
		filename: meshJobOutputFilenames.pointCloudPreviewE57,
		projectOperationId: "getProjectMergedPointCloudPreviewE57DownloadURL",
		jobOperationId: "getJobMergedPointCloudPreviewE57DownloadURL",
	},
	{
		pathSuffix: "merged-point-cloud/viewer-metadata",
		label:
			"merged point cloud viewer metadata (`merged-point-cloud.viewer.json`)",
		filename: meshJobOutputFilenames.viewerMetadata,
		projectOperationId: "getProjectMergedPointCloudViewerMetadataDownloadURL",
		jobOperationId: "getJobMergedPointCloudViewerMetadataDownloadURL",
	},
];

const pointCloudDownloadUrlResponses = {
	200: {
		description: "Presigned download URL created",
		content: {
			"application/json": {
				schema: MergedPointCloudDownloadUrlResponseSchema,
			},
		},
	},
	401: unauthorizedErrorResponse,
	403: organizationMembershipForbiddenErrorResponse,
	404: notFoundErrorResponse,
	500: pointCloudDownloadUrlErrorResponse,
} as const;

const createProjectPointCloudDownloadUrlRoute = ({
	description,
	operationId,
	path,
}: {
	description: string;
	operationId: string;
	path: string;
}) =>
	createRoute({
		method: "get",
		path,
		operationId,
		tags: ["Point Clouds"],
		description,
		request: {
			params: routeParamsSchema,
		},
		responses: pointCloudDownloadUrlResponses,
	});

const createJobPointCloudDownloadUrlRoute = ({
	description,
	operationId,
	path,
}: {
	description: string;
	operationId: string;
	path: string;
}) =>
	createRoute({
		method: "get",
		path,
		operationId,
		tags: ["Point Clouds"],
		description,
		request: {
			params: jobRouteParamsSchema,
		},
		responses: pointCloudDownloadUrlResponses,
	});

// Project-level download URLs resolve to the completed mesh job matching the
// currently selected zone scans (so selecting a different scan version flips
// the project's point cloud without re-running the merge), falling back to
// the newest completed job and then to the legacy fixed key for projects
// whose last merge predates versioned outputs.
for (const variant of pointCloudVariants) {
	const route = createProjectPointCloudDownloadUrlRoute({
		operationId: variant.projectOperationId,
		path: `/organizations/{orgId}/projects/{projectId}/${variant.pathSuffix}/download-url`,
		description: `Create a short-lived direct-from-R2 download URL for a project's ${variant.label}, produced by the completed mesh job matching the currently selected zone scans (falling back to the newest completed mesh job, then the legacy non-versioned object). Returns 404 until a mesh job has produced it.`,
	});

	meshPointCloudRoutes.openapi(route, async (c) => {
		const { orgId, projectId } = c.req.valid("param");
		const routeProject = await loadRouteProject({
			c,
			orgId,
			permission: { project: ["view"] },
			projectId,
		});

		if (!routeProject.ok) return routeProject.response;

		const candidateJobs = await resolveCurrentMeshGenerateJobCandidates(
			c.env,
			routeProject.db,
			{ orgId, projectId },
		);

		// This is a read snapshot: a newer completed job can land before the R2
		// head checks below, and the next request will pick it up.
		// Preserve this fallback order: first the job matching the selected scans,
		// then the newest completed job, then legacy pre-versioning outputs.
		const candidateKeys = [
			...candidateJobs.map((job) =>
				buildMeshJobObjectKey({
					orgId,
					projectId,
					jobId: job.id,
					filename: variant.filename,
				}),
			),
			buildLegacyMergedPointCloudObjectKey({
				orgId,
				projectId,
				filename: variant.filename,
			}),
		];

		const result = await resolveMergedPointCloudDownloadUrl(c, candidateKeys);

		if (!result.ok) return result.response;

		return c.json(result.body, 200);
	});
}

// Job-scoped download URLs for a specific mesh job's outputs.
for (const variant of pointCloudVariants) {
	const route = createJobPointCloudDownloadUrlRoute({
		operationId: variant.jobOperationId,
		path: `/organizations/{orgId}/projects/{projectId}/mesh-jobs/{jobId}/${variant.pathSuffix}/download-url`,
		description: `Create a short-lived direct-from-R2 download URL for a specific mesh job's ${variant.label}. Returns 404 until the mesh job consumer has written the object.`,
	});

	meshPointCloudRoutes.openapi(route, async (c) => {
		const { orgId, projectId, jobId } = c.req.valid("param");
		const routeProject = await loadRouteProject({
			c,
			orgId,
			permission: { project: ["view"] },
			projectId,
		});

		if (!routeProject.ok) return routeProject.response;

		const job = await routeProject.db
			.select({ id: meshJobs.id })
			.from(meshJobs)
			.where(and(eq(meshJobs.id, jobId), eq(meshJobs.projectId, projectId)))
			.get();

		if (!job) return c.json({ error: "Not found" as const }, 404);

		const result = await resolveMergedPointCloudDownloadUrl(c, [
			buildMeshJobObjectKey({
				orgId,
				projectId,
				jobId: job.id,
				filename: variant.filename,
			}),
		]);

		if (!result.ok) return result.response;

		return c.json(result.body, 200);
	});
}

export { meshPointCloudRoutes };
