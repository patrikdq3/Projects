import { describe, expect, it } from "bun:test";
import {
	zoneScanPreviewUploadRequiredHeaders,
	zoneScanUploadRequiredHeaders,
} from "./zones.scan-upload-contract";
import {
	buildVersionedZoneScanObjectKey,
	buildVersionedZoneScanPreviewObjectKey,
	isUploadedZoneScanObjectValid,
	isUploadedZoneScanPreviewObjectValid,
} from "./zones.scan-uploads";

describe("zone scan uploads", () => {
	it("builds versioned zone scan object keys", () => {
		expect(
			buildVersionedZoneScanObjectKey({
				orgId: "org-123",
				projectId: "project-123",
				uploadId: "upload-123",
				zoneId: "zone-123",
			}),
		).toBe(
			"organizations/org-123/projects/project-123/zones/zone-123/scans/upload-123.zip",
		);
	});

	it("builds versioned zone scan preview object keys", () => {
		expect(
			buildVersionedZoneScanPreviewObjectKey({
				orgId: "org-123",
				projectId: "project-123",
				uploadId: "upload-123",
				zoneId: "zone-123",
			}),
		).toBe(
			"organizations/org-123/projects/project-123/zones/zone-123/scans/upload-123.preview.bin",
		);
	});

	it("requires zip content type uploads", () => {
		expect(zoneScanUploadRequiredHeaders).toEqual({
			"Content-Type": "application/zip",
		});
	});

	it("requires octet-stream content type for preview uploads", () => {
		expect(zoneScanPreviewUploadRequiredHeaders).toEqual({
			"Content-Type": "application/octet-stream",
		});
	});

	it("validates uploaded preview object metadata by size only", () => {
		expect(isUploadedZoneScanPreviewObjectValid({ size: 1 } as R2Object)).toBe(
			true,
		);
		expect(isUploadedZoneScanPreviewObjectValid({ size: 0 } as R2Object)).toBe(
			false,
		);
	});

	it("validates uploaded scan object metadata", () => {
		expect(
			isUploadedZoneScanObjectValid({
				httpMetadata: {
					contentType: "application/zip",
				},
				size: 1,
			} as R2Object),
		).toBe(true);

		expect(
			isUploadedZoneScanObjectValid({
				httpMetadata: {
					contentType: "text/plain",
				},
				size: 1,
			} as R2Object),
		).toBe(false);

		expect(
			isUploadedZoneScanObjectValid({
				httpMetadata: {
					contentType: "application/zip",
				},
				size: 0,
			} as R2Object),
		).toBe(false);
	});
});
