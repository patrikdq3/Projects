import type { InferSelectModel, SQL } from "drizzle-orm";
import { and, desc, eq, inArray, isNull, ne, notInArray } from "drizzle-orm";
import type { WorkerAppEnv } from "../../app-env";
import type { getDb } from "../../db";
import { meshJobs } from "../../db/schema/app.schema";
import { readRowChanges } from "../../lib/db-changes";
import { appLogger } from "../../lib/logger";
import {
	type MeshJobStatusFile,
	meshJobConsumerRuntimeCapMs,
	meshJobDefinitions,
} from "../../lib/mesh/job-contract";
import {
	collectMeshGenerateZoneScanObjectKeys,
	computeMeshJobInputFingerprint,
} from "./mesh.jobs.builder";
import {
	buildMeshJobObjectKey,
	buildMeshJobStatusObjectKey,
	type MeshJobOutputFilename,
	meshJobOutputFilenames,
	requiredMeshJobOutputFilenames,
} from "./mesh.jobs.keys";
import { readMeshJobStatusFile } from "./mesh.jobs.status-file";

export type MeshJobRecord = InferSelectModel<typeof meshJobs>;
type MeshGenerateJobScope = {
	orgId: string;
	projectId: string;
	inputFingerprint?: string;
};

type MeshGenerateJobScopeWithFingerprint = Required<MeshGenerateJobScope>;

const hasInputFingerprint = (
	scope: MeshGenerateJobScope,
): scope is MeshGenerateJobScopeWithFingerprint =>
	typeof scope.inputFingerprint === "string";

// "In-flight" work: a job whose queue message should still be queued or
// running. Kept as one definition so status guards and predicates that
// distinguish active from terminal jobs stay in sync.
const meshJobInFlightStatuses: MeshJobRecord["status"][] = [
	"queued",
	"running",
];
export const isMeshJobInFlight = (status: MeshJobRecord["status"]): boolean =>
	meshJobInFlightStatuses.includes(status);
const isMeshJobReusable = (status: MeshJobRecord["status"]): boolean =>
	status === "completed" || isMeshJobInFlight(status);

// A job that has produced no status evidence after this long is considered
// lost. Derived as the consumer's single-run cap plus equal headroom for a
// queue redelivery to start and report, so it always stays above the cap and
// tracks it if it changes -- 24h at the current 12h cap.
export const meshJobTimeoutMs = 2 * meshJobConsumerRuntimeCapMs;

const millisecondsPerDay = 24 * 60 * 60 * 1000;
const cloudflareQueueMessageRetentionDays = 4;

// Stop re-reading status.json for terminal-failed jobs once queue redelivery
// can no longer resurrect them (Cloudflare Queues retains messages ~4 days).
export const meshJobReconcileWindowMs =
	cloudflareQueueMessageRetentionDays * millisecondsPerDay;

// How many of the newest jobs the reuse/fallback resolvers reconcile in one
// pass. This is the "recency window": jobs outside it are only reachable via
// the single-row fallback queries, so it must stay large enough to cover the
// realistic burst of concurrent/retried jobs for one set of inputs.
const meshJobRecencyWindowSize = 10;

// How many additional completed jobs the reuse gate walks back through, once the
// recency window and the newest completed job have all been turned down. Each
// candidate costs a round of object HEADs, so this is deliberately small: it
// exists to find a still-usable older result, not to search exhaustively.
const maxGatedFallbackCompletedMeshJobs = 3;

const meshJobActiveInputUniqueIndexName = "mesh_jobs_active_input_unique";

// D1 surfaces SQLite unique violations with varying message shapes: partial
// indexes report the index name, plain indexes report the column list, and
// both may carry a D1_ERROR/SQLITE_CONSTRAINT_UNIQUE wrapper. Match only the
// active-input index identity; routing another integrity error into conflict
// handling would hide a real bug.
//
// drizzle-orm >= 0.44 wraps every driver error in a DrizzleQueryError whose
// own message is just "Failed query: <sql>" -- the D1/SQLite text lives on
// the `cause` chain, so every Error in the (bounded) chain must be checked.
const meshJobActiveInputUniqueColumnList =
	/mesh_jobs\.project_id,\s*mesh_jobs\.type,\s*mesh_jobs\.input_fingerprint/i;

// Cap the `cause` walk so a malformed or self-referential chain can't loop
// forever; a couple of drizzle wrappers plus the driver error is only ~2-3
// deep, so 10 is generous headroom.
const meshJobErrorCauseWalkLimit = 10;

export const isMeshJobActiveInputConflict = (error: unknown): boolean => {
	let current: unknown = error;
	for (
		let depth = 0;
		depth < meshJobErrorCauseWalkLimit && current instanceof Error;
		depth += 1
	) {
		if (
			current.message.includes(meshJobActiveInputUniqueIndexName) ||
			meshJobActiveInputUniqueColumnList.test(current.message)
		) {
			return true;
		}
		current = current.cause;
	}
	return false;
};

const meshJobPublicErrorMaxLength = 500;
const defaultMeshJobFailedError = "Mesh job failed" as const;
const meshJobTimedOutError =
	"Mesh job timed out without reporting a result" as const;

const sanitizeMeshJobStatusError = (value: string | null | undefined) => {
	const normalized = value?.replace(/\s+/g, " ").trim();
	if (!normalized) return defaultMeshJobFailedError;

	const redacted = normalized
		.replace(/\bhttps?:\/\/\S+/gi, "[url]")
		.replace(/\b[a-zA-Z]:\\[^\s)\]"']+/g, "[path]")
		.replace(
			/(^|[\s(["'])\/(?:Users|home|var|tmp|opt|mnt|app|workspace|srv|etc|root|Volumes)\/[^\s)\]"']+/g,
			"$1[path]",
		)
		.replace(/\borganizations\/[^\s)\]"']+/g, "[object-key]");

	if (redacted.length <= meshJobPublicErrorMaxLength) return redacted;
	return `${redacted.slice(0, meshJobPublicErrorMaxLength - 3)}...`;
};

const parseStatusFileDate = (value: string | null | undefined) => {
	if (!value) return null;
	const date = new Date(value);
	return Number.isNaN(date.getTime()) ? null : date;
};

const parseStatusFileDateCappedAt = (
	value: string | null | undefined,
	latest: Date,
) => {
	const date = parseStatusFileDate(value);
	if (!date) return null;
	return date.getTime() > latest.getTime() ? latest : date;
};

const requiredMeshJobOutputFilenameValues = Object.values(
	requiredMeshJobOutputFilenames,
) as MeshJobOutputFilename[];

const currentMeshJobOutputFilenameValues = Object.values(
	meshJobOutputFilenames,
) as MeshJobOutputFilename[];

const hasMeshJobOutputObjects = async (
	env: WorkerAppEnv["Bindings"],
	{
		jobId,
		orgId,
		projectId,
	}: { jobId: string; orgId: string; projectId: string },
	filenames: MeshJobOutputFilename[],
) => {
	const outputObjects = await Promise.all(
		filenames.map((filename) =>
			env.BUCKET.head(
				buildMeshJobObjectKey({
					filename,
					jobId,
					orgId,
					projectId,
				}),
			),
		),
	);

	return outputObjects.every((object) => object !== null);
};

// Whether a job that reports completion actually produced the outputs a
// completed job must have. Deliberately the *required* set only: a job is
// "completed" because its merge ran to the end, and optional outputs added
// later must not retroactively un-complete it.
const hasCompletedMeshJobArtifacts = (
	env: WorkerAppEnv["Bindings"],
	scope: { jobId: string; orgId: string; projectId: string },
) => hasMeshJobOutputObjects(env, scope, requiredMeshJobOutputFilenameValues);

// Whether a completed job's outputs are still everything the current pipeline
// publishes, including the optional ones. This is the *reuse* bar rather than
// the completion bar: an older merge that predates an output (E57, viewer
// metadata) stays completed and downloadable, but reusing it would leave that
// output permanently 404 for the project, since the inputs hash the same and
// nothing would ever re-run the merge.
const hasCurrentMeshJobOutputs = (
	env: WorkerAppEnv["Bindings"],
	scope: { jobId: string; orgId: string; projectId: string },
) => hasMeshJobOutputObjects(env, scope, currentMeshJobOutputFilenameValues);

// The timestamp the timeout deadline is measured from: when the run last
// started, or when it was created if it never reported a start.
const getMeshJobStartReference = (job: MeshJobRecord) =>
	job.startedAt ?? job.createdAt;

const meshJobStartedAtUnchanged = (job: MeshJobRecord) =>
	job.startedAt === null
		? isNull(meshJobs.startedAt)
		: eq(meshJobs.startedAt, job.startedAt);

export const shouldReconcileMeshJob = (
	job: MeshJobRecord,
	now: Date = new Date(),
) => {
	if (job.status === "completed") return false;
	if (job.status === "failed") {
		return now.getTime() - job.createdAt.getTime() < meshJobReconcileWindowMs;
	}
	return true;
};

// Allowed mesh job status transitions (the lifecycle enforced here). Changing
// this table means updating every place that encodes it:
//   - this function's status guards (below), and the meshJobInFlightStatuses
//     set the `failed` guard builds on;
//   - the reconcileMeshJob branch order and its timeout logic;
//   - shouldReconcileMeshJob, which decides which statuses still reconcile;
//   - the SQL mesh_jobs_state_check row invariant and the
//     mesh_jobs_active_input_unique duplicate-work guard.
//
//   queued    -> running | completed | failed
//   running   -> completed | failed
//   failed    -> running | completed
//                (`running` only from later queue redelivery; `completed` from
//                 terminal status/artifact recovery)
//   completed -> (terminal; never transitions out)
//
// `failed` is not fully terminal: a redelivery whose start postdates the
// recorded completion may resurrect it to `running`, and terminal evidence may
// recover it to `completed`. `completed` is final.
const applyMeshJobTransition = async (
	db: ReturnType<typeof getDb>,
	job: MeshJobRecord,
	patch: Pick<MeshJobRecord, "status" | "startedAt" | "completedAt" | "error">,
	// Extra optimistic guard ANDed onto the status guard, evaluated against the
	// live row. Used to make a decision derived from the stale `job` snapshot
	// (e.g. "this run has timed out") re-check that the row has not moved on.
	extraGuard?: SQL,
) => {
	// Optimistic-concurrency guards mirroring the zone scan archive pattern:
	// `completed` overwrites any non-completed state, `failed` only replaces an
	// in-flight state (never a concurrent success), and `running` only moves a
	// job forward from queued or resurrects a failed one being redelivered.
	const guard =
		patch.status === "completed"
			? ne(meshJobs.status, "completed")
			: patch.status === "failed"
				? inArray(meshJobs.status, meshJobInFlightStatuses)
				: inArray(meshJobs.status, ["queued", "failed"]);

	let changes = 0;
	try {
		const result = await db
			.update(meshJobs)
			.set(patch)
			.where(and(eq(meshJobs.id, job.id), guard, extraGuard))
			.run();
		changes = readRowChanges(result);
	} catch (error) {
		// Resurrecting a failed job to `running` re-enters the
		// mesh_jobs_active_input_unique domain and collides when a newer retry
		// job for the same inputs is already queued/running. The retry
		// supersedes the redelivered attempt, so treat the conflict like losing
		// the optimistic race (fall through to the re-select below) instead of
		// letting it 500 every read path that reconciles this job.
		if (!isMeshJobActiveInputConflict(error)) throw error;
		appLogger
			.withMetadata({ jobId: job.id, patchStatus: patch.status })
			.info(
				"Mesh job transition skipped: an active job for the same inputs exists",
			);
	}

	if (changes > 0) {
		return { ...job, ...patch };
	}

	const latest = await db
		.select()
		.from(meshJobs)
		.where(eq(meshJobs.id, job.id))
		.get();

	return latest ?? job;
};

const refreshRunningMeshJobStart = async (
	db: ReturnType<typeof getDb>,
	job: MeshJobRecord,
	startedAt: Date,
): Promise<MeshJobRecord> => {
	const patch = {
		startedAt,
		completedAt: null,
		error: null,
	};

	const result = await db
		.update(meshJobs)
		.set(patch)
		.where(
			and(
				eq(meshJobs.id, job.id),
				eq(meshJobs.status, "running"),
				meshJobStartedAtUnchanged(job),
			),
		)
		.run();

	if (readRowChanges(result) > 0) {
		return { ...job, ...patch };
	}

	const latest = await db
		.select()
		.from(meshJobs)
		.where(eq(meshJobs.id, job.id))
		.get();

	return latest ?? job;
};

const buildMeshJobTerminalTimestampPatch = (
	statusFile: MeshJobStatusFile,
	job: MeshJobRecord,
	now: Date,
) => ({
	startedAt:
		parseStatusFileDateCappedAt(statusFile.startedAt, now) ?? job.startedAt,
	completedAt: parseStatusFileDateCappedAt(statusFile.completedAt, now) ?? now,
});

/**
 * Bring a mesh job row up to date with the consumer-written status.json in
 * R2, timing out jobs that never produced one. Safe to call on any job; jobs
 * that no longer need reconciliation are returned unchanged.
 */
export const reconcileMeshJob = async (
	env: WorkerAppEnv["Bindings"],
	db: ReturnType<typeof getDb>,
	{ orgId }: { orgId: string },
	job: MeshJobRecord,
	now: Date = new Date(),
): Promise<MeshJobRecord> => {
	if (!shouldReconcileMeshJob(job, now)) return job;

	const statusFile = await readMeshJobStatusFile(env, {
		expectedJobId: job.id,
		objectKey: buildMeshJobStatusObjectKey({
			orgId,
			projectId: job.projectId,
			jobId: job.id,
		}),
	});

	if (statusFile?.state === "completed") {
		if (job.status === "completed") return job;
		return applyMeshJobTransition(db, job, {
			status: "completed",
			...buildMeshJobTerminalTimestampPatch(statusFile, job, now),
			error: null,
		});
	}

	if (
		(statusFile?.state === "failed" || statusFile?.state === "running") &&
		(await hasCompletedMeshJobArtifacts(env, {
			jobId: job.id,
			orgId,
			projectId: job.projectId,
		}))
	) {
		return applyMeshJobTransition(db, job, {
			status: "completed",
			...buildMeshJobTerminalTimestampPatch(statusFile, job, now),
			error: null,
		});
	}

	if (statusFile?.state === "failed") {
		if (job.status === "failed") return job;
		return applyMeshJobTransition(db, job, {
			status: "failed",
			...buildMeshJobTerminalTimestampPatch(statusFile, job, now),
			error: sanitizeMeshJobStatusError(statusFile.error),
		});
	}

	const statusStartedAt =
		statusFile?.state === "running"
			? parseStatusFileDateCappedAt(statusFile.startedAt, now)
			: null;
	const runningStatusIsLaterRedelivery =
		statusStartedAt &&
		(!job.completedAt || statusStartedAt.getTime() > job.completedAt.getTime());

	if (
		statusFile?.state === "running" &&
		job.status === "failed" &&
		runningStatusIsLaterRedelivery
	) {
		return applyMeshJobTransition(db, job, {
			status: "running",
			startedAt: statusStartedAt,
			completedAt: null,
			error: null,
		});
	}

	if (
		statusFile?.state === "running" &&
		job.status === "running" &&
		statusStartedAt &&
		statusStartedAt.getTime() > getMeshJobStartReference(job).getTime()
	) {
		return refreshRunningMeshJobStart(db, job, statusStartedAt);
	}

	// No terminal evidence. Give up on jobs past the overall deadline. Measure
	// it from the most recent known start: the DB start reference, or a fresher
	// start the consumer reported in status.json. A queue redelivery/restart
	// writes a fresh `startedAt` to status.json before the Worker copies it into
	// the row, so consulting it here keeps a genuinely-active run from being
	// failed when its fresh start exists only in status.json -- while still
	// failing jobs that are truly stuck past the deadline.
	const timeoutReference =
		statusStartedAt &&
		statusStartedAt.getTime() > getMeshJobStartReference(job).getTime()
			? statusStartedAt
			: getMeshJobStartReference(job);
	if (now.getTime() - timeoutReference.getTime() > meshJobTimeoutMs) {
		if (job.status === "failed") return job;
		// The one transition the Worker decides on its own (all others mirror the
		// consumer's status.json), and the API masks it as a generic failure --
		// log it so a timeout is distinguishable from a real consumer failure.
		appLogger
			.withMetadata({
				elapsedMs: now.getTime() - timeoutReference.getTime(),
				jobId: job.id,
				projectId: job.projectId,
				startReference: timeoutReference.toISOString(),
				status: job.status,
				timeoutMs: meshJobTimeoutMs,
			})
			.warn(meshJobTimedOutError);
		// The "timed out" decision came from this stale snapshot's start
		// reference. If a queue redelivery restarted the job since we read it,
		// the live row's `started_at` has advanced and this write must not fire
		// -- otherwise it fails a run that is legitimately in progress again.
		return applyMeshJobTransition(
			db,
			job,
			{
				status: "failed",
				startedAt: job.startedAt,
				completedAt: now,
				error: meshJobTimedOutError,
			},
			meshJobStartedAtUnchanged(job),
		);
	}

	if (statusFile?.state === "running" && job.status === "queued") {
		return applyMeshJobTransition(db, job, {
			status: "running",
			startedAt: statusStartedAt ?? now,
			completedAt: null,
			error: null,
		});
	}

	return job;
};

const meshGenerateJobFilters = ({
	inputFingerprint,
	projectId,
}: Pick<MeshGenerateJobScope, "inputFingerprint" | "projectId">) => [
	eq(meshJobs.projectId, projectId),
	eq(meshJobs.type, meshJobDefinitions.generate.type),
	...(inputFingerprint
		? [eq(meshJobs.inputFingerprint, inputFingerprint)]
		: []),
];

// Reconciles a single job; overridable so a caller running several resolves in
// one request can dedupe R2 reads by memoizing per job id (see
// resolveCurrentMeshGenerateJobCandidates).
type MeshJobReconciler = (job: MeshJobRecord) => Promise<MeshJobRecord>;

const resolveRecentMeshGenerateJobs = async (
	env: WorkerAppEnv["Bindings"],
	db: ReturnType<typeof getDb>,
	{ orgId, projectId, inputFingerprint }: MeshGenerateJobScope,
	now: Date,
	reconcileJob: MeshJobReconciler = (job) =>
		reconcileMeshJob(env, db, { orgId }, job, now),
) => {
	const recentJobs = await db
		.select()
		.from(meshJobs)
		.where(and(...meshGenerateJobFilters({ inputFingerprint, projectId })))
		.orderBy(desc(meshJobs.createdAt), desc(meshJobs.id))
		.limit(meshJobRecencyWindowSize)
		.all();

	return Promise.all(recentJobs.map((job) => reconcileJob(job)));
};

// Newest single job matching the scope and an extra status condition, beyond
// the recency window the resolvers reconcile in bulk.
const resolveFallbackMeshGenerateJob = (
	db: ReturnType<typeof getDb>,
	scope: Pick<MeshGenerateJobScope, "inputFingerprint" | "projectId">,
	conditions: SQL[],
) =>
	db
		.select()
		.from(meshJobs)
		.where(and(...meshGenerateJobFilters(scope), ...conditions))
		.orderBy(desc(meshJobs.createdAt), desc(meshJobs.id))
		.limit(1)
		.get();

// `excludedJobIds` are candidates an async gate has already rejected this
// request, so the newest completed row is not handed back a second time (which
// would re-run its object checks and stop the search at a job already known to
// be unusable).
const resolveFallbackCompletedMeshGenerateJob = (
	db: ReturnType<typeof getDb>,
	scope: Pick<MeshGenerateJobScope, "inputFingerprint" | "projectId">,
	excludedJobIds: ReadonlySet<string> = new Set(),
) =>
	resolveFallbackMeshGenerateJob(db, scope, [
		eq(meshJobs.status, "completed"),
		...(excludedJobIds.size
			? [notInArray(meshJobs.id, [...excludedJobIds])]
			: []),
	]);

const resolveFallbackInFlightMeshGenerateJob = (
	db: ReturnType<typeof getDb>,
	scope: Pick<MeshGenerateJobScope, "inputFingerprint" | "projectId">,
) =>
	resolveFallbackMeshGenerateJob(db, scope, [
		inArray(meshJobs.status, meshJobInFlightStatuses),
	]);

// Reconcile the newest fallback in-flight job (beyond the recency window) and
// return it only if it still matches `accept` afterwards. Shared by the
// reusable and active resolvers, which differ only in that predicate.
const resolveFallbackInFlightMatch = async (
	env: WorkerAppEnv["Bindings"],
	db: ReturnType<typeof getDb>,
	scope: MeshGenerateJobScopeWithFingerprint,
	now: Date,
	accept: (job: MeshJobRecord) => boolean,
): Promise<MeshJobRecord | null> => {
	const inFlight = await resolveFallbackInFlightMeshGenerateJob(db, scope);
	if (!inFlight) return null;

	const resolvedInFlight = await reconcileMeshJob(
		env,
		db,
		{ orgId: scope.orgId },
		inFlight,
		now,
	);
	return accept(resolvedInFlight) ? resolvedInFlight : null;
};

const resolveMeshGenerateJobByPolicy = async (
	env: WorkerAppEnv["Bindings"],
	db: ReturnType<typeof getDb>,
	scope: MeshGenerateJobScope,
	now: Date,
	{
		acceptFallbackInFlight,
		acceptRecent,
		acceptResolved,
		includeFallbackCompleted,
		reconcileJob,
	}: {
		acceptFallbackInFlight?: (job: MeshJobRecord) => boolean;
		acceptRecent: (job: MeshJobRecord) => boolean;
		// Async gate applied to whichever job the policy is about to return. A
		// rejected candidate is skipped rather than ending the search, so an
		// older job that still passes can be returned instead.
		acceptResolved?: (job: MeshJobRecord) => Promise<boolean>;
		includeFallbackCompleted: boolean;
		reconcileJob?: MeshJobReconciler;
	},
): Promise<MeshJobRecord | null> => {
	const resolved = await resolveRecentMeshGenerateJobs(
		env,
		db,
		scope,
		now,
		reconcileJob,
	);
	// Candidates the gate turned down, so the fallback search below neither
	// re-tests them nor stops on them.
	const rejectedJobIds = new Set<string>();
	for (const job of resolved) {
		if (!acceptRecent(job)) continue;
		if (acceptResolved && !(await acceptResolved(job))) {
			rejectedJobIds.add(job.id);
			continue;
		}
		return job;
	}

	if (includeFallbackCompleted) {
		// The recency window is capped, so the newest completed job can sit
		// outside it. Without a gate this is the single query it always was; with
		// one, keep walking back through older completed jobs (bounded) so a
		// usable older result is reused instead of re-running the whole merge.
		for (
			let attempt = 0;
			attempt <= maxGatedFallbackCompletedMeshJobs;
			attempt++
		) {
			const completed = await resolveFallbackCompletedMeshGenerateJob(
				db,
				scope,
				rejectedJobIds,
			);
			if (!completed) break;
			if (acceptResolved && !(await acceptResolved(completed))) {
				rejectedJobIds.add(completed.id);
				continue;
			}
			return completed;
		}
	}

	if (acceptFallbackInFlight && hasInputFingerprint(scope)) {
		return resolveFallbackInFlightMatch(
			env,
			db,
			scope,
			now,
			acceptFallbackInFlight,
		);
	}

	return null;
};

/**
 * Resolve the newest completed mesh.generate job for a project, reconciling
 * recent in-flight jobs first so a just-finished job is visible immediately.
 * When `inputFingerprint` is given, only jobs for those exact inputs count.
 */
export const resolveLatestCompletedMeshGenerateJob = async (
	env: WorkerAppEnv["Bindings"],
	db: ReturnType<typeof getDb>,
	scope: MeshGenerateJobScope,
	now: Date = new Date(),
	reconcileJob?: MeshJobReconciler,
): Promise<MeshJobRecord | null> => {
	return resolveMeshGenerateJobByPolicy(env, db, scope, now, {
		acceptRecent: (job) => job.status === "completed",
		includeFallbackCompleted: true,
		reconcileJob,
	});
};

/**
 * Resolve a mesh.generate job that should prevent duplicate work for identical
 * inputs: prefer completed outputs, then an in-flight job whose message should
 * already be queued or running.
 *
 * A completed job only counts when it still has every output the current
 * pipeline publishes. Identical inputs hash to the same fingerprint forever, so
 * reusing a merge that predates an output (E57, viewer metadata) would leave
 * that output 404 with no way to ever produce it short of `?force=true`;
 * declining to reuse it makes the next plain launch fill the gap. In-flight
 * jobs are reused as-is: they have not written their outputs yet.
 */
export const resolveReusableMeshGenerateJob = async (
	env: WorkerAppEnv["Bindings"],
	db: ReturnType<typeof getDb>,
	scope: MeshGenerateJobScopeWithFingerprint,
	now: Date = new Date(),
): Promise<MeshJobRecord | null> => {
	return resolveMeshGenerateJobByPolicy(env, db, scope, now, {
		acceptFallbackInFlight: (job) => isMeshJobReusable(job.status),
		acceptRecent: (job) => isMeshJobReusable(job.status),
		acceptResolved: async (job) =>
			job.status !== "completed" ||
			(await hasCurrentMeshJobOutputs(env, {
				jobId: job.id,
				orgId: scope.orgId,
				projectId: job.projectId,
			})),
		includeFallbackCompleted: true,
	});
};

/**
 * Resolve only in-flight (queued/running) work for identical inputs. Used by
 * the force-enqueue conflict path, where handing back a completed job would
 * return exactly the cached result the caller asked to bypass; the honest
 * answers are "your rerun is already in flight" or nothing.
 */
export const resolveActiveMeshGenerateJob = async (
	env: WorkerAppEnv["Bindings"],
	db: ReturnType<typeof getDb>,
	scope: MeshGenerateJobScopeWithFingerprint,
	now: Date = new Date(),
): Promise<MeshJobRecord | null> => {
	const isActive = (job: MeshJobRecord) => isMeshJobInFlight(job.status);

	return resolveMeshGenerateJobByPolicy(env, db, scope, now, {
		acceptFallbackInFlight: isActive,
		acceptRecent: isActive,
		includeFallbackCompleted: false,
	});
};

/**
 * Resolve the completed mesh.generate jobs whose outputs may represent the
 * project right now, in preference order: the newest completed job matching
 * the project's currently selected zone scans, then the newest completed job
 * overall (deduplicated). The selection tier keeps the project-level point
 * cloud in step with scan version selection even when a re-enqueue reuses an
 * older job instead of creating a new row; projects with no uploaded
 * selection (or scans mid-upload, since only `uploaded` pointers feed the
 * fingerprint) simply have no selection tier. Callers try each candidate's
 * object in order, so a job whose artifact went missing cannot hide an older
 * completed job that still has it.
 */
export const resolveCurrentMeshGenerateJobCandidates = async (
	env: WorkerAppEnv["Bindings"],
	db: ReturnType<typeof getDb>,
	{ orgId, projectId }: { orgId: string; projectId: string },
	now: Date = new Date(),
): Promise<MeshJobRecord[]> => {
	const candidates: MeshJobRecord[] = [];

	// The selection and latest-completed tiers below reconcile overlapping
	// recency windows. Memoize per job id so each job's status.json is read at
	// most once per request instead of once per tier.
	const reconcileCache = new Map<string, Promise<MeshJobRecord>>();
	const reconcileJob: MeshJobReconciler = (job) => {
		const cached = reconcileCache.get(job.id);
		if (cached) return cached;
		const pending = reconcileMeshJob(env, db, { orgId }, job, now);
		reconcileCache.set(job.id, pending);
		return pending;
	};

	const zoneScanObjectKeys = await collectMeshGenerateZoneScanObjectKeys({
		db,
		orgId,
		projectId,
	});

	if (zoneScanObjectKeys.length > 0) {
		// The selection fingerprint is recomputed from the *current* contract
		// version, while each job row stored the fingerprint (and messageVersion)
		// it was created under. So the selection tier only matches jobs produced
		// under the current version: bumping meshJobDefinitions.generate.version
		// intentionally stops historical jobs from matching here, since their
		// outputs came from an older pipeline contract. The latest-completed tier
		// below still returns a (cross-version) point cloud until a job runs under
		// the new version, so a bump degrades selection accuracy but never leaves
		// the project with no point cloud.
		const inputFingerprint = await computeMeshJobInputFingerprint({
			type: meshJobDefinitions.generate.type,
			version: meshJobDefinitions.generate.version,
			zoneScanObjectKeys,
		});
		const selectionMatch = await resolveLatestCompletedMeshGenerateJob(
			env,
			db,
			{ orgId, projectId, inputFingerprint },
			now,
			reconcileJob,
		);
		if (selectionMatch) candidates.push(selectionMatch);
	}

	const latestCompleted = await resolveLatestCompletedMeshGenerateJob(
		env,
		db,
		{ orgId, projectId },
		now,
		reconcileJob,
	);
	if (
		latestCompleted &&
		!candidates.some((candidate) => candidate.id === latestCompleted.id)
	) {
		candidates.push(latestCompleted);
	}

	return candidates;
};
