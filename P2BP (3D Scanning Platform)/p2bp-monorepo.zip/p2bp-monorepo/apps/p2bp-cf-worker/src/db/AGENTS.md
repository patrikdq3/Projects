# Agent Notes

- `bun run dev` and `bun run db:migrate:local:dev` both target Wrangler's local `dev` environment.
- Omit `--env-file` on Wrangler-backed local commands like those above; keep explicit `--env-file` usage only when selecting a non-default env file for non-Wrangler commands such as remote `bun run db:migrate:remote`.
- Remote D1 migrations should run through `bun run db:migrate:remote` with `CLOUDFLARE_*` env vars supplied by `.env`, `bun --env-file=...`, Doppler, or another env provider instead of depending on a local `database_id` in `wrangler.jsonc`.
- The remote environment bootstrap order is: push secrets to the Worker, deploy, record the new `CLOUDFLARE_MAIN_DATABASE_ID`, update your secrets source, push secrets again, then run `bun run db:migrate:remote` with the target environment loaded.
- Use `getDb(env)` from `src/db/index.ts` instead of calling `drizzle(env.DB)` inline; it memoizes the Drizzle wrapper per D1 binding so warm Worker isolates reuse it across requests.
- `getDb(env)` emits structured `cacheStatus`/`instanceId` logs so repeated requests on a warm isolate can confirm the same Drizzle wrapper is being reused.
