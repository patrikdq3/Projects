import { drizzle } from "drizzle-orm/d1";
import { appLogger } from "../lib/logger";
import * as schema from "./schema";

type DatabaseEnv = Pick<CloudflareBindings, "DB">;
type DbBinding = DatabaseEnv["DB"];
type DbInstance = ReturnType<typeof createDb>;
type DbCacheEntry = {
	db: DbInstance;
	id: number;
};

const createDb = (binding: DbBinding) => drizzle(binding, { schema });

const dbCache = new WeakMap<DbBinding, DbCacheEntry>();
let nextDbInstanceId = 1;

export const getDb = (env: DatabaseEnv) => {
	const cachedEntry = dbCache.get(env.DB);

	if (cachedEntry) {
		appLogger
			.withMetadata({
				cacheName: "drizzle",
				cacheStatus: "hit",
				component: "db",
				instanceId: cachedEntry.id,
			})
			.info("Reusing Drizzle instance");

		return cachedEntry.db;
	}

	const db = createDb(env.DB);
	const entry = {
		db,
		id: nextDbInstanceId++,
	};

	dbCache.set(env.DB, entry);

	appLogger
		.withMetadata({
			cacheName: "drizzle",
			cacheStatus: "miss",
			component: "db",
			instanceId: entry.id,
		})
		.info("Created Drizzle instance");

	return db;
};
