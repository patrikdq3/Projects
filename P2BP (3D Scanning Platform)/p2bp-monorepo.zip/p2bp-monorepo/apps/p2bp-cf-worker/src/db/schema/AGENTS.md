# Agent Notes

- Regenerate Better Auth tables with `bun run better-auth-gen-schema`; that script uses the repo's pinned Better Auth CLI, so do not hand-edit `src/db/schema/better-auth.schema.ts` unless there is a specific reason.
- `src/db/schema/app.schema.ts` is reserved for app-owned tables; Better Auth-owned schema stays separate so regeneration does not overwrite custom tables.
