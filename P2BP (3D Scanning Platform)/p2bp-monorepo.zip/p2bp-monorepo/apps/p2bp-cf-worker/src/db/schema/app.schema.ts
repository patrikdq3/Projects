// App-owned Drizzle tables live here. Keep Better Auth generated tables in
// better-auth.schema.ts so regeneration does not overwrite custom schema.
import { relations, sql } from "drizzle-orm";
import {
	check,
	index,
	integer,
	real,
	sqliteTable,
	text,
	uniqueIndex,
} from "drizzle-orm/sqlite-core";
import { meshJobStatuses, meshJobTypes } from "../../lib/mesh/job-contract";
import {
	latitudeConstraints,
	longitudeConstraints,
} from "../../lib/schemas/geo";
import { zoneScanUploadStatuses } from "../../lib/zones/scan-upload-status";
import { projectConstraints } from "../../routes/api/projects.schemas";
import { organization } from "./better-auth.schema";

const sqlNumberLiteral = (value: number) => sql.raw(String(value));
const sqlStringLiteral = (value: string) =>
	sql.raw(`'${value.replaceAll("'", "''")}'`);
const sqlStringLiteralList = (values: readonly string[]) =>
	sql.join(
		values.map((value) => sqlStringLiteral(value)),
		sql`, `,
	);
const sqlStringLiteralMap = <const Values extends readonly string[]>(
	values: Values,
) =>
	Object.fromEntries(
		values.map((value) => [value, sqlStringLiteral(value)]),
	) as Record<Values[number], ReturnType<typeof sql>>;
const zoneScanUploadStatusSqlList = sqlStringLiteralList(
	zoneScanUploadStatuses,
);
const zoneScanUploadStatusSql = sqlStringLiteralMap(zoneScanUploadStatuses);
const meshJobStatusSqlList = sqlStringLiteralList(meshJobStatuses);
const meshJobStatusSql = sqlStringLiteralMap(meshJobStatuses);
const meshJobTypeSqlList = sqlStringLiteralList(meshJobTypes);

// ─── Projects ─────────────────────────────────────────────
export const projects = sqliteTable(
	"projects",
	{
		id: text("id")
			.primaryKey()
			.$defaultFn(() => crypto.randomUUID()),
		organizationId: text("organization_id")
			.notNull()
			.references(() => organization.id, { onDelete: "cascade" }),
		name: text("name").notNull(),
		description: text("description"),
		initialLat: real("initial_lat").notNull(),
		initialLong: real("initial_long").notNull(),
		zoneSize: integer("zone_size").notNull(),
		createdAt: integer("created_at", { mode: "timestamp" })
			.notNull()
			.default(sql`(unixepoch())`),
	},
	() => [
		check(
			"projects_name_check",
			sql`length(name) >= ${sqlNumberLiteral(projectConstraints.name.minLength)} AND length(name) <= ${sqlNumberLiteral(projectConstraints.name.maxLength)}`,
		),
		check(
			"description_check",
			sql`description IS NULL OR length(description) <= ${sqlNumberLiteral(projectConstraints.description.maxLength)}`,
		),
		check(
			"projects_initial_lat_check",
			sql`initial_lat > ${sqlNumberLiteral(projectConstraints.initialLat.minExclusive)} AND initial_lat < ${sqlNumberLiteral(projectConstraints.initialLat.maxExclusive)}`,
		),
		check(
			"projects_initial_long_check",
			sql`initial_long >= ${sqlNumberLiteral(longitudeConstraints.min)} AND initial_long <= ${sqlNumberLiteral(longitudeConstraints.max)}`,
		),
		check(
			"projects_zone_size_check",
			sql`zone_size > ${sqlNumberLiteral(projectConstraints.zoneSize.min - 1)}`,
		),
	],
);

// ─── Zones ───────────────────────────────────────────────
export const zones = sqliteTable(
	"zones",
	{
		id: text("id")
			.primaryKey()
			.$defaultFn(() => crypto.randomUUID()),
		projectId: text("project_id")
			.notNull()
			.references(() => projects.id, { onDelete: "cascade" }),
		x: integer("x").notNull(),
		y: integer("y").notNull(),
		scannedAt: integer("scanned_at", { mode: "timestamp" }).notNull(),
		duration: real("duration"),
		pointCount: integer("point_count"),
		scanObjectKey: text("scan_object_key"),
		scanUploadStatus: text("scan_upload_status", {
			enum: zoneScanUploadStatuses,
		}),
		scanUploadExpiresAt: integer("scan_upload_expires_at", {
			mode: "timestamp",
		}),
		scanUploadedAt: integer("scan_uploaded_at", { mode: "timestamp" }),
		metadata: text("metadata", { mode: "json" }),
		createdAt: integer("created_at", { mode: "timestamp" })
			.notNull()
			.default(sql`(unixepoch())`),
	},
	(table) => [
		uniqueIndex("zones_project_xy_unique").on(
			table.projectId,
			table.x,
			table.y,
		),
		uniqueIndex("zones_scan_object_key_unique").on(table.scanObjectKey),
		check("duration_check", sql`duration IS NULL OR duration >= 0`),
		check("point_count_check", sql`point_count IS NULL OR point_count >= 0`),
		check(
			"scan_object_key_check",
			sql`scan_object_key IS NULL OR length(scan_object_key) <= 2048`,
		),
		check(
			"scan_upload_status_check",
			sql`scan_upload_status IS NULL OR scan_upload_status IN (${zoneScanUploadStatusSqlList})`,
		),
		check(
			"scan_upload_state_check",
			sql`(
				scan_upload_status IS NULL
				AND scan_object_key IS NULL
				AND scan_upload_expires_at IS NULL
				AND scan_uploaded_at IS NULL
			) OR (
				scan_upload_status = ${zoneScanUploadStatusSql.pending}
				AND scan_object_key IS NOT NULL
				AND scan_upload_expires_at IS NOT NULL
				AND scan_uploaded_at IS NULL
			) OR (
				scan_upload_status = ${zoneScanUploadStatusSql.uploaded}
				AND scan_object_key IS NOT NULL
				AND scan_upload_expires_at IS NOT NULL
				AND scan_uploaded_at IS NOT NULL
			) OR (
				scan_upload_status = ${zoneScanUploadStatusSql.expired}
				AND scan_object_key IS NOT NULL
				AND scan_upload_expires_at IS NOT NULL
				AND scan_uploaded_at IS NULL
			)`,
		),
		check("metadata_check", sql`metadata IS NULL OR json_valid(metadata)`),
	],
);

// ─── Zone Scan Archives ───────────────────────────────────────
export const zoneScanArchives = sqliteTable(
	"zone_scan_archives",
	{
		id: text("id")
			.primaryKey()
			.$defaultFn(() => crypto.randomUUID()),
		zoneId: text("zone_id")
			.notNull()
			.references(() => zones.id, { onDelete: "cascade" }),
		objectKey: text("object_key").notNull(),
		uploadStatus: text("upload_status", {
			enum: zoneScanUploadStatuses,
		}).notNull(),
		uploadExpiresAt: integer("upload_expires_at", {
			mode: "timestamp",
		}).notNull(),
		uploadedAt: integer("uploaded_at", { mode: "timestamp" }),
		previewObjectKey: text("preview_object_key"),
		previewUploadStatus: text("preview_upload_status", {
			enum: zoneScanUploadStatuses,
		}),
		previewUploadExpiresAt: integer("preview_upload_expires_at", {
			mode: "timestamp",
		}),
		previewUploadedAt: integer("preview_uploaded_at", { mode: "timestamp" }),
		createdAt: integer("created_at", { mode: "timestamp" })
			.notNull()
			.default(sql`(unixepoch())`),
	},
	(table) => [
		uniqueIndex("zone_scan_archives_object_key_unique").on(table.objectKey),
		uniqueIndex("zone_scan_archives_preview_object_key_unique").on(
			table.previewObjectKey,
		),
		index("zone_scan_archives_zone_created_id_index").on(
			table.zoneId,
			table.createdAt,
			table.id,
		),
		check(
			"zone_scan_archives_object_key_check",
			sql`length(object_key) <= 2048`,
		),
		check(
			"zone_scan_archives_preview_object_key_check",
			sql`preview_object_key IS NULL OR length(preview_object_key) <= 2048`,
		),
		check(
			"zone_scan_archives_upload_status_check",
			sql`upload_status IN (${zoneScanUploadStatusSqlList})`,
		),
		check(
			"zone_scan_archives_preview_upload_status_check",
			sql`preview_upload_status IS NULL OR preview_upload_status IN (${zoneScanUploadStatusSqlList})`,
		),
		check(
			"zone_scan_archives_upload_state_check",
			sql`(
				upload_status = ${zoneScanUploadStatusSql.pending}
				AND uploaded_at IS NULL
			) OR (
				upload_status = ${zoneScanUploadStatusSql.uploaded}
				AND uploaded_at IS NOT NULL
			) OR (
				upload_status = ${zoneScanUploadStatusSql.expired}
				AND uploaded_at IS NULL
			)`,
		),
		check(
			"zone_scan_archives_preview_upload_state_check",
			sql`(
				preview_upload_status IS NULL
				AND preview_object_key IS NULL
				AND preview_upload_expires_at IS NULL
				AND preview_uploaded_at IS NULL
			) OR (
				preview_upload_status = ${zoneScanUploadStatusSql.pending}
				AND preview_object_key IS NOT NULL
				AND preview_upload_expires_at IS NOT NULL
				AND preview_uploaded_at IS NULL
			) OR (
				preview_upload_status = ${zoneScanUploadStatusSql.uploaded}
				AND preview_object_key IS NOT NULL
				AND preview_upload_expires_at IS NOT NULL
				AND preview_uploaded_at IS NOT NULL
			) OR (
				preview_upload_status = ${zoneScanUploadStatusSql.expired}
				AND preview_object_key IS NOT NULL
				AND preview_upload_expires_at IS NOT NULL
				AND preview_uploaded_at IS NULL
			)`,
		),
	],
);

// ─── Mesh Jobs ───────────────────────────────────────────
// One row per enqueued mesh processing job. Results are written by the
// external EC2 consumer under `.../mesh-jobs/{jobId}/`, and status is
// reconciled from the consumer-written `status.json` (see
// mesh.jobs.reconciliation.ts). `input_fingerprint` hashes the exact set of
// zone scan object keys so identical inputs can reuse a completed job.
export const meshJobs = sqliteTable(
	"mesh_jobs",
	{
		id: text("id")
			.primaryKey()
			.$defaultFn(() => crypto.randomUUID()),
		projectId: text("project_id")
			.notNull()
			.references(() => projects.id, { onDelete: "cascade" }),
		type: text("type", { enum: meshJobTypes }).notNull(),
		messageVersion: integer("message_version").notNull(),
		status: text("status", { enum: meshJobStatuses }).notNull(),
		inputFingerprint: text("input_fingerprint").notNull(),
		zoneScanObjectKeys: text("zone_scan_object_keys", { mode: "json" })
			.$type<string[]>()
			.notNull(),
		error: text("error"),
		startedAt: integer("started_at", { mode: "timestamp" }),
		completedAt: integer("completed_at", { mode: "timestamp" }),
		createdAt: integer("created_at", { mode: "timestamp" })
			.notNull()
			.default(sql`(unixepoch())`),
	},
	(table) => [
		index("mesh_jobs_project_created_id_index").on(
			table.projectId,
			table.createdAt,
			table.id,
		),
		index("mesh_jobs_cache_lookup_index").on(
			table.projectId,
			table.type,
			table.inputFingerprint,
			table.createdAt,
		),
		uniqueIndex("mesh_jobs_active_input_unique")
			.on(table.projectId, table.type, table.inputFingerprint)
			.where(
				sql`status IN (${meshJobStatusSql.queued}, ${meshJobStatusSql.running})`,
			),
		check("mesh_jobs_type_check", sql`type IN (${meshJobTypeSqlList})`),
		check("mesh_jobs_status_check", sql`status IN (${meshJobStatusSqlList})`),
		check(
			"mesh_jobs_input_fingerprint_check",
			sql`length(input_fingerprint) = 64`,
		),
		check(
			"mesh_jobs_zone_scan_object_keys_check",
			sql`json_valid(zone_scan_object_keys)`,
		),
		check(
			"mesh_jobs_state_check",
			sql`(
				status = ${meshJobStatusSql.queued}
				AND started_at IS NULL
				AND completed_at IS NULL
				AND error IS NULL
			) OR (
				status = ${meshJobStatusSql.running}
				AND started_at IS NOT NULL
				AND completed_at IS NULL
				AND error IS NULL
			) OR (
				status = ${meshJobStatusSql.completed}
				AND completed_at IS NOT NULL
				AND error IS NULL
			) OR (
				status = ${meshJobStatusSql.failed}
				AND completed_at IS NOT NULL
				AND error IS NOT NULL
			)`,
		),
	],
);

// ─── Boundary Points ───────────────────────────────────────────
export const boundaryPoints = sqliteTable(
	"boundary_points",
	{
		id: text("id")
			.primaryKey()
			.$defaultFn(() => crypto.randomUUID()),
		projectId: text("project_id")
			.notNull()
			.references(() => projects.id, { onDelete: "cascade" }),
		latitude: real("latitude").notNull(),
		longitude: real("longitude").notNull(),
		sortOrder: integer("sort_order").notNull().default(0),
	},
	() => [
		check(
			"boundary_lat_check",
			sql`latitude >= ${sqlNumberLiteral(latitudeConstraints.min)} AND latitude <= ${sqlNumberLiteral(latitudeConstraints.max)}`,
		),
		check(
			"boundary_long_check",
			sql`longitude >= ${sqlNumberLiteral(longitudeConstraints.min)} AND longitude <= ${sqlNumberLiteral(longitudeConstraints.max)}`,
		),
		check("boundary_sort_order_check", sql`sort_order >= 0`),
	],
);

// ─── Relations ───────────────────────────────────────────
export const projectsRelations = relations(projects, ({ one, many }) => ({
	organization: one(organization, {
		fields: [projects.organizationId],
		references: [organization.id],
	}),
	zones: many(zones),
	boundaryPoints: many(boundaryPoints),
	meshJobs: many(meshJobs),
}));

export const meshJobsRelations = relations(meshJobs, ({ one }) => ({
	project: one(projects, {
		fields: [meshJobs.projectId],
		references: [projects.id],
	}),
}));

export const zonesRelations = relations(zones, ({ one, many }) => ({
	project: one(projects, {
		fields: [zones.projectId],
		references: [projects.id],
	}),
	scanArchives: many(zoneScanArchives),
}));

export const zoneScanArchivesRelations = relations(
	zoneScanArchives,
	({ one }) => ({
		zone: one(zones, {
			fields: [zoneScanArchives.zoneId],
			references: [zones.id],
		}),
	}),
);

export const boundaryPointsRelations = relations(boundaryPoints, ({ one }) => ({
	project: one(projects, {
		fields: [boundaryPoints.projectId],
		references: [projects.id],
	}),
}));
