import { OpenAPIHono } from "@hono/zod-openapi";
import { trimTrailingSlash } from "hono/trailing-slash";
import type { WorkerAppEnv } from "./app-env";
import { loggingMiddleware } from "./lib/logging";
import { api } from "./routes/api";

export { Ec2InstanceStarter } from "./lib/aws/ec2-starter";

const app = new OpenAPIHono<WorkerAppEnv>();

app.use(trimTrailingSlash());
app.use(loggingMiddleware);
app.route("/api", api);

export default app;
