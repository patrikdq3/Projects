import { describe, expect, it } from "bun:test";
import { admin, member, owner, scanner } from "./permissions";

describe("organization roles", () => {
	it("allows scanners to view projects and view and update zones", () => {
		expect(scanner.authorize({ zone: ["view", "update"] }).success).toBe(true);
		expect(scanner.authorize({ project: ["view"] }).success).toBe(true);
		expect(scanner.authorize({ project: ["update"] }).success).toBe(false);
	});

	it("preserves zone viewing for members without allowing updates", () => {
		expect(member.authorize({ zone: ["view"] }).success).toBe(true);
		expect(member.authorize({ zone: ["update"] }).success).toBe(false);
	});

	it("allows admins and owners to view and update zones", () => {
		for (const role of [admin, owner]) {
			expect(role.authorize({ zone: ["view", "update"] }).success).toBe(true);
		}
	});

	it("restricts zone scan selection to admins and owners", () => {
		for (const role of [admin, owner]) {
			expect(role.authorize({ zoneScan: ["select"] }).success).toBe(true);
		}
		expect(member.authorize({ zoneScan: ["select"] }).success).toBe(false);
		expect(scanner.authorize({ zoneScan: ["select"] }).success).toBe(false);
	});

	it("restricts mesh job enqueueing to admins and owners", () => {
		for (const role of [admin, owner]) {
			expect(role.authorize({ meshJob: ["enqueue"] }).success).toBe(true);
		}
		expect(member.authorize({ meshJob: ["enqueue"] }).success).toBe(false);
		expect(scanner.authorize({ meshJob: ["enqueue"] }).success).toBe(false);
	});
});
