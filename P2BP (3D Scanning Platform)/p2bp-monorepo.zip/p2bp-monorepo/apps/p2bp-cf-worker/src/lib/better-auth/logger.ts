import type { Logger } from "better-auth";
import { serializeError } from "serialize-error";
import { appLogger } from "../logger";

const isError = (value: unknown): value is Error => {
	return value instanceof Error;
};

const normalizeDetails = (args: unknown[]) => {
	if (args.length === 0) {
		return undefined;
	}

	return args.map((arg) => {
		if (isError(arg)) {
			return serializeError(arg);
		}

		return arg;
	});
};

const getFirstError = (args: unknown[]) => {
	return args.find(isError);
};

export const betterAuthLogger: Logger = {
	level: "warn",
	log: (level, message, ...args) => {
		const details = normalizeDetails(args);
		const error = getFirstError(args);

		let logger = appLogger.withMetadata({
			component: "better-auth",
			...(details ? { details } : {}),
		});

		if (error) {
			logger = logger.withError(error);
		}

		logger[level](message);
	},
};
