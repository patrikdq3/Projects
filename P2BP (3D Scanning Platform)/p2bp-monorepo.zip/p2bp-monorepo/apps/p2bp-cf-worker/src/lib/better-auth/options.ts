import { passkey } from "@better-auth/passkey";
import type { BetterAuthOptions } from "better-auth";
import {
	emailOTP,
	openAPI,
	organization,
	twoFactor,
	username,
} from "better-auth/plugins";
import { importPKCS8, SignJWT } from "jose";
import { sendOtpEmail, sendPasswordResetLinkEmail } from "./email";
import { betterAuthLogger } from "./logger";
import { ac, admin, member, owner, scanner } from "./permissions";

type BetterAuthOptionEnv = {
	EMAIL_FROM_DOMAIN?: string;
	EMAIL_FROM_DOMAIN_NAME?: string;
	EMAIL?: Pick<SendEmail, "send">;
	GOOGLE_OAUTH_CLIENT_ID?: string;
	GOOGLE_OAUTH_CLIENT_SECRET?: string;
	GOOGLE_OAUTH_IOS_CLIENT_IDS?: string;
	APPLE_CLIENT_ID?: string;
	APPLE_TEAM_ID?: string;
	APPLE_KEY_ID?: string;
	APPLE_PRIVATE_KEY?: string;
	APPLE_APP_BUNDLE_IDENTIFIER?: string;
};

const splitEnvList = (value?: string) =>
	value
		?.split(";")
		.map((entry) => entry.trim())
		.filter((entry) => entry.length > 0) ?? [];

const normalizePrivateKey = (value: string) => value.replace(/\\n/g, "\n");

// Generate the client secret JWT required for Sign in with Apple.
async function generateAppleClientSecret(
	clientId: string,
	teamId: string,
	keyId: string,
	privateKey: string,
) {
	const key = await importPKCS8(privateKey, "ES256");
	const now = Math.floor(Date.now() / 1000);

	return new SignJWT({})
		.setProtectedHeader({ alg: "ES256", kid: keyId })
		.setIssuer(teamId)
		.setSubject(clientId)
		.setAudience("https://appleid.apple.com")
		.setIssuedAt(now)
		.setExpirationTime(now + 180 * 24 * 60 * 60)
		.sign(key);
}

const getSocialProviders = (env: BetterAuthOptionEnv) => {
	const googleClientId = env.GOOGLE_OAUTH_CLIENT_ID?.trim();
	const googleClientSecret = env.GOOGLE_OAUTH_CLIENT_SECRET?.trim();
	const googleClientIds = [
		...(googleClientId ? [googleClientId] : []),
		...splitEnvList(env.GOOGLE_OAUTH_IOS_CLIENT_IDS),
	];

	const appleClientId = env.APPLE_CLIENT_ID?.trim();
	const appleTeamId = env.APPLE_TEAM_ID?.trim();
	const appleKeyId = env.APPLE_KEY_ID?.trim();
	const applePrivateKey = env.APPLE_PRIVATE_KEY?.trim();
	const appleAppBundleIdentifier = env.APPLE_APP_BUNDLE_IDENTIFIER?.trim();

	const googleConfig =
		googleClientIds.length > 0 && googleClientSecret
			? {
					clientId:
						googleClientIds.length === 1 ? googleClientIds[0] : googleClientIds,
					clientSecret: googleClientSecret,
				}
			: undefined;

	const appleConfig =
		appleClientId && appleTeamId && appleKeyId && applePrivateKey
			? async () => ({
					clientId: appleClientId,
					clientSecret: await generateAppleClientSecret(
						appleClientId,
						appleTeamId,
						appleKeyId,
						normalizePrivateKey(applePrivateKey),
					),
					...(appleAppBundleIdentifier && {
						appBundleIdentifier: appleAppBundleIdentifier,
					}),
				})
			: undefined;

	return {
		...(googleConfig && {
			google: googleConfig,
		}),

		...(appleConfig && {
			apple: appleConfig,
		}),
	} satisfies BetterAuthOptions["socialProviders"];
};

export const createBetterAuthOptions = (
	env: BetterAuthOptionEnv = process.env,
) => {
	const socialProviders = getSocialProviders(env);
	const hasSocialProviders = Object.keys(socialProviders).length > 0;

	return {
		appName: "P2BP",
		basePath: "/api/auth",
		emailAndPassword: {
			enabled: true,
			requireEmailVerification: true,
			revokeSessionsOnPasswordReset: true,
			sendResetPassword: ({ user, url }) =>
				sendPasswordResetLinkEmail(env, { to: user.email, url }),
		},
		emailVerification: {
			autoSignInAfterVerification: true,
			sendOnSignUp: true,
		},
		logger: betterAuthLogger,
		plugins: [
			passkey({
				rpName: "P2BP",
			}),
			twoFactor({
				issuer: "P2BP",
				allowPasswordless: true,
			}),
			organization({
				allowUserToCreateOrganization: true,
				ac,
				roles: { member, scanner, admin, owner },
			}),
			emailOTP({
				sendVerificationOTP: ({ email, otp, type }) =>
					sendOtpEmail(env, { to: email, otp, type }),
				overrideDefaultEmailVerification: true,
				storeOTP: "hashed",
			}),
			username(),
			openAPI(),
		],
		...(hasSocialProviders ? { socialProviders } : {}),
		trustedOrigins: ["https://appleid.apple.com"], // necessary for apple sso
		databaseHooks: {
			user: {
				create: {
					after: async (user, ctx) => {
						try {
							const org = await ctx?.context?.adapter.create({
								model: "organization",
								data: {
									name: `${user.username ?? user.name}-workspace`,
									slug: `${user.id}-workspace`,
									createdAt: new Date(),
								},
							});

							if (!org) return;

							await ctx?.context?.adapter.create({
								model: "member",
								data: {
									organizationId: org.id,
									userId: user.id,
									role: "owner",
									createdAt: new Date(),
								},
							});
						} catch {
							// fail silently
						}
					},
				},
			},
		},
	} satisfies BetterAuthOptions;
};
