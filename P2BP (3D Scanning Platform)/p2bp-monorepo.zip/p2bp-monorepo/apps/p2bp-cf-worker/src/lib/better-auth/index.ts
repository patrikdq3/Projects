import { betterAuth } from "better-auth";
import { drizzleAdapter } from "better-auth/adapters/drizzle";
import { getDb } from "../../db";
import * as schema from "../../db/schema";
import { appLogger } from "../logger";
import { createBetterAuthOptions } from "./options";

type AuthEnv = Pick<
	CloudflareBindings,
	| "DB"
	| "EMAIL"
	| "BETTER_AUTH_SECRET"
	| "BASE_URL"
	| "EMAIL_FROM_DOMAIN"
	| "EMAIL_FROM_DOMAIN_NAME"
	| "GOOGLE_OAUTH_CLIENT_ID"
	| "GOOGLE_OAUTH_CLIENT_SECRET"
	| "GOOGLE_OAUTH_IOS_CLIENT_IDS"
	| "APPLE_CLIENT_ID"
	| "APPLE_TEAM_ID"
	| "APPLE_KEY_ID"
	| "APPLE_PRIVATE_KEY"
	| "APPLE_APP_BUNDLE_IDENTIFIER"
>;
type AuthBinding = AuthEnv["DB"];
type AuthInstance = ReturnType<typeof createAuth>;
type AuthCacheEntry = {
	auth: AuthInstance;
	id: number;
};
export type AuthSession = Awaited<
	ReturnType<AuthInstance["api"]["getSession"]>
>;

const createAuth = (env: AuthEnv) =>
	betterAuth({
		...createBetterAuthOptions(env),
		database: drizzleAdapter(getDb(env), { provider: "sqlite", schema }),
		baseURL: env.BASE_URL,
		secret: env.BETTER_AUTH_SECRET,
	});

const authCache = new WeakMap<AuthBinding, Map<string, AuthCacheEntry>>();
let nextAuthInstanceId = 1;

const getAuthCacheKey = (env: AuthEnv) =>
	[
		env.BASE_URL,
		env.BETTER_AUTH_SECRET,
		env.EMAIL_FROM_DOMAIN,
		env.EMAIL_FROM_DOMAIN_NAME ?? "",
		env.GOOGLE_OAUTH_CLIENT_ID ?? "",
		env.GOOGLE_OAUTH_CLIENT_SECRET ?? "",
		env.GOOGLE_OAUTH_IOS_CLIENT_IDS ?? "",
		env.APPLE_CLIENT_ID ?? "",
		env.APPLE_TEAM_ID ?? "",
		env.APPLE_KEY_ID ?? "",
		env.APPLE_PRIVATE_KEY ?? "",
		env.APPLE_APP_BUNDLE_IDENTIFIER ?? "",
	].join(":");

export const getAuth = (env: AuthEnv) => {
	let authByConfig = authCache.get(env.DB);

	if (!authByConfig) {
		authByConfig = new Map();
		authCache.set(env.DB, authByConfig);
	}

	const cacheKey = getAuthCacheKey(env);
	const cachedEntry = authByConfig.get(cacheKey);

	if (cachedEntry) {
		appLogger
			.withMetadata({
				baseURL: env.BASE_URL,
				cacheName: "better-auth",
				cacheStatus: "hit",
				component: "better-auth",
				instanceId: cachedEntry.id,
			})
			.info("Reusing Better Auth instance");

		return cachedEntry.auth;
	}

	const auth = createAuth(env);
	const entry = {
		auth,
		id: nextAuthInstanceId++,
	};

	authByConfig.set(cacheKey, entry);

	appLogger
		.withMetadata({
			baseURL: env.BASE_URL,
			cacheName: "better-auth",
			cacheStatus: "miss",
			component: "better-auth",
			instanceId: entry.id,
		})
		.info("Created Better Auth instance");

	return auth;
};

export const getAuthSession = (env: AuthEnv, headers: Headers) =>
	getAuth(env).api.getSession({ headers });
