# Agent Notes

- Better Auth's documented `logger` option is wired through `src/lib/better-auth/logger.ts`, keeping the auth-specific log adaptation next to Better Auth instead of inside the shared logger module.
- Auth intentionally allows passkey login as an alternative to password-plus-2FA because `twoFactor` is configured with `allowPasswordless: true`.
- Build shared auth config with `createBetterAuthOptions(...)` instead of eager top-level env access; schema generation intentionally works without local OAuth secrets, while runtime provider config still comes from the Worker env/cache key.
- Better Auth email delivery is wired through Cloudflare Email Service in `src/lib/better-auth/email.tsx`; runtime env must provide the `EMAIL` send_email binding and `EMAIL_FROM_DOMAIN`.
- Keep Hono JSX email template files that are imported by Better Auth config annotated with `/** @jsxImportSource hono/jsx */`. `bun run better-auth-gen-schema` loads `better-auth.config.ts` through the Better Auth CLI/Jiti path, which may not honor the repo `tsconfig.json` JSX import source and can otherwise look for `react/jsx-runtime`.
- Use `getAuth(env)` from `src/lib/better-auth/index.ts` instead of constructing Better Auth inside route handlers; it memoizes the Better Auth instance per D1 binding and auth config for warm Worker isolates.
- `getAuth(env)` emits structured `cacheStatus`/`instanceId` logs so repeated requests on a warm isolate can confirm the same Better Auth instance is being reused.
