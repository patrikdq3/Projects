import { createAccessControl } from "better-auth/plugins/access";
import {
	adminAc,
	defaultStatements,
	memberAc,
	ownerAc,
} from "better-auth/plugins/organization/access";

const statement = {
	...defaultStatements,
	project: ["create", "update", "view", "delete"],
	zone: ["view", "update"],
	// Selecting which uploaded scan archive version is a zone's current scan.
	zoneScan: ["select"],
	meshJob: ["enqueue"],
} as const;

const ac = createAccessControl(statement);

const member = ac.newRole({
	project: ["view"],
	zone: ["view"],
	...memberAc.statements,
});

const scanner = ac.newRole({
	project: ["view"],
	zone: ["view", "update"],
});

const admin = ac.newRole({
	project: ["create", "view", "update", "delete"],
	zone: ["view", "update"],
	zoneScan: ["select"],
	meshJob: ["enqueue"],
	...adminAc.statements,
});

const owner = ac.newRole({
	project: ["create", "view", "update", "delete"],
	zone: ["view", "update"],
	zoneScan: ["select"],
	meshJob: ["enqueue"],
	...ownerAc.statements,
});

export { ac, admin, member, owner, scanner, statement };
