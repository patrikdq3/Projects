/** @jsxImportSource hono/jsx */

type AuthEmailEnv = {
	EMAIL_FROM_DOMAIN?: string;
	EMAIL_FROM_DOMAIN_NAME?: string;
	EMAIL?: Pick<SendEmail, "send">;
};

type AuthEmailMessage = {
	to: string;
	subject: string;
	text: string;
	html: string;
};

type AuthOtpType =
	| "sign-in"
	| "email-verification"
	| "forget-password"
	| "change-email";

const APP_NAME = "P2BP";
const EMAIL_FROM_LOCAL_PART = "noreply";

const getEmailSender = (env: AuthEmailEnv) => {
	const fromDomain = env.EMAIL_FROM_DOMAIN?.trim();

	if (!env.EMAIL || !fromDomain) {
		throw new Error(
			"Cloudflare Email Service is not configured. Set the EMAIL binding and EMAIL_FROM_DOMAIN.",
		);
	}

	return {
		binding: env.EMAIL,
		from: {
			email: `${EMAIL_FROM_LOCAL_PART}@${fromDomain}`,
			name: env.EMAIL_FROM_DOMAIN_NAME?.trim() || APP_NAME,
		},
	};
};

export const sendAuthEmail = async (
	env: AuthEmailEnv,
	message: AuthEmailMessage,
) => {
	const { binding, from } = getEmailSender(env);

	await binding.send({
		from,
		to: message.to,
		subject: message.subject,
		text: message.text,
		html: message.html,
	});
};

const renderEmailHtml = (children: {
	toString(): string | Promise<string>;
}) => {
	const html = children.toString();

	if (typeof html !== "string") {
		throw new Error("Async auth email JSX components are not supported.");
	}

	return html;
};

const PasswordResetEmail = (props: { url: string }) => (
	<>
		<p>Reset your {APP_NAME} password by opening this link:</p>
		<p>
			<a href={props.url}>Reset password</a>
		</p>
		<p>If you did not request this, you can ignore this email.</p>
	</>
);

const OtpEmail = (props: { otp: string }) => (
	<>
		<p>Your {APP_NAME} verification code is:</p>
		<p>
			<strong style={{ fontSize: "24px", letterSpacing: "4px" }}>
				{props.otp}
			</strong>
		</p>
		<p>
			This code expires soon. If you did not request it, you can ignore this
			email.
		</p>
	</>
);

export const sendPasswordResetLinkEmail = (
	env: AuthEmailEnv,
	input: { to: string; url: string },
) =>
	sendAuthEmail(env, {
		to: input.to,
		subject: `Reset your ${APP_NAME} password`,
		text: [
			`Reset your ${APP_NAME} password by opening this link:`,
			input.url,
			"",
			"If you did not request this, you can ignore this email.",
		].join("\n"),
		html: renderEmailHtml(<PasswordResetEmail url={input.url} />),
	});

const getOtpSubject = (type: AuthOtpType) => {
	switch (type) {
		case "sign-in":
			return `Your ${APP_NAME} sign-in code`;
		case "email-verification":
			return `Verify your ${APP_NAME} email`;
		case "forget-password":
			return `Reset your ${APP_NAME} password`;
		case "change-email":
			return `Confirm your ${APP_NAME} email change`;
	}
};

export const sendOtpEmail = (
	env: AuthEmailEnv,
	input: { to: string; otp: string; type: AuthOtpType },
) => {
	return sendAuthEmail(env, {
		to: input.to,
		subject: getOtpSubject(input.type),
		text: [
			`Your ${APP_NAME} verification code is: ${input.otp}`,
			"",
			"This code expires soon. If you did not request it, you can ignore this email.",
		].join("\n"),
		html: renderEmailHtml(<OtpEmail otp={input.otp} />),
	});
};
