import { describe, expect, it } from "bun:test";
import { createRouteAccessResolver } from "./route-access";

describe("createRouteAccessResolver", () => {
	it("returns 401 when the caller has no session", async () => {
		const resolveAccess = createRouteAccessResolver({
			getMembership: async () => ({ role: "owner" }),
			getSession: async () => null,
		});

		const result = await resolveAccess({
			headers: new Headers(),
			orgId: "org-123",
		});

		expect(result).toEqual({
			error: "Unauthorized",
			ok: false,
			status: 401,
		});
	});

	it("returns 403 when the caller is authenticated but not an org member", async () => {
		const resolveAccess = createRouteAccessResolver({
			getMembership: async () => null,
			getSession: async () => ({
				session: { id: "session-123" },
				user: { id: "user-123" },
			}),
		});

		const result = await resolveAccess({
			headers: new Headers(),
			orgId: "org-123",
		});

		expect(result).toEqual({
			error: "Forbidden",
			ok: false,
			status: 403,
		});
	});

	it("rejects cross-tenant access before checking resource permissions", async () => {
		const membershipLookups: Array<{ orgId: string; userId: string }> = [];
		let permissionChecked = false;
		const resolveAccess = createRouteAccessResolver({
			checkPermission: async () => {
				permissionChecked = true;
				return true;
			},
			getMembership: async (input) => {
				membershipLookups.push(input);
				return input.orgId === "org-a" ? { role: "scanner" } : null;
			},
			getSession: async () => ({ user: { id: "user-123" } }),
		});

		const result = await resolveAccess({
			headers: new Headers(),
			orgId: "org-b",
		});

		expect(result).toEqual({
			error: "Forbidden",
			ok: false,
			status: 403,
		});
		expect(membershipLookups).toEqual([{ orgId: "org-b", userId: "user-123" }]);
		expect(permissionChecked).toBe(false);
	});

	it("returns 403 when an organization member lacks resource permission", async () => {
		const resolveAccess = createRouteAccessResolver({
			checkPermission: async () => false,
			getMembership: async () => ({ role: "member" }),
			getSession: async () => ({ user: { id: "user-123" } }),
		});

		const result = await resolveAccess({
			headers: new Headers(),
			orgId: "org-123",
		});

		expect(result).toEqual({
			error: "Forbidden",
			ok: false,
			status: 403,
		});
	});

	it("allows callers who belong to the requested organization", async () => {
		const resolveAccess = createRouteAccessResolver({
			getMembership: async () => ({ role: "owner" }),
			getSession: async () => ({
				session: { id: "session-123" },
				user: { id: "user-123" },
			}),
		});

		const result = await resolveAccess({
			headers: new Headers(),
			orgId: "org-123",
		});

		expect(result).toEqual({
			memberRole: "owner",
			ok: true,
			userId: "user-123",
		});
	});

	it("propagates unexpected session lookup failures", async () => {
		const resolveAccess = createRouteAccessResolver({
			getMembership: async () => ({ role: "owner" }),
			getSession: async () => {
				throw new Error("database unavailable");
			},
		});

		await expect(
			resolveAccess({
				headers: new Headers(),
				orgId: "org-123",
			}),
		).rejects.toThrow("database unavailable");
	});
});
