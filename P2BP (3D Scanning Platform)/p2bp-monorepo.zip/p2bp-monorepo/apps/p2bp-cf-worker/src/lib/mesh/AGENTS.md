# Agent Notes

- `job-contract.ts` is the Worker's source of truth for mesh job message types, versions, statuses, output filenames, status filename/schema, and consumer runtime cap. Keep it synchronized with `P2BP-Postprocessing/mesh_jobs.py`, `pull_queue.py`, and their contract tests.
- Treat `mesh.generate` version bumps as coordinated Worker + Postprocessing deploys. The Python consumer validates the version, and the Worker includes the version in `input_fingerprint`, so historical jobs stop matching the selected-scan tier until a new job completes.
- Do not enqueue `mesh.refine` v1. It has no `jobId`, while tracked job rows, per-job output keys, and status reconciliation assume one.
