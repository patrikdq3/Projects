import { z } from "zod";

// TypeScript-side mesh job contract shared by the Worker, D1 schema, queue
// message builder, and R2 artifact/status readers. Keep the external consumer
// contract in `P2BP-Postprocessing/mesh_jobs.py` / `pull_queue.py` in sync
// with any change.
//
// mesh.refine is an unimplemented stub: no route enqueues it, the consumer
// rejects it (NotImplementedError), and its v1 message carries no `jobId`
// while all job tracking (mesh_jobs rows, per-job R2 output keys, status.json
// reconciliation) assumes one. Implementing refine requires bumping it to a
// jobId-carrying version on both sides first -- do not enqueue v1 as-is.
export const meshJobDefinitions = {
	generate: { type: "mesh.generate", version: 3 },
	refine: { type: "mesh.refine", version: 1 },
} as const;

export const meshJobTypes = [
	meshJobDefinitions.generate.type,
	meshJobDefinitions.refine.type,
] as const;

export type MeshJobType = (typeof meshJobTypes)[number];

export const meshJobStatuses = [
	"queued",
	"running",
	"completed",
	"failed",
] as const;

export type MeshJobStatus = (typeof meshJobStatuses)[number];

export const requiredMeshJobOutputFilenames = {
	pointCloud: "merged-point-cloud.laz",
	pointCloudPreview: "merged-point-cloud.preview.laz",
} as const;

// Outputs a completed job is not required to have. The E57 exports (the point
// cloud format CAD tools such as Rhino import natively) are optional so jobs
// merged before they existed still reconcile as completed; their download
// endpoints simply 404 until a newer merge produces them.
export const optionalMeshJobOutputFilenames = {
	pointCloudE57: "merged-point-cloud.e57",
	pointCloudPreviewE57: "merged-point-cloud.preview.e57",
	viewerMetadata: "merged-point-cloud.viewer.json",
} as const;

export const meshJobOutputFilenames = {
	...requiredMeshJobOutputFilenames,
	...optionalMeshJobOutputFilenames,
} as const;

export type MeshJobOutputFilename =
	(typeof meshJobOutputFilenames)[keyof typeof meshJobOutputFilenames];

export const meshJobStatusFilename = "status.json" as const;

// The external consumer caps a single run at this long (P2BP-Postprocessing
// `pull_queue.py` MAX_RUNTIME_SECONDS) and writes a terminal status.json before
// exceeding it. The Worker's reconciliation deadline (meshJobTimeoutMs) is
// derived from this so it always stays above the cap; if the consumer's cap
// changes, update this value in lockstep so live runs are never failed early.
export const meshJobConsumerRuntimeCapMs = 12 * 60 * 60 * 1000;

// Accept both `Z` and `+00:00`-style offsets: the consumer normalizes to `Z`,
// but a writer that forgets would otherwise have its whole (valid) status file
// silently dropped and the job misreported as timed out. Downstream parsing
// uses `new Date(...)`, which handles offsets.
const statusFileTimestamp = z.iso.datetime({ offset: true }).nullish();

export const meshJobStatusFileSchema = z.object({
	state: z.enum(["running", "completed", "failed"]),
	jobId: z.string().nullish(),
	startedAt: statusFileTimestamp,
	completedAt: statusFileTimestamp,
	error: z.string().nullish(),
});

export type MeshJobStatusFile = z.infer<typeof meshJobStatusFileSchema>;

export type MeshJobQueueMessage =
	| {
			type: typeof meshJobDefinitions.generate.type;
			version: typeof meshJobDefinitions.generate.version;
			jobId: string;
			organizationId: string;
			projectId: string;
			zoneScanObjectKeys: string[];
	  }
	| {
			type: typeof meshJobDefinitions.refine.type;
			version: typeof meshJobDefinitions.refine.version;
			organizationId: string;
			projectId: string;
	  };
