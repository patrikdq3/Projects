import { LogLayer, StructuredTransport } from "loglayer";
import { serializeError } from "serialize-error";

export const appLogger = new LogLayer({
	errorSerializer: serializeError,
	transport: new StructuredTransport({
		logger: console,
		stringify: true,
	}),
});
