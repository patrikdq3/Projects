# Agent Notes

- Shared structured logging lives in `src/lib/logger.ts`.
- Hono request logging middleware lives in `src/lib/logging.ts`; keep request middleware concerns there instead of growing the shared logger module.
