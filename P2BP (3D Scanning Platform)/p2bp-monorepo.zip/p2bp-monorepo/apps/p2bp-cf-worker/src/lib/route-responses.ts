import { z } from "@hono/zod-openapi";

export const UnauthorizedErrorSchema = z
	.object({
		error: z.literal("Unauthorized"),
	})
	.openapi("UnauthorizedError");

export const ForbiddenErrorSchema = z
	.object({
		error: z.literal("Forbidden"),
	})
	.openapi("ForbiddenError");

export const NotFoundErrorSchema = z
	.object({
		error: z.literal("Not found"),
	})
	.openapi("NotFoundError");

export const unauthorizedErrorResponse = {
	description: "Authentication required",
	content: {
		"application/json": {
			schema: UnauthorizedErrorSchema,
		},
	},
} as const;

export const forbiddenErrorResponse = {
	description: "Authenticated caller is not allowed to access this resource",
	content: {
		"application/json": {
			schema: ForbiddenErrorSchema,
		},
	},
} as const;

export const organizationMembershipForbiddenErrorResponse = {
	...forbiddenErrorResponse,
	description: "Authenticated caller is not a member of the organization",
} as const;

export const notFoundErrorResponse = {
	description: "Not found",
	content: {
		"application/json": {
			schema: NotFoundErrorSchema,
		},
	},
} as const;
