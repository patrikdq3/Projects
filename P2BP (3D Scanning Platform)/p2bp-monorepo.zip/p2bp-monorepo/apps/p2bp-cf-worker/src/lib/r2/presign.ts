import { S3mini } from "s3mini";
import type { WorkerAppEnv } from "../../app-env";

export type R2PresignInput = {
	accessKeyId: string;
	accountId: string;
	bucketName: string;
	// Local development only: base URL of miniflare's S3-compatible endpoint for
	// the local R2 simulation, from `localR2S3Endpoint`. Unset everywhere else,
	// so presigning targets the real R2 S3 API.
	endpointOverride?: string;
	expiresInSeconds: number;
	objectKey: string;
	secretAccessKey: string;
};

/**
 * `R2_S3_ENDPOINT` is supplied by `wrangler dev --var` in local development only
 * (see the "dev" script in package.json), and is undefined in every deployed
 * environment.
 *
 * It is deliberately not declared in `wrangler.jsonc`: `secrets.required` is
 * enforced on every deploy by `scripts/prepare-deployment-secrets.ts`, and
 * `vars` would ship the value to the deployed Worker. That keeps it out of the
 * generated `CloudflareBindings`, so it is read through here rather than
 * widening that type for a binding only local dev ever sets.
 */
export const localR2S3Endpoint = (env: WorkerAppEnv["Bindings"]) =>
	(env as WorkerAppEnv["Bindings"] & { R2_S3_ENDPOINT?: string })
		.R2_S3_ENDPOINT;

// miniflare serves the bucket at `<endpoint>/<bucket-name>`, the same
// path-style layout R2's own S3 API uses, so only the origin differs.
export const r2S3Endpoint = ({
	accountId,
	bucketName,
	endpointOverride,
}: Pick<R2PresignInput, "accountId" | "bucketName" | "endpointOverride">) => {
	const override = endpointOverride?.trim().replace(/\/+$/, "");

	if (!override) {
		return `https://${accountId}.r2.cloudflarestorage.com/${bucketName}`;
	}

	// Accept an override that already ends in the bucket segment. Appending a
	// second copy would still sign and upload successfully -- miniflare routes
	// on `/<bucket>/<key>`, so the extra segment is swallowed into the key and
	// objects land under a `<bucket-name>/...` prefix that nothing else reads.
	const bucketSuffix = `/${bucketName}`;
	const base = override.endsWith(bucketSuffix)
		? override.slice(0, -bucketSuffix.length)
		: override;

	return `${base}${bucketSuffix}`;
};

export const r2DownloadUrlExpiresInSeconds = 30 * 60;

export const floorDateToSecond = (date: Date) =>
	new Date(Math.floor(date.getTime() / 1000) * 1000);

export const r2DownloadUrlExpiresAt = (
	expiresInSeconds: number = r2DownloadUrlExpiresInSeconds,
) =>
	new Date(floorDateToSecond(new Date()).getTime() + expiresInSeconds * 1000);

export const createR2PresignedPutUrl = async ({
	accessKeyId,
	accountId,
	bucketName,
	endpointOverride,
	expiresInSeconds,
	objectKey,
	requiredHeaders,
	secretAccessKey,
}: R2PresignInput & {
	requiredHeaders: Readonly<Record<string, string>>;
}) =>
	new S3mini({
		accessKeyId,
		endpoint: r2S3Endpoint({ accountId, bucketName, endpointOverride }),
		region: "auto",
		secretAccessKey,
	}).getPresignedUrl("PUT", objectKey, expiresInSeconds, {}, requiredHeaders);

export const createR2PresignedGetUrl = async ({
	accessKeyId,
	accountId,
	bucketName,
	endpointOverride,
	expiresInSeconds,
	objectKey,
	secretAccessKey,
}: R2PresignInput) =>
	new S3mini({
		accessKeyId,
		endpoint: r2S3Endpoint({ accountId, bucketName, endpointOverride }),
		region: "auto",
		secretAccessKey,
	}).getPresignedUrl("GET", objectKey, expiresInSeconds);

export const presignR2DownloadUrl = async (
	env: WorkerAppEnv["Bindings"],
	objectKey: string,
	expiresInSeconds: number = r2DownloadUrlExpiresInSeconds,
) => {
	const downloadUrl = await createR2PresignedGetUrl({
		accessKeyId: env.R2_ACCESS_KEY_ID,
		accountId: env.CLOUDFLARE_ACCOUNT_ID,
		bucketName: env.R2_BUCKET_NAME,
		endpointOverride: localR2S3Endpoint(env),
		expiresInSeconds,
		objectKey,
		secretAccessKey: env.R2_SECRET_ACCESS_KEY,
	});

	return {
		downloadUrl,
		expiresAt: r2DownloadUrlExpiresAt(expiresInSeconds),
	};
};
