import { describe, expect, it } from "bun:test";
import {
	createR2PresignedGetUrl,
	createR2PresignedPutUrl,
	floorDateToSecond,
	presignR2DownloadUrl,
	r2DownloadUrlExpiresAt,
	r2DownloadUrlExpiresInSeconds,
	r2S3Endpoint,
} from "./presign";

describe("r2 presign", () => {
	it("creates a presigned R2 PUT URL", async () => {
		const uploadUrl = await createR2PresignedPutUrl({
			accessKeyId: "access-key-id",
			accountId: "account-id",
			bucketName: "main-bucket",
			expiresInSeconds: 1800,
			objectKey:
				"organizations/org-123/projects/project-123/zones/zone-123/scans/upload-123.zip",
			requiredHeaders: { "Content-Type": "application/zip" },
			secretAccessKey: "secret-access-key",
		});

		expect(uploadUrl).toStartWith(
			"https://account-id.r2.cloudflarestorage.com/main-bucket/organizations/org-123/projects/project-123/zones/zone-123/scans/upload-123.zip?",
		);
		expect(uploadUrl).toContain("X-Amz-Algorithm=AWS4-HMAC-SHA256");
		expect(uploadUrl).toContain("X-Amz-Credential=access-key-id%2F");
		expect(uploadUrl).toContain("%2Fauto%2Fs3%2Faws4_request");
		expect(uploadUrl).toContain("X-Amz-Expires=1800");
		expect(uploadUrl).toContain("X-Amz-SignedHeaders=content-type%3Bhost");
		expect(uploadUrl).toContain("X-Amz-Signature=");
	});

	it("creates a presigned R2 GET URL", async () => {
		const downloadUrl = await createR2PresignedGetUrl({
			accessKeyId: "access-key-id",
			accountId: "account-id",
			bucketName: "main-bucket",
			expiresInSeconds: 1800,
			objectKey:
				"organizations/org-123/projects/project-123/zones/zone-123/scans/upload-123.preview.bin",
			secretAccessKey: "secret-access-key",
		});

		expect(downloadUrl).toStartWith(
			"https://account-id.r2.cloudflarestorage.com/main-bucket/organizations/org-123/projects/project-123/zones/zone-123/scans/upload-123.preview.bin?",
		);
		expect(downloadUrl).toContain("X-Amz-Algorithm=AWS4-HMAC-SHA256");
		expect(downloadUrl).toContain("X-Amz-Expires=1800");
		expect(downloadUrl).toContain("X-Amz-SignedHeaders=host");
		expect(downloadUrl).toContain("X-Amz-Signature=");
	});

	it("targets the R2 S3 API when no endpoint override is set", () => {
		expect(
			r2S3Endpoint({ accountId: "account-id", bucketName: "main-bucket" }),
		).toBe("https://account-id.r2.cloudflarestorage.com/main-bucket");
	});

	it.each([
		["http://localhost:8787/cdn-cgi/local/r2/s3"],
		["http://localhost:8787/cdn-cgi/local/r2/s3/"],
		["  http://localhost:8787/cdn-cgi/local/r2/s3//  "],
	])("appends the bucket to the endpoint override %p", (endpointOverride) => {
		expect(
			r2S3Endpoint({
				accountId: "account-id",
				bucketName: "main-bucket-dev",
				endpointOverride,
			}),
		).toBe("http://localhost:8787/cdn-cgi/local/r2/s3/main-bucket-dev");
	});

	it.each([
		["http://localhost:8787/cdn-cgi/local/r2/s3/main-bucket-dev"],
		["http://localhost:8787/cdn-cgi/local/r2/s3/main-bucket-dev/"],
		["  http://localhost:8787/cdn-cgi/local/r2/s3/main-bucket-dev//  "],
	])(
		"does not double up the bucket when the override %p already ends in it",
		(endpointOverride) => {
			expect(
				r2S3Endpoint({
					accountId: "account-id",
					bucketName: "main-bucket-dev",
					endpointOverride,
				}),
			).toBe("http://localhost:8787/cdn-cgi/local/r2/s3/main-bucket-dev");
		},
	);

	it("only strips a whole trailing bucket segment", () => {
		expect(
			r2S3Endpoint({
				accountId: "account-id",
				bucketName: "main-bucket-dev",
				endpointOverride:
					"http://localhost:8787/cdn-cgi/local/r2/s3/not-main-bucket-dev",
			}),
		).toBe(
			"http://localhost:8787/cdn-cgi/local/r2/s3/not-main-bucket-dev/main-bucket-dev",
		);
	});

	it.each([[undefined], [""], ["   "]])(
		"falls back to the R2 S3 API for the blank override %p",
		(endpointOverride) => {
			expect(
				r2S3Endpoint({
					accountId: "account-id",
					bucketName: "main-bucket",
					endpointOverride,
				}),
			).toBe("https://account-id.r2.cloudflarestorage.com/main-bucket");
		},
	);

	it("presigns against the local endpoint when the override is set", async () => {
		const downloadUrl = await createR2PresignedGetUrl({
			accessKeyId: "local-r2-access-key",
			accountId: "account-id",
			bucketName: "main-bucket-dev",
			endpointOverride: "http://localhost:8787/cdn-cgi/local/r2/s3",
			expiresInSeconds: 1800,
			objectKey: "organizations/org-123/merged-point-cloud.laz",
			secretAccessKey: "local-r2-secret-key",
		});

		expect(downloadUrl).toStartWith(
			"http://localhost:8787/cdn-cgi/local/r2/s3/main-bucket-dev/organizations/org-123/merged-point-cloud.laz?",
		);
		expect(downloadUrl).toContain("X-Amz-Credential=local-r2-access-key%2F");
		expect(downloadUrl).toContain("X-Amz-Signature=");
	});

	it("uses a 30 minute default download URL expiry", () => {
		expect(r2DownloadUrlExpiresInSeconds).toBe(30 * 60);
	});

	it("floors dates to the whole second", () => {
		expect(floorDateToSecond(new Date("2026-01-02T03:04:05.789Z"))).toEqual(
			new Date("2026-01-02T03:04:05.000Z"),
		);
	});

	it("computes a download URL expiry floored to the second", () => {
		const before = Date.now();
		const expiresAt = r2DownloadUrlExpiresAt();
		const after = Date.now();

		expect(expiresAt.getMilliseconds()).toBe(0);
		expect(expiresAt.getTime()).toBeGreaterThanOrEqual(
			floorDateToSecond(new Date(before)).getTime() +
				r2DownloadUrlExpiresInSeconds * 1000,
		);
		expect(expiresAt.getTime()).toBeLessThanOrEqual(
			floorDateToSecond(new Date(after)).getTime() +
				r2DownloadUrlExpiresInSeconds * 1000,
		);
	});

	it("presigns a download URL from env bindings and returns a matching expiresAt", async () => {
		const objectKey =
			"organizations/org-123/projects/project-123/merged-point-cloud.laz";
		const env = {
			R2_ACCESS_KEY_ID: "access-key-id",
			CLOUDFLARE_ACCOUNT_ID: "account-id",
			R2_BUCKET_NAME: "main-bucket",
			R2_SECRET_ACCESS_KEY: "secret-access-key",
		} as unknown as CloudflareBindings;

		const { downloadUrl, expiresAt } = await presignR2DownloadUrl(
			env,
			objectKey,
		);

		expect(downloadUrl).toStartWith(
			"https://account-id.r2.cloudflarestorage.com/main-bucket/organizations/org-123/projects/project-123/merged-point-cloud.laz?",
		);
		expect(downloadUrl).toContain(
			`X-Amz-Expires=${r2DownloadUrlExpiresInSeconds}`,
		);
		expect(expiresAt.getTime()).toBeGreaterThan(Date.now());
	});
});
