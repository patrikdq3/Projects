import { and, eq } from "drizzle-orm";
import type { Context } from "hono";
import type { WorkerAppEnv } from "../app-env";
import { getDb } from "../db";
import { member } from "../db/schema/better-auth.schema";
import { getAuth, getAuthSession } from "./better-auth";
import type { statement } from "./better-auth/permissions";

type SessionUser = {
	id: string;
};

type RouteAccessError =
	| {
			error: "Unauthorized";
			ok: false;
			status: 401;
	  }
	| {
			error: "Forbidden";
			ok: false;
			status: 403;
	  };

type RouteAccessSuccess = {
	memberRole: string;
	ok: true;
	userId: string;
};

export type RouteAccessResult = RouteAccessError | RouteAccessSuccess;

type PermissionStatement = typeof statement;
type PermissionResource = keyof PermissionStatement;
export type RoutePermission = {
	[Resource in PermissionResource]: {
		[Key in Resource]: PermissionStatement[Resource][number][];
	};
}[PermissionResource];

type RouteAccessDependencies = {
	checkPermission?: (headers: Headers, orgId: string) => Promise<boolean>;

	getMembership: (input: {
		orgId: string;
		userId: string;
	}) => Promise<{ role: string } | null>;

	getSession: (headers: Headers) => Promise<{ user: SessionUser } | null>;
};

type RouteAccessInput = {
	headers: Headers;
	orgId: string;
};

export const createRouteAccessResolver =
	(dependencies: RouteAccessDependencies) =>
	async ({ headers, orgId }: RouteAccessInput): Promise<RouteAccessResult> => {
		const session = await dependencies.getSession(headers);

		if (!session?.user?.id) {
			return {
				error: "Unauthorized",
				ok: false,
				status: 401,
			};
		}

		const organizationMembership = await dependencies.getMembership({
			orgId,
			userId: session.user.id,
		});

		if (!organizationMembership) {
			return {
				error: "Forbidden",
				ok: false,
				status: 403,
			};
		}

		if (dependencies.checkPermission) {
			const permitted = await dependencies.checkPermission(headers, orgId);

			if (!permitted) {
				return {
					error: "Forbidden",
					ok: false,
					status: 403,
				};
			}
		}

		return {
			memberRole: organizationMembership.role,
			ok: true,
			userId: session.user.id,
		};
	};

export const resolveRouteAccess = (
	env: WorkerAppEnv["Bindings"],
	headers: Headers,
	orgId: string,
	permissions: RoutePermission,
) =>
	createRouteAccessResolver({
		checkPermission: async (requestHeaders, orgId) => {
			const result = await getAuth(env).api.hasPermission({
				headers: requestHeaders,
				body: { permissions, organizationId: orgId },
			});
			return result.success;
		},
		getMembership: async ({ orgId, userId }) => {
			const db = getDb(env);
			const result = await db
				.select({ role: member.role })
				.from(member)
				.where(and(eq(member.organizationId, orgId), eq(member.userId, userId)))
				.get();
			return result ?? null;
		},
		getSession: async (requestHeaders) => {
			const session = await getAuthSession(env, requestHeaders);
			return session ? { user: { id: session.user.id } } : null;
		},
	})({ headers, orgId });

export const respondToRouteAccessError = (
	c: Context<WorkerAppEnv>,
	access: Extract<RouteAccessResult, { ok: false }>,
) =>
	access.status === 401
		? c.json({ error: "Unauthorized" as const }, 401)
		: c.json({ error: "Forbidden" as const }, 403);
