import { AwsClient } from "aws4fetch";
import type { WorkerAppEnv } from "../../app-env";

const knownEc2States = [
	"pending",
	"running",
	"shutting-down",
	"terminated",
	"stopping",
	"stopped",
] as const;

type KnownEc2State = (typeof knownEc2States)[number];

export type Ec2State = KnownEc2State | "unknown";

const isKnownEc2State = (value: string): value is KnownEc2State =>
	(knownEc2States as readonly string[]).includes(value);

export type StartEc2Action =
	| "already-running"
	| "start-requested"
	| "waiting-for-stop"
	| "unstartable";

export type StartEc2Result = {
	instanceId: string;
	previousState: Ec2State;
	action: StartEc2Action;
};

export class Ec2ApiError extends Error {
	readonly action: string;
	readonly status: number;
	readonly code: string | null;

	constructor(action: string, status: number, responseBody: string) {
		super(`AWS EC2 ${action} failed: ${status} ${responseBody}`);
		this.name = "Ec2ApiError";
		this.action = action;
		this.status = status;
		this.code = parseEc2ErrorCode(responseBody);
	}
}

const requireEnv = (value: string | undefined, name: string): string => {
	if (!value) {
		throw new Error(`Missing required environment variable: ${name}`);
	}

	return value;
};

const createEc2Client = (env: WorkerAppEnv["Bindings"]) => {
	return new AwsClient({
		accessKeyId: requireEnv(env.AWS_ACCESS_KEY_ID, "AWS_ACCESS_KEY_ID"),
		secretAccessKey: requireEnv(
			env.AWS_SECRET_ACCESS_KEY,
			"AWS_SECRET_ACCESS_KEY",
		),
		region: requireEnv(env.AWS_REGION, "AWS_REGION"),
		service: "ec2",
	});
};

const ec2Endpoint = (region: string) => `https://ec2.${region}.amazonaws.com/`;

export const parseEc2ErrorCode = (responseBody: string): string | null =>
	responseBody.match(/<Code>([^<]+)<\/Code>/)?.[1] ?? null;

export const parseEc2InstanceState = (describeXml: string): Ec2State => {
	const stateName = describeXml.match(
		/<instanceState>\s*<code>\d+<\/code>\s*<name>([^<]+)<\/name>\s*<\/instanceState>/,
	)?.[1];

	return stateName !== undefined && isKnownEc2State(stateName)
		? stateName
		: "unknown";
};

export const resolveStartActionForState = (
	state: Ec2State,
): Exclude<StartEc2Action, "start-requested"> | "start" => {
	switch (state) {
		case "pending":
		case "running":
			return "already-running";
		case "stopping":
			return "waiting-for-stop";
		case "shutting-down":
		case "terminated":
			return "unstartable";
		case "stopped":
		case "unknown":
			return "start";
		default: {
			const unhandled: never = state;
			throw new RangeError(
				`Unhandled EC2 instance state: ${String(unhandled)}`,
			);
		}
	}
};

const callEc2 = async (
	env: WorkerAppEnv["Bindings"],
	action: string,
	params: Record<string, string>,
) => {
	const region = requireEnv(env.AWS_REGION, "AWS_REGION");
	const client = createEc2Client(env);

	const body = new URLSearchParams({
		Action: action,
		Version: "2016-11-15",
		...params,
	}).toString();

	const response = await client.fetch(ec2Endpoint(region), {
		method: "POST",
		headers: {
			"Content-Type": "application/x-www-form-urlencoded; charset=utf-8",
		},
		body,
	});

	if (!response.ok) {
		throw new Ec2ApiError(action, response.status, await response.text());
	}

	return response.text();
};

export const startEc2Instance = async (
	env: WorkerAppEnv["Bindings"],
): Promise<StartEc2Result> => {
	const instanceId = requireEnv(env.EC2_INSTANCE_ID, "EC2_INSTANCE_ID");

	const describeXml = await callEc2(env, "DescribeInstances", {
		"InstanceId.1": instanceId,
	});
	const previousState = parseEc2InstanceState(describeXml);
	const resolvedAction = resolveStartActionForState(previousState);

	if (resolvedAction !== "start") {
		return { instanceId, previousState, action: resolvedAction };
	}

	try {
		await callEc2(env, "StartInstances", {
			"InstanceId.1": instanceId,
		});
	} catch (error) {
		// The instance can transition (e.g. into "stopping") between the
		// describe and start calls; treat that as retryable, not fatal.
		if (
			error instanceof Ec2ApiError &&
			error.code === "IncorrectInstanceState"
		) {
			return { instanceId, previousState, action: "waiting-for-stop" };
		}
		throw error;
	}

	return { instanceId, previousState, action: "start-requested" };
};
