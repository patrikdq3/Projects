import { DurableObject } from "cloudflare:workers";
import { appLogger } from "../logger";
import { type StartEc2Result, startEc2Instance } from "./ec2";

const RETRY_DELAY_MS = 15_000;
// A stopping instance usually reaches "stopped" within a minute or two, but a
// hung shutdown can take AWS several minutes to force-stop.
const MAX_RETRY_ATTEMPTS = 40;
const ATTEMPT_STORAGE_KEY = "retry-attempt";
const START_IN_PROGRESS_STORAGE_KEY = "start-in-progress-at";

/**
 * Retries EC2 start attempts via storage alarms while the instance is
 * mid-transition ("stopping" cannot be started until it reaches "stopped").
 *
 * Concurrent RPCs in the same Durable Object instance share the in-flight AWS
 * call and receive its real result. A running alarm can still interleave with
 * an RPC; that is safe because DescribeInstances is read-only, the one
 * transitional failure (IncorrectInstanceState) is handled as retryable, and at
 * most one retry alarm is ever scheduled, so all callers share one retry loop.
 */
export class Ec2InstanceStarter extends DurableObject<CloudflareBindings> {
	private startPromise: Promise<StartEc2Result> | null = null;

	async ensureRunning(): Promise<StartEc2Result> {
		if (!this.startPromise) {
			this.startPromise = this.startEc2Instance();
		}
		return this.startPromise;
	}

	private async startEc2Instance(): Promise<StartEc2Result> {
		try {
			await this.ctx.storage.put(START_IN_PROGRESS_STORAGE_KEY, Date.now());
			const result = await startEc2Instance(this.env);

			if (result.action === "waiting-for-stop") {
				// A fresh caller renews the bounded retry window while the instance is
				// still stopping, so a recent enqueue is not cut short by older attempts.
				await this.ctx.storage.put(ATTEMPT_STORAGE_KEY, 0);
				if ((await this.ctx.storage.getAlarm()) === null) {
					await this.ctx.storage.setAlarm(Date.now() + RETRY_DELAY_MS);
				}
			}

			return result;
		} finally {
			await this.ctx.storage.delete(START_IN_PROGRESS_STORAGE_KEY);
			this.startPromise = null;
		}
	}

	async alarm(): Promise<void> {
		const durableObjectId = this.ctx.id.toString();
		const attempt =
			((await this.ctx.storage.get<number>(ATTEMPT_STORAGE_KEY)) ?? 0) + 1;
		// Persist the incremented counter BEFORE the AWS call. The await below
		// is an interleave point; a counter write after it could stomp the
		// reset a concurrent ensureRunning() writes to renew the retry budget,
		// making the loop give up on a freshly requested start.
		await this.ctx.storage.put(ATTEMPT_STORAGE_KEY, attempt);
		const result = await startEc2Instance(this.env);

		if (result.action === "waiting-for-stop") {
			if (attempt >= MAX_RETRY_ATTEMPTS) {
				await this.ctx.storage.delete(ATTEMPT_STORAGE_KEY);
				appLogger
					.withMetadata({ ...result, attempt, durableObjectId })
					.error("Gave up starting EC2 instance while it was stopping");
				return;
			}

			await this.ctx.storage.setAlarm(Date.now() + RETRY_DELAY_MS);
			return;
		}

		await this.ctx.storage.delete(ATTEMPT_STORAGE_KEY);

		if (result.action === "unstartable") {
			appLogger
				.withMetadata({ ...result, attempt, durableObjectId })
				.error("EC2 instance can no longer be started");
			return;
		}

		appLogger
			.withMetadata({ ...result, attempt, durableObjectId })
			.info("EC2 instance start retry succeeded");
	}
}
