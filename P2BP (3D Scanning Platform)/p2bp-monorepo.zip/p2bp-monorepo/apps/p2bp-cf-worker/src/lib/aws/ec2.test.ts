import { describe, expect, it } from "bun:test";
import {
	Ec2ApiError,
	type Ec2State,
	parseEc2ErrorCode,
	parseEc2InstanceState,
	resolveStartActionForState,
} from "./ec2";

const describeXmlForState = (code: number, name: string) => `
<DescribeInstancesResponse xmlns="http://ec2.amazonaws.com/doc/2016-11-15/">
	<reservationSet>
		<item>
			<instancesSet>
				<item>
					<instanceId>i-0123456789abcdef0</instanceId>
					<instanceState>
						<code>${code}</code>
						<name>${name}</name>
					</instanceState>
				</item>
			</instancesSet>
		</item>
	</reservationSet>
</DescribeInstancesResponse>`;

describe("parseEc2InstanceState", () => {
	it.each([
		[0, "pending"],
		[16, "running"],
		[64, "stopping"],
		[80, "stopped"],
	] as const)("parses state code %d as %s", (code, name) => {
		expect(parseEc2InstanceState(describeXmlForState(code, name))).toBe(name);
	});

	it("returns unknown when no instance state is present", () => {
		expect(parseEc2InstanceState("<DescribeInstancesResponse/>")).toBe(
			"unknown",
		);
	});

	it("returns unknown for an unrecognized state name", () => {
		expect(parseEc2InstanceState(describeXmlForState(128, "hibernating"))).toBe(
			"unknown",
		);
	});
});

describe("parseEc2ErrorCode", () => {
	it("extracts the error code from an EC2 error response", () => {
		expect(
			parseEc2ErrorCode(
				`<Response><Errors><Error><Code>IncorrectInstanceState</Code><Message>The instance 'i-0123456789abcdef0' is not in a state from which it can be started.</Message></Error></Errors></Response>`,
			),
		).toBe("IncorrectInstanceState");
	});

	it("returns null when no error code is present", () => {
		expect(parseEc2ErrorCode("not xml")).toBeNull();
	});
});

describe("Ec2ApiError", () => {
	it("captures the action, status, and parsed error code", () => {
		const error = new Ec2ApiError(
			"StartInstances",
			400,
			"<Response><Errors><Error><Code>IncorrectInstanceState</Code></Error></Errors></Response>",
		);
		expect(error.action).toBe("StartInstances");
		expect(error.status).toBe(400);
		expect(error.code).toBe("IncorrectInstanceState");
		expect(error.message).toContain("AWS EC2 StartInstances failed: 400");
	});
});

describe("resolveStartActionForState", () => {
	it.each([
		["pending", "already-running"],
		["running", "already-running"],
		["stopping", "waiting-for-stop"],
		["shutting-down", "unstartable"],
		["terminated", "unstartable"],
		["stopped", "start"],
		["unknown", "start"],
	] as const)("maps %s to %s", (state, action) => {
		expect(resolveStartActionForState(state)).toBe(action);
	});

	it("throws RangeError for an unhandled state", () => {
		expect(() => resolveStartActionForState("hibernating" as Ec2State)).toThrow(
			RangeError,
		);
	});
});
