import { z } from "@hono/zod-openapi";

export const latitudeConstraints = {
	min: -90,
	max: 90,
} as const;

export const longitudeConstraints = {
	min: -180,
	max: 180,
} as const;

export const LatitudeSchema = z
	.number()
	.min(latitudeConstraints.min)
	.max(latitudeConstraints.max);

export const LongitudeSchema = z
	.number()
	.min(longitudeConstraints.min)
	.max(longitudeConstraints.max);
