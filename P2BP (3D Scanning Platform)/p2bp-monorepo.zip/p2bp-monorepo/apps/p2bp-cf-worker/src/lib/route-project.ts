import { and, eq } from "drizzle-orm";
import type { Context } from "hono";
import type { WorkerAppEnv } from "../app-env";
import { getDb } from "../db";
import { projects } from "../db/schema/app.schema";
import {
	type RoutePermission,
	resolveRouteAccess,
	respondToRouteAccessError,
} from "./route-access";

type RouteDb = ReturnType<typeof getDb>;

type DefaultRouteProject = {
	id: string;
};

type RouteProjectLoader<TProject> = (input: {
	db: RouteDb;
	orgId: string;
	projectId: string;
}) => Promise<TProject | null | undefined>;

type LoadRouteProjectInput<TProject, TContext extends Context<WorkerAppEnv>> = {
	c: TContext;
	getProject?: RouteProjectLoader<TProject>;
	orgId: string;
	permission: RoutePermission;
	projectId: string;
};

const getDefaultRouteProject: RouteProjectLoader<DefaultRouteProject> = ({
	db,
	orgId,
	projectId,
}) =>
	db
		.select({ id: projects.id })
		.from(projects)
		.where(and(eq(projects.id, projectId), eq(projects.organizationId, orgId)))
		.get();

export const loadRouteProject = async <
	TProject = DefaultRouteProject,
	TContext extends Context<WorkerAppEnv> = Context<WorkerAppEnv>,
>({
	c,
	getProject,
	orgId,
	permission,
	projectId,
}: LoadRouteProjectInput<TProject, TContext> &
	// Omitting `getProject` falls back to the default {id} loader, so it is
	// only sound when a default row satisfies TProject; require an explicit
	// loader for any richer project shape.
	(DefaultRouteProject extends TProject
		? unknown
		: { getProject: RouteProjectLoader<TProject> })) => {
	const access = await resolveRouteAccess(
		c.env,
		c.req.raw.headers,
		orgId,
		permission,
	);

	if (!access.ok) {
		return {
			ok: false as const,
			response: respondToRouteAccessError(c, access),
		};
	}

	const db = getDb(c.env);
	// Safe by construction: `getProject` may only be omitted when the
	// conditional constraint above proves DefaultRouteProject extends TProject.
	const loader =
		getProject ?? (getDefaultRouteProject as RouteProjectLoader<TProject>);
	const project = await loader({ db, orgId, projectId });

	if (!project) {
		return {
			ok: false as const,
			response: c.json({ error: "Not found" as const }, 404),
		};
	}

	return { db, ok: true as const, project };
};
