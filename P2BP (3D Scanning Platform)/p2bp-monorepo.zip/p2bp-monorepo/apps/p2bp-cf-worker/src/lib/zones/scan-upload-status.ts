export const zoneScanUploadStatuses = [
	"pending",
	"uploaded",
	"expired",
] as const;

export type ZoneScanUploadStatus = (typeof zoneScanUploadStatuses)[number];
