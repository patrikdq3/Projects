export const METERS_PER_DEGREE_LATITUDE = 111_320;
export const zoneGenerationConstraints = {
	insertChunkSize: 10,
	maxCandidateZones: 10_000,
	maxGeneratedZones: 5_000,
} as const;

const MIN_ZONE_OVERLAP_RATIO = 0.05;

type MeterPoint = {
	x: number;
	y: number;
};

type LatLongPoint = {
	latitude: number;
	longitude: number;
};

export type ZoneGridCell = {
	x: number;
	y: number;
};

type GridSquare = {
	maxX: number;
	maxY: number;
	minX: number;
	minY: number;
};

export class ZoneGenerationLimitError extends Error {
	constructor(
		message = "Project boundary and zone size would generate too many zones.",
	) {
		super(message);
		this.name = "ZoneGenerationLimitError";
	}
}

const toRadians = (degrees: number) => (degrees * Math.PI) / 180;

export const metersPerDegreeLongitude = (latitude: number) =>
	METERS_PER_DEGREE_LATITUDE * Math.cos(toRadians(latitude));

const toMeterPoint = ({
	initialLat,
	initialLong,
	metersPerLongDegree,
	point,
}: {
	initialLat: number;
	initialLong: number;
	metersPerLongDegree: number;
	point: LatLongPoint;
}): MeterPoint => ({
	x: (point.longitude - initialLong) * metersPerLongDegree,
	y: (point.latitude - initialLat) * METERS_PER_DEGREE_LATITUDE,
});

const squareForZone = ({
	x,
	y,
	zoneSize,
}: {
	x: number;
	y: number;
	zoneSize: number;
}): GridSquare => ({
	maxX: (x + 1) * zoneSize,
	maxY: (y + 1) * zoneSize,
	minX: x * zoneSize,
	minY: y * zoneSize,
});

const clipPolygon = ({
	getIntersection,
	isInside,
	polygon,
}: {
	getIntersection: (start: MeterPoint, end: MeterPoint) => MeterPoint;
	isInside: (point: MeterPoint) => boolean;
	polygon: MeterPoint[];
}) => {
	const clippedPolygon: MeterPoint[] = [];

	for (let index = 0; index < polygon.length; index++) {
		const current = polygon[index];
		const previous = polygon[(index + polygon.length - 1) % polygon.length];
		const currentInside = isInside(current);
		const previousInside = isInside(previous);

		if (currentInside) {
			if (!previousInside) {
				clippedPolygon.push(getIntersection(previous, current));
			}

			clippedPolygon.push(current);
		} else if (previousInside) {
			clippedPolygon.push(getIntersection(previous, current));
		}
	}

	return clippedPolygon;
};

const getVerticalIntersection =
	(x: number) => (start: MeterPoint, end: MeterPoint) => {
		const ratio = (x - start.x) / (end.x - start.x);

		return {
			x,
			y: start.y + ratio * (end.y - start.y),
		};
	};

const getHorizontalIntersection =
	(y: number) => (start: MeterPoint, end: MeterPoint) => {
		const ratio = (y - start.y) / (end.y - start.y);

		return {
			x: start.x + ratio * (end.x - start.x),
			y,
		};
	};

const clipPolygonToSquare = (polygon: MeterPoint[], square: GridSquare) =>
	[
		{
			getIntersection: getVerticalIntersection(square.minX),
			isInside: (point: MeterPoint) => point.x >= square.minX,
		},
		{
			getIntersection: getVerticalIntersection(square.maxX),
			isInside: (point: MeterPoint) => point.x <= square.maxX,
		},
		{
			getIntersection: getHorizontalIntersection(square.minY),
			isInside: (point: MeterPoint) => point.y >= square.minY,
		},
		{
			getIntersection: getHorizontalIntersection(square.maxY),
			isInside: (point: MeterPoint) => point.y <= square.maxY,
		},
	].reduce(
		(clippedPolygon, edge) =>
			clippedPolygon.length === 0
				? clippedPolygon
				: clipPolygon({ ...edge, polygon: clippedPolygon }),
		polygon,
	);

const polygonArea = (polygon: MeterPoint[]) =>
	Math.abs(
		polygon.reduce((area, point, index) => {
			const nextPoint = polygon[(index + 1) % polygon.length];

			return area + point.x * nextPoint.y - nextPoint.x * point.y;
		}, 0),
	) / 2;

const getSquarePolygonOverlapArea = (
	square: GridSquare,
	polygon: MeterPoint[],
) => {
	const clippedPolygon = clipPolygonToSquare(polygon, square);
	return polygonArea(clippedPolygon);
};

export const buildGeneratedZoneGridCells = ({
	boundary,
	initialLat,
	initialLong,
	zoneSize,
}: {
	boundary: LatLongPoint[];
	initialLat: number;
	initialLong: number;
	zoneSize: number;
}): ZoneGridCell[] => {
	const metersPerLongDegree = metersPerDegreeLongitude(initialLat);
	const polygon = boundary.map((point) =>
		toMeterPoint({ initialLat, initialLong, metersPerLongDegree, point }),
	);
	const xValues = polygon.map(({ x }) => x);
	const yValues = polygon.map(({ y }) => y);
	const minX = Math.floor(Math.min(...xValues) / zoneSize);
	const maxX = Math.ceil(Math.max(...xValues) / zoneSize) - 1;
	const minY = Math.floor(Math.min(...yValues) / zoneSize);
	const maxY = Math.ceil(Math.max(...yValues) / zoneSize) - 1;
	const candidateZoneCount = (maxX - minX + 1) * (maxY - minY + 1);

	if (candidateZoneCount > zoneGenerationConstraints.maxCandidateZones) {
		throw new ZoneGenerationLimitError();
	}

	const gridCells: ZoneGridCell[] = [];
	let fallbackGridCell: ZoneGridCell | null = null;
	let fallbackOverlapArea = 0;

	for (let x = minX; x <= maxX; x++) {
		for (let y = minY; y <= maxY; y++) {
			const square = squareForZone({ x, y, zoneSize });
			const overlapArea = getSquarePolygonOverlapArea(square, polygon);
			const squareArea =
				(square.maxX - square.minX) * (square.maxY - square.minY);

			if (overlapArea > fallbackOverlapArea) {
				fallbackGridCell = { x, y };
				fallbackOverlapArea = overlapArea;
			}

			if (overlapArea / squareArea < MIN_ZONE_OVERLAP_RATIO) {
				continue;
			}

			gridCells.push({ x, y });

			if (gridCells.length > zoneGenerationConstraints.maxGeneratedZones) {
				throw new ZoneGenerationLimitError();
			}
		}
	}

	if (gridCells.length === 0 && fallbackGridCell !== null) {
		gridCells.push(fallbackGridCell);
	}

	return gridCells;
};

export const buildZoneCorners = ({
	initialLat,
	initialLong,
	x,
	y,
	zoneSize,
}: {
	initialLat: number;
	initialLong: number;
	x: number;
	y: number;
	zoneSize: number;
}): LatLongPoint[] => {
	const metersPerLongDegree = metersPerDegreeLongitude(initialLat);
	const minX = x * zoneSize;
	const maxX = (x + 1) * zoneSize;
	const minY = y * zoneSize;
	const maxY = (y + 1) * zoneSize;
	const toLatLong = ({ x, y }: MeterPoint): LatLongPoint => ({
		latitude: initialLat + y / METERS_PER_DEGREE_LATITUDE,
		longitude: initialLong + x / metersPerLongDegree,
	});

	return [
		toLatLong({ x: minX, y: minY }),
		toLatLong({ x: maxX, y: minY }),
		toLatLong({ x: maxX, y: maxY }),
		toLatLong({ x: minX, y: maxY }),
	];
};
