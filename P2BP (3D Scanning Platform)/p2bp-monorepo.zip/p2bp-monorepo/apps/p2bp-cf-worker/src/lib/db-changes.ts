// D1 reports the affected row count on `meta.changes`; the bun-sqlite driver
// used by the migration-backed tests reports it on `changes`. Read whichever
// this driver provides so guarded-update "did my write win?" checks behave
// identically under both.
export const readRowChanges = (result: unknown): number => {
	if (typeof result !== "object" || result === null) return 0;
	const meta = (result as { meta?: { changes?: number } }).meta;
	if (meta && typeof meta.changes === "number") return meta.changes;
	const changes = (result as { changes?: number }).changes;
	return typeof changes === "number" ? changes : 0;
};
