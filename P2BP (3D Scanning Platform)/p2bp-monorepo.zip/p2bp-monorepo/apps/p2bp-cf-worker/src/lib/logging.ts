import { type HonoLogLayerVariables, honoLogLayer } from "@loglayer/hono";
import type { MiddlewareHandler } from "hono";
import type { WorkerAppEnv } from "../app-env";
import { appLogger } from "./logger";

type HonoLogLayerEnv = {
	Variables: HonoLogLayerVariables;
};

// `@loglayer/hono` only models the logger variables it adds, so widen it once
// to our full app env shape before routing requests through the middleware.
const toAppLogMiddleware = (middleware: MiddlewareHandler<HonoLogLayerEnv>) => {
	return middleware as unknown as MiddlewareHandler<WorkerAppEnv>;
};

const structuredLoggingMiddleware = toAppLogMiddleware(
	honoLogLayer({
		instance: appLogger,
	}),
);

export const loggingMiddleware: MiddlewareHandler<WorkerAppEnv> =
	structuredLoggingMiddleware;
