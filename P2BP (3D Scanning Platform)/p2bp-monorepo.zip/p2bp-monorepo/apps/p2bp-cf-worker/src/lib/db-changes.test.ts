import { describe, expect, it } from "bun:test";
import { readRowChanges } from "./db-changes";

describe("readRowChanges", () => {
	it("reads the D1 meta.changes shape", () => {
		expect(readRowChanges({ meta: { changes: 3 } })).toBe(3);
		expect(readRowChanges({ meta: { changes: 0 } })).toBe(0);
	});

	it("reads the bun-sqlite changes shape", () => {
		expect(readRowChanges({ changes: 2, lastInsertRowid: 5 })).toBe(2);
		expect(readRowChanges({ changes: 0 })).toBe(0);
	});

	it("prefers meta.changes when both are present", () => {
		expect(readRowChanges({ meta: { changes: 1 }, changes: 9 })).toBe(1);
	});

	it("defaults to 0 for unrecognized shapes", () => {
		expect(readRowChanges({})).toBe(0);
		expect(readRowChanges(null)).toBe(0);
		expect(readRowChanges(undefined)).toBe(0);
		expect(readRowChanges({ meta: {} })).toBe(0);
	});
});
