import { betterAuth } from "better-auth";
import { drizzleAdapter } from "better-auth/adapters/drizzle";
import { drizzle } from "drizzle-orm/d1";
import * as schema from "./src/db/schema";
import { createBetterAuthOptions } from "./src/lib/better-auth/options";

const { BASE_URL, BETTER_AUTH_SECRET, DB } = process.env;
const SCHEMA_GENERATION_BASE_URL = "http://localhost:8787";
const SCHEMA_GENERATION_SECRET = "schema-generation-only-secret-000000000000";

const db = drizzle(DB as unknown as D1Database);

export const auth = betterAuth({
	...createBetterAuthOptions(process.env),
	database: drizzleAdapter(db, { provider: "sqlite", schema }), // schema is required in order for bettter-auth to recognize
	baseURL: BASE_URL ?? SCHEMA_GENERATION_BASE_URL,
	secret: BETTER_AUTH_SECRET ?? SCHEMA_GENERATION_SECRET,
});
