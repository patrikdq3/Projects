# Development

This repo uses Bun, Wrangler, Hono, Better Auth, Drizzle ORM, Cloudflare D1, and Biome. Prefer Bun commands for local work:

```txt
bun install
bun run dev
bunx tsc --noEmit
bun run cf-typegen
```

Wrangler sets `ENVIRONMENT` as a Worker var for `dev`, `staging`, and `production`, and `src/lib/logging.ts` emits structured logs in every environment.

## Daily Workflow

Install dependencies:

```txt
bun install
```

Run the Worker locally:

```txt
bun run dev
```

Wrangler reads the local defaults from `.env` for this workflow.

Typecheck before opening a change:

```txt
bunx tsc --noEmit
```

Regenerate Worker binding types after changing `wrangler.jsonc`:

```txt
bun run cf-typegen
```

Biome is configured in `biome.json` for formatting, linting, and import organization. `worker-configuration.d.ts` is excluded from linting only.

## Cloudflare Object Policy

Do not commit account-specific Cloudflare object IDs to `wrangler.jsonc`.

That includes generated IDs for objects such as:

- D1 databases
- KV namespaces
- Queues
- Durable Objects resources, if an ID is generated for the workflow
- Any future Cloudflare object with an account-specific identifier

Committed Wrangler config should contain stable binding names and, where the platform supports it, stable object names. For this project, the D1 database binding is `DB`, with shared database names split by environment: `main-database-dev`, `main-database-staging`, and `main-database-production`.

The current `wrangler.jsonc` also declares required secrets for:

- `BETTER_AUTH_SECRET`
- `BASE_URL`
- `EMAIL_FROM_DOMAIN`
- `CLOUDFLARE_ACCOUNT_ID`
- `CLOUDFLARE_MAIN_DATABASE_ID`
- `CLOUDFLARE_D1_TOKEN`

`EMAIL_FROM_DOMAIN` must be a domain onboarded for Cloudflare Email Service sending. Auth emails are sent from `noreply@${EMAIL_FROM_DOMAIN}`. Remote Drizzle migrations read those values from env. `drizzle.config.ts` imports `dotenv/config`, so the preferred local pattern is to keep day-to-day values in `.env` and use `bun --env-file=...` only when you intentionally select a non-default env file. Doppler or any other env manager remains optional:

```txt
# Primary: file-based env files
bun --env-file=.env.dev run db:migrate:remote
bun --env-file=.env.staging run db:migrate:remote
bun --env-file=.env.production run db:migrate:remote

# Optional: Doppler
doppler run -c dev -- bun run db:migrate:remote
doppler run -c stg -- bun run db:migrate:remote
doppler run -c prd -- bun run db:migrate:remote
```

Use `bun run deploy:dev`, `bun run deploy:staging`, and `bun run deploy:production` to publish the Worker for each Cloudflare environment. Remote database setup and migrations should go through Drizzle with the target environment variables. If Wrangler writes generated IDs back into config, keep them local and remove them before committing.

Keep generated IDs and secrets in ignored local files such as `.env`, or in deployment environment or CI secrets.

Fresh setup order for a new checkout:

1. Run `bun install` and `bunx wrangler login`.
2. Configure local secrets with `.env`. An env manager is optional.
3. Verify local dev with `bun run db:migrate:local:dev` and `bun run dev`.
4. For each remote environment, push secrets to the Worker, deploy, record the new `CLOUDFLARE_MAIN_DATABASE_ID`, update your secrets source, push secrets again, then run `bun run db:migrate:remote` with that environment's `CLOUDFLARE_*` values loaded. If you keep separate remote env files such as `.env.<target>`, load the right one with `bun --env-file=...`.

## Schema Changes

The Drizzle schema lives under `src/db/schema/`, with Better Auth generated tables in `better-auth.schema.ts`, app-owned tables in `app.schema.ts`, and generated migrations under `drizzle/`.

`src/db/schema/app.schema.ts` is currently a placeholder for future app-owned tables.

When Better Auth schema changes are needed, use the existing generator instead of hand-editing generated auth tables:

```txt
bun run better-auth-gen-schema
```

`bun run better-auth-gen-schema` uses the repo's pinned Better Auth CLI devDependency, so schema generation stays on the checked-in lockfile instead of resolving `auth@latest` at runtime.

The schema generator is intentionally decoupled from local Better Auth and Google OAuth secrets, so it can run without Doppler or a populated `.env`.

Because the Better Auth CLI loads `better-auth.config.ts` outside the normal app build, TSX modules on that import path should declare their JSX runtime explicitly. Hono JSX email templates under `src/lib/better-auth/` use `/** @jsxImportSource hono/jsx */` so schema generation does not try to resolve `react/jsx-runtime`.

After editing schema files, generate a Drizzle migration:

```txt
bun run db:generate
```

Apply pending migrations to the D1 environment you want to update:

```txt
bun run db:migrate:local:dev
bun --env-file=.env.dev run db:migrate:remote
```

`bun run db:migrate:local:dev` still targets Wrangler's local `dev` environment so the local D1 schema matches the database used by `bun run dev`.

Remote migrations intentionally go through Drizzle's D1 HTTP driver instead of Wrangler so they use the target environment's `CLOUDFLARE_MAIN_DATABASE_ID` from a file-based env file, Doppler, or another env provider rather than requiring a local `database_id` in `wrangler.jsonc`.

List pending local migrations with:

```txt
bun run db:migrate:local:dev:list
```

## Auth Notes

Better Auth is configured in `src/lib/better-auth/options.ts` and mounted from `src/index.ts`.

The current setup enables:

- Email and password
- Passkeys
- Two-factor auth with `allowPasswordless: true`
- Organizations with user-created organizations enabled

Passkeys are intentionally allowed as an alternative sign-in path instead of requiring both passkey and 2FA in the same login flow.

## Before Opening a Change

Run:

```txt
bunx tsc --noEmit
```

If you changed `wrangler.jsonc`, also run:

```txt
bun run cf-typegen
```

If you changed schema files or migrations, run the relevant Drizzle and local migration commands before handing off.
