# P2BP

P2BP is a Bun-based TypeScript Cloudflare Worker built with Hono, Better Auth, Drizzle ORM, and Cloudflare D1.

## Requirements

- Bun
- A Cloudflare account
- Wrangler, run through the local project dependency with `bunx wrangler ...`

Install dependencies:

```txt
bun install
```

Log in to Cloudflare if needed:

```txt
bunx wrangler login
```

## Project Shape

- Worker entrypoint: `src/index.ts`
- Better Auth options: `src/lib/better-auth/options.ts`
- Better Auth Worker binding setup: `src/lib/better-auth/index.ts`
- Drizzle schema: `src/db/schema/`
- Generated migrations: `drizzle/`
- Wrangler config: `wrangler.jsonc`

The app currently mounts Better Auth at `/api/auth/*`, serves `Hello Hono!` from `/api`, and exposes the OpenAPI docs at `/api/open-api` with Scalar at `/api/scalar`.

Auth currently enables:

- Email and password
- Passkeys
- Two-factor auth
- Organizations

Two-factor auth is configured with `allowPasswordless: true`, so passkey login is intentionally allowed as an alternative to password-plus-2FA.

Wrangler also sets an `ENVIRONMENT` Worker var for `dev`, `staging`, and `production`, and the logging module emits structured logs in every environment.

## Cloudflare Resources

The Worker expects a D1 binding named `DB`. The committed `wrangler.jsonc` should describe shared binding names and shared object names, not account-specific generated IDs.

Use the environment-specific deploy scripts for the environment you want to publish:

```txt
bun run deploy:dev
bun run deploy:staging
bun run deploy:production
```

If Wrangler writes generated resource IDs back into local config, keep them local and do not commit them.

Drizzle's D1 HTTP tooling reads these values from local env:

```txt
CLOUDFLARE_ACCOUNT_ID=your-account-id
CLOUDFLARE_MAIN_DATABASE_ID=your-d1-database-id
CLOUDFLARE_D1_TOKEN=your-d1-api-token
```

`drizzle.config.ts` imports `dotenv/config`. Prefer `.env` for day-to-day work. When you intentionally use a non-default env file for remote migrations, load it explicitly with Bun so the active environment is visible in the command itself. Doppler or another env manager is still fine when you need it.

```txt
# Primary: file-based env files
bun --env-file=.env.dev run db:migrate:remote
bun --env-file=.env.staging run db:migrate:remote
bun --env-file=.env.production run db:migrate:remote

# Optional: Doppler
doppler run -c dev -- bun run db:migrate:remote
doppler run -c stg -- bun run db:migrate:remote
doppler run -c prd -- bun run db:migrate:remote
```

If you need to inspect remote D1 resources:

```txt
bunx wrangler d1 list
```

## From Scratch

### 1. Setup project and Wrangler login

Install dependencies and log in to Cloudflare:

```txt
bun install
bunx wrangler login
```

Set up local secrets:

- File-based local setup:
  - Create `.env`.
  - Put these keys in it:
    - `BETTER_AUTH_SECRET`
    - `BASE_URL=http://localhost:8787`
    - `EMAIL_FROM_DOMAIN`
    - `CLOUDFLARE_ACCOUNT_ID`
    - `CLOUDFLARE_D1_TOKEN`
    - `CLOUDFLARE_MAIN_DATABASE_ID`
- Optional env manager setup:
  - Supply the same keys with Doppler or another env provider when you do not want a local env file.

### 2. Verify local dev

Apply local migrations and run the Worker:

```txt
bun run db:migrate:local:dev
bun run dev
```

Wrangler and the local tooling in this repo both work with the default `.env`, so these local commands do not need `--env-file`.

If you prefer an env manager, wrap the same Bun commands with it instead:

```txt
doppler run -c dev_personal -- bun run db:migrate:local:dev
doppler run -c dev_personal -- bun run dev
```

Verify the API responds at `http://localhost:8787/api`, and check the docs at `http://localhost:8787/api/open-api`.

### 3. Remote environments

Repeat this sequence for remote `dev`, `staging`, and `production`:

1. Put the required secrets in your secrets source:
   - `BETTER_AUTH_SECRET`
   - `BASE_URL`
   - `EMAIL_FROM_DOMAIN`
   - `CLOUDFLARE_ACCOUNT_ID`
   - `CLOUDFLARE_D1_TOKEN`
   - `CLOUDFLARE_MAIN_DATABASE_ID`
2. Push secrets from your secrets source to the Worker.
3. Deploy the Worker.
4. Record the new `CLOUDFLARE_MAIN_DATABASE_ID` for that environment.
5. Store the new database ID back in your secrets manager or env file, then push secrets to the Worker again.
6. Run `bun run db:migrate:remote` with that environment's `CLOUDFLARE_*` values loaded. If you keep separate remote env files such as `.env.<target>`, load the right one with `bun --env-file=...`.

Secret push examples:

```txt
# Primary: file accepted by wrangler secret bulk
bunx wrangler secret bulk .secrets.dev.env --env dev
bunx wrangler secret bulk .secrets.stg.env --env staging
bunx wrangler secret bulk .secrets.prd.env

# Optional: Doppler
doppler secrets download -c dev --no-file --format json | bunx wrangler secret bulk --env dev
doppler secrets download -c stg --no-file --format json | bunx wrangler secret bulk --env staging
doppler secrets download -c prd --no-file --format json | bunx wrangler secret bulk
```

Deploy commands:

```txt
bun run deploy:dev
bun run deploy:staging
bun run deploy:production
```

Migration examples:

```txt
# Primary: file-based env files
bun --env-file=.env.dev run db:migrate:remote
bun --env-file=.env.staging run db:migrate:remote
bun --env-file=.env.production run db:migrate:remote

# Optional: Doppler
doppler run -c dev -- bun run db:migrate:remote
doppler run -c stg -- bun run db:migrate:remote
doppler run -c prd -- bun run db:migrate:remote
```

For file-based remote migrations, make sure the selected env file contains the target environment's `CLOUDFLARE_ACCOUNT_ID`, `CLOUDFLARE_MAIN_DATABASE_ID`, and `CLOUDFLARE_D1_TOKEN` before running the Bun command.

## Environment

Create local `.env` for Wrangler, Drizzle, and Better Auth tooling:

```txt
BASE_URL=http://localhost:8787
BETTER_AUTH_SECRET=replace-with-a-long-random-secret
EMAIL_FROM_DOMAIN=example.com
CLOUDFLARE_ACCOUNT_ID=your-account-id
CLOUDFLARE_MAIN_DATABASE_ID=your-d1-database-id
CLOUDFLARE_D1_TOKEN=your-d1-api-token
```

If you prefer per-environment files for remote migrations, use names such as `.env.dev`, `.env.staging`, and `.env.production` and load them with `bun --env-file=...`. These files are ignored by Git.

For deployed environments, configure secrets and environment variables in Cloudflare instead of committing local values:

```txt
bunx wrangler secret put BETTER_AUTH_SECRET
bunx wrangler secret put EMAIL_FROM_DOMAIN
```

Set `BASE_URL` to the deployed Worker URL for the target environment.
Set `EMAIL_FROM_DOMAIN` to a domain onboarded for Cloudflare Email Service sending. Auth emails are sent from `noreply@${EMAIL_FROM_DOMAIN}`.

## Database Setup

The Drizzle schema lives under `src/db/schema/`.

- Better Auth generated tables live in `src/db/schema/better-auth.schema.ts`
- App-owned tables belong in `src/db/schema/app.schema.ts`
- `src/db/schema/app.schema.ts` is currently a placeholder

After changing the schema, generate a migration:

```txt
bun run db:generate
```

Apply pending migrations to the environment you want to update:

```txt
bun run db:migrate:local:dev
bun --env-file=.env.dev run db:migrate:remote
```

`bun run db:migrate:local:dev` still targets Wrangler's local `dev` D1 database so the local schema matches the database used by `bun run dev`.

Remote migrations should use `bun --env-file=.env.<target> run db:migrate:remote` with `CLOUDFLARE_ACCOUNT_ID`, `CLOUDFLARE_MAIN_DATABASE_ID`, and `CLOUDFLARE_D1_TOKEN` supplied by a file-based env file, Doppler, or another env provider instead of relying on a local `database_id` in `wrangler.jsonc`.

List pending local Wrangler migrations:

```txt
bun run db:migrate:local:dev:list
```

When Better Auth schema changes are needed, regenerate the schema through the existing generator instead of hand-editing generated auth tables:

```txt
bun run better-auth-gen-schema
```

`bun run better-auth-gen-schema` uses the repo's pinned Better Auth CLI devDependency, so schema generation stays reproducible instead of resolving `auth@latest` at runtime.

It does not require local Better Auth or Google OAuth secrets; it falls back to schema-generation-only auth defaults when those values are absent.

## Development

Run the Worker locally:

```txt
bun run dev
```

Wrangler reads the local defaults from `.env` for this workflow.

Typecheck:

```txt
bunx tsc --noEmit
```

Regenerate Cloudflare binding types after changing `wrangler.jsonc` bindings:

```txt
bun run cf-typegen
```

Biome is configured in `biome.json` for formatting, linting, and import organization. `worker-configuration.d.ts` is excluded from linting only.

Deploy to production:

```txt
bun run deploy:production
```

Use `bun run deploy:dev` or `bun run deploy:staging` when you need those environments instead.
