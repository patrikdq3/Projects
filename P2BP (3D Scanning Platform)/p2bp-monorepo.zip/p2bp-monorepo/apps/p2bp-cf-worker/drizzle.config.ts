import "dotenv/config";
import { defineConfig } from "drizzle-kit";

export default defineConfig({
	out: "./drizzle",
	schema: [
		"./src/db/schema/better-auth.schema.ts",
		"./src/db/schema/app.schema.ts",
	],
	dialect: "sqlite",
	driver: "d1-http",
	dbCredentials: {
		accountId: process.env.CLOUDFLARE_ACCOUNT_ID,
		databaseId: process.env.CLOUDFLARE_MAIN_DATABASE_ID,
		token: process.env.CLOUDFLARE_D1_TOKEN,
	},
});
