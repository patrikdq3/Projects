# Agent Notes

- `scripts/check-wrangler-config.ts` is the CI gate behind `bun run ci:check-wrangler-config`.
- The script parses `wrangler.jsonc` as JSONC and rejects committed auto-provisioned KV (`id`, `preview_id`) and D1 (`database_id`, `preview_database_id`) IDs in top-level or named-environment bindings.
- Stable R2 `bucket_name` and `preview_bucket_name` values are allowed; Wrangler structural validation still comes from `bun run cf-typegen`.
