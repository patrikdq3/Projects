const WRANGLER_CONFIG_PATH = "wrangler.jsonc";
const AUTO_PROVISIONED_BINDINGS = [
	{
		section: "kv_namespaces",
		fields: ["id", "preview_id"],
		description: "KV namespace IDs",
	},
	{
		section: "d1_databases",
		fields: ["database_id", "preview_database_id"],
		description: "D1 database IDs",
	},
] as const;

function stripJsonComments(input: string): string {
	let output = "";
	let inString = false;
	let stringQuote = "";
	let escaped = false;
	let inLineComment = false;
	let inBlockComment = false;

	for (let index = 0; index < input.length; index++) {
		const char = input[index];
		const next = input[index + 1];

		if (inLineComment) {
			if (char === "\n" || char === "\r") {
				inLineComment = false;
				output += char;
			}

			continue;
		}

		if (inBlockComment) {
			if (char === "*" && next === "/") {
				inBlockComment = false;
				index++;
			}

			continue;
		}

		if (inString) {
			output += char;

			if (escaped) {
				escaped = false;
				continue;
			}

			if (char === "\\") {
				escaped = true;
				continue;
			}

			if (char === stringQuote) {
				inString = false;
				stringQuote = "";
			}

			continue;
		}

		if (char === "/" && next === "/") {
			inLineComment = true;
			index++;
			continue;
		}

		if (char === "/" && next === "*") {
			inBlockComment = true;
			index++;
			continue;
		}

		if (char === '"' || char === "'") {
			inString = true;
			stringQuote = char;
		}

		output += char;
	}

	return output;
}

function stripTrailingCommas(input: string): string {
	let output = "";
	let inString = false;
	let stringQuote = "";
	let escaped = false;

	for (let index = 0; index < input.length; index++) {
		const char = input[index];

		if (inString) {
			output += char;

			if (escaped) {
				escaped = false;
				continue;
			}

			if (char === "\\") {
				escaped = true;
				continue;
			}

			if (char === stringQuote) {
				inString = false;
				stringQuote = "";
			}

			continue;
		}

		if (char === '"' || char === "'") {
			inString = true;
			stringQuote = char;
			output += char;
			continue;
		}

		if (char === ",") {
			let cursor = index + 1;

			while (cursor < input.length && /\s/.test(input[cursor] ?? "")) {
				cursor++;
			}

			const next = input[cursor];

			if (next === "}" || next === "]") {
				continue;
			}
		}

		output += char;
	}

	return output;
}

function parseJsonc(input: string): unknown {
	return JSON.parse(stripTrailingCommas(stripJsonComments(input)));
}

function formatPath(path: string[]): string {
	if (path.length === 0) {
		return "$";
	}

	return path.reduce((accumulator, segment) => {
		if (/^\d+$/.test(segment)) {
			return `${accumulator}[${segment}]`;
		}

		return `${accumulator}.${segment}`;
	}, "$");
}

function isObject(value: unknown): value is Record<string, unknown> {
	return typeof value === "object" && value !== null && !Array.isArray(value);
}

function findProvisionedBindingLeaks(
	config: unknown,
	basePath: string[] = [],
): string[] {
	if (!isObject(config)) {
		return [];
	}

	const findings = AUTO_PROVISIONED_BINDINGS.flatMap(
		({ section, fields, description }) => {
			const sectionValue = config[section];

			if (!Array.isArray(sectionValue)) {
				return [];
			}

			return sectionValue.flatMap((entry, index) => {
				if (!isObject(entry)) {
					return [];
				}

				return fields.flatMap((field) => {
					if (!(field in entry)) {
						return [];
					}

					return [
						`${formatPath([...basePath, section, String(index), field])} (${description})`,
					];
				});
			});
		},
	);

	const environments = config.env;

	if (isObject(environments)) {
		return findings.concat(
			Object.entries(environments).flatMap(([name, envConfig]) =>
				findProvisionedBindingLeaks(envConfig, [...basePath, "env", name]),
			),
		);
	}

	return findings;
}

async function main() {
	const configContents = await Bun.file(WRANGLER_CONFIG_PATH).text();
	const parsedConfig = parseJsonc(configContents);
	const leakFindings = findProvisionedBindingLeaks(parsedConfig);

	if (leakFindings.length > 0) {
		console.error(
			[
				`${WRANGLER_CONFIG_PATH} contains auto-provisioned Cloudflare binding IDs that should not be committed.`,
				...leakFindings.map((finding) => `- ${finding}`),
			].join("\n"),
		);
		process.exit(1);
	}

	console.log(
		`${WRANGLER_CONFIG_PATH} does not contain leaked auto-provisioned KV or D1 binding IDs.`,
	);
}

void main();
