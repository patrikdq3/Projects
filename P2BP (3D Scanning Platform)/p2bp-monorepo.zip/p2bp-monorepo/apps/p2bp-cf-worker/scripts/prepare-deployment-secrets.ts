import { chmod, mkdir } from "node:fs/promises";
import { dirname } from "node:path";

import wranglerConfig from "../wrangler.jsonc";

type DeploymentEnvironment = "dev" | "staging" | "production";

function isDeploymentEnvironment(
	value: string,
): value is DeploymentEnvironment {
	return value === "dev" || value === "staging" || value === "production";
}

function requiredSecretsFor(environment: DeploymentEnvironment): string[] {
	const environmentConfig =
		environment === "production"
			? wranglerConfig
			: wranglerConfig.env[environment];
	const requiredSecrets = environmentConfig.secrets?.required;

	if (!Array.isArray(requiredSecrets) || requiredSecrets.length === 0) {
		throw new Error(
			`wrangler.jsonc does not define secrets.required for ${environment}.`,
		);
	}

	return requiredSecrets;
}

async function main() {
	const [, , environmentArgument, outputPath] = Bun.argv;

	if (!environmentArgument || !isDeploymentEnvironment(environmentArgument)) {
		throw new Error(
			"Expected deployment environment: dev, staging, or production.",
		);
	}

	if (!outputPath) {
		throw new Error("Expected an output path for the generated secrets file.");
	}

	const serializedSecrets = process.env.GITHUB_SECRETS_JSON;

	if (!serializedSecrets) {
		throw new Error("GITHUB_SECRETS_JSON is required.");
	}

	const availableSecrets = JSON.parse(serializedSecrets) as Record<
		string,
		unknown
	>;
	const requiredSecrets = requiredSecretsFor(environmentArgument);
	const missingSecrets = requiredSecrets.filter((name) => {
		const value = availableSecrets[name];
		return typeof value !== "string" || value.length === 0;
	});

	if (missingSecrets.length > 0) {
		throw new Error(
			`Missing required ${environmentArgument} secrets: ${missingSecrets.join(", ")}`,
		);
	}

	const deploymentSecrets = Object.fromEntries(
		requiredSecrets.map((name) => [name, availableSecrets[name]]),
	);

	await mkdir(dirname(outputPath), { recursive: true });
	await Bun.write(outputPath, `${JSON.stringify(deploymentSecrets)}\n`);
	await chmod(outputPath, 0o600);

	console.log(
		`Prepared ${requiredSecrets.length} ${environmentArgument} Worker secrets from wrangler.jsonc.`,
	);
}

void main();
