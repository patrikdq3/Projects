/**
 * One-time migration that normalizes existing zone scan archives:
 *
 *  1. Flattens the stored zip when it wraps everything in a single
 *     `<id>.scanproject/` directory, re-uploading it so the `.scanproject`
 *     CONTENTS sit at the zip root (matching the newer upload format).
 *  2. Backfills `preview.bin` for archives uploaded before the Worker started
 *     issuing a separate preview upload URL — extracting `preview.bin` from the
 *     zip, uploading it to the derived preview object key, and marking the
 *     preview `uploaded` in D1.
 *
 * It inspects every `uploaded` archive (downloading each zip once) so wrapped
 * archives get flattened even if their preview already exists. The extractor
 * handles both zip layouts: `preview.bin` at the root or `<id>.scanproject/preview.bin`.
 *
 * Run with credentials supplied via env (same names the repo already uses):
 *
 *   bun --env-file=.env.dev run migrate:zone-scan-previews
 *   bun --env-file=.env.dev run migrate:zone-scan-previews -- --dry-run
 *
 * Required env:
 *   CLOUDFLARE_ACCOUNT_ID, CLOUDFLARE_MAIN_DATABASE_ID, CLOUDFLARE_D1_TOKEN,
 *   R2_ACCESS_KEY_ID, R2_SECRET_ACCESS_KEY, R2_BUCKET_NAME
 *
 * The script is idempotent: previews that already exist in R2 are not
 * re-uploaded, and only the D1 pointer is reconciled.
 */
import { AwsClient } from "aws4fetch";
import { unzipSync, zipSync } from "fflate";

type ArchiveRow = {
	id: string;
	zone_id: string;
	object_key: string;
	upload_expires_at: number;
	preview_upload_status: string | null;
};

const SCANPROJECT_DIR_SUFFIX = ".scanproject";

const DRY_RUN = process.argv.includes("--dry-run");

const requireEnv = (name: string): string => {
	const value = process.env[name];
	if (!value) {
		throw new Error(`Missing required environment variable: ${name}`);
	}
	return value;
};

const accountId = requireEnv("CLOUDFLARE_ACCOUNT_ID");
const databaseId = requireEnv("CLOUDFLARE_MAIN_DATABASE_ID");
const d1Token = requireEnv("CLOUDFLARE_D1_TOKEN");
const bucketName = requireEnv("R2_BUCKET_NAME");

const r2 = new AwsClient({
	accessKeyId: requireEnv("R2_ACCESS_KEY_ID"),
	region: "auto",
	secretAccessKey: requireEnv("R2_SECRET_ACCESS_KEY"),
	service: "s3",
});

const r2ObjectUrl = (objectKey: string) => {
	const encodedKey = objectKey
		.split("/")
		.map((segment) => encodeURIComponent(segment))
		.join("/");
	return `https://${accountId}.r2.cloudflarestorage.com/${bucketName}/${encodedKey}`;
};

const d1Query = async <Row>(
	sql: string,
	params: (string | number | null)[] = [],
): Promise<Row[]> => {
	const response = await fetch(
		`https://api.cloudflare.com/client/v4/accounts/${accountId}/d1/database/${databaseId}/query`,
		{
			body: JSON.stringify({ params, sql }),
			headers: {
				authorization: `Bearer ${d1Token}`,
				"content-type": "application/json",
			},
			method: "POST",
		},
	);

	const payload = (await response.json()) as {
		errors?: { message: string }[];
		result?: { results: Row[] }[];
		success: boolean;
	};

	if (!response.ok || !payload.success) {
		const message =
			payload.errors?.map((error) => error.message).join("; ") ??
			`HTTP ${response.status}`;
		throw new Error(`D1 query failed: ${message}`);
	}

	return payload.result?.[0]?.results ?? [];
};

const previewObjectKeyFor = (objectKey: string) =>
	objectKey.replace(/\.zip$/, ".preview.bin");

const previewExistsInR2 = async (previewObjectKey: string) => {
	const response = await r2.fetch(r2ObjectUrl(previewObjectKey), {
		method: "HEAD",
	});
	if (response.status === 404) return false;
	if (!response.ok) {
		throw new Error(
			`Unexpected R2 HEAD status ${response.status} for ${previewObjectKey}`,
		);
	}
	return Number(response.headers.get("content-length") ?? "0") > 0;
};

const downloadZip = async (objectKey: string): Promise<Uint8Array> => {
	const response = await r2.fetch(r2ObjectUrl(objectKey));
	if (!response.ok) {
		throw new Error(
			`Failed to download zip ${objectKey}: HTTP ${response.status}`,
		);
	}
	return new Uint8Array(await response.arrayBuffer());
};

// The stored zip may contain either the `.scanproject` contents at the root
// (flat) or the whole `<id>.scanproject/` folder. Match `preview.bin` in both.
const extractPreviewFromEntries = (
	entries: Record<string, Uint8Array>,
): Uint8Array | null => {
	const previewName = Object.keys(entries).find(
		(name) => name === "preview.bin" || name.endsWith("/preview.bin"),
	);
	return previewName ? entries[previewName] : null;
};

// If every file in the zip lives under a single `<id>.scanproject/` directory,
// return a re-zipped archive with that wrapper stripped (contents at the root).
// Returns null when the archive is already flat / not wrapped (no change needed).
const flattenScanProjectEntries = (
	entries: Record<string, Uint8Array>,
): Uint8Array | null => {
	const fileNames = Object.keys(entries).filter((name) => !name.endsWith("/"));
	if (fileNames.length === 0) return null;

	const topLevelSegments = new Set(fileNames.map((name) => name.split("/")[0]));
	if (topLevelSegments.size !== 1) return null;

	const [prefix] = topLevelSegments;
	// Require an actual `<id>.scanproject/...` directory, not a root file that
	// merely happens to be named `<id>.scanproject`.
	if (
		!prefix.endsWith(SCANPROJECT_DIR_SUFFIX) ||
		!fileNames.some((name) => name.startsWith(`${prefix}/`))
	) {
		return null;
	}

	const flattened: Record<string, Uint8Array> = {};
	for (const name of fileNames) {
		const relativeName = name.slice(prefix.length + 1);
		if (relativeName.length > 0) flattened[relativeName] = entries[name];
	}
	return zipSync(flattened);
};

const uploadObject = async (
	objectKey: string,
	bytes: Uint8Array,
	contentType: string,
): Promise<void> => {
	const response = await r2.fetch(r2ObjectUrl(objectKey), {
		body: bytes,
		headers: { "content-type": contentType },
		method: "PUT",
	});
	if (!response.ok) {
		throw new Error(`Failed to upload ${objectKey}: HTTP ${response.status}`);
	}
};

const markPreviewUploaded = async (
	archive: ArchiveRow,
	previewObjectKey: string,
): Promise<void> => {
	await d1Query(
		`UPDATE zone_scan_archives
		 SET preview_object_key = ?,
		     preview_upload_status = 'uploaded',
		     preview_upload_expires_at = ?,
		     preview_uploaded_at = unixepoch()
		 WHERE id = ?`,
		[previewObjectKey, archive.upload_expires_at, archive.id],
	);
};

const main = async () => {
	console.log(
		`Normalizing zone scan archives (flatten .scanproject + backfill previews)${
			DRY_RUN ? " (dry run)" : ""
		}...`,
	);

	// Every uploaded zip is inspected so wrapped `.scanproject` archives can be
	// flattened, not just the ones still missing a preview.
	const archives = await d1Query<ArchiveRow>(
		`SELECT id, zone_id, object_key, upload_expires_at, preview_upload_status
		 FROM zone_scan_archives
		 WHERE upload_status = 'uploaded'`,
	);

	console.log(`Found ${archives.length} uploaded archive(s).`);

	let flattened = 0;
	let previewUploaded = 0;
	let previewReconciled = 0;
	let previewMissing = 0;
	let failed = 0;

	for (const archive of archives) {
		const previewObjectKey = previewObjectKeyFor(archive.object_key);
		const previewDone = archive.preview_upload_status === "uploaded";
		const label = `${archive.id} (${archive.object_key})`;
		try {
			const entries = unzipSync(await downloadZip(archive.object_key));

			// 1. Flatten a wrapped `<id>.scanproject/` archive in place.
			const flattenedZip = flattenScanProjectEntries(entries);
			if (flattenedZip) {
				if (DRY_RUN) {
					console.log(`• ${label}: would flatten .scanproject wrapper`);
				} else {
					await uploadObject(
						archive.object_key,
						flattenedZip,
						"application/zip",
					);
					console.log(`• ${label}: flattened .scanproject wrapper`);
				}
				flattened += 1;
			}

			// 2. Backfill the preview if it isn't already uploaded.
			if (previewDone) continue;

			if (await previewExistsInR2(previewObjectKey)) {
				if (DRY_RUN) {
					console.log(`• ${label}: preview exists; would reconcile pointer`);
				} else {
					await markPreviewUploaded(archive, previewObjectKey);
					console.log(`• ${label}: preview already in R2; pointer reconciled`);
				}
				previewReconciled += 1;
				continue;
			}

			const previewBytes = extractPreviewFromEntries(entries);
			if (!previewBytes) {
				console.warn(
					`• ${label}: no preview.bin found in zip; skipping preview`,
				);
				previewMissing += 1;
				continue;
			}

			if (DRY_RUN) {
				console.log(
					`• ${label}: would upload preview (${previewBytes.length} bytes)`,
				);
			} else {
				await uploadObject(
					previewObjectKey,
					previewBytes,
					"application/octet-stream",
				);
				await markPreviewUploaded(archive, previewObjectKey);
				console.log(
					`• ${label}: preview uploaded (${previewBytes.length} bytes)`,
				);
			}
			previewUploaded += 1;
		} catch (error) {
			failed += 1;
			console.error(
				`• ${label}: FAILED — ${error instanceof Error ? error.message : String(error)}`,
			);
		}
	}

	console.log(
		`\nDone. processed=${archives.length} flattened=${flattened} previewUploaded=${previewUploaded} previewReconciled=${previewReconciled} previewMissing=${previewMissing} failed=${failed}`,
	);

	if (failed > 0) process.exitCode = 1;
};

main().catch((error) => {
	console.error(error);
	process.exit(1);
});
