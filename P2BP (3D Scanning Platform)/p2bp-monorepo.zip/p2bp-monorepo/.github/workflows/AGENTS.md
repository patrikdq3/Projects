# Agent Notes

- `p2bp-cf-worker-ci.yml` runs Biome, Bun tests, TypeScript, Wrangler policy, and generated-file verification from `apps/p2bp-cf-worker` with Worker-shaped placeholder env vars and bindings (`BETTER_AUTH_*`, `CLOUDFLARE_*`, `DB`).
- `p2bp-cf-worker-deploy-dev.yml` runs after `P2BP Worker CI` succeeds for a push to `main`; `p2bp-cf-worker-deploy-staging.yml` runs after the dev workflow succeeds; and `p2bp-cf-worker-deploy-production.yml` remains a manual `workflow_dispatch` promotion. All three use `.github/actions/deploy-p2bp-worker`, which derives the uploaded Worker secrets from the selected environment's `secrets.required` list in `wrangler.jsonc` and then runs the remote D1 migration.
- `scanner-consolidator-ci.yml` preserves the app's change classifier and runs repository, Swift tooling, build, and test checks from `apps/scanner-consolidator`; action cache and artifact paths must remain workspace-root-relative because those actions do not inherit `defaults.run.working-directory`.
- `scanner-consolidator-ui-launch-tests.yml` runs the scheduled/manual UI launch suite from `apps/scanner-consolidator`.
- `p2bp-postprocessing-ci.yml` installs the locked uv environment and runs the Postprocessing Ruff and pytest targets through Nx.
