const app_name = 'wattareyoudoing.us';

export default app_name;