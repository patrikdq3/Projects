//import React from 'react';

import Register from '../components/Register.tsx';

const RegisterPage = () =>
{

    return(
      <div>
        <Register />
      </div>
    );
};

export default RegisterPage;

