//import React from 'react';

import Login from '../components/Login.tsx';

const LoginPage = () =>
{

    return(
      <div>
        <Login />
      </div>
    );
};

export default LoginPage;

