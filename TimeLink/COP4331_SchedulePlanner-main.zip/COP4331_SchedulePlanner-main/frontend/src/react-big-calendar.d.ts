// src/react-big-calendar.d.ts
declare module 'react-big-calendar';
