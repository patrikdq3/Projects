# Contacts Manager Web App

<img src="https://github.com/NoahAlbert/POOSD-Group8/blob/main/docs/Capture.PNG">

## Contributors:

- [Nicholas Piazza](https://github.com/NickPiazza21) - Project Manager
- [Noah Albert](https://github.com/NoahAlbert) - mySQL/Database
- [Andrew Martin](https://github.com/asjm223) - Frontend
- [Joe Hoang](https://github.com/joehoang13) - Frontend
- [Jason Torres](https://github.com/JaceDaDorito) - API
- [Patrik De Quevedo](https://github.com/patrikdq3) - API
